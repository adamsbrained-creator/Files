package ix.app.files.data

import android.content.Context

/** What the user picked in the menu, remembered on the device. */
class Settings(
    val grid: Boolean,
    val showHidden: Boolean,
    val sort: SortSpec,
    val theme: ThemeMode,
    /** How many days deleted things wait in the Trash. Zero means they go as soon as Undo is over. */
    val trashDays: Int,
)

class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): Settings {
        val field = prefs.getString(KEY_SORT_FIELD, null)
            ?.let { name -> SortField.entries.firstOrNull { it.name == name } }
            ?: SortField.Modified
        val ascending = prefs.getBoolean(KEY_SORT_ASCENDING, field.defaultAscending)
        return Settings(
            grid = prefs.getBoolean(KEY_GRID, false),
            showHidden = prefs.getBoolean(KEY_HIDDEN, false),
            sort = SortSpec(field, ascending),
            theme = prefs.getString(KEY_THEME, null)
                ?.let { name -> ThemeMode.entries.firstOrNull { it.name == name } }
                ?: ThemeMode.System,
            trashDays = prefs.getInt(KEY_TRASH_DAYS, DEFAULT_TRASH_DAYS),
        )
    }

    fun saveTheme(theme: ThemeMode) {
        prefs.edit().putString(KEY_THEME, theme.name).apply()
    }

    fun saveTrashDays(days: Int) {
        prefs.edit().putInt(KEY_TRASH_DAYS, days).apply()
    }

    fun saveGrid(grid: Boolean) {
        prefs.edit().putBoolean(KEY_GRID, grid).apply()
    }

    fun saveShowHidden(show: Boolean) {
        prefs.edit().putBoolean(KEY_HIDDEN, show).apply()
    }

    fun saveSort(sort: SortSpec) {
        prefs.edit()
            .putString(KEY_SORT_FIELD, sort.field.name)
            .putBoolean(KEY_SORT_ASCENDING, sort.ascending)
            .apply()
    }

    private companion object {
        const val KEY_GRID = "grid"
        const val KEY_HIDDEN = "show_hidden"
        const val KEY_SORT_FIELD = "sort_field"
        const val KEY_SORT_ASCENDING = "sort_ascending"
        const val KEY_THEME = "theme"
        const val KEY_TRASH_DAYS = "trash_days"
        const val DEFAULT_TRASH_DAYS = 30
    }
}
