package ix.app.files.ui.home

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ix.app.files.R
import ix.app.files.cast.CastHub
import ix.app.files.cast.CastItem
import ix.app.files.cast.CastMedia
import ix.app.files.data.ArchiveFormat
import ix.app.files.data.FolderEditTarget
import ix.app.files.data.FileItem
import ix.app.files.data.HomeTab
import ix.app.files.data.PictureLoader
import ix.app.files.data.TextFiles
import ix.app.files.data.SheetAnchor
import ix.app.files.data.StorageAccess
import ix.app.files.data.StorageInfo
import ix.app.files.ui.cast.CastBar
import ix.app.files.ui.cast.CastSheet
import ix.app.files.ui.cast.castItemsOf
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.openFile
import ix.app.files.util.shareFiles
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

/** Why the unlock prompt was opened, so the right thing happens once it succeeds. */
private enum class UnlockPurpose { Open, MoveIn }

/** Fling speed (px per second) that counts as a "flick" when letting go of the sheet. */
private const val SHEET_FLING_VELOCITY = 700f

@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val textDoc by viewModel.textDoc.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val storage = remember { StorageInfo.read() }
    val rootPath = remember { StorageAccess.root().absolutePath }
    val requestAccess = rememberAccessRequester(onResult = viewModel::refreshAccess)
    val importPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris -> viewModel.importFiles(uris) }
    // While items wait to be pasted, rows only open things: selecting is switched off.
    val pasting = state.clip != null
    val selection = remember(state.selected, pasting, viewModel) {
        val ignore: (String) -> Unit = { _ -> }
        Selection(state.selected, if (pasting) ignore else viewModel::toggleSelect)
    }

    // Short messages from the view model, such as "Could not rename".
    LaunchedEffect(viewModel) {
        viewModel.events.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    // Notes from the cast engine, such as "Lost connection to Xbox".
    LaunchedEffect(Unit) {
        CastHub.messages.collect { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
    }
    // What is waiting for a device to be picked in the "Cast to" sheet. Null while the sheet is closed.
    var castRequest by remember { mutableStateOf<CastRequest?>(null) }
    val askCast: (List<CastItem>, Int) -> Unit = { items, start ->
        if (items.isEmpty()) {
            Toast.makeText(context, R.string.cast_nothing, Toast.LENGTH_SHORT).show()
        } else {
            castRequest = CastRequest(items, start.coerceIn(0, items.lastIndex))
        }
    }
    // Looking at the extension only, so a long selection costs nothing to check on every frame.
    val canCastSelection = remember(state.selected) {
        state.selected.any { CastMedia.kindOf(File(it).extension) != null }
    }

    // Coming back from the "All files access" settings page lands here.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshAccess() }

    // Private locks itself when the app has been away for a while.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { viewModel.onBackgrounded() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { viewModel.onForegrounded() }

    // Opens a file in another app. Files in Private are locked, so an unlocked copy is made first.
    val openExternally: (FileItem) -> Unit = { file ->
        if (viewModel.isPrivatePath(file.path)) {
            viewModel.withReadableCopies(listOf(file.path)) { paths -> openFile(context, paths.first()) }
        } else {
            openFile(context, file.path)
        }
    }
    // Pictures and text open in the app's own viewers. Pictures come with the others of the list they were tapped in.
    // An archive (zip, 7z, rar, tar and the like) opens straight into the app's archive browser. Unpacking it,
    // moving it and so on are in the menu that opens when it is pressed and held.
    val openOrAsk: (FileItem) -> Unit = { file ->
        if (!viewModel.isPrivatePath(file.path) && ArchiveFormat.of(File(file.path).name) != null) {
            viewModel.openZip(file.path)
        } else if (TextFiles.viewable(file)) {
            viewModel.openText(file.path)
        } else if (PictureLoader.viewable(file)) {
            val around = picturesAround(state).filter { PictureLoader.viewable(it) }
            val index = around.indexOfFirst { it.path == file.path }
            if (index >= 0) viewModel.openViewer(around, index) else viewModel.openViewer(listOf(file), 0)
        } else {
            openExternally(file)
        }
    }

    var unlockPurpose by remember { mutableStateOf(UnlockPurpose.Open) }
    var menuOpen by remember { mutableStateOf(false) }
    val requestUnlock = rememberUnlockRequester(
        title = stringResource(R.string.unlock_title),
        subtitle = stringResource(R.string.unlock_subtitle),
        onResult = { ok ->
            if (ok) {
                viewModel.unlockPrivate()
                when (unlockPurpose) {
                    UnlockPurpose.Open -> viewModel.openPrivate()
                    UnlockPurpose.MoveIn -> viewModel.moveSelectedToPrivate()
                }
            }
        },
    )
    val onUnlockClick = {
        unlockPurpose = UnlockPurpose.Open
        requestUnlock()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(IxColors.Background),
    ) {
        HomeContent(
            state = state,
            viewModel = viewModel,
            storage = storage,
            onRequestAccess = requestAccess,
            onFileClick = openOrAsk,
            selection = selection,
            onUnlock = onUnlockClick,
            onMenu = { menuOpen = true },
            onImport = { importPicker.launch(arrayOf("*/*")) },
        )

        if (state.reportOpen) {
            StorageScreen(
                storage = storage,
                report = state.report,
                scanning = state.scanning,
                favorites = state.favorites,
                selection = selection,
                onBack = viewModel::closeReport,
                onOpenCategory = viewModel::openCategory,
                onFileClick = openOrAsk,
            )
        }

        // Below the zip screen and the browser, so a zip tapped in here can open on top of it.
        if (state.dupOpen) {
            DuplicatesScreen(
                groups = state.dupGroups,
                loading = state.dupLoading,
                scanning = state.scanning,
                rootPath = rootPath,
                favorites = state.favorites,
                selection = selection,
                onBack = viewModel::closeDuplicates,
                onSelectExtras = viewModel::selectDuplicateExtras,
                onFileClick = openOrAsk,
            )
        }

        if (state.cleanOpen) {
            CleanerScreen(
                groups = state.cleanGroups,
                loading = state.cleanLoading,
                scanning = state.scanning,
                rootPath = rootPath,
                favorites = state.favorites,
                selection = selection,
                onBack = viewModel::closeCleaner,
                onToggleGroup = viewModel::toggleGroup,
                onFileClick = openOrAsk,
                onFolderClick = { viewModel.openFolder(it.path) },
            )
        }

        if (state.appsOpen) {
            AppsScreen(
                apps = state.apps,
                loading = state.appsLoading,
                onBack = viewModel::closeApps,
                onBackup = viewModel::backupApps,
            )
        }

        if (state.trashOpen) {
            TrashScreen(
                trashItems = state.trashItems,
                loading = state.trashLoading,
                keepDays = state.trashDays,
                rootPath = rootPath,
                onBack = viewModel::closeTrash,
                onRestore = viewModel::restoreTrash,
                onDelete = viewModel::deleteTrashForever,
                onEmpty = viewModel::emptyTrash,
                onKeepDays = viewModel::setTrashDays,
            )
        }

        val open = state.openCategory
        if (open != null) {
            CategoryScreen(
                category = open,
                style = state.folderStyles[open],
                files = state.openFiles,
                count = state.counts[open] ?: 0,
                sort = state.sort,
                grid = state.grid,
                scanning = state.scanning,
                onBack = viewModel::closeCategory,
                onSortSelected = viewModel::selectSort,
                onFileClick = openOrAsk,
                favorites = state.favorites,
                selection = selection,
            )
        }

        BackHandler(enabled = state.arrangingHome) { viewModel.stopArranging() }

        if (state.newFilePrompt) {
            NameDialog(
                title = stringResource(R.string.canvas_new_file_title),
                initialName = "Untitled.txt",
                confirmLabel = stringResource(R.string.canvas_new_file_confirm),
                onConfirm = viewModel::createTextFile,
                onDismiss = { viewModel.promptNewFile(false) },
            )
        }

        state.folderEditor?.let { target ->
            FolderEditorHost(target = target, state = state, viewModel = viewModel)
        }

        val browsing = state.browserPath
        if (browsing != null) {
            val inPrivate = viewModel.isPrivatePath(browsing)
            BrowserScreen(
                path = browsing,
                rootPath = if (inPrivate) viewModel.privateRootPath else rootPath,
                rootLabel = stringResource(if (inPrivate) R.string.private_title else R.string.browser_root),
                folders = state.browserFolders,
                files = state.browserFiles,
                loading = state.browserLoading,
                failed = state.browserFailed,
                sort = state.sort,
                grid = state.grid,
                favorites = state.favorites,
                selection = selection,
                clip = state.clip,
                onUp = viewModel::browserUp,
                onOpenFolder = viewModel::openFolder,
                onSortSelected = viewModel::selectSort,
                onFileClick = openOrAsk,
                onNewFolder = viewModel::createFolder,
                onPaste = viewModel::pasteHere,
                onCancelClip = viewModel::cancelClip,
                onRefresh = viewModel::refreshBrowser,
            )
        }

        val zipOpen = state.zipPath
        if (zipOpen != null) {
            ZipScreen(
                zipName = File(zipOpen).name,
                inner = state.zipInner,
                folders = state.zipFolders,
                files = state.zipFiles,
                loading = state.zipLoading,
                failed = state.zipFailed,
                grid = state.grid,
                onUp = viewModel::zipUp,
                onOpenFolder = viewModel::openZipFolder,
                onOpenFile = { inner -> viewModel.previewZipEntry(inner) { path -> openFile(context, path) } },
                onExtract = viewModel::extractOpenZip,
            )
        }

        val openText = textDoc
        if (openText != null) {
            TextScreen(
                doc = openText,
                initialDraft = viewModel::currentDraft,
                onClose = viewModel::closeText,
                onEdit = viewModel::startEditing,
                onEdited = viewModel::onTextEdited,
                onSave = viewModel::saveText,
                onDiscard = viewModel::discardEdits,
                onStopEditing = viewModel::stopEditing,
                onOpenWith = {
                    if (viewModel.isPrivatePath(openText.path)) {
                        viewModel.withReadableCopies(listOf(openText.path)) { paths -> openFile(context, paths.first()) }
                    } else {
                        openFile(context, openText.path)
                    }
                },
            )
        }

        // The remote for whatever is being cast. It lifts itself above the selection bar and the Undo bar.
        CastBar(raised = state.selected.isNotEmpty() || state.undo != null)

        // Above every screen, but below the Undo bar, so a delete made in here can still be taken back.
        if (state.viewerImages.isNotEmpty()) {
            ImageViewer(
                images = state.viewerImages,
                startIndex = state.viewerIndex,
                isPrivate = { viewModel.isPrivatePath(it.path) },
                onClose = viewModel::closeViewer,
                onShare = { file ->
                    viewModel.withReadableCopies(listOf(file.path)) { paths -> shareFiles(context, paths) }
                },
                onOpenWith = openExternally,
                onDelete = { file -> viewModel.deleteFromViewer(file.path) },
                onCast = { shown, index ->
                    // Pictures in Private are locked files and never leave the phone.
                    val items = shown.filterNot { viewModel.isPrivatePath(it.path) }
                        .mapNotNull { CastMedia.itemFor(File(it.path)) }
                    val chosen = shown.getOrNull(index)?.path
                    askCast(items, items.indexOfFirst { it.path == chosen }.coerceAtLeast(0))
                },
            )
        }

        val undoNotice = state.undo
        if (undoNotice != null) {
            UndoBar(notice = undoNotice, onUndo = viewModel::undoLast, onDismiss = viewModel::finishUndo)
        }

        // Added last, so it sits on top and Back leaves selection mode before anything else.
        if (state.selected.isNotEmpty()) {
            SelectionOverlay(
                paths = state.selected,
                allFavorite = state.selected.all { it in state.favorites },
                inPrivate = state.selected.any { viewModel.isPrivatePath(it) },
                canPinHome = state.selected.size == 1 && state.selected.first().let {
                    !viewModel.isPrivatePath(it) && java.io.File(it).isDirectory
                },
                pinnedHome = state.selected.size == 1 &&
                    state.customFolders.any { it.path == state.selected.first() },
                onPinHome = viewModel::toggleHomeFolderSelected,
                canCast = canCastSelection,
                onCast = {
                    askCast(castItemsOf(state.selected), 0)
                    viewModel.clearSelection()
                },
                onClear = viewModel::clearSelection,
                onSelectAll = {
                    // Everything on the screen the user is looking at.
                    val visible: List<String> = when {
                        state.dupOpen -> state.dupGroups.flatMap { group -> group.files.map { it.path } }
                        state.cleanOpen -> state.cleanGroups.flatMap { group -> group.paths }
                        state.browserPath != null ->
                            state.browserFolders.map { it.path } + state.browserFiles.map { it.path }
                        state.openCategory != null -> state.openFiles.map { it.path }
                        state.reportOpen -> state.report?.largest.orEmpty().map { it.path }
                        state.searching ->
                            state.results.folders.map { it.path } + state.results.files.map { it.path }
                        state.tab == HomeTab.Favorites ->
                            state.favoriteFolders.map { it.path } + state.favoriteFiles.map { it.path }
                        else -> state.recent.map { it.path }
                    }
                    viewModel.selectAll(visible)
                },
                onCopy = { viewModel.startClip(move = false) },
                onMove = { viewModel.startClip(move = true) },
                onShare = {
                    viewModel.withReadableCopies(state.selected.toList()) { paths -> shareFiles(context, paths) }
                    viewModel.clearSelection()
                },
                onFavorite = viewModel::toggleFavoriteSelected,
                onCompress = viewModel::compressSelected,
                onExtract = viewModel::extractSelected,
                onMoveToPrivate = {
                    if (state.privateUnlocked) {
                        viewModel.moveSelectedToPrivate()
                    } else {
                        unlockPurpose = UnlockPurpose.MoveIn
                        requestUnlock()
                    }
                },
                onRename = viewModel::renameSelected,
                onRenameMany = viewModel::renameBatch,
                onOpenAsText = { path -> viewModel.openText(path) },
                onDelete = viewModel::deleteSelected,
            )
        }

        val pendingCast = castRequest
        if (pendingCast != null) {
            CastSheet(
                items = pendingCast.items,
                startIndex = pendingCast.start,
                onDismiss = { castRequest = null },
            )
        }

        if (menuOpen) {
            MenuDialog(
                grid = state.grid,
                freeform = state.homeFreeform,
                onFreeformChange = viewModel::setHomeFreeform,
                showHidden = state.showHidden,
                onGridChange = viewModel::setGrid,
                onShowHiddenChange = viewModel::setShowHidden,
                themeMode = themeMode,
                onThemeChange = viewModel::setThemeMode,
                onStorage = {
                    menuOpen = false
                    viewModel.openReport()
                },
                onDuplicates = {
                    menuOpen = false
                    viewModel.openDuplicates()
                },
                onCleaner = {
                    menuOpen = false
                    viewModel.openCleaner()
                },
                onApps = {
                    menuOpen = false
                    viewModel.openApps()
                },
                onTrash = {
                    menuOpen = false
                    viewModel.openTrash()
                },
                onDismiss = { menuOpen = false },
            )
        }

        if (state.busy) {
            BusyOverlay(
                label = stringResource(state.busyLabel),
                progress = state.busyProgress,
                cancellable = state.busyCancellable,
                onCancel = { viewModel.cancelBusyJob() },
            )
        }
    }
}

/**
 * Covers the screen while a copy, move, zip or delete runs, so nothing can be tapped halfway.
 * With a [progress] it draws a bar; with [cancellable] it offers Cancel, and Back does the same.
 */
@Composable
private fun BusyOverlay(label: String, progress: Float?, cancellable: Boolean, onCancel: () -> Unit) {
    BackHandler { if (cancellable) onCancel() }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .width(280.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(IxColors.Sheet)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (progress == null) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = IxColors.TextPrimary,
                        strokeWidth = 2.5.dp,
                    )
                }
                Text(
                    text = label,
                    color = IxColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                )
                if (progress != null) {
                    Text(
                        text = "${(progress * 100f).toInt()}%",
                        color = IxColors.TextSecondary,
                        fontSize = 14.sp,
                    )
                }
            }
            if (progress != null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(IxColors.Chip),
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress.coerceIn(0f, 1f))
                            .background(IxColors.Accent),
                    )
                }
            }
            if (cancellable) {
                Text(
                    text = stringResource(R.string.cancel),
                    color = IxColors.TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .align(Alignment.End)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(role = Role.Button, onClick = onCancel)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun HomeContent(
    state: HomeState,
    viewModel: HomeViewModel,
    storage: StorageInfo,
    onRequestAccess: () -> Unit,
    onFileClick: (ix.app.files.data.FileItem) -> Unit,
    selection: Selection,
    onUnlock: () -> Unit,
    onMenu: () -> Unit,
    onImport: () -> Unit,
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val anchor = state.sheet

    // Height of everything above the sheet when it is half open: the header block plus the
    // folder grid of the All tab. The half-open sheet starts right below it, so the layout fits
    // any screen size. The grid height is measured on the All tab and remembered, because the
    // Favorites tab fills the whole screen and must not move the sheet.
    var headerPx by remember { mutableIntStateOf(0) }
    var gridPx by rememberSaveable { mutableStateOf(0) }
    val topContentPx = if (headerPx > 0 && gridPx > 0) headerPx + gridPx else 0

    // Back clears the search first, if there is one.
    val searching = state.searching
    BackHandler(
        enabled = (searching || state.filtersOpen) && state.openCategory == null && state.browserPath == null,
    ) {
        viewModel.clearSearch()
    }

    // Back closes the sheet step by step: open, then half-open, then hidden.
    BackHandler(enabled = anchor != SheetAnchor.Hidden && state.openCategory == null && state.browserPath == null) {
        viewModel.setSheet(if (anchor == SheetAnchor.Expanded) SheetAnchor.Collapsed else SheetAnchor.Hidden)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // The sheet's top edge, in pixels from the top of the screen. Bigger means lower.
        val hiddenPx = with(density) { maxHeight.toPx() }
        val statusPx = WindowInsets.statusBars.getTop(density).toFloat()
        val expandedPx = statusPx + with(density) { 128.dp.toPx() }
        val collapsedPx = (topContentPx + with(density) { 16.dp.toPx() })
            .coerceAtMost(hiddenPx - with(density) { 280.dp.toPx() })
            .coerceAtLeast(expandedPx + 1f)

        val sheetTop = remember { Animatable(hiddenPx) }

        // Move the sheet whenever the wanted position changes (buttons, Back, or a finished drag).
        LaunchedEffect(anchor, hiddenPx, expandedPx, collapsedPx, topContentPx > 0) {
            val target = when (anchor) {
                SheetAnchor.Hidden -> hiddenPx
                SheetAnchor.Collapsed -> collapsedPx
                SheetAnchor.Expanded -> expandedPx
            }
            if (anchor == SheetAnchor.Hidden || topContentPx > 0) sheetTop.animateTo(target)
        }

        val dragState = rememberDraggableState { delta ->
            scope.launch { sheetTop.snapTo((sheetTop.value + delta).coerceIn(expandedPx, hiddenPx)) }
        }
        val dragModifier = Modifier.draggable(
            state = dragState,
            orientation = Orientation.Vertical,
            onDragStopped = { velocity ->
                val stops = listOf(
                    SheetAnchor.Expanded to expandedPx,
                    SheetAnchor.Collapsed to collapsedPx,
                    SheetAnchor.Hidden to hiddenPx,
                )
                val here = sheetTop.value
                val next = when {
                    // Flick up: the next stop above. Flick down: the next stop below.
                    velocity < -SHEET_FLING_VELOCITY -> stops.lastOrNull { it.second < here - 1f } ?: stops.first()
                    velocity > SHEET_FLING_VELOCITY -> stops.firstOrNull { it.second > here + 1f } ?: stops.last()
                    else -> stops.minBy { abs(it.second - here) }
                }
                viewModel.setSheet(next.first)
                sheetTop.animateTo(next.second)
            },
        )

        // Everything above the sheet
        Column(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { if (!searching) headerPx = it.height }
                    .statusBarsPadding()
                    .padding(top = 12.dp),
            ) {
                HomeHeader(
                    storage = storage,
                    onStorageClick = { if (state.hasAccess) viewModel.openStorage() else onRequestAccess() },
                )
                Spacer(Modifier.height(12.dp))
                SearchRow(
                    externalQuery = state.query,
                    onQueryChange = viewModel::search,
                    onMenuClick = onMenu,
                    onFiltersClick = viewModel::toggleFilters,
                    filtersOpen = state.filtersOpen,
                )
                if (state.filtersOpen) {
                    Spacer(Modifier.height(10.dp))
                    SearchFilterRow(
                        filter = state.filter,
                        onChange = viewModel::setFilter,
                        saved = state.savedSearches,
                        canSave = searching && state.savedSearches.none {
                            it.query == state.query.trim() && it.filter == state.filter
                        },
                        onSave = viewModel::saveCurrentSearch,
                        onApply = viewModel::applySavedSearch,
                        onDelete = viewModel::deleteSavedSearch,
                        suggestedName = state.query.trim(),
                    )
                }
                if (!searching) {
                    Spacer(Modifier.height(6.dp))
                    HomeTabs(selected = state.tab, onSelect = viewModel::selectTab)
                }
                Spacer(Modifier.height(16.dp))
            }

            if (searching) {
                SearchResultsList(
                    results = state.results,
                    scanning = state.scanning,
                    grid = state.grid,
                    favorites = state.favorites,
                    selection = selection,
                    rootPath = StorageAccess.root().absolutePath,
                    onFolderClick = { viewModel.openFolder(it.path) },
                    onFileClick = onFileClick,
                    modifier = Modifier.weight(1f),
                )
            } else when (state.tab) {
                HomeTab.All -> {
                    val freeform = state.homeFreeform && state.hasAccess
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .then(if (freeform) Modifier.weight(1f) else Modifier)
                            .onSizeChanged {
                                // On the canvas the Recent sheet, when pulled up, covers the lower part of it.
                                gridPx = if (freeform) (it.height * 0.62f).toInt() else it.height
                            },
                    ) {
                        if (freeform) {
                            FreeformCanvas(
                                counts = state.counts,
                                scanning = state.scanning,
                                styles = state.folderStyles,
                                customFolders = state.customFolders,
                                refreshKey = state.browserPath,
                                order = state.homeOrder,
                                spots = state.homeSpots,
                                onSpotChange = viewModel::setHomeSpot,
                                onCategoryClick = viewModel::openCategory,
                                onCategoryLongClick = { viewModel.openFolderEditor(FolderEditTarget.Builtin(it)) },
                                onCustomClick = { viewModel.openFolder(it.path) },
                                onCustomLongClick = { viewModel.openFolderEditor(FolderEditTarget.Custom(it.id)) },
                                onNewFolder = viewModel::startNewFolderAt,
                                onNewFile = { viewModel.promptNewFile(true) },
                                onImport = onImport,
                                modifier = Modifier.fillMaxSize(),
                            )
                        } else if (state.hasAccess) {
                            CategoryGrid(
                                counts = state.counts,
                                scanning = state.scanning,
                                styles = state.folderStyles,
                                customFolders = state.customFolders,
                                refreshKey = state.browserPath,
                                order = state.homeOrder,
                                arranging = state.arrangingHome,
                                onOrderChange = viewModel::setHomeOrder,
                                onArrangeDone = viewModel::stopArranging,
                                onCategoryClick = viewModel::openCategory,
                                onCategoryLongClick = { viewModel.openFolderEditor(FolderEditTarget.Builtin(it)) },
                                onCustomClick = { viewModel.openFolder(it.path) },
                                onCustomLongClick = { viewModel.openFolderEditor(FolderEditTarget.Custom(it.id)) },
                                onAddClick = { viewModel.openFolderEditor(FolderEditTarget.New) },
                            )
                        } else {
                            AccessCard(onRequestAccess)
                        }
                    }
                }

                HomeTab.Favorites ->
                    FavoritesList(
                        folders = state.favoriteFolders,
                        files = state.favoriteFiles,
                        onFolderClick = { viewModel.openFolder(it.path) },
                        onFileClick = onFileClick,
                        grid = state.grid,
                        favorites = state.favorites,
                        selection = selection,
                        modifier = Modifier.weight(1f),
                    )

                HomeTab.Private ->
                    if (state.privateUnlocked) {
                        PrivateUnlocked(
                            count = state.privateCount,
                            onOpen = viewModel::openPrivate,
                            onLock = viewModel::lockPrivate,
                        )
                    } else {
                        PrivateLocked(onUnlock)
                    }
            }
        }

        // While the sheet is hidden, a strip along the bottom edge listens for the swipe up.
        // It sits above the system gesture area and has a very faint handle as the only hint.
        if (anchor == SheetAnchor.Hidden && !searching) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(72.dp)
                    .then(dragModifier),
            ) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(IxColors.Handle.copy(alpha = 0.6f)),
                )
            }
        }

        // The sheet keeps its bottom on the screen edge and grows upward as its top edge moves.
        RecentSheet(
            files = state.recent,
            sort = state.sort,
            expanded = anchor == SheetAnchor.Expanded,
            onToggleExpanded = {
                viewModel.setSheet(
                    if (anchor == SheetAnchor.Expanded) SheetAnchor.Collapsed else SheetAnchor.Expanded,
                )
            },
            onSortSelected = viewModel::selectSort,
            onFileClick = onFileClick,
            favorites = state.favorites,
            selection = selection,
            dragModifier = dragModifier,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .layout { measurable, constraints ->
                    val height = (hiddenPx - sheetTop.value).roundToInt().coerceAtLeast(0)
                    val placeable = measurable.measure(
                        constraints.copy(minHeight = height, maxHeight = height),
                    )
                    layout(placeable.width, height) { placeable.place(0, 0) }
                },
        )
    }
}

/** Shown on the All tab until the user allows file access. */
@Composable
private fun AccessCard(onRequestAccess: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(IxColors.Field),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Folder, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        }
        Text(
            text = stringResource(R.string.access_title),
            color = IxColors.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
        )
        Text(
            text = stringResource(R.string.access_body),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Box(
            Modifier
                .height(48.dp)
                .clip(CircleShape)
                .background(IxColors.TextPrimary)
                .clickable(role = Role.Button, onClick = onRequestAccess)
                .padding(horizontal = 28.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.access_button),
                color = IxColors.Background,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
private fun PrivateLocked(onUnlock: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(IxColors.Field),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Lock, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        }
        Text(
            text = stringResource(R.string.private_locked),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
        )
        PillButton(stringResource(R.string.private_unlock), filled = true, onClick = onUnlock)
        Text(
            text = stringResource(R.string.private_hint),
            color = IxColors.TextSecondary,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun PrivateUnlocked(count: Int, onOpen: () -> Unit, onLock: () -> Unit) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(IxColors.Field),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Unlock, tint = IxColors.Accent, size = 24.dp, strokeWidth = 1.8f)
        }
        Text(
            text = stringResource(R.string.private_unlocked),
            color = IxColors.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = itemsLabel(context, count),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton(stringResource(R.string.private_open), filled = true, onClick = onOpen)
            PillButton(stringResource(R.string.private_lock), filled = false, onClick = onLock)
        }
    }
}

@Composable
private fun PillButton(label: String, filled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(46.dp)
            .clip(CircleShape)
            .then(
                if (filled) {
                    Modifier.background(IxColors.TextPrimary)
                } else {
                    Modifier.border(1.dp, IxColors.Outline, CircleShape)
                },
            )
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (filled) IxColors.Background else IxColors.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** What the "Cast to" sheet will start on the device that gets picked. */
private class CastRequest(val items: List<CastItem>, val start: Int)

/** The files of the list the user is looking at, in the order shown, so the viewer can swipe through them. */
private fun picturesAround(state: HomeState): List<FileItem> = when {
    state.browserPath != null -> state.browserFiles
    state.openCategory != null -> state.openFiles
    state.cleanOpen -> state.cleanGroups.flatMap { it.files }
    state.dupOpen -> state.dupGroups.flatMap { it.files }
    state.reportOpen -> state.report?.largest.orEmpty()
    state.searching -> state.results.files
    state.tab == HomeTab.Favorites -> state.favoriteFiles
    else -> state.recent
}
