package ix.app.files.cast

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** Told when a cast session begins and ends, so the Android side can keep the process and Wi-Fi awake. */
interface CastHooks {
    fun onSessionStarted()
    fun onSessionEnded()
}

/** How patient the engine is. The tests use small numbers. */
class CastTiming(
    val pollMs: Long = 1200,
    /** After a new file is handed over, the device may report STOPPED for a moment. Ignore it for this long. */
    val settleMs: Long = 6000,
    /** After a seek or a pause, the position the device reports is not trusted for this long. */
    val holdPositionMs: Long = 2500,
    val retryMs: Long = 600,
    /** One "second" of the slideshow interval. The tests make it short. */
    val slideshowUnitMs: Long = 1000,
)

/**
 * Plays a list of videos, songs and pictures on one DLNA / UPnP device.
 *
 * The device downloads each file from the [MediaServer] inside this app, and the engine is its remote control:
 * it hands over a file, presses Play, and every ~1.2 s asks where the device is, so the UI can show the
 * position and notice when the device's own remote was used. When a file ends, the next one is handed over.
 *
 * All state lives on [scope], which must run on one thread. Every public function is safe to call from any thread.
 */
class CastEngine(
    private val lan: Lan,
    private val scope: CoroutineScope,
    private val settings: () -> CastSettings,
    private val post: (String) -> Unit = {},
    private val hooks: CastHooks? = null,
    private val durationOf: (File) -> Long = { 0L },
    private val makeRenderer: (CastDevice) -> Renderer = { UpnpRenderer(lan, it) },
    private val server: MediaServer = MediaServer(),
    private val timing: CastTiming = CastTiming(),
) {
    private val _state = MutableStateFlow(CastState())
    val state: StateFlow<CastState> = _state

    private var renderer: Renderer? = null
    private var sink: List<String> = emptyList()
    private var host = ""

    private var loadJob: Job? = null
    private var pollJob: Job? = null

    /** The file the device was last told to play. -1 while nothing is on the device. */
    private var loadedIndex = -1
    private var everPlayed = false
    private var settleUntil = 0L
    private var holdPositionUntil = 0L
    private var holdPlayingUntil = 0L
    private var shownAt = 0L
    private var lastRel = 0L
    private var lastDur = 0L
    private var failedPolls = 0
    private var foreignPolls = 0
    private var stoppedPolls = 0
    private var skipStreak = 0
    private var pollCount = 0

    private fun now() = System.nanoTime() / 1_000_000
    private fun name() = _state.value.device?.name ?: "The device"

    // ---- starting and stopping ---------------------------------------------------------------

    /** Shows [items] on [device], starting with the one at [startIndex]. Replaces whatever was playing. */
    fun start(device: CastDevice, items: List<CastItem>, startIndex: Int = 0) {
        if (items.isEmpty()) return
        scope.launch { doStart(device, items, startIndex.coerceIn(0, items.lastIndex)) }
    }

    private suspend fun doStart(d: CastDevice, items: List<CastItem>, startIndex: Int) {
        val sameDevice = renderer != null && _state.value.device?.udn == d.udn &&
            _state.value.phase == CastPhase.CONNECTED
        if (sameDevice) {
            loadJob?.cancel()
            skipStreak = 0
            _state.update { it.copy(queue = items, index = startIndex, slideshow = false) }
            load(startIndex)
            return
        }
        if (renderer != null) teardown(null, stopDevice = true)

        _state.value = CastState(CastPhase.CONNECTING, d, items, startIndex)
        CastLog.log("connecting to ${d.name} (${d.host})")
        val r = makeRenderer(d)
        val probe = withContext(Dispatchers.IO) {
            runCatching {
                val st = r.transportState()
                val vol = runCatching { r.getVolume() }.getOrNull()
                val sk = runCatching { r.sinkFormats() }.getOrDefault(emptyList())
                Triple(st, vol, sk)
            }
        }
        val result = probe.getOrElse { e ->
            CastLog.log("connect failed: $e")
            post("Couldn't connect to ${d.name}")
            _state.value = CastState()
            return
        }
        val ip = lan.localIpFor(d.host)
        if (ip == null) {
            post("Couldn't find this phone's Wi-Fi address")
            _state.value = CastState()
            return
        }

        renderer = r
        sink = result.third
        host = ip
        loadedIndex = -1
        resetCounters()
        server.plain = settings().plainStream
        try {
            server.start()
        } catch (e: IOException) {
            CastLog.log("media server failed: $e")
            post("Couldn't start sharing files from this phone")
            renderer = null
            _state.value = CastState()
            return
        }
        hooks?.onSessionStarted()
        _state.update { it.copy(phase = CastPhase.CONNECTED, volume = result.second ?: -1) }
        CastLog.log("connected, local address $ip, ${sink.size} formats reported")

        load(startIndex)
        startPolling()
    }

    private fun resetCounters() {
        everPlayed = false
        settleUntil = 0L
        holdPositionUntil = 0L
        holdPlayingUntil = 0L
        lastRel = 0L
        lastDur = 0L
        failedPolls = 0
        foreignPolls = 0
        stoppedPolls = 0
        skipStreak = 0
        pollCount = 0
    }

    /** Ends the session. The device is told to stop when [stopDevice] is true. */
    fun stop() {
        scope.launch { if (renderer != null) teardown(null, stopDevice = true) }
    }

    private fun teardown(message: String?, stopDevice: Boolean) {
        val r = renderer
        loadJob?.cancel(); loadJob = null
        pollJob?.cancel(); pollJob = null
        CastLog.log("session ended: ${message ?: "stopped"}")
        if (message != null) post(message)
        renderer = null
        loadedIndex = -1
        _state.value = CastState()
        server.stop()
        if (r != null && stopDevice) scope.launch(Dispatchers.IO) { runCatching { r.stop() } }
        if (r != null) hooks?.onSessionEnded()
    }

    // ---- handing a file to the device --------------------------------------------------------

    private fun load(index: Int) {
        val r = renderer ?: return
        loadJob?.cancel()
        loadJob = scope.launch {
            val queue = _state.value.queue
            val original = queue.getOrNull(index) ?: return@launch
            try {
                if (!File(original.path).isFile) {
                    skipOrStop(index, "“${original.title}” is not there any more")
                    return@launch
                }
                // Songs and videos come with their length, so the device can show a progress bar right away.
                var item = original
                if (item.kind != CastKind.Image && item.durationMs <= 0L) {
                    val d = withContext(Dispatchers.IO) { runCatching { durationOf(File(item.path)) }.getOrDefault(0L) }
                    if (d > 0) {
                        item = item.copy(durationMs = d)
                        _state.update { s ->
                            s.copy(queue = s.queue.mapIndexed { i, q -> if (i == index) item else q })
                        }
                    }
                }

                if (settings().checkFormats && sink.isNotEmpty() && !FormatSupport.supports(sink, item.mime)) {
                    skipOrStop(index, "${name()} says it can't play .${item.ext} files. Turn off “Check formats” to try anyway.")
                    return@launch
                }
                skipStreak = 0

                server.plain = settings().plainStream
                val sendSubtitle = settings().subtitles && !settings().plainStream && item.subtitlePath != null
                val urls = server.urlFor(item, host, sendSubtitle)
                val url = urls.url
                val didl = Didl.build(item, urls.id, url, settings().plainStream, urls.subtitleUrl)
                CastLog.log("load ${item.title} -> $url" + if (urls.subtitleUrl != null) " (with subtitles)" else "")

                loadedIndex = -1
                everPlayed = false
                stoppedPolls = 0
                lastRel = 0L
                lastDur = item.durationMs
                settleUntil = now() + timing.settleMs
                holdPositionUntil = now() + timing.settleMs
                _state.update {
                    it.copy(
                        index = index, loading = true, playing = false,
                        positionMs = 0L, durationMs = item.durationMs,
                    )
                }

                withContext(Dispatchers.IO) {
                    r.setUri(url, didl)
                    playWithRetry(r)
                }
                loadedIndex = index
                settleUntil = now() + timing.settleMs
                shownAt = now()
                if (item.kind == CastKind.Image) _state.update { it.copy(loading = false, playing = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CastLog.log("load failed: $e")
                skipOrStop(index, "${name()} couldn't play “${original.title}”. Not every device plays every format.")
            }
        }
    }

    /** A file could not be shown: go on to the next one, or give up when none is left or too many failed in a row. */
    private fun skipOrStop(index: Int, message: String) {
        val s = _state.value
        post(message)
        if (index + 1 < s.queue.size && ++skipStreak <= 3) {
            load(index + 1)
        } else {
            _state.update { it.copy(index = index, loading = false, playing = false) }
            // Nothing is playing and nothing will: do not leave the session hanging.
            teardown(null, stopDevice = true)
        }
    }

    private suspend fun playWithRetry(r: Renderer) {
        var last: Exception? = null
        repeat(4) {
            try {
                r.play()
                return
            } catch (e: IOException) {
                throw e
            } catch (e: UpnpException) {
                last = e
                delay(timing.retryMs)
            }
        }
        throw last ?: IOException("Play failed")
    }

    // ---- the remote control ------------------------------------------------------------------

    fun togglePlay() {
        scope.launch {
            val r = renderer ?: return@launch
            if (loadedIndex < 0) { load(_state.value.index); return@launch }
            if (_state.value.playing) command(r, "pause", playing = false) { r.pause() }
            else command(r, "play", playing = true) { r.play() }
        }
    }

    private suspend fun command(r: Renderer, what: String, playing: Boolean, block: () -> Unit) {
        holdPlayingUntil = now() + timing.holdPositionMs
        _state.update { it.copy(playing = playing) }
        try {
            withContext(Dispatchers.IO) { block() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CastLog.log("$what failed: $e")
            post("${name()} didn't accept that")
        }
    }

    fun seekTo(ms: Long) {
        scope.launch {
            val r = renderer ?: return@launch
            val item = _state.value.current ?: return@launch
            if (item.kind == CastKind.Image || loadedIndex < 0) return@launch
            val target = ms.coerceAtLeast(0L)
            holdPositionUntil = now() + timing.holdPositionMs
            _state.update { it.copy(positionMs = target) }
            try {
                withContext(Dispatchers.IO) { r.seek(target) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CastLog.log("seek failed: $e")
                post("${name()} can't jump to that spot")
            }
        }
    }

    fun skipBy(deltaMs: Long) {
        val s = _state.value
        val target = (s.positionMs + deltaMs).let { if (s.durationMs > 0) it.coerceAtMost(s.durationMs - 1000) else it }
        seekTo(target)
    }

    fun next() {
        scope.launch {
            val s = _state.value
            if (renderer != null && s.hasNext) { skipStreak = 0; load(s.index + 1) }
        }
    }

    /** More than a few seconds in: back to the start of this file. Otherwise the file before it. */
    fun previous() {
        scope.launch {
            val s = _state.value
            if (renderer == null) return@launch
            val item = s.current
            if (item != null && item.kind != CastKind.Image && s.positionMs > 5000 || !s.hasPrevious) {
                seekTo(0)
            } else {
                skipStreak = 0
                load(s.index - 1)
            }
        }
    }

    fun jumpTo(index: Int) {
        scope.launch {
            val s = _state.value
            if (renderer != null && index in s.queue.indices) { skipStreak = 0; load(index) }
        }
    }

    // ---- slideshow ---------------------------------------------------------------------------

    /** Pictures move on by themselves while this is on. It stops at the last picture. */
    fun setSlideshow(on: Boolean) {
        scope.launch {
            if (renderer == null) return@launch
            shownAt = now()
            _state.update { it.copy(slideshow = on) }
        }
    }

    // ---- volume ------------------------------------------------------------------------------

    fun stepVolume(direction: Int) {
        scope.launch {
            val r = renderer ?: return@launch
            val known = _state.value.volume
            val step = settings().volumeStep
            val base = if (known >= 0) known else withContext(Dispatchers.IO) { runCatching { r.getVolume() }.getOrNull() } ?: 30
            setVolumeNow(r, (base + direction * step).coerceIn(0, 100))
        }
    }

    fun setVolume(v: Int) {
        scope.launch { renderer?.let { setVolumeNow(it, v.coerceIn(0, 100)) } }
    }

    private suspend fun setVolumeNow(r: Renderer, v: Int) {
        _state.update { it.copy(volume = v) }
        try {
            withContext(Dispatchers.IO) { r.setVolume(v) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CastLog.log("set volume failed: $e")
            post("${name()} didn't accept the volume change")
        }
    }

    // ---- polling the device ------------------------------------------------------------------

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                delay(timing.pollMs)
                pollOnce()
            }
        }
    }

    private class Poll(val state: String, val pos: PositionInfo, val volume: Int?)

    internal suspend fun pollOnce() {
        val r = renderer ?: return
        if (loadJob?.isActive == true) return
        val wantVolume = ++pollCount % 5 == 0
        val got = withContext(Dispatchers.IO) {
            runCatching {
                val st = r.transportState()
                val pos = r.positionInfo()
                val vol = if (wantVolume) runCatching { r.getVolume() }.getOrNull() else null
                Poll(st, pos, vol)
            }.getOrNull()
        }
        if (renderer !== r) return   // ended while we waited

        if (got == null) {
            if (++failedPolls >= 6) teardown("Lost connection to ${name()}", stopDevice = false)
            return
        }
        failedPolls = 0
        val st = got.state
        val pos = got.pos
        val item = _state.value.current
        // While stopped, a device may reset its position to 0 (user pressed Stop) or leave it at the end (file ended).
        // Only a later position counts then, so a reset can never look like "just ended".
        pos.relMs?.let {
            if (st != "STOPPED" && st != "NO_MEDIA_PRESENT") lastRel = it else if (it > lastRel) lastRel = it
        }
        pos.durMs?.takeIf { it > 0 }?.let { lastDur = it }
        val t = now()
        val settled = t > settleUntil && st != "TRANSITIONING"
        val ours = loadedIndex >= 0

        _state.update { s ->
            s.copy(
                positionMs = if (t < holdPositionUntil || !ours) s.positionMs else pos.relMs ?: s.positionMs,
                durationMs = if (lastDur > 0) lastDur else s.durationMs,
                playing = if (t < holdPlayingUntil && ours) s.playing else (st == "PLAYING"),
                loading = st == "TRANSITIONING" ||
                    (ours && !everPlayed && item?.kind != CastKind.Image && st != "PAUSED_PLAYBACK" && st != "STOPPED"),
                volume = got.volume ?: s.volume,
            )
        }

        // Did someone else start something on the device? Our addresses all carry this session's token.
        val foreign = pos.trackUri.isNotBlank() && !pos.trackUri.contains("/${server.token}/")
        if (settled && foreign && ours) {
            if (++foreignPolls >= 3) {
                teardown("${name()} was taken over by something else", stopDevice = false)
                return
            }
        } else if (!foreign) {
            foreignPolls = 0
        }

        // Pictures have no playing and no end: the device just shows them until told otherwise,
        // or until the slideshow's time is up.
        if (ours && item?.kind == CastKind.Image && _state.value.slideshow &&
            t - shownAt >= settings().slideshowSeconds * timing.slideshowUnitMs
        ) {
            val s = _state.value
            if (s.hasNext) { skipStreak = 0; load(s.index + 1) } else _state.update { it.copy(slideshow = false) }
            return
        }
        if (!ours || item == null || item.kind == CastKind.Image) return

        when (st) {
            "PLAYING" -> { everPlayed = true; stoppedPolls = 0 }
            "STOPPED", "NO_MEDIA_PRESENT" -> if (settled) {
                stoppedPolls++
                if (everPlayed && stoppedPolls >= 2) {
                    val ended = lastDur <= 0 || lastRel >= lastDur - 3000
                    if (ended) {
                        val s = _state.value
                        if (s.hasNext) { skipStreak = 0; load(s.index + 1) } else teardown(null, stopDevice = true)
                    } else {
                        teardown("${name()} stopped playing", stopDevice = false)
                    }
                } else if (!everPlayed && stoppedPolls >= 5) {
                    skipOrStop(
                        _state.value.index,
                        "${name()} couldn't play “${item.title}”. Not every device plays every format (.${item.ext}).",
                    )
                }
            }
            else -> stoppedPolls = 0
        }
    }
}
