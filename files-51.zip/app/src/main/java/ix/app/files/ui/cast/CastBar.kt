package ix.app.files.ui.cast

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ix.app.files.R
import ix.app.files.cast.CastHub
import ix.app.files.cast.CastKind
import ix.app.files.cast.CastPhase
import ix.app.files.cast.clockLabel
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

/**
 * The remote control that floats at the bottom while something is being cast: what is playing and where,
 * play and pause, next and previous, a seek bar, and the device's volume. [raised] lifts it above the
 * selection bar or the Undo bar when one of them is showing.
 */
@Composable
fun CastBar(raised: Boolean) {
    val state by CastHub.state.collectAsStateWithLifecycle()
    if (state.phase == CastPhase.IDLE) return

    val context = LocalContext.current
    val item = state.current
    val isImage = item?.kind == CastKind.Image
    val shape = RoundedCornerShape(24.dp)
    var dragging by remember { mutableStateOf<Float?>(null) }

    val subtitle = buildString {
        append(state.device?.name.orEmpty())
        if (state.queue.size > 1) append(" · ").append(context.getString(R.string.cast_position, state.index + 1, state.queue.size))
        when {
            state.phase == CastPhase.CONNECTING -> append(" · ").append(context.getString(R.string.cast_connecting))
            state.loading -> append(" · ").append(context.getString(R.string.cast_loading))
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(start = 12.dp, end = 12.dp, bottom = if (raised) 92.dp else 12.dp),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PathIcon(
                    when (item?.kind) {
                        CastKind.Audio -> Glyphs.Audio
                        CastKind.Image -> Glyphs.Images
                        else -> Glyphs.Videos
                    },
                    tint = IxColors.Accent,
                    size = 22.dp,
                    strokeWidth = 1.8f,
                )
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 12.dp),
                ) {
                    Text(
                        text = item?.title.orEmpty(),
                        color = IxColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = subtitle,
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                BarButton(Glyphs.Close, stringResource(R.string.cast_stop), onClick = CastHub::stop)
            }

            if (!isImage) {
                val length = state.durationMs
                val shown = dragging ?: state.positionMs.coerceIn(0L, length.coerceAtLeast(0L)).toFloat()
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = clockLabel(shown.toLong()),
                        color = IxColors.TextSecondary,
                        fontSize = 11.sp,
                    )
                    Slider(
                        value = shown,
                        onValueChange = { dragging = it },
                        onValueChangeFinished = {
                            dragging?.let { CastHub.seekTo(it.toLong()) }
                            dragging = null
                        },
                        valueRange = 0f..(if (length > 0) length.toFloat() else 1f),
                        enabled = length > 0 && state.phase == CastPhase.CONNECTED,
                        colors = SliderDefaults.colors(
                            thumbColor = IxColors.TextPrimary,
                            activeTrackColor = IxColors.TextPrimary,
                            inactiveTrackColor = IxColors.Chip,
                            disabledThumbColor = IxColors.Handle,
                            disabledActiveTrackColor = IxColors.Handle,
                            disabledInactiveTrackColor = IxColors.Chip,
                        ),
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = if (length > 0) clockLabel(length) else "--:--",
                        color = IxColors.TextSecondary,
                        fontSize = 11.sp,
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                BarButton(
                    Glyphs.SkipPrevious, stringResource(R.string.cast_previous),
                    enabled = state.hasPrevious || !isImage,
                    onClick = CastHub::previous,
                )
                // Videos and songs play and pause. A list of pictures starts and stops its slideshow instead.
                if (!isImage || state.queue.size > 1) {
                    Box(
                        Modifier
                            .padding(horizontal = 4.dp)
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(IxColors.TextPrimary)
                            .clickable(role = Role.Button) {
                                if (isImage) CastHub.setSlideshow(!state.slideshow) else CastHub.togglePlay()
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        val running = if (isImage) state.slideshow else state.playing
                        val label = stringResource(
                            when {
                                isImage && running -> R.string.cast_slideshow_stop
                                isImage -> R.string.cast_slideshow_start
                                running -> R.string.cast_pause
                                else -> R.string.cast_play
                            },
                        )
                        PathIcon(
                            if (running) Glyphs.Pause else Glyphs.Play,
                            tint = IxColors.Background,
                            size = 24.dp,
                            strokeWidth = 2.2f,
                            modifier = Modifier.semantics { contentDescription = label },
                        )
                    }
                }
                BarButton(
                    Glyphs.SkipNext, stringResource(R.string.cast_next),
                    enabled = state.hasNext,
                    onClick = CastHub::next,
                )
                Box(Modifier.weight(1f))
                if (state.device?.rcUrl != null) {
                    BarButton(Glyphs.Minus, stringResource(R.string.cast_volume_down)) { CastHub.stepVolume(-1) }
                    Box(Modifier.size(width = 34.dp, height = 40.dp), contentAlignment = Alignment.Center) {
                        if (state.volume >= 0) {
                            Text(
                                text = state.volume.toString(),
                                color = IxColors.TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        } else {
                            PathIcon(Glyphs.Volume, tint = IxColors.TextSecondary, size = 20.dp, strokeWidth = 1.8f)
                        }
                    }
                    BarButton(Glyphs.Plus, stringResource(R.string.cast_volume_up)) { CastHub.stepVolume(+1) }
                }
            }
        }
    }
}

@Composable
private fun BarButton(
    glyph: List<String>,
    description: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .size(44.dp)
            .alpha(if (enabled) 1f else 0.35f)
            .clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 2f)
    }
}
