package ix.app.files.cast

import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale

/**
 * Subtitle files that sit next to a video ("Film.mkv" and "Film.srt", or "Film.en.srt") and what a TV needs from them.
 * Only SubRip (.srt) is handled: it is what TVs that can show external subtitles accept.
 */
object Subtitles {

    /** A subtitle file much bigger than this is not a subtitle. */
    private const val MAX_BYTES = 5L * 1024 * 1024

    /**
     * The subtitle file for [video], or null. "Film.srt" wins over "Film.en.srt", the rest go by name.
     * Pass [siblings] (the files of the same folder) when looking up many videos in one folder.
     */
    fun find(video: File, siblings: List<File>? = null): File? {
        val base = video.nameWithoutExtension
        if (base.isEmpty()) return null
        val files = siblings ?: video.parentFile?.listFiles()?.toList().orEmpty()
        val matches = files.filter {
            it.isFile && it.extension.equals("srt", ignoreCase = true) &&
                (it.nameWithoutExtension.equals(base, ignoreCase = true) ||
                    it.nameWithoutExtension.startsWith("$base.", ignoreCase = true))
        }
        return matches.minWithOrNull(
            compareBy<File> { !it.nameWithoutExtension.equals(base, ignoreCase = true) }.thenBy { it.name.lowercase() },
        )
    }

    /** The text of a subtitle file's bytes, whatever it was saved as. */
    fun decode(bytes: ByteArray, language: String = Locale.getDefault().language): String {
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        // Real UTF-8 is easy to recognise: old single-byte text almost never happens to be valid UTF-8.
        val strict = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        try {
            return strict.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            // an old Windows code page: guess it from the phone's language
        }
        return String(bytes, legacyCharset(language))
    }

    /** The Windows code page that subtitles in the phone's language were most likely saved with. */
    fun legacyCharset(language: String): Charset {
        val name = when (language.lowercase()) {
            "cs", "sk", "pl", "hu", "ro", "hr", "sl", "bs", "sq" -> "windows-1250"
            "ru", "uk", "bg", "sr", "mk", "be", "kk" -> "windows-1251"
            "el" -> "windows-1253"
            "tr", "az" -> "windows-1254"
            "he", "iw" -> "windows-1255"
            "ar", "fa", "ur" -> "windows-1256"
            "lt", "lv", "et" -> "windows-1257"
            "vi" -> "windows-1258"
            else -> "windows-1252"
        }
        return runCatching { Charset.forName(name) }.getOrDefault(Charsets.ISO_8859_1)
    }

    /** What the TV gets: the subtitle file as UTF-8, which is what TVs expect. Empty when it can not be read. */
    fun utf8Bytes(file: File, language: String = Locale.getDefault().language): ByteArray {
        if (!file.isFile || file.length() > MAX_BYTES) return ByteArray(0)
        return runCatching { decode(file.readBytes(), language).toByteArray(Charsets.UTF_8) }.getOrDefault(ByteArray(0))
    }
}
