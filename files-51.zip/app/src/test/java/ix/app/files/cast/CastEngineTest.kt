package ix.app.files.cast

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** A device that does what the tests tell it to. */
private class FakeRenderer : Renderer {
    @Volatile var state = "NO_MEDIA_PRESENT"
    @Volatile var rel = 0L
    @Volatile var dur = 0L
    @Volatile var trackUri = ""
    @Volatile var level: Int? = 20
    @Volatile var sink: List<String> = emptyList()
    @Volatile var failSetUri: Exception? = null
    @Volatile var failPolls = false
    @Volatile var autoPlay = true
    val calls = CopyOnWriteArrayList<String>()
    val uris = CopyOnWriteArrayList<String>()
    val didls = CopyOnWriteArrayList<String>()

    override fun setUri(uri: String, didl: String) {
        failSetUri?.let { throw it }
        calls += "setUri"
        uris += uri; didls += didl
        trackUri = uri
        rel = 0
        state = "STOPPED"
    }

    override fun play() { calls += "play"; if (autoPlay) state = "PLAYING" }
    override fun pause() { calls += "pause"; state = "PAUSED_PLAYBACK" }
    override fun stop() { calls += "stop"; state = "STOPPED" }
    override fun seek(ms: Long) { calls += "seek:$ms"; rel = ms }
    override fun transportState(): String { if (failPolls) throw IOException("gone"); return state }
    override fun positionInfo(): PositionInfo { if (failPolls) throw IOException("gone"); return PositionInfo(rel, dur, trackUri) }
    override fun getVolume(): Int? = level
    override fun setVolume(v: Int) { calls += "vol:$v"; level = v }
    override fun sinkFormats(): List<String> = sink

    /** The device reached the end of the file by itself. */
    fun finishNaturally() { rel = dur - 500; state = "STOPPED" }
}

private class FakeLan : Lan {
    override fun open(url: String): HttpURLConnection = throw UnsupportedOperationException()
    override fun bind(socket: DatagramSocket) {}
    override fun localIpFor(host: String): String? = "127.0.0.1"
}

class CastEngineTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val executor = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())
    private val fake = FakeRenderer()
    private val messages = CopyOnWriteArrayList<String>()
    @Volatile private var started = 0
    @Volatile private var ended = 0
    private var settings = CastSettings()
    private lateinit var engine: CastEngine

    private val device = CastDevice(
        "uuid:1", "Xbox", "Xbox One", DeviceKind.TV, "192.168.1.20", "http://192.168.1.20/d.xml",
        "http://192.168.1.20/avt", "urn:schemas-upnp-org:service:AVTransport:1", null, null, null, null,
    )

    @Before
    fun setUp() {
        engine = CastEngine(
            lan = FakeLan(),
            scope = scope,
            settings = { settings },
            post = { messages += it },
            hooks = object : CastHooks {
                override fun onSessionStarted() { started++ }
                override fun onSessionEnded() { ended++ }
            },
            durationOf = { 10_000L },
            makeRenderer = { fake },
            timing = CastTiming(pollMs = 15, settleMs = 60, holdPositionMs = 40, retryMs = 5, slideshowUnitMs = 20),
        )
        fake.dur = 10_000L
    }

    @After
    fun tearDown() {
        engine.stop()
        Thread.sleep(50)
        executor.shutdownNow()
    }

    private fun video(name: String, ext: String = "mp4") =
        CastMedia.itemFor(tmp.newFile("$name.$ext").also { it.writeBytes(ByteArray(64)) })!!

    private fun waitFor(what: String, ms: Long = 4000, cond: () -> Boolean) {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (cond()) return
            Thread.sleep(10)
        }
        throw AssertionError("Timed out waiting for: $what (state=${engine.state.value}, calls=${fake.calls}, messages=$messages)")
    }

    @Test
    fun startsFirstFile_andShowsPlaying() {
        engine.start(device, listOf(video("a"), video("b")))
        waitFor("playing") { engine.state.value.playing }
        val s = engine.state.value
        assertEquals(CastPhase.CONNECTED, s.phase)
        assertEquals(0, s.index)
        assertEquals(20, s.volume)
        assertEquals(1, started)
        assertEquals(1, fake.uris.size)
        assertTrue(fake.uris[0].contains("/m/1.mp4"))
        assertTrue(fake.didls[0].contains("object.item.videoItem"))
        assertEquals("The length is looked up so the device can show a progress bar", 10_000L, s.durationMs)
        assertTrue(fake.didls[0].contains("duration=\"0:00:10.000\""))
    }

    @Test
    fun mediaServerReallyServesTheAnnouncedFile() {
        val item = video("clip")
        engine.start(device, listOf(item))
        waitFor("uri") { fake.uris.isNotEmpty() }
        val c = java.net.URL(fake.uris[0]).openConnection() as HttpURLConnection
        assertEquals(200, c.responseCode)
        assertEquals(64, c.inputStream.readBytes().size)
    }

    @Test
    fun movesOnToTheNextFile_whenOneEnds() {
        engine.start(device, listOf(video("a"), video("b")))
        waitFor("first playing") { engine.state.value.playing }
        fake.finishNaturally()
        waitFor("second file loaded") { fake.uris.size == 2 }
        waitFor("second playing") { engine.state.value.index == 1 && engine.state.value.playing }
        assertTrue(fake.uris[1].contains("/m/2.mp4"))
    }

    @Test
    fun endsTheSession_afterTheLastFile() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        fake.finishNaturally()
        waitFor("session over") { engine.state.value.phase == CastPhase.IDLE && ended == 1 }
        waitFor("device told to stop") { fake.calls.contains("stop") }
    }

    @Test
    fun stoppingOnTheDeviceMidway_endsWithAMessage_andDoesNotAdvance() {
        engine.start(device, listOf(video("a"), video("b")))
        waitFor("playing") { engine.state.value.playing }
        fake.rel = 3_000
        Thread.sleep(80)
        fake.state = "STOPPED"
        waitFor("session over") { engine.state.value.phase == CastPhase.IDLE }
        assertEquals(1, fake.uris.size)
        assertTrue(messages.any { it.contains("stopped playing") })
    }

    @Test
    fun pauseAndPlayFromTheDeviceRemote_areFollowed() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        fake.state = "PAUSED_PLAYBACK"
        waitFor("shown paused") { !engine.state.value.playing }
        fake.state = "PLAYING"
        waitFor("shown playing") { engine.state.value.playing }
    }

    @Test
    fun togglePlay_sendsPauseThenPlay() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        engine.togglePlay()
        waitFor("paused") { fake.calls.contains("pause") && !engine.state.value.playing }
        engine.togglePlay()
        waitFor("playing again") { fake.calls.count { it == "play" } >= 2 && engine.state.value.playing }
    }

    @Test
    fun seek_isSentAndShownRightAway() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        engine.seekTo(7_000)
        waitFor("seek sent") { fake.calls.contains("seek:7000") }
        assertEquals(7_000L, engine.state.value.positionMs)
    }

    @Test
    fun nextAndPrevious_moveThroughTheQueue() {
        engine.start(device, listOf(video("a"), video("b"), video("c")))
        waitFor("playing") { engine.state.value.playing }
        engine.next()
        waitFor("b") { fake.uris.size == 2 && engine.state.value.index == 1 }
        // Within the first seconds, Previous goes to the file before
        engine.previous()
        waitFor("a again") { fake.uris.size == 3 && engine.state.value.index == 0 }
        assertTrue(fake.uris[2].contains("/m/1.mp4"))
    }

    @Test
    fun previousFarIntoAFile_restartsIt() {
        engine.start(device, listOf(video("a"), video("b")))
        waitFor("playing") { engine.state.value.playing }
        engine.next()
        waitFor("b playing") { engine.state.value.index == 1 && engine.state.value.playing }
        fake.rel = 30_000
        waitFor("position shown") { engine.state.value.positionMs >= 30_000 }
        engine.previous()
        waitFor("restart") { fake.calls.contains("seek:0") }
        assertEquals(1, engine.state.value.index)
    }

    @Test
    fun volumeSteps_useTheSettingAndStayInRange() {
        settings = CastSettings(volumeStep = 15)
        engine.start(device, listOf(video("a")))
        waitFor("connected") { engine.state.value.volume == 20 }
        engine.stepVolume(+1)
        waitFor("35") { fake.calls.contains("vol:35") }
        engine.setVolume(250)
        waitFor("clamped") { fake.calls.contains("vol:100") }
        engine.stepVolume(+1)
        engine.stepVolume(+1)
        Thread.sleep(60)
        assertFalse(fake.calls.any { it == "vol:115" })
    }

    @Test
    fun unsupportedFormat_isSkipped_whenCheckingIsOn() {
        settings = CastSettings(checkFormats = true)
        fake.sink = listOf("http-get:*:video/mp4:*")
        engine.start(device, listOf(video("a", "mkv"), video("b", "mp4")))
        waitFor("b loaded") { fake.uris.size == 1 && engine.state.value.index == 1 }
        assertTrue(fake.uris[0].endsWith(".mp4"))
        assertTrue(messages.any { it.contains(".mkv") })
    }

    @Test
    fun unsupportedFormat_isTriedAnyway_byDefault() {
        fake.sink = listOf("http-get:*:video/mp4:*")
        engine.start(device, listOf(video("a", "mkv")))
        waitFor("sent") { fake.uris.size == 1 }
        assertTrue(fake.uris[0].endsWith(".mkv"))
    }

    @Test
    fun checkFormats_stopsWhenNothingElseIsLeft() {
        settings = CastSettings(checkFormats = true)
        fake.sink = listOf("http-get:*:video/mp4:*")
        engine.start(device, listOf(video("a", "mkv")))
        waitFor("closed") { engine.state.value.phase == CastPhase.IDLE && messages.isNotEmpty() }
        assertTrue(fake.uris.isEmpty())
    }

    @Test
    fun deviceThatRefusesAFile_triggersSkip() {
        fake.failSetUri = UpnpException(714, "Illegal MIME-type")
        engine.start(device, listOf(video("a", "avi")))
        waitFor("gave up") { engine.state.value.phase == CastPhase.IDLE && messages.isNotEmpty() }
        assertTrue(messages.last().contains("couldn't play"))
    }

    @Test
    fun deviceThatNeverStartsPlaying_isGivenUpOn() {
        fake.autoPlay = false     // takes the file, accepts Play, but stays STOPPED
        engine.start(device, listOf(video("a")))
        waitFor("gave up") { messages.any { it.contains("couldn't play") } }
        waitFor("session closed") { engine.state.value.phase == CastPhase.IDLE }
    }

    @Test
    fun losingTheDevice_endsTheSession() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        fake.failPolls = true
        waitFor("lost") { engine.state.value.phase == CastPhase.IDLE }
        assertTrue(messages.any { it.contains("Lost connection") })
        assertFalse("a lost device is not sent Stop", fake.calls.contains("stop"))
    }

    @Test
    fun somethingElseTakingOverTheDevice_endsTheSession() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        fake.trackUri = "http://someone-else/video.mp4"
        waitFor("taken over") { engine.state.value.phase == CastPhase.IDLE }
        assertTrue(messages.any { it.contains("taken over") })
        assertFalse(fake.calls.contains("stop"))
    }

    @Test
    fun picturesNeverEndOnTheirOwn() {
        val pic = CastMedia.itemFor(tmp.newFile("p.jpg").also { it.writeBytes(ByteArray(8)) })!!
        fake.autoPlay = false
        engine.start(device, listOf(pic))
        waitFor("shown") { fake.calls.contains("play") }
        Thread.sleep(400)   // many polls with the device STOPPED
        assertEquals(CastPhase.CONNECTED, engine.state.value.phase)
        assertTrue(fake.didls[0].contains("imageItem"))
    }

    @Test
    fun missingFile_isSkipped() {
        val gone = video("gone")
        File(gone.path).delete()
        engine.start(device, listOf(gone, video("b")))
        waitFor("b loaded") { fake.uris.size == 1 }
        assertTrue(messages.any { it.contains("not there") })
    }

    @Test
    fun castingAgainToTheSameDevice_replacesTheQueue_withoutReconnecting() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        engine.start(device, listOf(video("x"), video("y")), startIndex = 1)
        waitFor("y loaded") { fake.uris.size == 2 && engine.state.value.index == 1 }
        assertEquals(2, engine.state.value.queue.size)
        assertEquals(1, started)
        assertEquals(0, ended)
    }

    @Test
    fun connectFailure_reportsAndStaysIdle() {
        val broken = CastEngine(
            lan = FakeLan(), scope = scope, settings = { settings }, post = { messages += it },
            makeRenderer = {
                object : Renderer by fake {
                    override fun transportState(): String = throw IOException("unreachable")
                }
            },
            timing = CastTiming(pollMs = 15, settleMs = 60, holdPositionMs = 40, retryMs = 5),
        )
        broken.start(device, listOf(video("a")))
        waitFor("reported") { messages.any { it.contains("Couldn't connect") } }
        assertEquals(CastPhase.IDLE, broken.state.value.phase)
        assertNull(broken.state.value.device)
    }

    @Test
    fun stop_tellsTheDeviceAndEndsTheSession() {
        engine.start(device, listOf(video("a")))
        waitFor("playing") { engine.state.value.playing }
        engine.stop()
        waitFor("idle") { engine.state.value.phase == CastPhase.IDLE && ended == 1 }
        waitFor("stop sent") { fake.calls.contains("stop") }
    }

    // ---- slideshow ---------------------------------------------------------------------------

    private fun picture(name: String) =
        CastMedia.itemFor(tmp.newFile("$name.jpg").also { it.writeBytes(ByteArray(8)) })!!

    @Test
    fun slideshow_isOffByDefault() {
        engine.start(device, listOf(picture("a"), picture("b")))
        waitFor("first shown") { fake.calls.contains("play") }
        Thread.sleep(400)   // far longer than the interval (5 x 20 ms)
        assertEquals(0, engine.state.value.index)
        assertFalse(engine.state.value.slideshow)
        assertEquals(1, fake.uris.size)
    }

    @Test
    fun slideshow_movesOnByItself_andStopsAtTheLastPicture() {
        engine.start(device, listOf(picture("a"), picture("b"), picture("c")))
        waitFor("first shown") { fake.uris.size == 1 && engine.state.value.playing }
        engine.setSlideshow(true)
        waitFor("last picture") { engine.state.value.index == 2 && fake.uris.size == 3 }
        waitFor("slideshow over") { !engine.state.value.slideshow }
        Thread.sleep(300)
        assertEquals("it did not wrap around", 3, fake.uris.size)
        assertEquals(CastPhase.CONNECTED, engine.state.value.phase)
    }

    @Test
    fun slideshow_usesTheIntervalFromTheSettings() {
        settings = CastSettings(slideshowSeconds = 50)   // 50 x 20 ms = 1 s
        engine.start(device, listOf(picture("a"), picture("b")))
        waitFor("first shown") { fake.uris.size == 1 && engine.state.value.playing }
        engine.setSlideshow(true)
        Thread.sleep(500)
        assertEquals("still on the first picture", 1, fake.uris.size)
        waitFor("moved on after a second") { fake.uris.size == 2 }
    }

    @Test
    fun slideshow_isResetByANewQueue() {
        engine.start(device, listOf(picture("a"), picture("b")))
        waitFor("shown") { fake.uris.size == 1 && engine.state.value.playing }
        engine.setSlideshow(true)
        waitFor("on") { engine.state.value.slideshow }
        engine.start(device, listOf(picture("x"), picture("y")))
        waitFor("reset") { !engine.state.value.slideshow }
    }

    @Test
    fun slideshow_cannotBeStartedWithoutASession() {
        engine.setSlideshow(true)
        Thread.sleep(80)
        assertFalse(engine.state.value.slideshow)
    }

    // ---- subtitles ---------------------------------------------------------------------------

    private fun filmWithSubtitle(): CastItem {
        val dir = tmp.newFolder()
        File(dir, "Film.srt").writeText("1\n00:00:01,000 --> 00:00:02,000\nHello\n")
        return CastMedia.itemFor(File(dir, "Film.mp4").also { it.writeBytes(ByteArray(16)) })!!
    }

    @Test
    fun subtitles_areSentWithTheVideo_byDefault() {
        engine.start(device, listOf(filmWithSubtitle()))
        waitFor("sent") { fake.didls.isNotEmpty() }
        assertTrue(fake.didls[0].contains("CaptionInfoEx"))
        val sub = Regex("/s/\\d+\\.srt").find(fake.didls[0])
        assertTrue(sub != null)
        // the TV can really fetch it
        val url = Regex("http://[^<]+/s/\\d+\\.srt").find(fake.didls[0])!!.value
        val c = java.net.URL(url).openConnection() as HttpURLConnection
        assertEquals(200, c.responseCode)
        assertTrue(c.inputStream.readBytes().toString(Charsets.UTF_8).contains("Hello"))
    }

    @Test
    fun subtitles_areLeftOut_whenTheOptionIsOff_orTheStreamIsPlain() {
        settings = CastSettings(subtitles = false)
        engine.start(device, listOf(filmWithSubtitle()))
        waitFor("sent") { fake.didls.size == 1 }
        assertFalse(fake.didls[0].contains("srt"))
        settings = CastSettings(subtitles = true, plainStream = true)
        engine.start(device, listOf(filmWithSubtitle()))
        waitFor("sent again") { fake.didls.size == 2 }
        assertFalse(fake.didls[1].contains("srt"))
    }

    @Test
    fun videoWithoutSubtitleFile_getsTheSameDescriptionAsBefore() {
        engine.start(device, listOf(video("plain")))
        waitFor("sent") { fake.didls.isNotEmpty() }
        assertFalse(fake.didls[0].contains("sec:") || fake.didls[0].contains("pv:"))
    }
}
