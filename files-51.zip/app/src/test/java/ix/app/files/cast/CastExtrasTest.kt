package ix.app.files.cast

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Folder playlists, subtitles and their wire format. */
class CastExtrasTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val servers = ArrayList<MediaServer>()

    @After
    fun tearDown() = servers.forEach { it.stop() }

    private fun File.make(name: String, bytes: ByteArray = ByteArray(8)): File =
        File(this, name).also { it.parentFile.mkdirs(); it.writeBytes(bytes) }

    // ---- natural order -----------------------------------------------------------------------

    @Test
    fun naturalCompare_countsDigitsByValue() {
        val sorted = listOf("Episode 10.mkv", "episode 2.mkv", "Episode 1.mkv", "Episode 02a.mkv", "Extras.mkv")
            .sortedWith { a, b -> CastMedia.naturalCompare(a, b) }
        assertEquals(listOf("Episode 1.mkv", "episode 2.mkv", "Episode 02a.mkv", "Episode 10.mkv", "Extras.mkv"), sorted)
        assertTrue(CastMedia.naturalCompare("a", "A") == 0)
        assertTrue(CastMedia.naturalCompare("a1", "a") > 0)
        assertTrue(CastMedia.naturalCompare("007", "7") == 0)
        assertTrue(CastMedia.naturalCompare("a9", "a10") < 0)
    }

    // ---- folder playlists --------------------------------------------------------------------

    @Test
    fun collect_takesCastableFilesOfAFolder_inNaturalOrder() {
        val dir = tmp.newFolder("Show")
        for (n in listOf("S01E10.mp4", "S01E2.mp4", "S01E1.mkv", "notes.txt", ".hidden.mp4", "poster.jpg")) dir.make(n)
        File(dir, "Extras").mkdirs(); File(dir, "Extras").make("deep.mp4")

        val titles = CastMedia.collect(listOf(dir.path)).map { File(it.path).name }
        assertEquals(listOf("poster.jpg", "S01E1.mkv", "S01E2.mp4", "S01E10.mp4"), titles)
    }

    @Test
    fun collect_mixesFilesAndFolders_withoutDuplicates() {
        val dir = tmp.newFolder("Clips")
        val a = dir.make("a.mp4")
        val b = dir.make("b.mp4")
        val loose = tmp.newFile("Loose.mp3")
        val items = CastMedia.collect(listOf(a.path, dir.path, loose.path, b.path))
        // "Clips" sorts before "Loose.mp3"; a and b appear once although they were also selected by themselves
        assertEquals(listOf("a.mp4", "b.mp4", "Loose.mp3"), items.map { File(it.path).name }.let { names ->
            names.sortedBy { n -> listOf("a.mp4", "b.mp4", "Loose.mp3").indexOf(n) }
        })
        assertEquals(3, items.size)
        assertEquals(items.size, items.map { it.path }.toSet().size)
    }

    @Test
    fun collect_respectsTheLimit_andEmptyFoldersGiveNothing() {
        val dir = tmp.newFolder("Many")
        repeat(30) { dir.make("v$it.mp4") }
        assertEquals(10, CastMedia.collect(listOf(dir.path), limit = 10).size)
        assertTrue(CastMedia.collect(listOf(tmp.newFolder("Empty").path)).isEmpty())
        assertTrue(CastMedia.collect(listOf(File(tmp.root, "missing.mp4").path)).isEmpty())
    }

    // ---- finding subtitles -------------------------------------------------------------------

    @Test
    fun find_prefersTheExactName_thenTheLanguageVariants() {
        val dir = tmp.newFolder("Films")
        val film = dir.make("Film.mkv")
        dir.make("Film.en.srt"); dir.make("Film.cs.srt")
        assertEquals("Film.cs.srt", Subtitles.find(film)!!.name)
        dir.make("film.SRT")
        assertEquals("film.SRT", Subtitles.find(film)!!.name)
    }

    @Test
    fun find_ignoresOtherFilesAndOtherFormats() {
        val dir = tmp.newFolder("Films2")
        val film = dir.make("Film.mp4")
        dir.make("Film2.srt"); dir.make("Filmore.srt"); dir.make("Film.ass"); dir.make("Other.srt")
        assertNull(Subtitles.find(film))
        assertNull(Subtitles.find(File(dir, ".mp4")))
    }

    @Test
    fun itemFor_attachesSubtitlesToVideosOnly() {
        val dir = tmp.newFolder("Mixed")
        val video = dir.make("Clip.mp4")
        val song = dir.make("Song.mp3")
        dir.make("Clip.srt"); dir.make("Song.srt")
        assertEquals(File(dir, "Clip.srt").path, CastMedia.itemFor(video)!!.subtitlePath)
        assertNull(CastMedia.itemFor(song)!!.subtitlePath)
    }

    // ---- encodings ---------------------------------------------------------------------------

    private val czech = "1\n00:00:01,000 --> 00:00:02,000\nPříliš žluťoučký kůň úpěl ďábelské ódy\n"

    @Test
    fun decode_keepsUtf8_andDropsTheBom() {
        val utf8 = czech.toByteArray(Charsets.UTF_8)
        assertEquals(czech, Subtitles.decode(utf8, "en"))
        assertEquals(czech, Subtitles.decode(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + utf8, "en"))
    }

    @Test
    fun decode_readsUtf16() {
        val le = byteArrayOf(0xFF.toByte(), 0xFE.toByte()) + czech.toByteArray(Charsets.UTF_16LE)
        val be = byteArrayOf(0xFE.toByte(), 0xFF.toByte()) + czech.toByteArray(Charsets.UTF_16BE)
        assertEquals(czech, Subtitles.decode(le, "cs"))
        assertEquals(czech, Subtitles.decode(be, "cs"))
    }

    @Test
    fun decode_guessesTheOldCodePageFromThePhonesLanguage() {
        val cp1250 = czech.toByteArray(charset("windows-1250"))
        assertEquals(czech, Subtitles.decode(cp1250, "cs"))
        assertEquals(czech, Subtitles.decode(cp1250, "sk"))
        // the same bytes read as Western European text are not the Czech text
        assertFalse(czech == Subtitles.decode(cp1250, "en"))
        val cyrillic = "Привет, мир\n".toByteArray(charset("windows-1251"))
        assertEquals("Привет, мир\n", Subtitles.decode(cyrillic, "ru"))
        assertEquals(charset("windows-1252"), Subtitles.legacyCharset("de"))
    }

    // ---- DIDL with subtitles -----------------------------------------------------------------

    private val video = CastItem("/x/Film.mp4", "Film", CastKind.Video, "video/mp4", "mp4", 10, 5_000, "/x/Film.srt")

    @Test
    fun didl_carriesTheSubtitleInTheFormsTvsLookFor() {
        val xml = Didl.build(video, 4, "http://h:1/t/m/4.mp4", false, "http://h:1/t/s/4.srt")
        assertTrue(xml.contains("xmlns:sec=\"http://www.sec.co.kr/\""))
        assertTrue(xml.contains("<res protocolInfo=\"http-get:*:text/srt:*\">http://h:1/t/s/4.srt</res>"))
        assertTrue(xml.contains("<sec:CaptionInfoEx sec:type=\"srt\">http://h:1/t/s/4.srt</sec:CaptionInfoEx>"))
        assertTrue(xml.contains("<pv:subtitleFileUri>http://h:1/t/s/4.srt</pv:subtitleFileUri>"))
        // the video itself still comes first, and the whole thing is well-formed XML
        assertTrue(xml.indexOf("video/mp4") < xml.indexOf("text/srt"))
        assertEquals("Film", Soap.parse(xml)["title"])
        assertEquals("srt", Soap.parse(xml)["subtitleFileType"])
    }

    @Test
    fun didl_withoutSubtitlesIsUnchanged_andPlainNeverCarriesThem() {
        val none = Didl.build(video, 4, "http://h/4.mp4", false)
        assertFalse(none.contains("sec:") || none.contains("pv:") || none.contains("text/srt"))
        val plain = Didl.build(video, 4, "http://h/4.mp4", true, "http://h/4.srt")
        assertFalse(plain.contains("srt"))
    }

    // ---- the server's subtitle route ---------------------------------------------------------

    private fun get(u: String, method: String = "GET") =
        (URL(u).openConnection() as HttpURLConnection).apply { requestMethod = method; readTimeout = 3000 }

    private fun serverWithFilm(srtBytes: ByteArray): Triple<MediaServer, CastItem, File> {
        val dir = tmp.newFolder()
        dir.make("Film.mp4", ByteArray(100))
        dir.make("Film.srt", srtBytes)
        val item = CastMedia.itemFor(File(dir, "Film.mp4"))!!
        val s = MediaServer().also { it.start(); servers += it }
        return Triple(s, item, dir)
    }

    @Test
    fun subtitleRoute_servesUtf8_andTheVideoPointsToIt() {
        val (s, item, _) = serverWithFilm(czech.toByteArray(charset("windows-1250")))
        val urls = s.urlFor(item, "127.0.0.1", withSubtitle = true)
        assertTrue(urls.subtitleUrl!!.endsWith("/s/${urls.id}.srt"))

        val sub = get(urls.subtitleUrl!!)
        assertEquals(200, sub.responseCode)
        assertTrue(sub.contentType.startsWith("text/srt"))
        val body = sub.inputStream.readBytes().toString(Charsets.UTF_8)
        // Without Czech set as the phone language the guess may differ, but the answer is always valid UTF-8 text
        assertTrue(body.contains("00:00:01,000 --> 00:00:02,000"))

        val v = get(urls.url, "HEAD")
        assertEquals(200, v.responseCode)
        assertEquals(urls.subtitleUrl, v.getHeaderField("CaptionInfo.sec"))
    }

    @Test
    fun subtitleRoute_isClosed_whenNotAskedFor() {
        val (s, item, _) = serverWithFilm(czech.toByteArray())
        val urls = s.urlFor(item, "127.0.0.1", withSubtitle = false)
        assertNull(urls.subtitleUrl)
        assertNull(get(urls.url, "HEAD").getHeaderField("CaptionInfo.sec"))
        assertEquals(404, get("http://127.0.0.1:${s.port}/${s.token}/s/${urls.id}.srt").responseCode)
    }

    @Test
    fun plainMode_sendsNoCaptionHeader() {
        val (s, item, _) = serverWithFilm(czech.toByteArray())
        s.plain = true
        val urls = s.urlFor(item, "127.0.0.1", withSubtitle = true)
        assertNull(get(urls.url, "HEAD").getHeaderField("CaptionInfo.sec"))
    }

    @Test
    fun subtitleThatDisappeared_orIsEmpty_is404() {
        val (s, item, dir) = serverWithFilm(ByteArray(0))
        val urls = s.urlFor(item, "127.0.0.1", withSubtitle = true)
        assertEquals(404, get(urls.subtitleUrl!!).responseCode)
        File(dir, "Film.srt").delete()
        assertEquals(404, get(urls.subtitleUrl!!).responseCode)
    }
}
