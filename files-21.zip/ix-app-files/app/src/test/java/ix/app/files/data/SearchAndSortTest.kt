package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Test
import ix.app.files.util.formatFileSize
import java.util.Locale

class SearchAndSortTest {

    private val scan = ScanData(
        byCategory = emptyMap(),
        recent = emptyList(),
        files = listOf(
            fileItem("/s/holiday.jpg", modified = 5),
            fileItem("/s/my holiday notes.txt", modified = 9),
            fileItem("/s/report.pdf", modified = 1),
            fileItem("/s/Holiday2.png", modified = 7),
        ),
    )

    @Test
    fun namesThatStartWithTheTextComeFirst_newestFirst() {
        val found = SearchEngine.search(scan, "holiday").files.map { it.path }
        assertEquals(listOf("/s/Holiday2.png", "/s/holiday.jpg", "/s/my holiday notes.txt"), found)
    }

    @Test
    fun extensionAndWholeNameMatch() {
        assertEquals(listOf("/s/report.pdf"), SearchEngine.search(scan, "pdf").files.map { it.path })
        assertEquals(listOf("/s/report.pdf"), SearchEngine.search(scan, "report.pdf").files.map { it.path })
    }

    @Test
    fun blankSearchFindsNothing() {
        assertEquals(0, SearchEngine.search(scan, "   ").total)
    }

    @Test
    fun sortSpec_flipsOnSameFieldAndUsesDefaultsOnNewField() {
        val start = SortSpec(SortField.Modified, ascending = false)
        assertEquals(true, start.select(SortField.Modified).ascending)
        val name = start.select(SortField.Name)
        assertEquals(SortField.Name, name.field)
        assertEquals(true, name.ascending)
    }

    @Test
    fun filesSortByNameIgnoringCase_andBySizeDescending() {
        val files = listOf(
            fileItem("/a/b.txt", size = 5),
            fileItem("/a/A.txt", size = 50),
            fileItem("/a/c.txt", size = 1),
        )
        assertEquals(
            listOf("A", "b", "c"),
            files.sortedBySpec(SortSpec(SortField.Name, ascending = true)).map { it.name },
        )
        assertEquals(
            listOf(50L, 5L, 1L),
            files.sortedBySpec(SortSpec(SortField.Size, ascending = false)).map { it.sizeBytes },
        )
    }

    @Test
    fun fileSizesUseDecimalUnits() {
        assertEquals("820 KB", formatFileSize(820_000, Locale.US))
        assertEquals("1.1 MB", formatFileSize(1_100_000, Locale.US))
        assertEquals("148 MB", formatFileSize(148_000_000, Locale.US))
        assertEquals("0 B", formatFileSize(-5, Locale.US))
    }
}
