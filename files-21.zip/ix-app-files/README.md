# ix.app.files

A fast, minimal Android file manager. Kotlin, Jetpack Compose, Material 3.

Design reference: the Home mockup (dark, gray folders, bottom "Recent" sheet).
Behavior reference: [Material Files](https://github.com/zhanghai/materialfiles). It is GPL-3.0 and is
only a reference for how a file manager should behave. No code is copied from it.

## Status: Step 21 (hidden names in Private)

| Done | Next |
| --- | --- |
| Home layout from the mockup | Tie the Private key to the unlock screen |
| Real folder counts and Recent files (background scan) | |
| Folder browser: any folder, path bar, sort, new folder | |
| Favorites, saved on the device | |
| Previews: pictures, video frames, song covers, app icons, first page of PDFs | |
| Selection: copy, move, share, delete, favorite, rename, details, select all | |
| Private folder behind fingerprint, face or screen lock, with every file encrypted and every name hidden | |
| Search across every file and folder by name or extension | |
| Menu: layout, theme (system, light, dark), show hidden files, storage, duplicates | |
| Zip: compress, extract, look inside without extracting | |
| Duplicate finder with Select extras | |
| Progress bar and Cancel for copy, move, zip and extract | |
| Undo for delete, move and copy (a few seconds, one level) | |
| Safer move, copies keep their date, extract checks free space | |
| Duplicates confirmed by comparing whole files | |
| Private hidden from screenshots and the Recent apps screen | |
| Unit tests for file operations, search, sorting, zip and duplicates | |
| Storage screen: usage by kind of file, largest files you can delete | |

**Private** is a folder inside the app's own storage, so other apps and the gallery can not see it.
It opens with the phone's fingerprint, face or screen lock, and locks again after the app has been
away for a minute. Every file in it is encrypted: each file gets its own random AES-256 key, sealed
with a master key that lives in the Android Keystore and never leaves the phone's secure hardware.
The content is stored in 64 KB pieces with AES-GCM, so a changed or cut-off file is noticed.
Names of files and folders are encrypted too (stored as "~" and scrambled text, with the key kept beside the folder and sealed by the same Keystore key). What is not hidden: sizes (roughly), dates and how many items a folder holds. Someone who copies the
files off the phone, even with root access, gets unreadable content. Someone who can run code as
this app on an unlocked phone could still ask the Keystore to open files, because the key is not
tied to the unlock screen. Opening or sharing a file makes a temporary readable copy that is wiped when
Private locks. Files in Private are deleted if the app is uninstalled or its data is cleared.

The app asks for **All files access** on Android 11 and up (a settings page), or the normal storage
permission on Android 8 to 10. Nothing leaves the device: the app has no internet permission.

## Tests

Plain JVM tests live in `app/src/test`. Run them with `./gradlew :app:testDebugUnitTest`. The GitHub workflow runs them
before building the APK and uploads the report as `unit-test-report`.

## Build locally

Needs JDK 17 and the Android SDK (API 35).

```
./gradlew :app:assembleRelease
```

The APK lands in `app/build/outputs/apk/release/`.

## Build on GitHub

1. Create a repo and push this folder to `main`.
2. Open the **Actions** tab. **Release APK** runs on its own for every push.
   You can also start it with **Run workflow**.
3. When it finishes, open the run and download:
   - `ix.app.files-release-apk` is the installable APK.
   - `r8-mapping` is the R8 mapping file. Keep it to decode crash traces.
4. To publish a GitHub Release with the APK attached, push a tag: `git tag v0.1.0 && git push --tags`.

Without any secrets the APK is signed with the **debug key**. It installs fine and is good for testing.
Debug-signed and own-key-signed builds can't be installed over each other, so uninstall first if you switch.

### Sign with your own key (optional)

Create a keystore once:

```
keytool -genkeypair -v -keystore release.jks -alias ixfiles -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks > release.jks.b64        # on macOS: base64 -i release.jks
```

Then add four repository secrets (Settings > Secrets and variables > Actions):

| Secret | Value |
| --- | --- |
| `IX_KEYSTORE_BASE64` | contents of `release.jks.b64` |
| `IX_KEYSTORE_PASSWORD` | the store password |
| `IX_KEY_ALIAS` | `ixfiles` (or your alias) |
| `IX_KEY_PASSWORD` | the key password |

Keep `release.jks` somewhere safe and never commit it. Losing it means you can't update installed copies.

## Project layout

```
app/src/main/java/ix/app/files/
  MainActivity.kt
  data/        models, scanner, search, folder lister, file operations, favorites and settings stores, thumbnails, storage info
  ui/theme/    colors and theme
  ui/components/  PathIcon (stroked SVG icons), FolderIcon, FileIcon
  ui/home/     HomeScreen, header, tabs, category grid, recent sheet, folder browser, favorites, selection bars, name dialog, unlock, list/grid view, menu, storage screen, view model
  util/        size formatting, opening and sharing files
  (tests)      app/src/test/java/ix/app/files/data
```

Icons are drawn from the same SVG paths as the mockup, so there are no icon libraries or image files.
