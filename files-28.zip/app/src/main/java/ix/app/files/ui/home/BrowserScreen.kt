package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.Clip
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.data.VaultNames
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import java.io.File

/**
 * The folder browser: one folder at a time, folders first, with a path bar on top.
 * Back (the arrow or the system gesture) goes up one folder, and closes the browser at the top of storage.
 */
@Composable
fun BrowserScreen(
    path: String,
    rootPath: String,
    rootLabel: String,
    folders: List<FolderItem>,
    files: List<FileItem>,
    loading: Boolean,
    failed: Boolean,
    sort: SortSpec,
    grid: Boolean,
    favorites: Set<String>,
    selection: Selection,
    clip: Clip?,
    onUp: () -> Unit,
    onOpenFolder: (String) -> Unit,
    onSortSelected: (SortField) -> Unit,
    onFileClick: (FileItem) -> Unit,
    onNewFolder: (String) -> Unit,
    onPaste: () -> Unit,
    onCancelClip: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onUp)
    var newFolderOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val title = if (path == rootPath) rootLabel else VaultNames.plainName(File(path))
    val itemCount = folders.size + files.size
    val newFolderDescription = stringResource(R.string.new_folder)

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onUp)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp),
                ) {
                    Text(
                        text = title,
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    )
                    Text(
                        text = if (loading) "" else itemsLabel(context, itemCount),
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button) { newFolderOpen = true }
                        .semantics { contentDescription = newFolderDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.NewFolder, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.8f)
                }
                SortButton(sort = sort, onSortSelected = onSortSelected)
            }

            PathBar(path = path, rootPath = rootPath, rootLabel = rootLabel, onOpen = onOpenFolder)

            when {
                loading -> Box(Modifier.fillMaxSize())

                failed -> CenteredNote(stringResource(R.string.browser_failed))

                itemCount == 0 -> CenteredNote(stringResource(R.string.browser_empty))

                // A new folder starts at the top of its list.
                else -> key(path, grid) {
                    ItemsView(
                        folders = folders,
                        files = files,
                        grid = grid,
                        favorites = favorites,
                        selection = selection,
                        onOpenFolder = { onOpenFolder(it.path) },
                        onOpenFile = onFileClick,
                        contentPadding = PaddingValues(bottom = bottomInset + (if (clip != null) 104.dp else 24.dp)),
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }

        if (clip != null) {
            PasteBar(
                clip = clip,
                onPaste = onPaste,
                onCancel = onCancelClip,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }

    if (newFolderOpen) {
        NameDialog(
            title = stringResource(R.string.new_folder),
            initialName = "",
            confirmLabel = stringResource(R.string.new_folder_confirm),
            onConfirm = { name ->
                newFolderOpen = false
                onNewFolder(name)
            },
            onDismiss = { newFolderOpen = false },
        )
    }
}

/** Bottom bar while copying or moving: what is waiting, Cancel, and the paste button. */
@Composable
private fun PasteBar(clip: Clip, onPaste: () -> Unit, onCancel: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = 16.dp, end = 16.dp, bottom = 14.dp)
            .clip(shape)
            .background(IxColors.Sheet)
            .border(1.dp, IxColors.SheetBorder, shape)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = stringResource(if (clip.move) R.string.paste_move_title else R.string.paste_copy_title),
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = itemsLabel(context, clip.paths.size),
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
            )
        }
        Text(
            text = stringResource(R.string.cancel),
            color = IxColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(CircleShape)
                .clickable(role = Role.Button, onClick = onCancel)
                .padding(horizontal = 14.dp, vertical = 12.dp),
        )
        Box(
            Modifier
                .height(44.dp)
                .clip(CircleShape)
                .background(IxColors.TextPrimary)
                .clickable(role = Role.Button, onClick = onPaste)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(if (clip.move) R.string.paste_move_button else R.string.paste_copy_button),
                color = IxColors.Background,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
private fun CenteredNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}

/** "Internal storage › DCIM › Camera". Tap any part to jump back to that folder. */
@Composable
private fun PathBar(path: String, rootPath: String, rootLabel: String, onOpen: (String) -> Unit) {
    val crumbs = remember(path, rootPath, rootLabel) { crumbsOf(path, rootPath, rootLabel) }
    val scroll = rememberScrollState()
    // Keep the current folder (the last part) in view when the path is longer than the screen.
    LaunchedEffect(scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }

    Row(
        Modifier
            .fillMaxWidth()
            .height(40.dp)
            .horizontalScroll(scroll)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        crumbs.forEachIndexed { index, crumb ->
            val isLast = index == crumbs.lastIndex
            if (index > 0) {
                PathIcon(Glyphs.ChevronRight, tint = IxColors.Handle, size = 14.dp, strokeWidth = 2.2f)
            }
            Text(
                text = crumb.first,
                color = if (isLast) IxColors.TextPrimary else IxColors.TextSecondary,
                fontSize = 13.sp,
                fontWeight = if (isLast) FontWeight.SemiBold else FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(enabled = !isLast, role = Role.Button) { onOpen(crumb.second) }
                    .padding(horizontal = 8.dp, vertical = 7.dp),
            )
        }
    }
}

/** Splits [path] into (label, full path) pairs, starting at the top of storage. */
private fun crumbsOf(path: String, rootPath: String, rootLabel: String): List<Pair<String, String>> {
    val result = ArrayList<Pair<String, String>>()
    result.add(rootLabel to rootPath)
    if (path == rootPath || !path.startsWith(rootPath)) return result
    var current = rootPath
    for (name in path.removePrefix(rootPath).split('/')) {
        if (name.isEmpty()) continue
        current = "$current/$name"
        // Inside Private the names on disk are hidden, so the bar shows the real ones.
        result.add(VaultNames.plainName(File(current)) to current)
    }
    return result
}
