package ix.app.files.data

import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** One line of text as the reader shows it. [number] is 0 for the continuation of a very long line. */
class TextRow(val number: Int, val text: String)

/** One hit of a search: the row it is in, and where in that row. */
class TextMatch(val row: Int, val start: Int, val end: Int)

/** The text of a file after reading: with how it was written, so saving can write it back the same way. */
class Decoded(
    val text: String,
    /** The file used Windows line endings. They are shown as plain new lines and written back on save. */
    val crlf: Boolean,
    /** The file started with a UTF-8 byte order mark. It is kept on save. */
    val bom: Boolean,
    /** False for anything that is not plain UTF-8, which is shown but never saved, so it can not be damaged. */
    val editable: Boolean,
)

enum class TextProblem { TooLarge, Binary, Unreadable }

class Loaded(val decoded: Decoded?, val sizeBytes: Long, val problem: TextProblem?)

/**
 * Reading, showing and saving text files. Reading and writing go through the Vault, so a file in Private is
 * opened and saved in place without ever leaving a readable copy on the phone.
 */
object TextFiles {

    /** Larger files are not opened here. */
    const val MAX_VIEW_BYTES = 10L * 1024 * 1024

    /** Larger files can be read but not edited, because typing in a huge box gets slow. */
    const val MAX_EDIT_BYTES = 512L * 1024

    /** A line longer than this is shown in pieces, because one giant piece of text is slow to draw. */
    const val ROW_CHARS = 4_000

    private const val SNIFF_BYTES = 8 * 1024

    private val extensions = setOf(
        "txt", "text", "md", "markdown", "log", "json", "jsonl", "xml", "html", "htm", "css", "js", "mjs", "ts",
        "tsx", "jsx", "kt", "kts", "java", "py", "rb", "go", "rs", "c", "h", "cpp", "hpp", "cs", "swift", "sh",
        "bat", "ps1", "yml", "yaml", "toml", "ini", "cfg", "conf", "properties", "gradle", "csv", "tsv", "sql",
        "srt", "vtt", "lrc", "gitignore", "gitattributes", "env", "tex", "bib", "vcf", "ics", "m3u", "m3u8",
        "php", "lua", "dart", "pl", "r", "diff", "patch", "editorconfig", "rst", "adoc", "nfo",
    )

    /** Well-known text files that have no extension at all. */
    private val plainNames = setOf(
        "readme", "license", "licence", "changelog", "makefile", "dockerfile", "authors", "contributors",
        "notice", "todo", "copying", "install",
    )

    /** True if a file with this full name (extension included) is text the reader opens straight away. */
    fun isTextName(fileName: String): Boolean {
        val lower = fileName.lowercase()
        val dot = lower.lastIndexOf('.')
        return if (dot >= 0) lower.substring(dot + 1) in extensions else lower in plainNames
    }

    fun viewable(file: FileItem): Boolean =
        file.extension.lowercase() in extensions || (file.extension.isEmpty() && file.name.lowercase() in plainNames)

    private fun isUtf16(bytes: ByteArray): Boolean =
        bytes.size >= 2 &&
            ((bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) ||
                (bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()))

    /** Turns file content into text. UTF-8 is the only thing that may be saved again. */
    fun decode(bytes: ByteArray): Decoded {
        if (isUtf16(bytes)) return finish(String(bytes, Charsets.UTF_16), bom = false, editable = false)
        val bom = bytes.size >= 3 &&
            bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()
        val start = if (bom) 3 else 0
        var valid = true
        val raw = try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes, start, bytes.size - start))
                .toString()
        } catch (e: CharacterCodingException) {
            valid = false
            String(bytes, start, bytes.size - start, Charsets.ISO_8859_1)
        }
        return finish(raw, bom, valid)
    }

    private fun finish(raw: String, bom: Boolean, editable: Boolean): Decoded {
        val crlf = raw.contains("\r\n")
        return Decoded(if (crlf) raw.replace("\r\n", "\n") else raw, crlf, bom, editable)
    }

    /** The file content for [text], written the way the file was found. */
    fun encode(text: String, crlf: Boolean, bom: Boolean): ByteArray {
        val unix = text.replace("\r\n", "\n")
        val body = (if (crlf) unix.replace("\n", "\r\n") else unix).toByteArray(Charsets.UTF_8)
        return if (bom) byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body else body
    }

    /** A zero byte in the first few KB means this is not text (UTF-16 is the exception and is checked first). */
    fun looksBinary(bytes: ByteArray): Boolean {
        if (isUtf16(bytes)) return false
        val limit = minOf(bytes.size, SNIFF_BYTES)
        for (i in 0 until limit) if (bytes[i] == 0.toByte()) return true
        return false
    }

    /** Reads [file]. Blocks, so call it off the main thread. */
    fun load(file: File): Loaded {
        val size = Vault.displaySize(file, file.length())
        if (size > MAX_VIEW_BYTES) return Loaded(null, size, TextProblem.TooLarge)
        val bytes = try {
            Vault.openRead(file).use { it.readBytes() }
        } catch (e: Exception) {
            return Loaded(null, size, TextProblem.Unreadable)
        }
        if (looksBinary(bytes)) return Loaded(null, size, TextProblem.Binary)
        return Loaded(decode(bytes), size, null)
    }

    /**
     * Saves [text] over [file]. It is written next to the file first and then swapped in, so a crash or a full
     * phone never leaves a half-written file. Blocks, so call it off the main thread.
     */
    fun save(file: File, text: String, crlf: Boolean, bom: Boolean): Boolean {
        val bytes = encode(text, crlf, bom)
        val parent = file.parentFile ?: return false
        val temp = File(parent, file.name + Vault.TEMP_SUFFIX)
        return try {
            Vault.openWrite(temp).use { it.write(bytes) }
            if (!temp.renameTo(file)) {
                temp.delete()
                Vault.openWrite(file).use { it.write(bytes) }
            }
            true
        } catch (e: IOException) {
            temp.delete()
            false
        }
    }

    /** The most hits a search lists. More than this and the count shows "+". */
    const val MAX_MATCHES = 5_000

    /**
     * Every place [query] appears in [rows], in order, ignoring capital letters. A hit never runs across the
     * cut of a very long line, and hits do not overlap.
     */
    fun findAll(rows: List<TextRow>, query: String, limit: Int = MAX_MATCHES): List<TextMatch> {
        if (query.isEmpty()) return emptyList()
        val result = ArrayList<TextMatch>()
        for ((index, row) in rows.withIndex()) {
            var from = 0
            while (true) {
                val at = row.text.indexOf(query, from, ignoreCase = true)
                if (at < 0) break
                result.add(TextMatch(index, at, at + query.length))
                if (result.size >= limit) return result
                from = at + query.length
            }
        }
        return result
    }

    /** How many lines [text] has. A final new line does not start another one. */
    fun lineCount(text: String): Int {
        if (text.isEmpty()) return 0
        return text.count { it == '\n' } + (if (text.endsWith('\n')) 0 else 1)
    }

    /** [text] as rows for the reader, with very long lines cut into pieces. */
    fun rows(text: String): List<TextRow> {
        val result = ArrayList<TextRow>()
        var number = 0
        var start = 0
        while (true) {
            val found = text.indexOf('\n', start)
            val end = if (found < 0) text.length else found
            number++
            if (end - start <= ROW_CHARS) {
                result.add(TextRow(number, text.substring(start, end)))
            } else {
                var from = start
                var first = true
                while (from < end) {
                    val to = minOf(from + ROW_CHARS, end)
                    result.add(TextRow(if (first) number else 0, text.substring(from, to)))
                    first = false
                    from = to
                }
            }
            if (end >= text.length) break
            start = end + 1
        }
        if (text.endsWith('\n') && result.isNotEmpty()) result.removeAt(result.lastIndex)
        return result
    }
}
