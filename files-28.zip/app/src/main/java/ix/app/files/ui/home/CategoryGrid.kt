package ix.app.files.ui.home

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.data.CustomFolder
import ix.app.files.data.FolderStyle
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.FolderIconChoices
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import java.io.File
import java.text.NumberFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal val Category.titleRes: Int
    get() = when (this) {
        Category.Downloads -> R.string.category_downloads
        Category.Images -> R.string.category_images
        Category.Videos -> R.string.category_videos
        Category.Audio -> R.string.category_audio
        Category.Docs -> R.string.category_docs
        Category.Apps -> R.string.category_apps
    }

internal val Category.glyph: List<String>
    get() = when (this) {
        Category.Downloads -> Glyphs.Downloads
        Category.Images -> Glyphs.Images
        Category.Videos -> Glyphs.Videos
        Category.Audio -> Glyphs.Audio
        Category.Docs -> Glyphs.Docs
        Category.Apps -> Glyphs.Apps
    }

/** The icon the user picked, or [fallback] when they picked none. */
internal fun glyphFor(style: FolderStyle?, fallback: List<String>): List<String> =
    style?.icon?.let { key -> FolderIconChoices.firstOrNull { it.key == key }?.glyph } ?: fallback

/** The icon to draw for a built-in folder: the user's pick, or the folder's own. */
internal fun Category.glyphFor(style: FolderStyle?): List<String> = glyphFor(style, glyph)

/** The name to show for a folder: the user's own, or the built-in one. */
@Composable
internal fun Category.displayName(style: FolderStyle?): String = style?.name ?: stringResource(titleRes)

/** What one tile in the grid stands for. */
private sealed interface GridItem {
    data class Builtin(val category: Category) : GridItem
    data class Custom(val folder: CustomFolder) : GridItem
    data object Add : GridItem
}

/**
 * The Home folders, three per row, sitting directly on the background: the six built-in ones, then any the
 * user added, then a "New folder" tile. Tap opens a folder, long press edits it.
 */
@Composable
fun CategoryGrid(
    counts: Map<Category, Int>,
    scanning: Boolean,
    styles: Map<Category, FolderStyle>,
    customFolders: List<CustomFolder>,
    /** Changes when the contents of a custom folder may have changed, so its count is read again. */
    refreshKey: Any?,
    onCategoryClick: (Category) -> Unit,
    onCategoryLongClick: (Category) -> Unit,
    onCustomClick: (CustomFolder) -> Unit,
    onCustomLongClick: (CustomFolder) -> Unit,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val items = Category.entries.map<Category, GridItem> { GridItem.Builtin(it) } +
        customFolders.map { GridItem.Custom(it) } +
        GridItem.Add

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        items.chunked(3).forEach { rowItems ->
            Row(Modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { item ->
                    val cellModifier = Modifier.weight(1f)
                    when (item) {
                        is GridItem.Builtin -> {
                            val category = item.category
                            val style = styles[category]
                            val count = counts[category] ?: 0
                            FolderCell(
                                title = category.displayName(style),
                                subtitle = if (scanning && count == 0) {
                                    stringResource(R.string.scanning)
                                } else {
                                    itemsLabel(LocalContext.current, count)
                                },
                                glyph = category.glyphFor(style),
                                tint = style?.color?.let { Color(it) },
                                onClick = { onCategoryClick(category) },
                                onLongClick = { onCategoryLongClick(category) },
                                modifier = cellModifier,
                            )
                        }

                        is GridItem.Custom -> {
                            val folder = item.folder
                            val context = LocalContext.current
                            val count by produceState(initialValue = -1, folder.path, refreshKey) {
                                value = withContext(Dispatchers.IO) {
                                    File(folder.path).list()?.count { !it.startsWith(".") } ?: 0
                                }
                            }
                            FolderCell(
                                title = folder.style.name ?: File(folder.path).name,
                                subtitle = if (count < 0) "" else itemsLabel(context, count),
                                glyph = glyphFor(folder.style, Glyphs.Folder),
                                tint = folder.style.color?.let { Color(it) },
                                onClick = { onCustomClick(folder) },
                                onLongClick = { onCustomLongClick(folder) },
                                modifier = cellModifier,
                            )
                        }

                        GridItem.Add -> FolderCell(
                            title = stringResource(R.string.new_folder),
                            subtitle = "",
                            glyph = Glyphs.Plus,
                            tint = null,
                            faded = true,
                            onClick = onAddClick,
                            onLongClick = null,
                            modifier = cellModifier,
                        )
                    }
                }
                // Keep the last row's tiles the same width as the rows above it.
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderCell(
    title: String,
    subtitle: String,
    glyph: List<String>,
    tint: Color?,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    faded: Boolean = false,
) {
    val haptics = LocalHapticFeedback.current
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                role = Role.Button,
                onClick = onClick,
                onLongClick = onLongClick?.let { longClick ->
                    {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        longClick()
                    }
                },
            )
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FolderIcon(
            glyph = glyph,
            modifier = Modifier
                .size(width = 84.dp, height = 70.dp)
                .alpha(if (faded) 0.5f else 1f),
            tint = tint,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = title,
            color = IxColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (subtitle.isNotEmpty()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
            )
        }
    }
}

/** "42 items", "1,284 items", "1 item". */
fun itemsLabel(context: Context, count: Int): String =
    context.resources.getQuantityString(R.plurals.items_count, count, NumberFormat.getIntegerInstance().format(count))
