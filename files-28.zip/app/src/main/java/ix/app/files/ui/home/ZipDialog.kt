package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ix.app.files.R
import ix.app.files.ui.theme.IxColors

/**
 * Shown when a zip is tapped: look inside it, unpack it next to itself, or hand it to another app.
 * Tapping outside the box closes it and does nothing.
 */
@Composable
fun ZipDialog(
    name: String,
    onLookInside: () -> Unit,
    onExtract: () -> Unit,
    onOpenWith: () -> Unit,
    onDismiss: () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .padding(vertical = 22.dp),
        ) {
            Text(
                text = name,
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 22.dp),
            )
            Spacer(Modifier.height(10.dp))
            ZipOption(stringResource(R.string.zip_look_inside), onLookInside)
            ZipOption(stringResource(R.string.action_extract), onExtract)
            ZipOption(stringResource(R.string.zip_open_with), onOpenWith)
        }
    }
}

@Composable
private fun ZipOption(label: String, onClick: () -> Unit) {
    Text(
        text = label,
        color = IxColors.TextPrimary,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 14.dp),
    )
}
