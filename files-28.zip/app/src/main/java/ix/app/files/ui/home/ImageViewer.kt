package ix.app.files.ui.home

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.PictureLoader
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize

private const val MAX_ZOOM = 6f
private const val DOUBLE_TAP_ZOOM = 2.5f

/** What a page of the viewer is doing. */
private sealed interface PageState {
    object Loading : PageState
    object Failed : PageState
    class Ready(val bitmap: Bitmap) : PageState
}

/**
 * A full-screen picture viewer. Swipe sideways for the next picture in [images], pinch or double-tap to zoom,
 * tap once to hide or show the bars. It is always dark, whatever the app's theme is.
 */
@Composable
fun ImageViewer(
    images: List<FileItem>,
    startIndex: Int,
    isPrivate: (FileItem) -> Boolean,
    onClose: () -> Unit,
    onShare: (FileItem) -> Unit,
    onOpenWith: (FileItem) -> Unit,
    onDelete: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onClose)
    if (images.isEmpty()) return

    val context = LocalContext.current
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, images.size - 1)) { images.size }
    var barsShown by remember { mutableStateOf(true) }
    var askDelete by remember { mutableStateOf<FileItem?>(null) }
    val current = images[pager.currentPage.coerceIn(0, images.size - 1)]
    val backDescription = stringResource(R.string.back_description)
    val bar = Color.Black.copy(alpha = 0.55f)

    Box(
        modifier
            .fillMaxSize()
            .background(Color.Black)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            key = { index -> images[index.coerceIn(0, images.size - 1)].path },
        ) { page ->
            val file = images[page.coerceIn(0, images.size - 1)]
            ZoomablePicture(
                file = file,
                onTap = { barsShown = !barsShown },
                onOpenWith = { onOpenWith(file) },
            )
        }

        if (barsShown) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(bar)
                    .statusBarsPadding()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp)
                    .align(Alignment.TopCenter),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onClose)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = Color.White, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp),
                ) {
                    Text(
                        text = if (current.extension.isEmpty()) current.name else current.name + "." + current.extension,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = context.getString(
                            R.string.viewer_meta,
                            context.getString(R.string.viewer_position, pager.currentPage + 1, images.size),
                            formatFileSize(current.sizeBytes),
                            modifiedLabel(current.modifiedMillis),
                        ),
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(bar)
                    .navigationBarsPadding()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                ViewerAction(Glyphs.Share, stringResource(R.string.action_share)) { onShare(current) }
                ViewerAction(Glyphs.OpenWith, stringResource(R.string.action_open_with)) { onOpenWith(current) }
                ViewerAction(Glyphs.Trash, stringResource(R.string.action_delete)) { askDelete = current }
            }
        }
    }

    val doomed = askDelete
    if (doomed != null) {
        // A picture in Private is deleted for good, anything else can be taken back for a few seconds.
        val inPrivate = isPrivate(doomed)
        AlertDialog(
            onDismissRequest = { askDelete = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.action_delete)) },
            text = {
                Text(context.getString(if (inPrivate) R.string.delete_message_file else R.string.delete_ask_file, doomed.name))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        askDelete = null
                        onDelete(doomed)
                    },
                ) { Text(stringResource(R.string.action_delete), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { askDelete = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ViewerAction(glyph: List<String>, label: String, onClick: () -> Unit) {
    Column(
        Modifier
            .width(88.dp)
            .height(54.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        PathIcon(glyph, tint = Color.White, size = 22.dp, strokeWidth = 1.8f)
        Text(text = label, color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 3.dp))
    }
}

/**
 * One picture that can be pinched, dragged and double-tapped. A single finger on a picture that is not zoomed
 * is left alone, so the pager can turn the page.
 */
@Composable
private fun ZoomablePicture(
    file: FileItem,
    onTap: () -> Unit,
    onOpenWith: () -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        // Big enough to look sharp when zoomed in a little, small enough to be safe in memory.
        val wantedPx = with(density) { maxOf(maxWidth, maxHeight).roundToPx() }.coerceIn(512, 3000)
        val state by produceState<PageState>(PageState.Loading, file.path, file.modifiedMillis, wantedPx) {
            val bitmap = PictureLoader.load(file, wantedPx)
            value = if (bitmap != null) PageState.Ready(bitmap) else PageState.Failed
        }

        var scale by remember { mutableFloatStateOf(1f) }
        var offset by remember { mutableStateOf(Offset.Zero) }

        when (val s = state) {
            PageState.Loading -> CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(28.dp),
                color = Color.White,
                strokeWidth = 2.dp,
            )

            PageState.Failed -> Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(32.dp)
                    .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = stringResource(R.string.viewer_failed),
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                )
                TextButton(onClick = onOpenWith) {
                    Text(stringResource(R.string.action_open_with), color = Color.White)
                }
            }

            is PageState.Ready -> {
                val image = remember(s.bitmap) { s.bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = { onTap() },
                                onDoubleTap = { tap ->
                                    if (scale > 1.01f) {
                                        scale = 1f
                                        offset = Offset.Zero
                                    } else {
                                        val center = Offset(size.width / 2f, size.height / 2f)
                                        scale = DOUBLE_TAP_ZOOM
                                        // Zoom towards the tapped spot.
                                        offset = clampOffset((center - tap) * (DOUBLE_TAP_ZOOM - 1f), DOUBLE_TAP_ZOOM, size.width, size.height)
                                    }
                                },
                            )
                        }
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val event = awaitPointerEvent()
                                    val fingers = event.changes.count { it.pressed }
                                    if (fingers >= 2 || scale > 1.01f) {
                                        val zoom = event.calculateZoom()
                                        val pan = event.calculatePan()
                                        val centroid = event.calculateCentroid(useCurrent = false)
                                        val center = Offset(size.width / 2f, size.height / 2f)
                                        val newScale = (scale * zoom).coerceIn(1f, MAX_ZOOM)
                                        if (centroid != Offset.Unspecified) {
                                            // Keep the spot between the fingers where it is.
                                            val moved = (centroid - center - offset) * (newScale / scale)
                                            offset = clampOffset(centroid + pan - center - moved, newScale, size.width, size.height)
                                        }
                                        scale = newScale
                                        if (newScale <= 1.01f) offset = Offset.Zero
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                )
            }
        }
    }
}

/** Keeps a zoomed picture from being dragged completely out of view. */
private fun clampOffset(offset: Offset, scale: Float, width: Int, height: Int): Offset {
    val maxX = width * (scale - 1f) / 2f
    val maxY = height * (scale - 1f) / 2f
    return Offset(offset.x.coerceIn(-maxX, maxX), offset.y.coerceIn(-maxY, maxY))
}
