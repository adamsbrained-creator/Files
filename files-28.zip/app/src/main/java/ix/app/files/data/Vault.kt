package ix.app.files.data

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Wraps and unwraps the small random key that locks one file. The real one lives in the Android Keystore,
 * so the master key never leaves the phone's secure hardware. Tests use a plain software one.
 */
interface KeyWrapper {
    /** Turns a 32 byte file key into exactly [Vault.WRAPPED_SIZE] bytes that only this wrapper can open. */
    fun wrap(key: ByteArray): ByteArray

    fun unwrap(blob: ByteArray): ByteArray
}

/**
 * The encrypted Private folder.
 *
 * Every file inside Private is stored as: "IXP1", then its own random AES key wrapped by the master key, then
 * the content in 64 KB pieces, each sealed with AES-GCM. A piece that was changed, cut off or moved around
 * fails to open, so damage is noticed instead of silently producing a wrong file.
 *
 * Names and folders are not hidden, only what is inside the files.
 *
 * The rest of the app reads and writes files through [openRead] and [openWrite], which lock and unlock
 * by themselves for paths inside Private and do nothing for any other path.
 */
object Vault {
    const val CHUNK = 64 * 1024
    private const val TAG_SIZE = 16
    private const val FULL = CHUNK + TAG_SIZE
    const val WRAPPED_SIZE = 60
    const val HEADER = 4 + WRAPPED_SIZE
    private val MAGIC = byteArrayOf(0x49, 0x58, 0x50, 0x31)

    @Volatile
    private var root: String? = null

    @Volatile
    private var keyWrapper: KeyWrapper? = null

    /** Tells the vault which folder is Private. Null turns it off, which is how the tests run. */
    fun configure(dir: File?) {
        root = dir?.absolutePath
        // The key for hidden names sits next to the Private folder, not inside it.
        VaultNames.reset(dir?.let { File(it.absoluteFile.parentFile, "private-names.key") })
    }

    /** The Private folder itself, or null if there is none. */
    internal val rootPath: String? get() = root

    internal fun isRoot(file: File): Boolean = root == file.absolutePath

    internal fun wrapKey(key: ByteArray): ByteArray = wrapper().wrap(key)

    internal fun unwrapKey(blob: ByteArray): ByteArray = wrapper().unwrap(blob)

    /** Replaces the Keystore with another wrapper. For tests. */
    fun useKeyWrapper(wrapper: KeyWrapper?) {
        keyWrapper = wrapper
    }

    private fun wrapper(): KeyWrapper {
        keyWrapper?.let { return it }
        return synchronized(this) {
            keyWrapper ?: KeystoreWrapper().also { keyWrapper = it }
        }
    }

    /** Makes sure the master key exists, so the first file does not pay for creating it. */
    fun prepare() {
        wrapper().unwrap(wrapper().wrap(ByteArray(32)))
    }

    fun isPrivate(file: File): Boolean {
        val r = root ?: return false
        val p = file.absolutePath
        return p == r || p.startsWith("$r/")
    }

    /** True if the file starts like a vault file. Files from before encryption was added do not. */
    fun isEncrypted(file: File): Boolean {
        if (!file.isFile || file.length() < HEADER + TAG_SIZE) return false
        return try {
            FileInputStream(file).use { input ->
                val head = ByteArray(4)
                readFully(input, head, 4) == 4 && head.contentEquals(MAGIC)
            }
        } catch (e: IOException) {
            false
        }
    }

    /** The size the content will have once opened. Anything outside Private, or not yet locked, is its own size. */
    fun displaySize(file: File, rawSize: Long): Long =
        if (isPrivate(file) && isEncrypted(file)) plainSizeOf(rawSize) else rawSize

    /** Content size for a locked file of [storedSize] bytes. */
    fun plainSizeOf(storedSize: Long): Long {
        val body = storedSize - HEADER
        if (body <= 0L) return 0L
        val pieces = (body + FULL - 1) / FULL
        return (body - pieces * TAG_SIZE).coerceAtLeast(0L)
    }

    /** Reads [file]. Inside Private the content is unlocked on the way. */
    fun openRead(file: File): InputStream {
        val raw = FileInputStream(file)
        if (!isPrivate(file) || !isEncrypted(file)) return raw
        return try {
            DecryptingInput(raw, wrapper())
        } catch (e: Exception) {
            raw.close()
            throw e
        }
    }

    /** Writes [file]. Inside Private the content is locked on the way. */
    fun openWrite(file: File): OutputStream {
        val raw = FileOutputStream(file)
        if (!isPrivate(file)) return raw
        return try {
            EncryptingOutput(raw, wrapper())
        } catch (e: Exception) {
            raw.close()
            throw e
        }
    }

    /** True when copying from [source] to [target] has to lock or unlock, so a plain rename would be wrong. */
    fun crossesBoundary(source: File, target: File): Boolean = isPrivate(source) != isPrivate(target)

    /** The whole content of a small file, or null if it is bigger than [maxBytes]. */
    fun readAll(file: File, maxBytes: Long): ByteArray? {
        if (displaySize(file, file.length()) > maxBytes) return null
        return openRead(file).use { it.readBytes() }
    }

    /**
     * Locks every file in [dir] that is still plain, and hides every name that is still readable, which is what
     * things put in Private before encryption was added look like. Safe to run again: locked files are skipped.
     *
     * A file that is being written into Private right now also looks plain for a moment, because its first
     * locked piece is not on disk yet. Locking it again would replace it with a broken file. So a file changed
     * in the last [minAgeMillis] is left alone (the next unlock gets it), and only one run happens at a time.
     * Leftovers of a run that was cut short are removed. Names are only touched if they are still readable, and
     * everything written in now gets a hidden name from the start, so that part can not catch a file mid-write.
     */
    fun lockExisting(dir: File, minAgeMillis: Long = 5_000L, now: Long = System.currentTimeMillis()) {
        if (!dir.isDirectory) return
        synchronized(lockExistingGate) {
            // Chosen before anything is rewritten, because locking a file changes the date of its folder.
            val namesToHide = VaultNames.hideCandidates(dir, minAgeMillis, now)
            val files = dir.walkTopDown().filter { it.isFile }.toList()
            for (file in files) {
                if (file.name.endsWith(TEMP_SUFFIX)) {
                    // The plain original is still there, so a stale half-locked copy is only clutter.
                    if (now - file.lastModified() > STALE_TEMP_MS) file.delete()
                    continue
                }
                if (isEncrypted(file)) continue
                if (now - file.lastModified() < minAgeMillis) continue
                val temp = File(file.parentFile, file.name + TEMP_SUFFIX)
                try {
                    FileInputStream(file).use { input -> openWrite(temp).use { output -> input.copyTo(output) } }
                    temp.setLastModified(file.lastModified())
                    // A rename over the old file is one step, so there is never a moment with neither of them.
                    if (!temp.renameTo(file)) temp.delete()
                } catch (e: Exception) {
                    temp.delete()
                }
            }
            VaultNames.hide(namesToHide)
        }
    }

    private val lockExistingGate = Any()
    internal const val TEMP_SUFFIX = ".ixtmp"
    private const val STALE_TEMP_MS = 10 * 60 * 1000L

    private fun readFully(input: InputStream, buffer: ByteArray, length: Int = buffer.size): Int {
        var done = 0
        while (done < length) {
            val read = input.read(buffer, done, length - done)
            if (read < 0) break
            done += read
        }
        return done
    }

    /** Each piece has its own IV: its number. The key is new for every file, so numbers never repeat under a key. */
    private fun ivFor(piece: Int): ByteArray {
        val iv = ByteArray(12)
        iv[8] = (piece ushr 24).toByte()
        iv[9] = (piece ushr 16).toByte()
        iv[10] = (piece ushr 8).toByte()
        iv[11] = piece.toByte()
        return iv
    }

    /** Whether a piece is the last one is part of what is sealed, so a cut-off file does not open. */
    private fun lastFlag(last: Boolean): ByteArray = byteArrayOf((if (last) 1 else 0).toByte())

    private class EncryptingOutput(private val out: OutputStream, wrapper: KeyWrapper) : OutputStream() {
        private val key: SecretKeySpec
        private val buffer = ByteArray(CHUNK)
        private var filled = 0
        private var piece = 0
        private var closed = false

        init {
            val raw = ByteArray(32)
            SecureRandom().nextBytes(raw)
            val wrapped = wrapper.wrap(raw)
            if (wrapped.size != WRAPPED_SIZE) throw IOException("Unexpected key size")
            key = SecretKeySpec(raw, "AES")
            out.write(MAGIC)
            out.write(wrapped)
        }

        override fun write(b: Int) {
            write(byteArrayOf(b.toByte()), 0, 1)
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            var pos = off
            var left = len
            while (left > 0) {
                // A full piece is only sealed once more data follows, so the last piece can be marked as last.
                if (filled == CHUNK) seal(false)
                val count = minOf(left, CHUNK - filled)
                System.arraycopy(b, pos, buffer, filled, count)
                filled += count
                pos += count
                left -= count
            }
        }

        private fun seal(last: Boolean) {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_SIZE * 8, ivFor(piece)))
            cipher.updateAAD(lastFlag(last))
            out.write(cipher.doFinal(buffer, 0, filled))
            piece++
            filled = 0
        }

        override fun flush() {
            out.flush()
        }

        override fun close() {
            if (closed) return
            closed = true
            try {
                seal(true)
            } finally {
                out.close()
            }
        }
    }

    private class DecryptingInput(private val input: InputStream, wrapper: KeyWrapper) : InputStream() {
        private val key: SecretKeySpec
        private var block = ByteArray(FULL)
        private var blockLength = 0
        private var ahead = ByteArray(FULL)
        private var plain = ByteArray(0)
        private var plainPos = 0
        private var piece = 0
        private var finished = false

        init {
            val head = ByteArray(HEADER)
            if (readFully(input, head) != HEADER || !head.copyOfRange(0, 4).contentEquals(MAGIC)) {
                throw IOException("Not a private file")
            }
            key = SecretKeySpec(wrapper.unwrap(head.copyOfRange(4, HEADER)), "AES")
            blockLength = readFully(input, block)
            if (blockLength == 0) throw IOException("This file is cut short")
        }

        /** Opens the next piece. False once everything has been read. */
        private fun nextPiece(): Boolean {
            if (finished) return false
            // Looking one piece ahead is how the last one is recognised.
            val aheadLength = readFully(input, ahead)
            val last = aheadLength == 0
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(TAG_SIZE * 8, ivFor(piece)))
            cipher.updateAAD(lastFlag(last))
            plain = try {
                cipher.doFinal(block, 0, blockLength)
            } catch (e: GeneralSecurityException) {
                throw IOException("This file was changed or damaged", e)
            }
            plainPos = 0
            val swap = block
            block = ahead
            ahead = swap
            blockLength = aheadLength
            piece++
            if (last) finished = true
            return true
        }

        override fun read(): Int {
            val one = ByteArray(1)
            return if (read(one, 0, 1) < 0) -1 else one[0].toInt() and 0xFF
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (len == 0) return 0
            while (plainPos >= plain.size) {
                if (!nextPiece()) return -1
            }
            val count = minOf(len, plain.size - plainPos)
            System.arraycopy(plain, plainPos, b, off, count)
            plainPos += count
            return count
        }

        override fun close() {
            input.close()
        }
    }
}
