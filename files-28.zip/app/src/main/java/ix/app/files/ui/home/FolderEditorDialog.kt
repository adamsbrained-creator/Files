package ix.app.files.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FolderEditTarget
import ix.app.files.data.FOLDER_NAME_MAX
import ix.app.files.data.FolderColorChoices
import ix.app.files.data.FolderStyle
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.FolderIconChoices
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import java.io.File

/** Opens the editor for whatever [target] is: a built-in folder, one the user added, or a brand new one. */
@Composable
fun FolderEditorHost(target: FolderEditTarget, state: HomeState, viewModel: HomeViewModel) {
    when (target) {
        is FolderEditTarget.Builtin -> {
            val category = target.category
            FolderEditorDialog(
                title = stringResource(R.string.folder_edit_title),
                defaultName = stringResource(category.titleRes),
                defaultGlyph = category.glyph,
                current = state.folderStyles[category],
                secondaryLabel = if (state.folderStyles[category]?.isDefault == false) {
                    stringResource(R.string.folder_edit_reset)
                } else {
                    null
                },
                onSecondary = { viewModel.setFolderStyle(category, FolderStyle()) },
                onSave = { viewModel.setFolderStyle(category, it) },
                onDismiss = viewModel::closeFolderEditor,
            )
        }

        is FolderEditTarget.Custom -> {
            val folder = state.customFolders.firstOrNull { it.id == target.id } ?: return
            FolderEditorDialog(
                title = stringResource(R.string.folder_edit_title),
                defaultName = File(folder.path).name,
                defaultGlyph = Glyphs.Folder,
                current = folder.style,
                secondaryLabel = stringResource(R.string.folder_edit_remove),
                onSecondary = { viewModel.removeCustomFolder(folder.id) },
                onSave = { viewModel.updateCustomFolder(folder.id, it) },
                onDismiss = viewModel::closeFolderEditor,
            )
        }

        FolderEditTarget.New -> FolderEditorDialog(
            title = stringResource(R.string.new_folder),
            defaultName = "",
            defaultGlyph = Glyphs.Folder,
            current = null,
            secondaryLabel = null,
            onSecondary = {},
            onSave = { viewModel.createCustomFolder(it) },
            onDismiss = viewModel::closeFolderEditor,
            confirmLabel = stringResource(R.string.new_folder_confirm),
        )
    }
}

/**
 * Lets the user set a folder's name, color and icon, with a live preview on top.
 * Save keeps whatever differs from the default. [secondaryLabel] is an extra button on the left
 * (Reset or Remove); it is hidden when null.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun FolderEditorDialog(
    title: String,
    defaultName: String,
    defaultGlyph: List<String>,
    current: FolderStyle?,
    secondaryLabel: String?,
    onSecondary: () -> Unit,
    onSave: (FolderStyle) -> Unit,
    onDismiss: () -> Unit,
    confirmLabel: String = stringResource(R.string.folder_edit_save),
) {
    var name by remember { mutableStateOf(current?.name ?: defaultName) }
    var color by remember { mutableStateOf(current?.color) }
    var icon by remember { mutableStateOf(current?.icon) }

    val shownGlyph = glyphFor(FolderStyle(icon = icon), defaultGlyph)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(title) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    FolderIcon(
                        glyph = shownGlyph,
                        modifier = Modifier.size(width = 84.dp, height = 70.dp),
                        tint = color?.let { Color(it) },
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { if (it.length <= FOLDER_NAME_MAX) name = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.folder_edit_name)) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = IxColors.TextPrimary,
                        unfocusedTextColor = IxColors.TextPrimary,
                        cursorColor = IxColors.TextPrimary,
                        focusedBorderColor = IxColors.TextSecondary,
                        unfocusedBorderColor = IxColors.Outline,
                        focusedLabelColor = IxColors.TextSecondary,
                        unfocusedLabelColor = IxColors.TextSecondary,
                    ),
                )

                SectionLabel(stringResource(R.string.folder_edit_color))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    FolderColorChoices.forEach { choice ->
                        ColorDot(choice = choice, selected = choice == color, onClick = { color = choice })
                    }
                }

                SectionLabel(stringResource(R.string.folder_edit_icon))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    // "Default" is the folder's own icon, shown first.
                    IconCell(glyph = defaultGlyph, selected = icon == null, onClick = { icon = null })
                    FolderIconChoices.forEach { choice ->
                        IconCell(glyph = choice.glyph, selected = icon == choice.key, onClick = { icon = choice.key })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    val trimmed = name.trim()
                    onSave(
                        FolderStyle(
                            name = trimmed.takeIf { it != defaultName },
                            color = color,
                            icon = icon,
                        ),
                    )
                },
            ) { Text(confirmLabel, color = IxColors.TextPrimary) }
        },
        dismissButton = {
            Row {
                if (secondaryLabel != null) {
                    TextButton(onClick = onSecondary) {
                        Text(secondaryLabel, color = IxColors.Danger)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            }
        },
    )
}

@Composable
private fun SectionLabel(text: String) {
    Text(text = text, color = IxColors.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun ColorDot(choice: Int?, selected: Boolean, onClick: () -> Unit) {
    val fill = choice?.let { Color(it) } ?: IxColors.FolderFrontBottom
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(fill)
            .border(
                BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) IxColors.TextPrimary else IxColors.Outline),
                CircleShape,
            )
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            val onFill = if (fill.red * 0.299f + fill.green * 0.587f + fill.blue * 0.114f > 0.6f) Color.Black else Color.White
            PathIcon(Glyphs.Check, tint = onFill, size = 18.dp, strokeWidth = 2.4f)
        }
    }
}

@Composable
private fun IconCell(glyph: List<String>, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) IxColors.Chip else Color.Transparent)
            .border(
                BorderStroke(if (selected) 2.dp else 1.dp, if (selected) IxColors.TextPrimary else IxColors.Outline),
                RoundedCornerShape(12.dp),
            )
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
    }
}
