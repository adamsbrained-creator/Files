package ix.app.files.data

import java.io.File
import java.io.IOException
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Hides the names of files and folders inside Private.
 *
 * On disk a name is stored as "~" followed by the encrypted name. The same name always gives the same stored
 * text, so a name that is already taken is noticed. Screens show the real name through [plainName] and
 * [decode]; everything that makes a new name inside Private goes through [storedName].
 *
 * The name key is a random secret kept next to the Private folder, sealed by the same Keystore master key
 * that protects the file contents.
 */
object VaultNames {
    private const val PREFIX = "~"
    private const val IV_SIZE = 12
    private const val TAG_SIZE = 16

    /** The longest name a folder may hold is 255 bytes. Stored names stay under this. */
    private const val MAX_STORED = 250

    private class Keys(val encrypt: SecretKeySpec, val derive: SecretKeySpec)

    private val lock = Any()

    @Volatile
    private var keyFile: File? = null

    @Volatile
    private var keys: Keys? = null

    /** Called by [Vault.configure]. Forgets any key that was loaded. */
    internal fun reset(file: File?) {
        synchronized(lock) {
            keyFile = file
            keys = null
        }
    }

    private fun keys(): Keys {
        keys?.let { return it }
        return synchronized(lock) {
            keys ?: createKeys().also { keys = it }
        }
    }

    private fun createKeys(): Keys {
        val file = keyFile ?: throw IOException("Private is not set up")
        val secret = if (file.exists()) {
            Vault.unwrapKey(file.readBytes())
        } else {
            val fresh = ByteArray(32)
            SecureRandom().nextBytes(fresh)
            val temp = File(file.path + ".tmp")
            temp.writeBytes(Vault.wrapKey(fresh))
            // The key file appears whole or not at all.
            if (!temp.renameTo(file)) throw IOException("Could not save the name key")
            fresh
        }
        return Keys(
            encrypt = SecretKeySpec(hmac(secret, "encrypt"), "AES"),
            derive = SecretKeySpec(hmac(secret, "derive"), "HmacSHA256"),
        )
    }

    private fun hmac(key: ByteArray, label: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        return mac.doFinal(label.toByteArray(Charsets.UTF_8))
    }

    /** The text stored on disk for [plain]. The IV comes from the name itself, so equal names stay equal. */
    fun encode(plain: String): String {
        val k = keys()
        val data = plain.toByteArray(Charsets.UTF_8)
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(k.derive)
        val iv = mac.doFinal(data).copyOf(IV_SIZE)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, k.encrypt, GCMParameterSpec(TAG_SIZE * 8, iv))
        val sealed = cipher.doFinal(data)
        return PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(iv + sealed)
    }

    /** The real name for stored text, or null if it is not stored text (a name from before names were hidden). */
    fun decodeOrNull(stored: String): String? {
        if (!stored.startsWith(PREFIX)) return null
        return try {
            val raw = Base64.getUrlDecoder().decode(stored.substring(PREFIX.length))
            if (raw.size < IV_SIZE + TAG_SIZE) return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, keys().encrypt, GCMParameterSpec(TAG_SIZE * 8, raw, 0, IV_SIZE))
            String(cipher.doFinal(raw, IV_SIZE, raw.size - IV_SIZE), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    /** Like [decodeOrNull], but a name that is not stored text is returned as it is. */
    fun decode(stored: String): String = decodeOrNull(stored) ?: stored

    /** The name to show for [file]. Anything outside Private, and the Private folder itself, is its own name. */
    fun plainName(file: File): String =
        if (Vault.isPrivate(file) && !Vault.isRoot(file)) decode(file.name) else file.name

    /**
     * The name to give a new entry called [plain] inside [dir]. Inside Private it is the stored text, shortened
     * if it would not fit; anywhere else it is [plain] unchanged.
     */
    fun storedName(dir: File?, plain: String): String =
        if (dir != null && Vault.isPrivate(dir)) encode(fit(plain)) else plain

    /** The name [source] gets when it lands in [destDir]: unlocked on the way out, locked on the way in. */
    fun nameFor(source: File, destDir: File): String = storedName(destDir, plainName(source))

    /** Cuts the middle of a name that is too long to store, keeping its extension. */
    fun fit(plain: String): String {
        var name = plain
        while (encode(name).length > MAX_STORED) {
            val dot = name.lastIndexOf('.')
            val extension = if (dot > 0 && name.length - dot <= 12) name.substring(dot) else ""
            val base = name.substring(0, name.length - extension.length)
            if (base.length <= 4) break
            name = base.dropLast(4) + extension
        }
        return name
    }

    /**
     * Hides every name in [dir] that is still readable. Names already hidden are left alone, and so is anything
     * changed within [minAgeMillis] of [now], the same rule the locking of old files follows.
     */
    fun hideExisting(dir: File, minAgeMillis: Long = 5_000L, now: Long = System.currentTimeMillis()) {
        hide(hideCandidates(dir, minAgeMillis, now))
    }

    /** The entries of [dir] whose names are still readable and old enough to touch, deepest first. */
    fun hideCandidates(dir: File, minAgeMillis: Long, now: Long): List<File> {
        if (!dir.isDirectory) return emptyList()
        return dir.walkBottomUp()
            .filter {
                it != dir && !it.name.endsWith(Vault.TEMP_SUFFIX) &&
                    now - it.lastModified() >= minAgeMillis && decodeOrNull(it.name) == null
            }
            .toList()
    }

    /** Renames [entries], given deepest first so a folder is renamed only after everything in it. */
    fun hide(entries: List<File>) {
        for (entry in entries) {
            if (!entry.exists()) continue
            val target = File(entry.parentFile, encode(fit(entry.name)))
            if (!target.exists()) entry.renameTo(target)
        }
    }

    /** [path] with every stored name in it swapped for the real one, for showing. */
    fun displayPath(path: String): String {
        val root = Vault.rootPath ?: return path
        if (path != root && !path.startsWith("$root/")) return path
        val rest = path.substring(root.length)
        return root + rest.split('/').joinToString("/") { part -> if (part.isEmpty()) part else decode(part) }
    }
}
