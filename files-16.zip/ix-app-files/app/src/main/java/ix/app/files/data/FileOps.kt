package ix.app.files.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Copying, moving and measuring files. Everything here blocks, so call it off the main thread. */
object FileOps {

    /**
     * What a paste did. [done] pairs each source path with the path it now has.
     * [skipped] counts items that can not go there (a folder into itself, or a move to where it already is).
     * [cancelled] is true if the user stopped it; whatever finished before that stays done.
     */
    class PasteResult(
        val done: List<Pair<String, String>>,
        val skipped: Int,
        val failed: Int,
        val cancelled: Boolean,
    )

    /** The size of a file, or of everything inside a folder. */
    fun sizeOf(file: File): Long {
        if (!file.isDirectory) return file.length()
        var total = 0L
        for (f in file.walkTopDown()) {
            if (f.isFile) total += f.length()
        }
        return total
    }

    /**
     * Copies or moves [paths] into [dest]. A name that is taken gets " (1)", " (2)" and so on.
     * Progress goes to [control], and the job stops early once it is cancelled.
     */
    fun paste(dest: File, paths: List<String>, move: Boolean, control: JobControl = JobControl()): PasteResult {
        val done = ArrayList<Pair<String, String>>()
        var skipped = 0
        var failed = 0
        var stopped = false
        val destPath = dest.absolutePath
        val sizes = paths.map { sizeOf(File(it)) }
        control.totalBytes = sizes.sum()
        for ((index, path) in paths.withIndex()) {
            if (control.cancelled) {
                stopped = true
                break
            }
            val source = File(path)
            if (!source.exists()) {
                failed++
                continue
            }
            val sourcePath = source.absolutePath
            val intoItself = source.isDirectory && (destPath == sourcePath || destPath.startsWith("$sourcePath/"))
            val alreadyThere = move && source.parentFile?.absolutePath == destPath
            if (intoItself || alreadyThere) {
                skipped++
                continue
            }
            val target = uniqueTarget(dest, source.name)
            val ok = try {
                if (move) moveTo(source, target, control, sizes[index]) else copyTree(source, target, control)
            } catch (e: JobStopped) {
                if (target.exists()) target.deleteRecursively()
                stopped = true
                break
            } catch (e: Exception) {
                false
            }
            if (ok) {
                done.add(sourcePath to target.absolutePath)
            } else {
                // Do not leave half a copy behind.
                if (target.exists()) target.deleteRecursively()
                failed++
            }
        }
        return PasteResult(done, skipped, failed, stopped)
    }

    /** Copies a file or a whole folder, counting the bytes as they go. */
    private fun copyTree(source: File, target: File, control: JobControl): Boolean {
        if (source.isDirectory) {
            if (!target.mkdirs() && !target.isDirectory) return false
            val children = source.listFiles() ?: return false
            var all = true
            for (child in children) {
                control.check()
                if (!copyTree(child, File(target, child.name), control)) all = false
            }
            return all
        }
        copyFile(source, target, control)
        return true
    }

    private fun copyFile(source: File, target: File, control: JobControl) {
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                val buffer = ByteArray(256 * 1024)
                while (true) {
                    control.check()
                    val read = input.read(buffer)
                    if (read < 0) break
                    output.write(buffer, 0, read)
                    control.add(read.toLong())
                }
            }
        }
    }

    private fun moveTo(source: File, target: File, control: JobControl, size: Long): Boolean {
        // On the same storage a move is just a rename, which is instant.
        if (source.renameTo(target)) {
            control.add(size)
            return true
        }
        if (!copyTree(source, target, control)) return false
        return if (source.isDirectory) source.deleteRecursively() else source.delete()
    }

    /** [name] inside [dir], or "name (1)", "name (2)" and so on if that is taken. */
    fun uniqueTarget(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val extension = if (dot > 0) name.substring(dot) else ""
        var n = 1
        while (candidate.exists()) {
            candidate = File(dir, "$base ($n)$extension")
            n++
        }
        return candidate
    }

    /**
     * Packs [sources] into the zip file [target]. Folders go in with everything inside them.
     * Returns false (and leaves no half-written zip) if anything went wrong.
     */
    fun zip(sources: List<File>, target: File, control: JobControl = JobControl()): Boolean {
        control.totalBytes = sources.sumOf { sizeOf(it) }
        val written = try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(target))).use { out ->
                val buffer = ByteArray(64 * 1024)
                for (source in sources) {
                    val base = source.parentFile ?: continue
                    val entries = if (source.isDirectory) source.walkTopDown() else sequenceOf(source)
                    for (file in entries) {
                        control.check()
                        // The zip being written must not end up inside itself.
                        if (file.absolutePath == target.absolutePath) continue
                        val name = file.relativeTo(base).invariantSeparatorsPath
                        if (file.isDirectory) {
                            val entry = ZipEntry("$name/")
                            entry.time = file.lastModified()
                            out.putNextEntry(entry)
                            out.closeEntry()
                        } else {
                            val entry = ZipEntry(name)
                            entry.time = file.lastModified()
                            out.putNextEntry(entry)
                            FileInputStream(file).use { input ->
                                while (true) {
                                    control.check()
                                    val read = input.read(buffer)
                                    if (read < 0) break
                                    out.write(buffer, 0, read)
                                    control.add(read.toLong())
                                }
                            }
                            out.closeEntry()
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
        if (!written && target.exists()) target.delete()
        return written
    }

    /**
     * Unpacks [zip] into [destDir]. Entries that try to climb out of the folder with "../" are skipped.
     * Returns false if the zip could not be read to the end.
     */
    fun unzip(zip: File, destDir: File, control: JobControl = JobControl()): Boolean {
        return try {
            destDir.mkdirs()
            val root = destDir.canonicalPath
            ZipInputStream(BufferedInputStream(CountingStream(FileInputStream(zip), control))).use { input ->
                var entry: ZipEntry? = input.nextEntry
                while (entry != null) {
                    val out = File(destDir, entry.name)
                    val safe = out.canonicalPath.startsWith(root + File.separator)
                    if (safe) {
                        if (entry.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { output -> input.copyTo(output) }
                            if (entry.time > 0) out.setLastModified(entry.time)
                        }
                    }
                    input.closeEntry()
                    entry = input.nextEntry
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Reads through to the real stream, counting what passes and stopping once the job is cancelled. */
    private class CountingStream(input: InputStream, private val control: JobControl) : FilterInputStream(input) {
        override fun read(): Int {
            control.check()
            val value = super.read()
            if (value >= 0) control.add(1L)
            return value
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            control.check()
            val count = super.read(buffer, offset, length)
            if (count > 0) control.add(count.toLong())
            return count
        }
    }

    /** Where an old path ended up after a move, or null if the move did not touch it. */
    fun remap(path: String, from: String, to: String): String? = when {
        path == from -> to
        path.startsWith("$from/") -> to + path.substring(from.length)
        else -> null
    }

    /** The files inside [paths] (folders are walked), capped so a huge folder does not stall the media scan. */
    fun filesUnder(paths: List<String>, limit: Int = 500): List<String> {
        val result = ArrayList<String>()
        for (path in paths) {
            val root = File(path)
            if (root.isFile) {
                result.add(root.path)
            } else {
                for (f in root.walkTopDown()) {
                    if (f.isFile) result.add(f.path)
                    if (result.size >= limit) return result
                }
            }
            if (result.size >= limit) return result
        }
        return result
    }

    /** What the Details dialog shows. [name], [location] and [modifiedMillis] describe the first selected item. */
    class Details(
        val count: Int,
        val name: String,
        val location: String,
        val modifiedMillis: Long,
        val isFolder: Boolean,
        val files: Int,
        val folders: Int,
        val bytes: Long,
    )

    suspend fun measure(paths: List<String>): Details = withContext(Dispatchers.IO) {
        var files = 0
        var folders = 0
        var bytes = 0L
        for (path in paths) {
            val root = File(path)
            if (root.isDirectory) {
                for (f in root.walkTopDown()) {
                    ensureActive()
                    if (f.isDirectory) {
                        if (f != root) folders++
                    } else {
                        files++
                        bytes += f.length()
                    }
                }
            } else {
                files++
                bytes += root.length()
            }
        }
        val first = File(paths.first())
        Details(
            count = paths.size,
            name = first.name,
            location = first.parent.orEmpty(),
            modifiedMillis = first.lastModified(),
            isFolder = first.isDirectory,
            files = files,
            folders = folders,
            bytes = bytes,
        )
    }
}
