package ix.app.files.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import ix.app.files.data.Thumbnails
import ix.app.files.ui.theme.IxColors

private sealed interface ThumbState {
    object Loading : ThumbState
    object Failed : ThumbState
    class Ready(val bitmap: Bitmap) : ThumbState
}

/**
 * A rounded square preview of an image or video. While it loads, a quiet placeholder is shown;
 * if the file can not be decoded, [fallback] is shown instead (the gray page icon).
 */
@Composable
fun Thumbnail(
    file: FileItem,
    size: Dp,
    modifier: Modifier = Modifier,
    fallback: @Composable () -> Unit,
) {
    val px = with(LocalDensity.current) { size.roundToPx() }
    val cached = Thumbnails.peek(file, px)
    val initial: ThumbState = when {
        cached != null -> ThumbState.Ready(cached)
        Thumbnails.hasFailed(file, px) -> ThumbState.Failed
        else -> ThumbState.Loading
    }
    val state by produceState(initial, file.path, file.modifiedMillis, px) {
        if (value is ThumbState.Loading) {
            val bitmap = Thumbnails.load(file, px)
            value = if (bitmap != null) ThumbState.Ready(bitmap) else ThumbState.Failed
        }
    }

    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        when (val s = state) {
            is ThumbState.Ready -> {
                val image = remember(s.bitmap) { s.bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp)),
                )
                if (file.kind == FileKind.Video) {
                    Box(
                        Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        PathIcon(Glyphs.Play, tint = Color.White, size = 10.dp, strokeWidth = 2.6f)
                    }
                }
            }

            ThumbState.Loading -> Box(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                    .background(IxColors.Chip),
            )

            ThumbState.Failed -> fallback()
        }
    }
}
