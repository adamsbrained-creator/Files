package ix.app.files.data

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes
import java.util.PriorityQueue

/**
 * Walks shared storage once and sorts what it finds into the Home folders.
 *
 * - Downloads is read first, so it is ready almost at once.
 * - Hidden files and folders (names starting with a dot) and the Android folder are skipped.
 * - [publish] is called about once a second with everything found so far, then once at the end.
 */
class FileScanner {

    suspend fun scan(root: File, publish: (ScanData) -> Unit) {
        withContext(Dispatchers.IO) {
            val job = coroutineContext[Job]
            val rootPath = root.toPath()
            val downloads = File(root, "Download")

            val lists: Map<Category, ArrayList<FileItem>> = Category.entries.associateWith { ArrayList<FileItem>() }
            val newest = PriorityQueue<FileItem>(RECENT_LIMIT + 1, compareBy<FileItem> { it.modifiedMillis })
            var lastPublish = SystemClock.elapsedRealtime()

            fun snapshot() = ScanData(
                byCategory = lists.mapValues { it.value.toList() },
                recent = newest.sortedByDescending { it.modifiedMillis },
            )

            fun record(file: Path, attrs: BasicFileAttributes, inDownloads: Boolean) {
                val fileName = file.fileName?.toString() ?: return
                if (fileName.startsWith(".")) return
                val dot = fileName.lastIndexOf('.')
                val name = if (dot > 0) fileName.substring(0, dot) else fileName
                val extension = if (dot > 0 && dot < fileName.length - 1) fileName.substring(dot + 1).lowercase() else ""
                val kind = FileKinds.kindOf(extension)
                val item = FileItem(
                    path = file.toString(),
                    name = name,
                    extension = extension,
                    sizeBytes = attrs.size(),
                    modifiedMillis = attrs.lastModifiedTime().toMillis(),
                    kind = kind,
                )
                FileKinds.categoryOf(kind)?.let { lists.getValue(it).add(item) }
                if (inDownloads) lists.getValue(Category.Downloads).add(item)
                newest.add(item)
                if (newest.size > RECENT_LIMIT) newest.poll()
            }

            fun walk(start: Path, inDownloads: Boolean, skip: Path?) {
                Files.walkFileTree(
                    start,
                    object : SimpleFileVisitor<Path>() {
                        override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                            if (job?.isActive == false) return FileVisitResult.TERMINATE
                            if (dir == start) return FileVisitResult.CONTINUE
                            val name = dir.fileName?.toString().orEmpty()
                            if (name.startsWith(".")) return FileVisitResult.SKIP_SUBTREE
                            if (skip != null && dir == skip) return FileVisitResult.SKIP_SUBTREE
                            if (dir.parent == rootPath && name == "Android") return FileVisitResult.SKIP_SUBTREE
                            return FileVisitResult.CONTINUE
                        }

                        override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                            if (job?.isActive == false) return FileVisitResult.TERMINATE
                            if (attrs.isRegularFile) {
                                record(file, attrs, inDownloads)
                                val now = SystemClock.elapsedRealtime()
                                if (now - lastPublish >= PUBLISH_INTERVAL_MS) {
                                    lastPublish = now
                                    publish(snapshot())
                                }
                            }
                            return FileVisitResult.CONTINUE
                        }

                        // Folders we are not allowed to read are simply skipped.
                        override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult =
                            FileVisitResult.CONTINUE
                    },
                )
            }

            if (downloads.isDirectory) {
                walk(downloads.toPath(), inDownloads = true, skip = null)
                publish(snapshot())
            }
            walk(rootPath, inDownloads = false, skip = downloads.toPath())

            if (job?.isActive != false) publish(snapshot())
        }
    }

    private companion object {
        const val RECENT_LIMIT = 40
        const val PUBLISH_INTERVAL_MS = 1_000L
    }
}
