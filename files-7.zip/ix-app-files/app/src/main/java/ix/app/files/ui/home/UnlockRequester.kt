package ix.app.files.ui.home

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import ix.app.files.R

/**
 * Returns a function that asks the user to prove it is them, with a fingerprint or face if the
 * phone has one, or with the screen lock (PIN, pattern, password). [onResult] gets true on success.
 *
 * Android 11 and up use the system biometric sheet. Older versions open the screen lock page.
 * A phone without any screen lock can not protect Private, so the user is told to set one.
 */
@Composable
fun rememberUnlockRequester(title: String, subtitle: String, onResult: (Boolean) -> Unit): () -> Unit {
    val context = LocalContext.current
    val latestOnResult by rememberUpdatedState(onResult)
    val legacyLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result -> latestOnResult(result.resultCode == Activity.RESULT_OK) }

    return remember(context, legacyLauncher, title, subtitle) {
        {
            val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            if (keyguard == null || !keyguard.isDeviceSecure) {
                Toast.makeText(context, R.string.unlock_no_lock, Toast.LENGTH_LONG).show()
                latestOnResult(false)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val prompt = BiometricPrompt.Builder(context)
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK or
                            BiometricManager.Authenticators.DEVICE_CREDENTIAL,
                    )
                    .build()
                prompt.authenticate(
                    CancellationSignal(),
                    ContextCompat.getMainExecutor(context),
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                            latestOnResult(true)
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                            latestOnResult(false)
                        }
                    },
                )
            } else {
                val intent = keyguard.createConfirmDeviceCredentialIntent(title, subtitle)
                if (intent != null) legacyLauncher.launch(intent) else latestOnResult(false)
            }
        }
    }
}
