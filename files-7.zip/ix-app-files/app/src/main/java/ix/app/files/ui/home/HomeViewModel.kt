package ix.app.files.ui.home

import android.app.Application
import android.media.MediaScannerConnection
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.data.Clip
import ix.app.files.data.FavoritesStore
import ix.app.files.data.FileOps
import ix.app.files.data.FileItem
import ix.app.files.data.FileScanner
import ix.app.files.data.FolderItem
import ix.app.files.data.FolderLister
import ix.app.files.data.HomeTab
import ix.app.files.data.Listing
import ix.app.files.data.ScanData
import ix.app.files.data.SheetAnchor
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.data.StorageAccess
import ix.app.files.data.Thumbnails
import ix.app.files.data.sortedBySpec
import ix.app.files.data.sortedFoldersBySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class HomeState(
    val tab: HomeTab = HomeTab.All,
    val sort: SortSpec = SortSpec(),
    val sheet: SheetAnchor = SheetAnchor.Hidden,
    val hasAccess: Boolean = false,
    val scanning: Boolean = false,
    val scan: ScanData = ScanData.Empty,
    val counts: Map<Category, Int> = emptyMap(),
    val recent: List<FileItem> = emptyList(),
    val openCategory: Category? = null,
    val openFiles: List<FileItem> = emptyList(),

    /** True after the user proved it is them. Private locks again by itself, see [onForegrounded]. */
    val privateUnlocked: Boolean = false,
    /** How many items sit in the Private folder. Only known while it is unlocked. */
    val privateCount: Int = 0,

    /** Items waiting to be pasted into a folder of the browser. Null when nothing is being copied or moved. */
    val clip: Clip? = null,
    /** True while a copy, move or delete runs. The screen shows a blocking "Working…" card. */
    val busy: Boolean = false,

    /** Paths of the files and folders ticked in selection mode. Empty means not selecting. */
    val selected: Set<String> = emptySet(),

    /** Paths of every favorite, saved on the device. */
    val favorites: Set<String> = emptySet(),
    /** The favorites that still exist, ready to show on the Favorites tab. */
    val favoriteFolders: List<FolderItem> = emptyList(),
    val favoriteFiles: List<FileItem> = emptyList(),

    /** The folder the browser shows, or null while the browser is closed. */
    val browserPath: String? = null,
    val browserLoading: Boolean = false,
    val browserFailed: Boolean = false,
    val browserFolders: List<FolderItem> = emptyList(),
    val browserFiles: List<FileItem> = emptyList(),
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val scanner = FileScanner()
    private val favoritesStore = FavoritesStore(application)
    private var scanJob: Job? = null
    private var sortJob: Job? = null
    private var favoritesJob: Job? = null
    private var browserJob: Job? = null
    private var browserSortJob: Job? = null
    private var lastScanAt = 0L
    private var leftAt = 0L

    /** Private lives inside the app's own storage. Other apps and the gallery can not see it. */
    private val privateDir = File(application.filesDir, "private")
    val privateRootPath: String = privateDir.absolutePath

    /** The unsorted contents of the folder in the browser, kept so a new sort needs no disk read. */
    @Volatile
    private var browserListing: Listing? = null

    private val _state = MutableStateFlow(
        HomeState(
            hasAccess = StorageAccess.hasAccess(application),
            favorites = favoritesStore.load(),
        ),
    )
    val state: StateFlow<HomeState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<Int>(extraBufferCapacity = 4)

    /** One-off messages for the user, as string resource ids. The screen shows them as toasts. */
    val events: SharedFlow<Int> = _events.asSharedFlow()

    init {
        if (_state.value.hasAccess) {
            startScan()
            resolveFavorites()
        }
    }

    /** Call when the app comes back to the front, and after the user answers the permission prompt. */
    fun refreshAccess() {
        val granted = StorageAccess.hasAccess(getApplication())
        _state.update { it.copy(hasAccess = granted) }
        if (!granted) return
        val neverScanned = lastScanAt == 0L
        val stale = SystemClock.elapsedRealtime() - lastScanAt > RESCAN_AFTER_MS
        if (scanJob?.isActive != true && (neverScanned || stale)) startScan()
        // Files may have changed while the app was in the background.
        resolveFavorites()
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    fun selectTab(tab: HomeTab) {
        _state.update { it.copy(tab = tab, selected = emptySet()) }
    }

    fun setSheet(anchor: SheetAnchor) {
        _state.update { it.copy(sheet = anchor) }
    }

    fun selectSort(field: SortField) {
        _state.update {
            val spec = it.sort.select(field)
            it.copy(sort = spec, recent = it.scan.recent.sortedBySpec(spec))
        }
        sortOpenFiles()
        resortBrowser()
    }

    // ---- Home folders (Downloads, Images, ...) ----

    fun openCategory(category: Category) {
        _state.update { it.copy(openCategory = category, openFiles = emptyList(), selected = emptySet()) }
        sortOpenFiles()
    }

    fun closeCategory() {
        sortJob?.cancel()
        _state.update { it.copy(openCategory = null, openFiles = emptyList(), selected = emptySet()) }
    }

    // ---- Selection and actions ----

    /** Ticks or unticks one item. The first tick starts selection mode, the last untick ends it. */
    fun toggleSelect(path: String) {
        _state.update {
            val now = it.selected
            it.copy(selected = if (path in now) now - path else now + path)
        }
    }

    fun clearSelection() {
        _state.update { if (it.selected.isEmpty()) it else it.copy(selected = emptySet()) }
    }

    /** If everything selected is already a favorite, removes them all. Otherwise adds them all. */
    fun toggleFavoriteSelected() {
        val chosen = _state.value.selected.filter { !isPrivatePath(it) }.toSet()
        if (chosen.isEmpty()) {
            clearSelection()
            return
        }
        val current = _state.value.favorites
        val next = if (chosen.all { it in current }) current - chosen else current + chosen
        favoritesStore.save(next)
        _state.update { it.copy(favorites = next, selected = emptySet()) }
        resolveFavorites()
    }

    /** Renames the one selected item. [newName] is the full new name, extension included. */
    fun renameSelected(newName: String) {
        val path = _state.value.selected.singleOrNull() ?: return
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/') || name == "." || name == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val old = File(path)
        val target = File(old.parentFile, name)
        if (target.path == old.path) {
            clearSelection()
            return
        }
        viewModelScope.launch {
            val renamed = withContext(Dispatchers.IO) {
                val ok = !target.exists() && old.renameTo(target)
                if (ok) MediaScannerConnection.scanFile(getApplication(), arrayOf(old.path, target.path), null, null)
                ok
            }
            if (!renamed) {
                _events.tryEmit(R.string.rename_failed)
                return@launch
            }
            val favorites = _state.value.favorites
            val nextFavorites = if (old.path in favorites) favorites - old.path + target.path else favorites
            if (nextFavorites != favorites) favoritesStore.save(nextFavorites)
            _state.update { it.copy(favorites = nextFavorites, selected = emptySet()) }
            reloadAfterChange()
            startScan()
        }
    }

    /** Deletes everything selected. Folders go with all that is inside them. The screen asks first. */
    fun deleteSelected() {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet(), busy = true) }
        viewModelScope.launch {
            val removed = withContext(Dispatchers.IO) {
                for (path in paths) {
                    val file = File(path)
                    if (file.isDirectory) file.deleteRecursively() else file.delete()
                }
                MediaScannerConnection.scanFile(getApplication(), paths.toTypedArray(), null, null)
                paths.filter { !File(it).exists() }
            }
            if (removed.size < paths.size) _events.tryEmit(R.string.delete_failed)

            applyRemoved(removed)
        }
    }

    /**
     * Drops items that are gone from the lists and from Favorites right away, instead of scanning
     * everything again, and ends the "Working…" card.
     */
    private suspend fun applyRemoved(removed: List<String>) {
        val pruned = withContext(Dispatchers.Default) { withoutPaths(_state.value.scan, removed) }
        val favorites = _state.value.favorites
        val kept = favorites.filterNot { fav ->
            removed.any { gone -> fav == gone || fav.startsWith("$gone/") }
        }.toSet()
        if (kept.size != favorites.size) favoritesStore.save(kept)
        _state.update {
            it.copy(
                scan = pruned,
                counts = pruned.byCategory.mapValues { entry -> entry.value.size },
                recent = pruned.recent.sortedBySpec(it.sort),
                favorites = kept,
                busy = false,
            )
        }
        sortOpenFiles()
        reloadAfterChange()
    }

    /** Copy or Move was tapped: remember the selection and let the user pick a folder in the browser. */
    fun startClip(move: Boolean) {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(clip = Clip(paths, move), selected = emptySet()) }
        // Copying out of Private starts at the top of storage, since that is where things go.
        val current = _state.value.browserPath
        if (current == null || isPrivatePath(current)) openStorage()
    }

    fun cancelClip() {
        _state.update { it.copy(clip = null) }
    }

    /** Pastes the waiting items into the folder the browser is showing. */
    fun pasteHere() {
        val clip = _state.value.clip ?: return
        val dest = _state.value.browserPath ?: return
        _state.update { it.copy(busy = true) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                val outcome = FileOps.paste(File(dest), clip.paths, clip.move)
                val touched = ArrayList<String>()
                touched.addAll(FileOps.filesUnder(outcome.done.map { it.second }))
                if (clip.move) touched.addAll(clip.paths)
                if (touched.isNotEmpty()) {
                    MediaScannerConnection.scanFile(getApplication(), touched.toTypedArray(), null, null)
                }
                outcome
            }
            if (result.skipped > 0) _events.tryEmit(R.string.paste_skipped)
            if (result.failed > 0) _events.tryEmit(R.string.paste_failed)

            // A moved favorite stays a favorite at its new place.
            var favorites = _state.value.favorites
            if (clip.move) {
                for ((from, to) in result.done) {
                    favorites = favorites.map { FileOps.remap(it, from, to) ?: it }.toSet()
                }
                if (favorites != _state.value.favorites) favoritesStore.save(favorites)
            }
            _state.update { it.copy(clip = null, busy = false, favorites = favorites) }
            reloadAfterChange()
            if (result.done.isNotEmpty()) startScan()
        }
    }

    /** Creates a folder inside the folder the browser is showing. */
    fun createFolder(name: String) {
        val dir = _state.value.browserPath ?: return
        val clean = name.trim()
        if (clean.isEmpty() || clean.contains('/') || clean == "." || clean == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val target = File(dir, clean)
        viewModelScope.launch {
            val created = withContext(Dispatchers.IO) { !target.exists() && target.mkdir() }
            if (created) loadBrowser(dir) else _events.tryEmit(R.string.folder_failed)
        }
    }

    // ---- Private ----

    fun isPrivatePath(path: String): Boolean = path == privateRootPath || path.startsWith("$privateRootPath/")

    /** The top folder the browser stops at: Private for Private paths, shared storage for the rest. */
    fun rootOf(path: String): String =
        if (isPrivatePath(path)) privateRootPath else StorageAccess.root().absolutePath

    fun unlockPrivate() {
        _state.update { it.copy(privateUnlocked = true) }
        refreshPrivateCount()
    }

    /** Locks Private and closes anything that shows it. */
    fun lockPrivate() {
        val s = _state.value
        if (!s.privateUnlocked) return
        val browsingPrivate = s.browserPath?.let { isPrivatePath(it) } == true
        val clipHasPrivate = s.clip?.paths?.any { isPrivatePath(it) } == true
        val selectionHasPrivate = s.selected.any { isPrivatePath(it) }
        _state.update {
            it.copy(
                privateUnlocked = false,
                privateCount = 0,
                clip = if (clipHasPrivate) null else it.clip,
                selected = if (selectionHasPrivate) emptySet() else it.selected,
            )
        }
        if (browsingPrivate) closeBrowser()
        Thumbnails.clear()
    }

    fun openPrivate() {
        privateDir.mkdirs()
        openFolder(privateRootPath)
    }

    /** The app left the screen. Remember when, so Private can lock if the user stays away a while. */
    fun onBackgrounded() {
        leftAt = SystemClock.elapsedRealtime()
    }

    fun onForegrounded() {
        if (leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > PRIVATE_RELOCK_MS) lockPrivate()
    }

    /** Moves the selected items into Private. They disappear from everywhere else. */
    fun moveSelectedToPrivate() {
        if (!_state.value.privateUnlocked) return
        val paths = _state.value.selected.filter { !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet(), busy = true) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                privateDir.mkdirs()
                val outcome = FileOps.paste(privateDir, paths, move = true)
                MediaScannerConnection.scanFile(getApplication(), paths.toTypedArray(), null, null)
                outcome
            }
            if (result.failed > 0) _events.tryEmit(R.string.paste_failed)
            applyRemoved(result.done.map { it.first })
        }
    }

    private fun refreshPrivateCount() {
        if (!_state.value.privateUnlocked) return
        viewModelScope.launch(Dispatchers.IO) {
            val count = privateDir.list()?.size ?: 0
            _state.update { it.copy(privateCount = count) }
        }
    }

    private fun withoutPaths(data: ScanData, removed: List<String>): ScanData {
        val exact = removed.toHashSet()
        val prefixes = removed.map { "$it/" }
        fun gone(file: FileItem): Boolean = file.path in exact || prefixes.any { file.path.startsWith(it) }
        return ScanData(
            byCategory = data.byCategory.mapValues { entry -> entry.value.filterNot { gone(it) } },
            recent = data.recent.filterNot { gone(it) },
        )
    }

    private fun reloadAfterChange() {
        resolveFavorites()
        refreshPrivateCount()
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    // ---- Favorites ----

    /** Looks up the saved paths on disk. Ones that no longer exist are simply not shown. */
    private fun resolveFavorites() {
        val paths = _state.value.favorites
        favoritesJob?.cancel()
        favoritesJob = viewModelScope.launch(Dispatchers.IO) {
            val folders = ArrayList<FolderItem>()
            val files = ArrayList<FileItem>()
            for (path in paths) {
                if (isPrivatePath(path)) continue
                val folder = FolderLister.folderAt(path)
                if (folder != null) {
                    folders.add(folder)
                } else {
                    val file = FolderLister.fileAt(path)
                    if (file != null) files.add(file)
                }
            }
            val sortedFolders = folders.sortedBy { it.name.lowercase() }
            val sortedFiles = files.sortedBy { it.name.lowercase() }
            _state.update { it.copy(favoriteFolders = sortedFolders, favoriteFiles = sortedFiles) }
        }
    }

    // ---- Folder browser ----

    /** Opens the root of shared storage. */
    fun openStorage() {
        openFolder(StorageAccess.root().absolutePath)
    }

    fun openFolder(path: String) {
        browserListing = null
        _state.update {
            it.copy(
                selected = emptySet(),
                browserPath = path,
                browserLoading = true,
                browserFailed = false,
                browserFolders = emptyList(),
                browserFiles = emptyList(),
            )
        }
        loadBrowser(path)
    }

    /** Goes one folder up. From the top of storage it closes the browser. */
    fun browserUp() {
        val path = _state.value.browserPath ?: return
        val root = rootOf(path)
        val parent = File(path).parent
        if (path == root || parent == null || !parent.startsWith(root)) {
            closeBrowser()
        } else {
            openFolder(parent)
        }
    }

    fun closeBrowser() {
        browserJob?.cancel()
        browserSortJob?.cancel()
        browserListing = null
        _state.update {
            it.copy(
                clip = null,
                selected = emptySet(),
                browserPath = null,
                browserLoading = false,
                browserFailed = false,
                browserFolders = emptyList(),
                browserFiles = emptyList(),
            )
        }
    }

    private fun loadBrowser(path: String) {
        browserJob?.cancel()
        browserJob = viewModelScope.launch(Dispatchers.IO) {
            val listing = FolderLister.list(File(path))
            val spec = _state.value.sort
            val folders = listing.folders.sortedFoldersBySpec(spec)
            val files = listing.files.sortedBySpec(spec)
            _state.update {
                if (it.browserPath == path) {
                    browserListing = listing
                    it.copy(
                        browserLoading = false,
                        browserFailed = listing.failed,
                        browserFolders = folders,
                        browserFiles = files,
                    )
                } else {
                    it
                }
            }
        }
    }

    /** The sort changed: reorder what is already loaded. */
    private fun resortBrowser() {
        val path = _state.value.browserPath ?: return
        val listing = browserListing ?: return
        val spec = _state.value.sort
        browserSortJob?.cancel()
        browserSortJob = viewModelScope.launch(Dispatchers.Default) {
            val folders = listing.folders.sortedFoldersBySpec(spec)
            val files = listing.files.sortedBySpec(spec)
            _state.update {
                if (it.browserPath == path) it.copy(browserFolders = folders, browserFiles = files) else it
            }
        }
    }

    // ---- Scanning ----

    private fun startScan() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _state.update { it.copy(scanning = true) }
            try {
                // The first scan shows progress as it goes. Later scans only replace the numbers
                // when they are complete, so counts never drop back while a rescan is running.
                val progressive = lastScanAt == 0L
                var latest: ScanData? = null
                scanner.scan(StorageAccess.root()) { data ->
                    if (progressive) applyScan(data) else latest = data
                }
                latest?.let { applyScan(it) }
                lastScanAt = SystemClock.elapsedRealtime()
            } finally {
                _state.update { it.copy(scanning = false) }
            }
        }
    }

    /** Called from the scanner's thread. Cheap on purpose: only the small recent list is sorted here. */
    private fun applyScan(data: ScanData) {
        _state.update {
            it.copy(
                scan = data,
                counts = data.byCategory.mapValues { entry -> entry.value.size },
                recent = data.recent.sortedBySpec(it.sort),
            )
        }
        sortOpenFiles()
    }

    /** Sorting a folder with tens of thousands of files happens off the main thread. */
    private fun sortOpenFiles() {
        val current = _state.value
        val category = current.openCategory ?: return
        val source = current.scan.byCategory[category].orEmpty()
        val spec = current.sort
        sortJob?.cancel()
        sortJob = viewModelScope.launch(Dispatchers.Default) {
            val sorted = source.sortedBySpec(spec)
            _state.update { if (it.openCategory == category) it.copy(openFiles = sorted) else it }
        }
    }

    private companion object {
        const val RESCAN_AFTER_MS = 60_000L
        const val PRIVATE_RELOCK_MS = 60_000L
    }
}
