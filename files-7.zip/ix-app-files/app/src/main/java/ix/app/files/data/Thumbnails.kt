package ix.app.files.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/**
 * Small square previews for images and videos.
 * Decoding happens off the main thread, three at a time, and finished previews stay in a memory cache.
 */
object Thumbnails {

    private val cache = object : LruCache<String, Bitmap>(cacheSizeKb()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount / 1024
    }
    private val failed: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val gate = Semaphore(3)

    private fun cacheSizeKb(): Int = (Runtime.getRuntime().maxMemory() / 1024 / 12).toInt()

    private fun keyOf(file: FileItem, px: Int) = "${file.path}|${file.modifiedMillis}|$px"

    /** Forgets every preview, for example when Private locks. */
    fun clear() {
        cache.evictAll()
        failed.clear()
    }

    /** The preview if it is already in memory. Safe to call while composing. */
    fun peek(file: FileItem, px: Int): Bitmap? = cache.get(keyOf(file, px))

    /** True if this file was tried before and could not be decoded. */
    fun hasFailed(file: FileItem, px: Int): Boolean = keyOf(file, px) in failed

    /** Returns the preview, decoding it first if needed. Null means the file has no preview. */
    suspend fun load(file: FileItem, px: Int): Bitmap? {
        val key = keyOf(file, px)
        cache.get(key)?.let { return it }
        if (key in failed) return null
        val bitmap = gate.withPermit {
            currentCoroutineContext().ensureActive()
            withContext(Dispatchers.IO) { decode(file, px) }
        }
        if (bitmap != null) cache.put(key, bitmap) else failed.add(key)
        return bitmap
    }

    private fun decode(file: FileItem, px: Int): Bitmap? = try {
        when (file.kind) {
            FileKind.Image -> decodeImage(file, px)
            FileKind.Video -> decodeVideo(file.path, px)
            else -> null
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }

    private fun decodeImage(file: FileItem, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // Let the decoder shrink the picture while reading, so a 12 MP photo never fills memory.
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val source = BitmapFactory.decodeFile(file.path, options) ?: return null

        val square = ThumbnailUtils.extractThumbnail(source, px, px)
        val degrees = if (file.extension == "jpg" || file.extension == "jpeg") exifDegrees(file.path) else 0
        if (degrees == 0) return square
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(square, 0, 0, square.width, square.height, matrix, true)
    }

    private fun decodeVideo(path: String, px: Int): Bitmap? {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(path)
            // A negative time asks for whichever frame the system thinks represents the video.
            val frame = retriever.getFrameAtTime(-1L) ?: return null
            return ThumbnailUtils.extractThumbnail(frame, px, px)
        } finally {
            retriever.release()
        }
    }

    private fun exifDegrees(path: String): Int = try {
        when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }
}
