package ix.app.files

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.activity.viewModels
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ix.app.files.cast.CastHub
import ix.app.files.data.StorageAccess
import ix.app.files.data.ThemeMode
import ix.app.files.ui.home.HomeScreen
import ix.app.files.ui.home.HomeViewModel
import ix.app.files.ui.home.WelcomeScreen
import ix.app.files.ui.theme.IxFilesTheme
import java.io.File

class MainActivity : ComponentActivity() {

    private val viewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // A rotation re-delivers the same intent, and it must not reopen the folder the person has left.
        if (savedInstanceState == null) openFolderFrom(intent)
        CastHub.init(applicationContext)
        // First frame: follow the phone. The effect below corrects it if the user picked a look in the menu.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        setContent {
            val mode by viewModel.themeMode.collectAsStateWithLifecycle()
            val secure by viewModel.secureScreen.collectAsStateWithLifecycle()
            val welcome by viewModel.showWelcome.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            // The welcome pages are always dark, so the status and navigation icons must be light on them,
            // even on a phone that is set to the light look.
            val dark = welcome || when (mode) {
                ThemeMode.System -> systemDark
                ThemeMode.Light -> false
                ThemeMode.Dark -> true
            }

            // Dark bars get light icons and the other way round, in whichever look is showing.
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                )
                onDispose { }
            }

            // While Private is on screen: no screenshots, and a blank card in the Recent apps screen.
            DisposableEffect(secure) {
                if (secure) {
                    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                onDispose { }
            }

            IxFilesTheme(dark = dark) {
                if (welcome) {
                    WelcomeScreen(onFinish = viewModel::finishWelcome)
                } else {
                    HomeScreen(viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openFolderFrom(intent)
    }

    /**
     * Other apps can ask for a folder ("show in folder", "all downloads"). It opens in the browser, as long as
     * the app is allowed to see storage and the folder is really inside it.
     */
    private fun openFolderFrom(intent: Intent?) {
        if (intent == null || !StorageAccess.hasAccess(this)) return
        val path = when (intent.action) {
            ACTION_VIEW_DOWNLOADS -> downloadsPath()
            Intent.ACTION_VIEW -> intent.data?.let { folderPathOf(it) }
            else -> null
        } ?: return
        val folder = File(path)
        val root = StorageAccess.root().canonicalFile
        val canonical = try {
            folder.canonicalFile
        } catch (e: Exception) {
            return
        }
        if (canonical.isDirectory && (canonical == root || canonical.path.startsWith(root.path + "/"))) {
            viewModel.openFolder(canonical.path)
        }
    }

    @Suppress("DEPRECATION")
    private fun downloadsPath(): String =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path

    /** The folder a link points to: a plain file link, this app's own picker link, or the system's "primary:" link. */
    private fun folderPathOf(uri: Uri): String? {
        val root = StorageAccess.root().path
        return when (uri.scheme) {
            "file" -> uri.path
            "content" -> try {
                val id = DocumentsContract.getDocumentId(uri)
                when {
                    uri.authority == "$packageName.documents" -> id
                    uri.authority == "com.android.externalstorage.documents" && id.startsWith("primary:") ->
                        "$root/${id.removePrefix("primary:")}"
                    else -> null
                }
            } catch (e: Exception) {
                null
            }
            else -> null
        }
    }

    private companion object {
        const val ACTION_VIEW_DOWNLOADS = "android.intent.action.VIEW_DOWNLOADS"
    }
}
