package ix.app.files.ui.home

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Arrangement
import ix.app.files.R
import ix.app.files.data.ArchiveFormat
import ix.app.files.data.Checksums
import ix.app.files.data.FileOps
import ix.app.files.data.JobControl
import ix.app.files.data.JobStopped
import ix.app.files.data.RenameRule
import ix.app.files.data.TextFiles
import ix.app.files.data.VaultNames
import ix.app.files.ui.components.FileIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.OpenMime
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.format.FormatStyle


private enum class SelectionDialog { None, Rename, RenameMany, Delete, Details }

/** One tile in the "More" sheet. */
private class MoreEntry(val label: String, val glyph: List<String>, val onClick: () -> Unit)

/**
 * Shown while anything is selected: a bar on top with the count, and a floating bar of actions
 * at the bottom. Back (or the X) leaves selection mode.
 */
@Composable
fun SelectionOverlay(
    paths: Set<String>,
    allFavorite: Boolean,
    inPrivate: Boolean,
    /** Float the actions as round and pill buttons, instead of one rounded bar. */
    pills: Boolean = false,
    /** One folder is selected, so it can be put on Home. */
    canPinHome: Boolean,
    /** That folder is on Home already, so the action takes it off. */
    pinnedHome: Boolean,
    onPinHome: () -> Unit,
    /** At least one selected file is a video, song or picture a TV could show. */
    canCast: Boolean,
    onCast: () -> Unit,
    /** Folders and any number of files go to a PC on the same Wi-Fi, with no limit on how many. */
    onSendToPc: () -> Unit,
    onClear: () -> Unit,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onShare: () -> Unit,
    onFavorite: () -> Unit,
    onMoveToPrivate: () -> Unit,
    onCompress: () -> Unit,
    onExtract: () -> Unit,
    onRename: (String) -> Unit,
    onRenameMany: (RenameRule) -> Unit,
    onOpenAsText: (String) -> Unit,
    /** One file is selected: pick the app to open it with. */
    onOpenWith: (String) -> Unit,
    /** One web page (.html, .svg) is selected: show it in a browser. */
    onOpenInBrowser: (String) -> Unit,
    onDelete: () -> Unit,
) {
    BackHandler(onBack = onClear)
    var dialog by remember { mutableStateOf(SelectionDialog.None) }
    var moreOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val count = paths.size
    val countLabel = context.resources.getQuantityString(
        R.plurals.selected_count,
        count,
        NumberFormat.getIntegerInstance().format(count),
    )
    val clearDescription = stringResource(R.string.selection_clear)

    // What the "More" sheet offers for this selection. Each entry closes the sheet first, then does its job.
    val moreEntries = buildList {
        // One file: choose the app to open it with. Web pages can also go straight to a browser.
        val single = if (count == 1) File(paths.first()) else null
        if (single != null && single.isFile) {
            add(MoreEntry(context.getString(R.string.action_open_with), Glyphs.OpenWith) { onOpenWith(single.path) })
            if (OpenMime.isWebPage(VaultNames.plainName(single))) {
                add(MoreEntry(context.getString(R.string.action_open_in_browser), Glyphs.Globe) { onOpenInBrowser(single.path) })
            }
        }
        // Files in Private are locked, so they are never sent to or shown on another device.
        if (!inPrivate) {
            add(MoreEntry(context.getString(R.string.action_send_to_pc), Glyphs.Laptop) { onSendToPc() })
        }
        if (canCast && !inPrivate) {
            add(MoreEntry(context.getString(R.string.action_cast), Glyphs.Cast) { onCast() })
        }
        // Favorites and Private are for things outside Private. Inside it, neither makes sense.
        if (!inPrivate) {
            add(
                MoreEntry(
                    context.getString(if (allFavorite) R.string.action_unfavorite else R.string.action_favorite),
                    Glyphs.Star,
                ) { onFavorite() },
            )
            if (canPinHome) {
                add(
                    MoreEntry(
                        context.getString(if (pinnedHome) R.string.action_unpin_home else R.string.action_pin_home),
                        Glyphs.Home,
                    ) { onPinHome() },
                )
            }
            add(MoreEntry(context.getString(R.string.action_private), Glyphs.Lock) { onMoveToPrivate() })
        }
        // Any single file can be read as text, whatever it is called. Names the reader opens by itself
        // are left out, because tapping them already does it.
        if (single != null && single.isFile && !TextFiles.isTextName(VaultNames.plainName(single))) {
            add(MoreEntry(context.getString(R.string.action_open_as_text), Glyphs.Docs) { onOpenAsText(single.path) })
        }
        if (count >= 1) {
            add(
                MoreEntry(context.getString(R.string.action_rename), Glyphs.Edit) {
                    dialog = if (count == 1) SelectionDialog.Rename else SelectionDialog.RenameMany
                },
            )
        }
        // Zipping and extracting read files as they are stored, so they are left out inside Private.
        if (!inPrivate) {
            add(MoreEntry(context.getString(R.string.action_compress), Glyphs.Archive) { onCompress() })
        }
        if (!inPrivate && paths.all { ArchiveFormat.of(File(it).name) != null }) {
            add(MoreEntry(context.getString(R.string.action_extract), Glyphs.Downloads) { onExtract() })
        }
        add(MoreEntry(context.getString(R.string.action_details), Glyphs.Info) { dialog = SelectionDialog.Details })
    }

    Box(Modifier.fillMaxSize()) {
        // Top bar. It covers the screen's own header, so it also swallows taps.
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .drawBehind {
                    drawRect(IxColors.Background)
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(IxColors.Glow, IxColors.Glow.copy(alpha = 0f)),
                            center = Offset(size.width / 2f, 0f),
                            radius = size.width * 0.95f,
                        ),
                    )
                }
                .pointerInput(Unit) { detectTapGestures { } }
                .statusBarsPadding()
                .height(56.dp)
                .padding(start = 10.dp, end = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onClear)
                    .semantics { contentDescription = clearDescription },
                contentAlignment = Alignment.Center,
            ) {
                PathIcon(Glyphs.Close, tint = IxColors.TextPrimary, size = 26.dp, strokeWidth = 1.8f)
            }
            Text(
                text = countLabel,
                color = IxColors.TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp),
            )
            Text(
                text = stringResource(R.string.select_all),
                color = IxColors.TextPrimary,
                fontSize = 17.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onSelectAll)
                    .padding(horizontal = 8.dp, vertical = 10.dp),
            )
        }

        // Floating action bar
        if (pills) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(start = 18.dp, end = 18.dp, bottom = 14.dp)
                    .pointerInput(Unit) { detectTapGestures { } },
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    Modifier.padding(start = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    PathIcon(Glyphs.Docs, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 1.8f)
                    Text(
                        text = NumberFormat.getIntegerInstance().format(count),
                        color = IxColors.TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                val deleteDescription = stringResource(R.string.action_delete)
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(IxColors.Danger.copy(alpha = 0.28f))
                        .clickable(role = Role.Button) { dialog = SelectionDialog.Delete }
                        .semantics { contentDescription = deleteDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.Trash, tint = IxColors.Danger, size = 24.dp, strokeWidth = 1.8f)
                }
                PillButton(
                    label = stringResource(R.string.action_move),
                    background = IxColors.Chip,
                    content = IxColors.TextPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onMove,
                )
                PillButton(
                    label = stringResource(R.string.action_share),
                    background = IxColors.TextPrimary,
                    content = IxColors.Background,
                    modifier = Modifier.weight(1f),
                    onClick = onShare,
                )
                val moreDescription = stringResource(R.string.action_more)
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(IxColors.Chip)
                        .clickable(role = Role.Button) { moreOpen = true }
                        .semantics { contentDescription = moreDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.More, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
                }
            }
        } else {
            // A soft fade so rows do not run into the bar, then the frosted bar itself.
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(120.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(IxColors.Background.copy(alpha = 0f), IxColors.Background.copy(alpha = 0.92f)),
                        ),
                    ),
            )
            val barShape = RoundedCornerShape(36.dp)
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, bottom = 22.dp)
                    .height(72.dp)
                    .clip(barShape)
                    .background(IxColors.Glass)
                    .border(1.dp, IxColors.GlassBorder, barShape)
                    .pointerInput(Unit) { detectTapGestures { } },
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ActionButton(Glyphs.Copy, stringResource(R.string.action_copy), onClick = onCopy)
                ActionButton(Glyphs.Move, stringResource(R.string.action_move), onClick = onMove)
                ActionButton(Glyphs.Share, stringResource(R.string.action_share), onClick = onShare)
                ActionButton(
                    Glyphs.Trash,
                    stringResource(R.string.action_delete),
                    tint = IxColors.Danger,
                ) { dialog = SelectionDialog.Delete }
                ActionButton(Glyphs.More, stringResource(R.string.action_more)) { moreOpen = true }
            }
        }
    }

    if (moreOpen) {
        MoreSheet(
            paths = paths,
            countLabel = countLabel,
            entries = moreEntries,
            onDismiss = { moreOpen = false },
        )
    }

    when (dialog) {
        SelectionDialog.None -> Unit

        SelectionDialog.Rename -> NameDialog(
            title = stringResource(R.string.action_rename),
            initialName = VaultNames.plainName(File(paths.first())),
            confirmLabel = stringResource(R.string.rename_confirm),
            onConfirm = { name ->
                dialog = SelectionDialog.None
                onRename(name)
            },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.RenameMany -> BatchRenameDialog(
            files = remember(paths) { paths.map { File(it) } },
            onConfirm = { rule ->
                dialog = SelectionDialog.None
                onRenameMany(rule)
            },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.Details -> DetailsSheet(
            paths = remember(paths) { paths.toList() },
            countLabel = countLabel,
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = SelectionDialog.None },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.action_delete)) },
            text = {
                // One item is named, so it is clear what is about to go. A folder says it takes its contents too.
                val only = if (count == 1) File(paths.first()) else null
                val onlyName = only?.let { VaultNames.plainName(it) }
                // Anything outside Private can be undone for a few seconds. Private files go for good.
                Text(
                    when {
                        only == null -> context.resources.getQuantityString(
                            if (inPrivate) R.plurals.delete_message else R.plurals.delete_ask,
                            count,
                            NumberFormat.getIntegerInstance().format(count),
                        )
                        only.isDirectory -> context.getString(
                            if (inPrivate) R.string.delete_message_folder else R.string.delete_ask_folder,
                            onlyName,
                        )
                        else -> context.getString(
                            if (inPrivate) R.string.delete_message_file else R.string.delete_ask_file,
                            onlyName,
                        )
                    },
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        dialog = SelectionDialog.None
                        onDelete()
                    },
                ) { Text(stringResource(R.string.action_delete), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { dialog = SelectionDialog.None }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ActionButton(
    glyph: List<String>,
    label: String,
    tint: Color = IxColors.TextPrimary,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .width(64.dp)
            .height(60.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        PathIcon(glyph, tint = tint, size = 22.dp, strokeWidth = 1.9f)
        Text(
            text = label,
            color = tint,
            fontSize = 13.sp,
            maxLines = 1,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

/** What the "More" and "Details" sheets are about: the item's icon, name and "size · date", or the count. */
@Composable
private fun SheetItemHeader(paths: Collection<String>, countLabel: String) {
    val single = if (paths.size == 1) File(paths.first()) else null
    val title = if (single != null) VaultNames.plainName(single) else countLabel
    val subtitle = when {
        single == null -> ""
        single.isDirectory -> modifiedLabel(single.lastModified())
        else -> stringResource(R.string.file_meta, formatFileSize(single.length()), modifiedLabel(single.lastModified()))
    }
    Row(
        Modifier.padding(bottom = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(Modifier.width(44.dp), contentAlignment = Alignment.Center) {
            if (single != null && single.isFile) {
                FileIcon(single.extension)
            } else {
                ListFolderIcon(width = 44.dp)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = IxColors.TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (subtitle.isNotEmpty()) {
                Text(text = subtitle, color = IxColors.TextSecondary, fontSize = 15.sp, maxLines = 1)
            }
        }
    }
}

/** The "More" sheet: a grid of three tiles per row, one for each extra action. */
@Composable
private fun MoreSheet(paths: Set<String>, countLabel: String, entries: List<MoreEntry>, onDismiss: () -> Unit) {
    GlassSheet(onDismiss = onDismiss) {
        SheetItemHeader(paths, countLabel)
        Column(
            Modifier.verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            entries.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { entry ->
                        MoreTile(entry, Modifier.weight(1f)) {
                            onDismiss()
                            entry.onClick()
                        }
                    }
                    // A short last row keeps its tiles as wide as the rows above.
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun MoreTile(entry: MoreEntry, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .height(88.dp)
            .clip(shape)
            .background(IxColors.Tile)
            .border(1.dp, IxColors.TileBorder, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        PathIcon(entry.glyph, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        Text(
            text = entry.label,
            color = IxColors.TextPrimary,
            fontSize = 14.sp,
            lineHeight = 16.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

/** Name, place, size and date of the selection. A folder's size is added up in the background. */
@Composable
private fun DetailsSheet(paths: List<String>, countLabel: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val details by produceState<FileOps.Details?>(null, paths) { value = FileOps.measure(paths) }
    val number = NumberFormat.getIntegerInstance()

    GlassSheet(onDismiss = onDismiss) {
        SheetItemHeader(paths, countLabel)
        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            val d = details
            if (d == null) {
                Text(
                    text = stringResource(R.string.calculating),
                    color = IxColors.TextSecondary,
                    fontSize = 17.sp,
                    modifier = Modifier.padding(vertical = 18.dp),
                )
            } else {
                val filesLabel = context.resources.getQuantityString(
                    R.plurals.details_files,
                    d.files,
                    number.format(d.files),
                )
                val sizeChips = if (d.isFolder || d.count > 1) {
                    listOf(formatFileSize(d.bytes), filesLabel)
                } else {
                    listOf(formatFileSize(d.bytes))
                }
                val listShape = RoundedCornerShape(22.dp)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(listShape)
                        .background(IxColors.Tile),
                ) {
                    if (d.count == 1) {
                        DetailRow(stringResource(R.string.detail_name), listOf(d.name), first = true)
                        DetailRow(stringResource(R.string.detail_location), listOf(d.location))
                        DetailRow(stringResource(R.string.detail_size), sizeChips)
                        DetailRow(
                            stringResource(R.string.detail_modified),
                            listOf(
                                DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
                                    .format(Instant.ofEpochMilli(d.modifiedMillis).atZone(ZoneId.systemDefault())),
                            ),
                        )
                    } else {
                        DetailRow(stringResource(R.string.detail_selected), listOf(itemsLabel(context, d.count)), first = true)
                        DetailRow(stringResource(R.string.detail_size), sizeChips)
                    }
                }
                if (d.count == 1 && !d.isFolder) {
                    Column(Modifier.padding(top = 14.dp, start = 4.dp, end = 4.dp)) { ChecksumBlock(paths.first()) }
                }
            }
        }
        PrimaryPill(
            label = stringResource(R.string.close),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp),
            onClick = onDismiss,
        )
    }
}

/**
 * One line of the details list: the label in gray on the left, the value on the right.
 * More than one value is shown as separate rounded chips, like a folder's size and file count.
 */
@Composable
private fun DetailRow(label: String, values: List<String>, first: Boolean = false) {
    Column {
        if (!first) Box(Modifier.fillMaxWidth().height(1.dp).background(IxColors.TileBorder))
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 58.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = label, color = IxColors.TextSecondary, fontSize = 17.sp)
            Spacer(Modifier.width(16.dp))
            Row(
                Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (values.size > 1) {
                    values.forEach { value ->
                        Text(
                            text = value,
                            color = IxColors.TextPrimary,
                            fontSize = 15.sp,
                            maxLines = 1,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(IxColors.TileBorder.copy(alpha = 0.18f))
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                        )
                    }
                } else {
                    Text(
                        text = values.firstOrNull().orEmpty(),
                        color = IxColors.TextPrimary,
                        fontSize = 17.sp,
                        textAlign = TextAlign.End,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/**
 * MD5, SHA-1 and SHA-256 of one file. Nothing is read until "Calculate" is tapped, because a big file takes a
 * while. Leaving the dialog stops the reading. Tapping a value copies it.
 */
@Composable
private fun ChecksumBlock(path: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var started by remember(path) { mutableStateOf(false) }
    var percent by remember(path) { mutableStateOf(0) }
    var result by remember(path) { mutableStateOf<Checksums?>(null) }
    var failed by remember(path) { mutableStateOf(false) }
    val control = remember(path) { JobControl() }
    DisposableEffect(path) { onDispose { control.cancel() } }

    LaunchedEffect(started, path) {
        if (!started) return@LaunchedEffect
        val total = File(path).length()
        control.totalBytes = total
        val poll = launch {
            while (true) {
                delay(200)
                percent = if (total > 0L) ((control.done * 100L) / total).toInt().coerceIn(0, 99) else 0
            }
        }
        try {
            result = withContext(Dispatchers.IO) { Checksums.of(File(path), control) }
        } catch (e: JobStopped) {
            // The dialog was closed.
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failed = true
        } finally {
            poll.cancel()
        }
    }

    Column {
        Text(text = stringResource(R.string.detail_checksums), color = IxColors.TextSecondary, fontSize = 12.sp)
        val done = result
        when {
            failed -> Text(
                text = stringResource(R.string.checksum_failed),
                color = IxColors.Danger,
                fontSize = 14.sp,
            )

            done != null -> {
                val copied = stringResource(R.string.checksum_copied)
                for ((label, value) in listOf("MD5" to done.md5, "SHA-1" to done.sha1, "SHA-256" to done.sha256)) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                clipboard.setText(AnnotatedString(value))
                                Toast.makeText(context, copied, Toast.LENGTH_SHORT).show()
                            }
                            .padding(top = 6.dp),
                    ) {
                        Text(text = label, color = IxColors.TextSecondary, fontSize = 11.sp)
                        Text(
                            text = value,
                            color = IxColors.TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                }
                Text(
                    text = stringResource(R.string.checksum_tap_hint),
                    color = IxColors.TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }

            started -> Text(
                text = context.getString(R.string.checksum_progress, percent.toString()),
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
            )

            else -> Box(
                Modifier
                    .padding(top = 6.dp)
                    .height(36.dp)
                    .clip(CircleShape)
                    .background(IxColors.Button)
                    .clickable(role = Role.Button) { started = true }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(R.string.checksum_calculate),
                    color = IxColors.TextPrimary,
                    fontSize = 13.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

/** A wide rounded button for the floating pill bar. */
@Composable
private fun PillButton(
    label: String,
    background: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .height(60.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, color = content, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}
