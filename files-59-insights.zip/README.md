# ix.app.files

A fast, minimal Android file manager. Kotlin, Jetpack Compose, Material 3.

Design reference: the Home mockup (dark, gray folders, bottom "Recent" sheet).
Behavior reference: [Material Files](https://github.com/zhanghai/materialfiles). It is GPL-3.0 and is
only a reference for how a file manager should behave. No code is copied from it.

## Status: Step 54 (Real lock label, side menu slides out)

| Done | Next |
| --- | --- |
| Settings page: a storage ring with Clean up, then rows in rounded cards (View, Look, Tools, Private, About), each with its current value. Reached from All settings in the side menu | |
| Short side menu from the sliders button: Home and folder looks, five tools (with Apps) and All settings. It replaces the old View and settings dialog | |
| View page: Home layout, Folder layout and Selecting as preview cards (menu, View). The menu itself is shorter and shows the current choices on one row | |
| Tidy up on the Freeform canvas shows "Layout reset · Undo" for 8 seconds, so the old layout can be put back | |
| Press and hold a day heading to select every day between it and the nearest day that has a selected file | |
| Folders you added to Home show their total size next to the item count | |
| Freeform canvas: tiles snap to a loose 24 dp grid when dropped; Tidy up in the press-and-hold menu resets the layout | |
| Tap a day heading in Timeline (or in Recent) to select all its files; tap again to deselect them | |
| Selected rows in lists get the same blue wash and blue check as tiles. With Timeline on, Favorites also shows as days of files | |
| Selected files get a blue wash and a blue check in the corner of their tile. With Timeline on, the Recent sheet shows a heading for each day | |
| Timeline view: a folder as a big folder on top, then its subfolders, then files grouped by day, each day a row of previews (menu, Layout, Timeline) | |
| Pill selection bar: the actions for selected files float as Delete, Move and Share buttons (menu, Selecting, Pills) | |
| Freeform Home: drag the folders anywhere on the canvas, press and hold an empty spot for New folder, New file and Import. Menu, Home: Grid or Freeform | |
| Welcome pages on the first start: Welcome, then Everything in one place (Next, Skip, Get started). Phones that already gave file access skip them | |
| Home layout from the mockup | |
| Real folder counts and Recent files (background scan) | |
| Folder browser: any folder, path bar, sort, new folder | |
| Favorites, saved on the device | |
| Previews: pictures, video frames, song covers, app icons, first page of PDFs | |
| Selection: copy, move, share, delete, favorite, rename, details, select all | |
| Open with: select one file, More, Open with shows every app that can open it, so you pick each time (also in the text reader menu and the picture viewer). HTML and SVG files also have Open in browser, which offers only browsers. Files in Private are opened from an unlocked temporary copy | |
| Private folder behind fingerprint, face or screen lock, with every file encrypted and every name hidden | |
| Search across every file and folder by name or extension | |
| Menu: layout, theme (system, light, dark), show hidden files, storage, duplicates, clean up | |
| Zip: compress, extract, look inside without extracting | |
| Archives open on a tap: zip, 7z, rar, tar, tar.gz, tar.bz2, tar.xz and single .gz, .bz2, .xz files; unpack from the press-and-hold menu | |
| Clean up screen: installers, temporary and empty files, empty folders, big files untouched for months | |
| Search filters: type, size and date, alone or together with text | |
| Picture viewer: swipe through a folder, pinch and double-tap zoom, Share, Open with, Delete (Private pictures too) | |
| Folder browser remembers where each folder was scrolled to, and pulls down to refresh | |
| Find in text: highlighted hits, next and previous, count. In the editor it also replaces one hit or all of them | |
| Text reader and editor: line numbers, wrap, text size, edit and save (UTF-8, up to 512 KB), Private files stay locked | |
| Duplicate finder with Select extras | |
| Batch rename: numbering, find and replace, add text, with a live preview and no overwrites | |
| Checksums: MD5, SHA-1 and SHA-256 of a file (Private files too), tap to copy | |
| Trash: deleted items wait 30 days (or 7, or not at all), restore, delete forever or empty | |
| Apps: installed apps with size, search and sort, open, info, uninstall, back up the apk (split apks too) | |
| Uninstall many apps: tick several apps, press Uninstall, and the system asks about each one in turn (Android has no single question for many apps). Saying no to one stops the rest; system apps are left out | |
| Insights (menu, Tools): suggestions with a button each, where the space is (by folder and by age), what grew since last week, the folders and files you open most, and sorting rules. Nothing moves or goes to the Trash until you tap and confirm; Trash and Undo still apply | |
| Suggestions: your rules; pictures, videos, songs and documents lying in Download (Move to Pictures, Movies, Music, Documents); old screenshots; kinds of file you keep deleting (installers, archives, temporary files only); old Download files; big files nobody touched; folders you open often (Add to Home); big folders untouched for months; folders that grew. Not now hides one for 30 days | |
| Sorting rules: where to look, which kinds or extensions, name contains, not changed for N days, then Move to a folder or Move to Trash. Six quick rules to add with a tap. A rule only creates a suggestion | |
| Habits: the app remembers, on the phone only, which files and folders you open and which kinds of file you delete (a capped list, newer opens count more). Off switch and Clear history in Insights. Private is never recorded. Sort by Most used in the sort menu | |
| Progress bar and Cancel for copy, move, zip and extract | |
| Undo for delete, move and copy (a few seconds, one level) | |
| Safer move, copies keep their date, extract checks free space | |
| Duplicates confirmed by comparing whole files | |
| Private hidden from screenshots and the Recent apps screen | |
| Unit tests for file operations, search, sorting, zip and duplicates | |
| Storage screen: usage by kind of file, largest files you can delete | |
| Home folders: press and hold to rename, change color and icon; add your own folders with the New folder tile | |
| Private key tied to the unlock: the key opens only right after a fingerprint or the screen lock, and leaves memory when Private locks. Older Private files move to it on the first unlock | |
| Add to Home: select one folder, More, Add to Home (or Remove from Home). It gets a tile you can rename, color and arrange | |
| A Home folder that was deleted or moved shows dimmed as "Folder not found"; tap it to remove the tile | |
| Saved searches: keep a search with its filters under a name (up to 20), run it again from the Saved chip, delete it | |
| Arrange: drag the Home folders, built-in and added, into your own order (press and hold, then Arrange) | |
| Cast: show videos, songs and pictures, or a whole folder of them in natural order (Episode 2 before Episode 10), on a TV, Xbox or PC on the same Wi-Fi (DLNA / UPnP). Select files, More, Cast to device; or Cast in the picture viewer. A remote at the bottom has play, pause, seek, next, previous and volume, and keeps going with the screen off | |
| Cast subtitles: a .srt next to a video (same name, or Name.en.srt) is sent to TVs that can show it, always as UTF-8 (old Windows code pages are converted using the phone's language) | |
| Cast slideshow: on a list of pictures the remote starts and stops a slideshow, 3, 5, 10 or 30 seconds a picture | |

**Private** is a folder inside the app's own storage, so other apps and the gallery can not see it.
It opens with the phone's fingerprint, face or screen lock, and locks again after the app has been
away for a minute. Every file in it is encrypted: each file gets its own random AES-256 key, sealed
with a master key that lives in the Android Keystore and never leaves the phone's secure hardware.
The content is stored in 64 KB pieces with AES-GCM, so a changed or cut-off file is noticed.
Names of files and folders are encrypted too (stored as "~" and scrambled text, with the key kept beside the folder and sealed by the same Keystore key). What is not hidden: sizes (roughly), dates and how many items a folder holds. Someone who copies the
files off the phone, even with root access, gets unreadable content. The file keys are sealed by one root key. The root key is kept in a file next to Private, sealed by a Keystore key
that only works for a minute after a strong fingerprint or the screen lock (a weak face unlock does not count).
While Private is unlocked the root key sits in memory; locking Private wipes it, so code running inside the app
on an unlocked phone can not open Private files without the user unlocking again. **If the phone's screen lock is
removed or reset to none, Android deletes that Keystore key and the files in Private can no longer be opened.**
Changing from one PIN or pattern to another is fine, and so is adding a fingerprint. Files made by earlier versions
are moved to the new key on the first unlock (only the small sealed key in each file's header changes, in place),
and the old key is removed once every file has moved. Opening or sharing a file makes a temporary readable copy that is wiped when
Private locks. Files in Private are deleted if the app is uninstalled or its data is cleared.

The app asks for **All files access** on Android 11 and up (a settings page), or the normal storage
permission on Android 8 to 10.

**Casting** uses network permissions, but only for the home network: the app looks for DLNA / UPnP media renderers
(an Xbox, a smart TV, Kodi, Windows Media Player) with SSDP, and starts a small web server on the phone that only
serves the files you picked, behind a random address that changes every time. The TV downloads the file from the
phone, so seeking works (HTTP Range) and nothing goes through the internet. Files in Private are never cast.
A foreground service (the "Casting" notification, with Stop) keeps the phone serving the file while the screen is off.
Two options in the Cast sheet help stubborn devices: "Check formats first" (skip files the device says it can not
play) and "Plain stream" (no DLNA headers). "Copy log" in the same sheet copies what happened, for bug reports.
Subtitles are sent in the forms Samsung, Philips-style and other TVs look for (an extra address in the file's description
and a header); Xbox and Windows players usually ignore them, and "Send subtitles" in the Cast sheet turns them off.
A folder is cast by selecting it and choosing Cast: its videos, songs and pictures directly inside it are played in order.
Not every device plays every format: an Xbox handles mp4 (H.264) best, mkv and avi depend on the model.

## Tests

Plain JVM tests live in `app/src/test`. Run them with `./gradlew :app:testDebugUnitTest`. The GitHub workflow runs them
before building the APK and uploads the report as `unit-test-report`.

## Build locally

Needs JDK 17 and the Android SDK (API 35).

```
./gradlew :app:assembleRelease
```

The APK lands in `app/build/outputs/apk/release/`.

## Build on GitHub

1. Create a repo and push this folder to `main`.
2. Open the **Actions** tab. **Release APK** runs on its own for every push.
   You can also start it with **Run workflow**.
3. When it finishes, open the run and download:
   - `ix.app.files-release-apk` is the installable APK.
   - `r8-mapping` is the R8 mapping file. Keep it to decode crash traces.
4. To publish a GitHub Release with the APK attached, push a tag: `git tag v0.1.0 && git push --tags`.

Without any secrets the APK is signed with the **debug key**. It installs fine and is good for testing.
Debug-signed and own-key-signed builds can't be installed over each other, so uninstall first if you switch.

### Builds that update the installed app

The **Build Files (signed, updates the installed app)** workflow signs every build with the key in `signing/ixfiles.jks`,
so each APK installs over the previous one. It puts the plain `.apk` on the Releases page as a pre-release (`build-N`).
The first time you move to it, uninstall the old app once, because the key is different. Details in `signing/README.md`.
If you use it, remove or switch off **Release APK** so a push does not build twice.

### Sign with your own key (optional)

Create a keystore once:

```
keytool -genkeypair -v -keystore release.jks -alias ixfiles -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks > release.jks.b64        # on macOS: base64 -i release.jks
```

Then add four repository secrets (Settings > Secrets and variables > Actions):

| Secret | Value |
| --- | --- |
| `IX_KEYSTORE_BASE64` | contents of `release.jks.b64` |
| `IX_KEYSTORE_PASSWORD` | the store password |
| `IX_KEY_ALIAS` | `ixfiles` (or your alias) |
| `IX_KEY_PASSWORD` | the key password |

Keep `release.jks` somewhere safe and never commit it. Losing it means you can't update installed copies.

## Project layout

```
app/src/main/java/ix/app/files/
  MainActivity.kt
  data/        models, scanner, search, folder lister, file operations, favorites and settings stores, thumbnails, storage info
  ui/theme/    colors and theme
  ui/components/  PathIcon (stroked SVG icons), FolderIcon, FileIcon
  cast/        DLNA / UPnP casting: discovery (SSDP), SOAP, file server with Range, engine, hub and foreground service
  ui/cast/     the Cast to sheet and the remote bar
  ui/home/     HomeScreen, header, tabs, category grid, recent sheet, folder browser, favorites, selection bars, name dialog, unlock, list/grid view, menu, storage screen, view model
  util/        size formatting, opening and sharing files
  insights/    habits, storage stats, suggestions and sorting rules (plain Kotlin, unit tested), and their saving
  (tests)      app/src/test/java/ix/app/files/data and .../cast
```

Icons are drawn from the same SVG paths as the mockup, so there are no icon libraries or image files.
