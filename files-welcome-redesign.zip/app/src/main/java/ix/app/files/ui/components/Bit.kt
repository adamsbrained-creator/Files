package ix.app.files.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import ix.app.files.ui.theme.Figtree

/** What Bit is doing. */
enum class BitPose {
    /** Standing, arms down. */
    Hello,

    /** Holding up a PDF, a DOC and a JPG. Drawn on a 160 x 152 sheet; the other poses use 160 x 140. */
    Files,

    /** Standing next to a padlock. */
    Lock,
}

/** Bit's body, from the Round 1 mockup. */
val BitBody = Color(0xFFE4E4E8)

/** Antenna ball, cheeks, sparkle and padlock. Follows the app's orange. */
val BitAccent = Color(0xFFFF6A2B)

private val Antenna = Color(0xFF8E8E98)
private val Ink = Color(0xFF1A1A1E)
private val Keyhole = Color(0xFF0C0C0E)
private val Paper = Color(0xFFF1F1F4)
private val PaperLine = Color(0xFFC9C9D0)

private fun parse(data: String): Path = PathParser().parsePathString(data).toPath()

private val Mouth by lazy { parse("M72 82q8 7 16 0") }
private val Shackle by lazy { parse("M116 88v-7a9 9 0 0 1 18 0v7") }

// Four-point sparkles. Each pose puts them in its own spots.
private val HelloAccentSparkle by lazy { parse("M24 27Q24 34 31 34Q24 34 24 41Q24 34 17 34Q24 34 24 27z") }
private val HelloGraySparkle by lazy { parse("M140 39Q140 44 145 44Q140 44 140 49Q140 44 135 44Q140 44 140 39z") }
private val FilesAccentSparkle by lazy { parse("M22 27Q22 34 29 34Q22 34 22 41Q22 34 15 34Q22 34 22 27z") }
private val FilesGraySparkle by lazy { parse("M140 35Q140 40 145 40Q140 40 140 45Q140 40 135 40Q140 40 140 35z") }
private val LockAccentSparkle by lazy { parse("M26 34Q26 40 32 40Q26 40 26 46Q26 40 20 40Q26 40 26 34z") }

/** One sheet of paper Bit holds: where it sits (left edge), how it tilts, and its label. */
private class Sheet(val left: Float, val tilt: Float, val label: String, val labelColor: Color)

// Drawn in this order, so JPG ends up on top.
private val Sheets = listOf(
    Sheet(left = 30f, tilt = -13f, label = "PDF", labelColor = Color(0xFFC9241F)),
    Sheet(left = 90f, tilt = 13f, label = "DOC", labelColor = Color(0xFF1F6BFF)),
    Sheet(left = 60f, tilt = 0f, label = "JPG", labelColor = Color(0xFFB8520C)),
)

/**
 * Bit, the mascot. It is drawn in the mockup's own 160-wide coordinates and scaled to the width it is given,
 * so give it the sheet's proportions: 160 x 140 for [BitPose.Hello] and [BitPose.Lock], 160 x 152 for [BitPose.Files].
 */
@Composable
fun Bit(
    pose: BitPose,
    description: String,
    modifier: Modifier = Modifier,
    body: Color = BitBody,
    accent: Color = BitAccent,
) {
    val measurer = rememberTextMeasurer()
    // Limbs are the body color with a soft shadow laid over it.
    val limb = remember(body) { lerp(body, Color.Black, 0.16f) }

    Canvas(modifier.semantics { contentDescription = description }) {
        val labelStyle = TextStyle(
            fontFamily = Figtree,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 8.5f.toSp(),
            color = Color.White,
        )

        scale(size.width / 160f, pivot = Offset.Zero) {
            roundRect(limb, 54f, 100f, 18f, 24f, 9f)
            roundRect(limb, 88f, 100f, 18f, 24f, 9f)
            if (pose != BitPose.Files) {
                ellipse(limb, 34f, 84f, 8f, 12f)
                ellipse(limb, 126f, 84f, 8f, 12f)
            }

            // Antenna
            roundRect(Antenna, 77f, 14f, 6f, 26f, 3f)
            drawCircle(accent, radius = 8f, center = Offset(80f, 14f))

            // Head and face
            roundRect(body, 38f, 36f, 84f, 74f, 30f)
            drawCircle(Ink, radius = 5.5f, center = Offset(66f, 70f))
            drawCircle(Ink, radius = 5.5f, center = Offset(94f, 70f))
            ellipse(accent, 54f, 80f, 6f, 4f, alpha = 0.45f)
            ellipse(accent, 106f, 80f, 6f, 4f, alpha = 0.45f)
            drawPath(Mouth, Ink, style = Stroke(width = 3.5f, cap = StrokeCap.Round))

            when (pose) {
                BitPose.Hello -> {
                    drawPath(HelloAccentSparkle, accent)
                    drawPath(HelloGraySparkle, Antenna)
                }

                BitPose.Files -> {
                    for (sheet in Sheets) {
                        rotate(sheet.tilt, pivot = Offset(sheet.left + 20f, 142f)) {
                            val x = sheet.left
                            roundRect(Paper, x, 98f, 40f, 44f, 6f)
                            roundRect(sheet.labelColor, x + 6f, 104f, 26f, 12f, 3f)
                            val text = measurer.measure(text = sheet.label, style = labelStyle)
                            drawText(
                                text,
                                topLeft = Offset(x + 19f - text.size.width / 2f, 113.2f - text.firstBaseline),
                            )
                            roundRect(PaperLine, x + 6f, 121f, 26f, 3.5f, 1.75f)
                            roundRect(PaperLine, x + 6f, 128f, 18f, 3.5f, 1.75f)
                        }
                    }
                    // Arms come up in front of the papers.
                    drawLine(limb, Offset(42f, 88f), Offset(52f, 119f), strokeWidth = 13f, cap = StrokeCap.Round)
                    drawCircle(limb, radius = 8.5f, center = Offset(53f, 121f))
                    drawLine(limb, Offset(118f, 88f), Offset(108f, 119f), strokeWidth = 13f, cap = StrokeCap.Round)
                    drawCircle(limb, radius = 8.5f, center = Offset(107f, 121f))

                    drawPath(FilesAccentSparkle, accent)
                    drawPath(FilesGraySparkle, Antenna)
                }

                BitPose.Lock -> {
                    roundRect(accent, 108f, 88f, 34f, 28f, 8f)
                    drawPath(Shackle, Antenna, style = Stroke(width = 5f, cap = StrokeCap.Round))
                    drawCircle(Keyhole, radius = 4f, center = Offset(125f, 101f))
                    drawPath(LockAccentSparkle, accent)
                }
            }
        }
    }
}

private fun DrawScope.roundRect(color: Color, x: Float, y: Float, width: Float, height: Float, radius: Float) =
    drawRoundRect(color, topLeft = Offset(x, y), size = Size(width, height), cornerRadius = CornerRadius(radius, radius))

private fun DrawScope.ellipse(color: Color, cx: Float, cy: Float, rx: Float, ry: Float, alpha: Float = 1f) =
    drawOval(color, topLeft = Offset(cx - rx, cy - ry), size = Size(rx * 2f, ry * 2f), alpha = alpha)
