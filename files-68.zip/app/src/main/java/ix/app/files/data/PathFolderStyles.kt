package ix.app.files.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateMapOf
import org.json.JSONObject

/**
 * The look (color, icon, icon color) the person gave to a folder inside the browser, kept by its path.
 * Home tiles keep their own looks in [FolderStyleStore]; this is for every other folder. Reading a path in a
 * composable updates it when the look changes.
 */
object PathFolderStyles {

    private val styles = mutableStateMapOf<String, FolderStyle>()
    private var prefs: SharedPreferences? = null

    /** Loads the saved looks once. Call it at start-up. */
    fun attach(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("path_folder_styles", Context.MODE_PRIVATE)
        prefs = p
        for ((path, raw) in p.all) {
            val text = raw as? String ?: continue
            try {
                val o = JSONObject(text)
                val style = FolderStyle(
                    color = if (o.has("color")) o.getInt("color") else null,
                    icon = o.optString("icon", "").takeIf { it.isNotBlank() },
                    iconColor = if (o.has("icon_color")) o.getInt("icon_color") else null,
                )
                if (!style.isDefault) styles[path] = style
            } catch (e: Exception) {
                // A damaged entry just falls back to the default look.
            }
        }
    }

    fun styleOf(path: String): FolderStyle? = styles[path]

    fun set(path: String, style: FolderStyle) {
        val clean = style.copy(name = null)
        if (clean.isDefault) {
            styles.remove(path)
            prefs?.edit()?.remove(path)?.apply()
            return
        }
        styles[path] = clean
        val o = JSONObject()
        clean.color?.let { o.put("color", it) }
        clean.icon?.let { o.put("icon", it) }
        clean.iconColor?.let { o.put("icon_color", it) }
        prefs?.edit()?.putString(path, o.toString())?.apply()
    }
}
