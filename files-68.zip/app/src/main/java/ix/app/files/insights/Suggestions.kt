package ix.app.files.insights

import ix.app.files.data.CleanerEngine
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind

enum class SuggestionKind {
    /** Files that one of the person's rules picks out. */
    Rule,

    /** Pictures, videos, songs or documents lying in Download that belong in their own folders. */
    Misplaced,
    OldScreenshots,

    /** A kind of file the person keeps deleting, and more of it is lying around. */
    DeleteHabit,
    OldDownloads,
    BigUntouched,

    /** A folder opened often that is not on Home. */
    FrequentFolder,

    /** A big folder nobody has opened or changed for months. */
    StaleFolder,

    /** A folder that grew a lot since the last snapshot. */
    Growing,

    /** Installers (apk files) that did their job long ago. */
    Installers,

    /** Zip and other archives that have sat for a while. */
    Archives,

    /** Big videos nobody has opened. */
    BigVideos,

    /** "photo (1).jpg" lying next to "photo.jpg". */
    CopyNames,
}

/** What the "do it" button of a suggestion does. Nothing happens until the person taps it. */
sealed class SuggestionAction {
    /** Tick the files, so the usual selection bar (Delete, Move, ...) takes over. */
    object Review : SuggestionAction()

    class MoveTo(val destPath: String) : SuggestionAction()

    /** Put the files in the Trash, where Undo and the Trash screen can bring them back. */
    object Trash : SuggestionAction()

    class AddToHome(val path: String) : SuggestionAction()

    class OpenFolder(val path: String) : SuggestionAction()
}

/**
 * One thing the app suggests. [subject] says what it is about: the rule's name, a folder path, an extension,
 * a kind of file. [bytes] is the space involved (for a growing folder, how much it grew).
 */
class Suggestion(
    val id: String,
    val kind: SuggestionKind,
    val subject: String,
    val files: List<FileItem>,
    val bytes: Long,
    val action: SuggestionAction,
) {
    val count: Int get() = files.size
}

/** The numbers behind the suggestions, as the person set them. The defaults are what the app always used. */
class InsightsTuning(
    val bigBytes: Long = InsightsEngine.BIG_BYTES,
    val bigDays: Int = 180,
    val staleDays: Int = 120,
    val staleFolderBytes: Long = InsightsEngine.STALE_FOLDER_BYTES,
    val growthBytes: Long = InsightsEngine.GROWTH_BYTES,
    val downloadDays: Int = 60,
    val shotDays: Int = 30,
    /** Suggestion kinds the person turned off. */
    val off: Set<SuggestionKind> = emptySet(),
    /** Full paths of folders nothing is suggested from. */
    val protectedPaths: Set<String> = emptySet(),
)

/** Everything the suggestions are worked out from. */
class InsightsInput(
    val files: List<FileItem>,
    /** Paths of the folders the scan found. */
    val folderPaths: Set<String>,
    val rootPath: String,
    val habits: Habits,
    val rules: List<SortRule>,
    /** Folders already on Home. */
    val homeFolders: Set<String>,
    /** The older snapshot to measure growth against, if there is one. */
    val baseline: StorageSnapshot?,
    /** Ids of suggestions the person said "not now" to, still in force. */
    val dismissed: Set<String>,
    val now: Long,
    val tuning: InsightsTuning = InsightsTuning(),
)

class KindStat(val kind: FileKind, val bytes: Long, val count: Int)

class ExtStat(val extension: String, val bytes: Long, val count: Int)

class HabitFile(val file: FileItem, val count: Int)

class HabitFolder(val path: String, val count: Int)

/** What the Insights screen shows. */
class InsightsReport(
    val suggestions: List<Suggestion>,
    val totalBytes: Long,
    val fileCount: Int,
    val folders: List<FolderSize>,
    val ages: List<AgeStat>,
    val growth: List<Growth>,
    /** When the snapshot the growth is measured from was taken; null while there is none yet. */
    val growthSince: Long?,
    val topFolders: List<HabitFolder>,
    val topFiles: List<HabitFile>,
    /** The sizes now, for the caller to save as the next snapshot when it is time. */
    val snapshot: StorageSnapshot,
    /** Space by kind of file, biggest first. */
    val kinds: List<KindStat>,
    /** Space by file extension, biggest first. */
    val extensions: List<ExtStat>,
    /** The biggest files of all. */
    val biggest: List<FileItem>,
    /** The newest and the oldest file, by when it last changed. */
    val newestFile: FileItem?,
    val oldestFile: FileItem?,
    /** New or changed in the last 7 days and in the last 30 days. */
    val addedWeekBytes: Long,
    val addedWeekCount: Int,
    val addedMonthBytes: Long,
    val addedMonthCount: Int,
    /** Bytes that changed on each of the last seven days, oldest first; the last is today. */
    val weekDays: List<Long>,
    val emptyFiles: Int,
    /** Space that the suggestions which end in a delete would clear, counted once. */
    val reclaimBytes: Long,
    val reclaimCount: Int,
    /** Ids of the suggestions in [reclaimBytes]. */
    val reclaimIds: Set<String>,
)

object InsightsEngine {

    private const val DAY = StorageInsights.DAY_MILLIS

    const val BIG_BYTES = 100L * 1024 * 1024
    const val STALE_FOLDER_BYTES = 500L * 1024 * 1024
    const val GROWTH_BYTES = 500L * 1024 * 1024
    private const val BIG_VIDEO_BYTES = 250L * 1024 * 1024

    private val installerExtensions = setOf("apk", "xapk", "apks", "apkm")
    private val archiveExtensions = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")

    /** Growth is only reported against a snapshot at least this old, so it means something. */
    private const val MIN_BASELINE_AGE = 1 * DAY
    private const val MAX_FILES_PER_SUGGESTION = 2000

    /** Kinds of file that are fine to suggest deleting more of once the person keeps deleting them. */
    private val disposable = setOf(
        "apk", "xapk", "apks", "apkm", "zip", "rar", "7z", "tar", "gz", "iso", "exe", "msi", "torrent",
        "tmp", "temp", "bak", "log", "crdownload", "part",
    )

    /** Folders at the top of storage that are never "stale" or worth adding to Home. */
    private val standardFolders = setOf(
        "alarms", "audiobooks", "dcim", "documents", "download", "downloads", "movies", "music",
        "notifications", "pictures", "podcasts", "recordings", "ringtones",
    )

    fun build(input: InsightsInput): InsightsReport {
        val root = input.rootPath.trimEnd('/')
        val now = input.now
        val tuning = input.tuning
        fun isProtected(path: String): Boolean {
            for (p in tuning.protectedPaths) if (path == p || path.startsWith("$p/")) return true
            return false
        }
        val files = if (tuning.protectedPaths.isEmpty()) input.files else input.files.filter { !isProtected(it.path) }
        val snapshot = StorageInsights.snapshot(files, root, now)
        val baseline = input.baseline?.takeIf { now - it.takenMillis >= MIN_BASELINE_AGE }

        val suggestions = ArrayList<Suggestion>()
        val claimed = HashSet<String>()

        fun offer(
            id: String,
            kind: SuggestionKind,
            subject: String,
            picked: List<FileItem>,
            action: SuggestionAction,
        ) {
            if (id in input.dismissed || picked.isEmpty() || kind in tuning.off) return
            val list = picked.sortedByDescending { it.sizeBytes }.take(MAX_FILES_PER_SUGGESTION)
            for (f in list) claimed.add(f.path)
            suggestions.add(Suggestion(id, kind, subject, list, list.sumOf { it.sizeBytes }, action))
        }

        fun free(list: List<FileItem>): List<FileItem> = list.filter { it.path !in claimed }

        // 1. The person's own rules come first.
        for (rule in input.rules) {
            if (!rule.enabled || !rule.valid) continue
            val hits = free(files.filter { rule.matches(it, root, now) })
            val action = if (rule.action == RuleAction.Trash) SuggestionAction.Trash else SuggestionAction.MoveTo(rule.destPath(root) ?: continue)
            offer("rule:${rule.id}", SuggestionKind.Rule, rule.name, hits, action)
        }

        // 2. Things lying in Download that have a home of their own.
        val downloads = "$root/Download/"
        val homes = listOf(
            FileKind.Image to "Pictures",
            FileKind.Video to "Movies",
            FileKind.Audio to "Music",
            FileKind.Document to "Documents",
        )
        for ((kind, dest) in homes) {
            val hits = free(files.filter { it.kind == kind && it.path.startsWith(downloads) && it.path.indexOf('/', downloads.length) < 0 && now - it.modifiedMillis >= 3 * DAY })
            if (hits.size >= 5) offer("misplaced:${kind.name}", SuggestionKind.Misplaced, dest, hits, SuggestionAction.MoveTo("$root/$dest"))
        }

        // 3. Old screenshots.
        val shots = free(
            files.filter {
                it.kind == FileKind.Image && it.path.contains("/Screenshots/", ignoreCase = true) && now - it.modifiedMillis >= tuning.shotDays * DAY
            },
        )
        if (shots.size >= 10) offer("screenshots", SuggestionKind.OldScreenshots, "Screenshots", shots, SuggestionAction.Review)

        // 4. Kinds of file the person keeps deleting.
        val habitual = input.habits.deletedExtensions.entries
            .filter { it.value >= 3 && it.key in disposable }
            .sortedByDescending { it.value }
            .take(2)
        for ((ext, _) in habitual) {
            val hits = free(files.filter { it.extension.lowercase() == ext && now - it.modifiedMillis >= 7 * DAY })
            if (hits.size >= 3) offer("deletes:$ext", SuggestionKind.DeleteHabit, ext, hits, SuggestionAction.Review)
        }

        // 5. Old things in Download.
        val oldDownloads = free(files.filter { it.path.startsWith(downloads) && now - it.modifiedMillis >= tuning.downloadDays * DAY })
        if (oldDownloads.size >= 5) offer("old-downloads", SuggestionKind.OldDownloads, "Download", oldDownloads, SuggestionAction.Review)

        // 6. Big files nobody has touched, in this app or on disk.
        val big = free(
            files.filter {
                it.sizeBytes >= tuning.bigBytes && now - it.modifiedMillis >= tuning.bigDays * DAY && input.habits.files[it.path] == null
            },
        )
        if (big.isNotEmpty()) offer("big-untouched", SuggestionKind.BigUntouched, "", big, SuggestionAction.Review)

        // 6b. Installers that did their job.
        val installers = free(files.filter { it.extension in installerExtensions })
        if (installers.size >= 2) offer("installers", SuggestionKind.Installers, "", installers, SuggestionAction.Review)

        // 6c. Copies by name: "photo (1).jpg" next to "photo.jpg".
        if (SuggestionKind.CopyNames !in tuning.off) {
            val every = HashSet<String>(files.size * 2)
            for (f in files) every.add(f.path)
            val copies = free(files.filter { CleanerEngine.isNameCopy(it, every) })
            if (copies.size >= 3) offer("copy-names", SuggestionKind.CopyNames, "", copies, SuggestionAction.Review)
        }

        // 6d. Archives that sat for a month.
        val archives = free(files.filter { it.extension in archiveExtensions && now - it.modifiedMillis >= 30 * DAY })
        if (archives.size >= 3) offer("archives", SuggestionKind.Archives, "", archives, SuggestionAction.Review)

        // 6e. Big videos nobody opened.
        val videos = free(
            files.filter {
                it.kind == FileKind.Video && it.sizeBytes >= BIG_VIDEO_BYTES && now - it.modifiedMillis >= 30 * DAY &&
                    input.habits.files[it.path] == null
            },
        )
        if (videos.isNotEmpty()) offer("big-videos", SuggestionKind.BigVideos, "", videos, SuggestionAction.Review)

        // 7. Folders the person opens a lot and has not put on Home.
        val sizes = HashMap<String, Long>()
        for (s in snapshot.folderBytes) sizes[s.key] = s.value
        for ((path, use) in input.habits.topFolders(12, now)) {
            if (suggestions.count { it.kind == SuggestionKind.FrequentFolder } >= 3) break
            if (path !in input.folderPaths || path in input.homeFolders || path == root) continue
            if (use.count < 5 || now - use.lastMillis > 30 * DAY) continue
            val parent = path.substringBeforeLast('/')
            if (parent == root && path.substringAfterLast('/').lowercase() in standardFolders) continue
            val id = "frequent:$path"
            if (id in input.dismissed || SuggestionKind.FrequentFolder in tuning.off || isProtected(path)) continue
            suggestions.add(Suggestion(id, SuggestionKind.FrequentFolder, path, emptyList(), sizes[path] ?: 0L, SuggestionAction.AddToHome(path)))
        }

        // 8. Big folders that have sat untouched.
        val staleList = if (SuggestionKind.StaleFolder in tuning.off) emptyList() else staleFolders(files, root, snapshot, input.habits, now, tuning)
        for (path in staleList.take(3)) {
            val id = "stale:$path"
            if (id in input.dismissed) continue
            suggestions.add(Suggestion(id, SuggestionKind.StaleFolder, path, emptyList(), sizes[path] ?: 0L, SuggestionAction.OpenFolder(path)))
        }

        // 9. Folders that grew.
        val growth = StorageInsights.growth(baseline, snapshot, tuning.growthBytes)
        for (g in growth.take(2)) {
            val id = "growing:${g.path}"
            if (id in input.dismissed || SuggestionKind.Growing in tuning.off) continue
            suggestions.add(Suggestion(id, SuggestionKind.Growing, g.path, emptyList(), g.deltaBytes, SuggestionAction.OpenFolder(g.path)))
        }

        val ordered = suggestions.sortedWith(compareBy<Suggestion> { it.kind != SuggestionKind.Rule }.thenByDescending { it.bytes })

        val byPath = HashMap<String, FileItem>()
        val wanted = input.habits.topFiles(8, now)
        val wantedPaths = wanted.map { it.first }.toHashSet()
        for (f in files) if (f.path in wantedPaths) byPath[f.path] = f
        val topFiles = wanted.mapNotNull { (path, use) -> byPath[path]?.let { HabitFile(it, use.count) } }
        val topFolders = input.habits.topFolders(8, now)
            .filter { it.first in input.folderPaths || it.first == root }
            .map { HabitFolder(it.first, it.second.count) }

        // The whole-storage numbers.
        val kindBytes = LongArray(FileKind.entries.size)
        val kindCounts = IntArray(FileKind.entries.size)
        val extBytes = HashMap<String, Long>()
        val extCounts = HashMap<String, Int>()
        val weekDays = LongArray(7)
        var weekBytes = 0L
        var weekCount = 0
        var monthBytes = 0L
        var monthCount = 0
        var emptyFiles = 0
        var newest: FileItem? = null
        var oldest: FileItem? = null
        val startOfToday = now - now % DAY
        for (f in files) {
            kindBytes[f.kind.ordinal] += f.sizeBytes
            kindCounts[f.kind.ordinal]++
            val ext = f.extension.ifEmpty { "-" }
            extBytes[ext] = (extBytes[ext] ?: 0L) + f.sizeBytes
            extCounts[ext] = (extCounts[ext] ?: 0) + 1
            if (f.sizeBytes == 0L) emptyFiles++
            val age = now - f.modifiedMillis
            if (age < 30 * DAY) {
                monthBytes += f.sizeBytes
                monthCount++
            }
            if (age < 7 * DAY) {
                weekBytes += f.sizeBytes
                weekCount++
                val back = ((startOfToday - f.modifiedMillis + DAY - 1) / DAY).toInt().coerceIn(0, 6)
                weekDays[6 - back] += f.sizeBytes
            }
            if (newest == null || f.modifiedMillis > newest.modifiedMillis) newest = f
            if (f.modifiedMillis > 0L && (oldest == null || f.modifiedMillis < oldest.modifiedMillis)) oldest = f
        }
        val kinds = FileKind.entries
            .map { KindStat(it, kindBytes[it.ordinal], kindCounts[it.ordinal]) }
            .filter { it.count > 0 }
            .sortedByDescending { it.bytes }
        val extensions = extBytes.entries
            .sortedByDescending { it.value }
            .take(8)
            .map { ExtStat(it.key, it.value, extCounts.getValue(it.key)) }

        // What the suggestions that end in a delete would give back.
        val reclaimable = ordered.filter { s ->
            when (s.kind) {
                SuggestionKind.BigUntouched, SuggestionKind.OldDownloads, SuggestionKind.OldScreenshots,
                SuggestionKind.DeleteHabit, SuggestionKind.Installers, SuggestionKind.Archives,
                SuggestionKind.BigVideos, SuggestionKind.CopyNames,
                -> true
                SuggestionKind.Rule -> s.action is SuggestionAction.Trash
                else -> false
            }
        }

        return InsightsReport(
            suggestions = ordered,
            totalBytes = files.sumOf { it.sizeBytes },
            fileCount = files.size,
            folders = StorageInsights.folderSizes(files, root).take(8),
            ages = StorageInsights.ageBands(files, now),
            growth = growth,
            growthSince = baseline?.takenMillis,
            topFolders = topFolders,
            topFiles = topFiles,
            snapshot = snapshot,
            kinds = kinds,
            extensions = extensions,
            biggest = files.sortedByDescending { it.sizeBytes }.take(10),
            newestFile = newest,
            oldestFile = oldest,
            addedWeekBytes = weekBytes,
            addedWeekCount = weekCount,
            addedMonthBytes = monthBytes,
            addedMonthCount = monthCount,
            weekDays = weekDays.toList(),
            emptyFiles = emptyFiles,
            reclaimBytes = reclaimable.sumOf { it.bytes },
            reclaimCount = reclaimable.sumOf { it.count },
            reclaimIds = reclaimable.map { it.id }.toSet(),
        )
    }

    /** Big folders, one or two levels down, where nothing changed for 120 days and the person has not opened them. */
    private fun staleFolders(
        files: List<FileItem>,
        root: String,
        snapshot: StorageSnapshot,
        habits: Habits,
        now: Long,
        tuning: InsightsTuning,
    ): List<String> {
        val newest = HashMap<String, Long>()
        for (file in files) {
            val dirs = StorageInsights.foldersOf(file.path, root)
            if (dirs.isEmpty()) continue
            val first = "$root/${dirs[0]}"
            newest[first] = maxOf(newest[first] ?: 0L, file.modifiedMillis)
            if (dirs.size >= 2) {
                val second = "$first/${dirs[1]}"
                newest[second] = maxOf(newest[second] ?: 0L, file.modifiedMillis)
            }
        }
        fun stale(path: String): Boolean {
            val bytes = snapshot.folderBytes[path] ?: return false
            if (bytes < tuning.staleFolderBytes) return false
            val changed = newest[path] ?: return false
            if (now - changed < tuning.staleDays * DAY) return false
            val opened = habits.folders[path]?.lastMillis ?: 0L
            return now - opened >= tuning.staleDays * DAY
        }
        val out = ArrayList<String>()
        val firstLevel = snapshot.folderBytes.keys.filter { it.substringBeforeLast('/') == root }
        for (top in firstLevel) {
            if (top.substringAfterLast('/').lowercase() in standardFolders) {
                // A standard folder as a whole is in use, but a big untouched folder inside it can still be named.
                snapshot.folderBytes.keys.filter { it.substringBeforeLast('/') == top && stale(it) }.forEach { out.add(it) }
            } else if (stale(top)) {
                out.add(top)
            } else {
                snapshot.folderBytes.keys.filter { it.substringBeforeLast('/') == top && stale(it) }.forEach { out.add(it) }
            }
        }
        return out.sortedByDescending { snapshot.folderBytes[it] ?: 0L }
    }
}
