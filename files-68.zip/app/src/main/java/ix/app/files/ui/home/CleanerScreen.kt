package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.CleanGroup
import ix.app.files.data.CleanKind
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.data.ToolPrefs
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File

private fun CleanKind.hue(): Color = when (this) {
    CleanKind.Installers -> Hue.Blue
    CleanKind.Leftovers -> Hue.Yellow
    CleanKind.EmptyFolders -> Hue.Grey
    CleanKind.CopyNames -> Hue.Pink
    CleanKind.Screenshots -> Hue.Mint
    CleanKind.Archives -> Hue.Lavender
    CleanKind.OldDownloads -> Hue.Peach
    CleanKind.LargeOld -> Hue.Slate
}

private fun CleanKind.glyph(): List<String> = when (this) {
    CleanKind.Installers -> Glyphs.Apps
    CleanKind.Leftovers -> Glyphs.Bolt
    CleanKind.EmptyFolders -> Glyphs.Folder
    CleanKind.CopyNames -> Glyphs.Copy
    CleanKind.Screenshots -> Glyphs.Images
    CleanKind.Archives -> Glyphs.Archive
    CleanKind.OldDownloads -> Glyphs.Downloads
    CleanKind.LargeOld -> Glyphs.Pie
}

private fun CleanKind.titleRes(): Int = when (this) {
    CleanKind.Installers -> R.string.cleaner_installers
    CleanKind.Leftovers -> R.string.cleaner_leftovers
    CleanKind.EmptyFolders -> R.string.cleaner_empty_folders
    CleanKind.CopyNames -> R.string.t_clean_copies
    CleanKind.Screenshots -> R.string.t_clean_screenshots
    CleanKind.Archives -> R.string.t_clean_archives
    CleanKind.OldDownloads -> R.string.t_clean_old_downloads
    CleanKind.LargeOld -> R.string.cleaner_large_old
}

/** What a kind is and how it is picked, with the person's own numbers in it. */
@Composable
private fun CleanKind.hint(prefs: ToolPrefs): String = when (this) {
    CleanKind.Installers -> stringResource(R.string.cleaner_installers_hint)
    CleanKind.Leftovers -> stringResource(R.string.t_clean_leftovers_hint, prefs.cleanSettleHours)
    CleanKind.EmptyFolders -> stringResource(R.string.cleaner_empty_folders_hint)
    CleanKind.CopyNames -> stringResource(R.string.t_clean_copies_hint)
    CleanKind.Screenshots -> stringResource(R.string.t_clean_screenshots_hint, prefs.cleanShotDays)
    CleanKind.Archives -> stringResource(R.string.t_clean_archives_hint, prefs.cleanArchiveDays)
    CleanKind.OldDownloads -> stringResource(R.string.t_clean_old_downloads_hint, prefs.cleanDownloadDays)
    CleanKind.LargeOld -> stringResource(R.string.t_clean_large_hint, formatFileSize(prefs.cleanLargeBytes), prefs.cleanLargeDays)
}

/**
 * The Clean up page: how much can go, what it is made of, and a list you tick through. Tap a line to tick it,
 * hold to open it. Nothing is deleted until the knob is slid across, and what is cleared goes to the Trash,
 * where Undo and the Trash page can bring it back.
 */
@Composable
fun CleanerScreen(
    groups: List<CleanGroup>,
    loading: Boolean,
    scanning: Boolean,
    rootPath: String,
    selection: Selection,
    prefs: ToolPrefs,
    onPrefs: (ToolPrefs) -> Unit,
    onBack: () -> Unit,
    onToggleGroup: (List<String>) -> Unit,
    onClean: () -> Unit,
    onFileClick: (FileItem) -> Unit,
    onFolderClick: (FolderItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = androidx.compose.ui.platform.LocalContext.current
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)
    var only by remember { mutableStateOf<CleanKind?>(null) }
    var collapsed by remember { mutableStateOf(setOf<CleanKind>()) }
    var sheet by remember { mutableStateOf(false) }

    // A kind that vanished (its group is empty after a new look) cannot stay as the filter.
    val filter = only?.takeIf { kind -> groups.any { it.kind == kind } }
    val shownGroups = if (filter == null) groups else groups.filter { it.kind == filter }

    val total = groups.sumOf { it.bytes }
    val allPaths = remember(groups) { groups.flatMap { it.paths } }
    val safePaths = remember(groups) { groups.filter { it.kind.safe }.flatMap { it.paths } }
    val sizeOf = remember(groups) {
        val map = HashMap<String, Long>()
        for (g in groups) for (f in g.files) map[f.path] = f.sizeBytes
        map
    }
    val picked = selection.paths
    val pickedBytes = remember(picked, sizeOf) { picked.sumOf { sizeOf[it] ?: 0L } }
    val hasPick = picked.isNotEmpty()
    val allPicked = allPaths.isNotEmpty() && allPaths.all { it in picked }
    val safePicked = safePaths.isNotEmpty() && safePaths.all { it in picked }

    Box(modifier.toolPage()) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 120.dp)) {
            item(key = "hero") {
                ToolHero(
                    hue = Hue.Mint,
                    eyebrow = stringResource(R.string.cleaner_title),
                    onBack = onBack,
                    action = { HeroIconButton(Glyphs.Sliders, stringResource(R.string.t_customize)) { sheet = true } },
                ) {
                    val shownBytes = if (hasPick) pickedBytes else total
                    val text = formatFileSize(shownBytes)
                    when {
                        loading -> {
                            HeroNumber("…")
                            HeroSub(stringResource(R.string.cleaner_loading))
                        }

                        groups.isEmpty() -> {
                            HeroNumber("0", "B")
                            HeroSub(stringResource(R.string.cleaner_empty))
                        }

                        else -> {
                            HeroNumber(text.substringBefore(' '), text.substringAfter(' ', ""))
                            HeroSub(
                                if (hasPick) {
                                    stringResource(R.string.t_clean_selected_of, formatFileSize(total))
                                } else {
                                    stringResource(R.string.t_clean_ready)
                                },
                            )
                            Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                HeroPill(
                                    label = stringResource(if (safePicked) R.string.t_clean_deselect_safe else R.string.t_clean_select_safe),
                                    filled = true,
                                    enabled = safePaths.isNotEmpty(),
                                    onClick = { onToggleGroup(safePaths) },
                                )
                                HeroPill(
                                    label = stringResource(if (allPicked) R.string.cleaner_deselect else R.string.cleaner_select),
                                    filled = false,
                                    onClick = { onToggleGroup(allPaths) },
                                )
                            }
                        }
                    }
                    if (scanning && !loading) {
                        HeroSub(stringResource(R.string.cleaner_scanning_note), Modifier.padding(top = 12.dp))
                    }
                }
            }

            if (!loading && groups.isNotEmpty()) {
                item(key = "chips") {
                    ChipRow(Modifier.padding(top = 18.dp)) {
                        ToolChip(stringResource(R.string.t_all), selected = filter == null, onClick = { only = null })
                        for (g in groups) {
                            ToolChip(
                                label = stringResource(g.kind.titleRes()),
                                selected = filter == g.kind,
                                count = g.count.toString(),
                                onClick = { only = if (filter == g.kind) null else g.kind },
                            )
                        }
                    }
                }
                item(key = "tip") {
                    Text(
                        stringResource(R.string.t_clean_tip),
                        color = IxColors.TextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                    )
                }
            }

            for (group in shownGroups) {
                val isOpen = group.kind !in collapsed
                val groupPaths = group.paths
                item(key = "h:" + group.kind.name) {
                    GroupHeader(
                        group = group,
                        prefs = prefs,
                        open = isOpen,
                        allPicked = groupPaths.all { it in picked },
                        onToggle = { onToggleGroup(groupPaths) },
                        onFold = { collapsed = if (isOpen) collapsed + group.kind else collapsed - group.kind },
                    )
                }
                if (isOpen) {
                    items(group.folders, key = { "d:" + it.path }) { folder ->
                        CleanRow(
                            title = folder.name,
                            meta = locationOf(folder.path, rootPath, rootLabel) + " · " + modifiedLabel(folder.modifiedMillis),
                            glyph = Glyphs.Folder,
                            hue = Hue.Grey,
                            picked = folder.path in picked,
                            onToggle = { selection.toggle(folder.path) },
                            onOpen = { onFolderClick(folder) },
                        )
                    }
                    items(group.files, key = { "f:" + it.path }) { file ->
                        CleanRow(
                            title = if (file.extension.isEmpty()) file.name else file.name + "." + file.extension,
                            meta = locationOf(file.path, rootPath, rootLabel) + " · " + formatFileSize(file.sizeBytes) + " · " + modifiedLabel(file.modifiedMillis),
                            glyph = kindGlyph(file.kind),
                            hue = kindHue(file.kind),
                            picked = file.path in picked,
                            onToggle = { selection.toggle(file.path) },
                            onOpen = { onFileClick(file) },
                        )
                    }
                }
            }

            if (!loading && groups.isEmpty()) {
                item(key = "empty") { ToolNote(stringResource(R.string.t_clean_empty_hint)) }
            }
        }

        if (hasPick) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, IxColors.Background)))
                    .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = bottomInset + 14.dp),
            ) {
                SlideToConfirm(
                    label = if (pickedBytes > 0L) {
                        stringResource(R.string.t_clean_slide, formatFileSize(pickedBytes))
                    } else {
                        stringResource(R.string.t_clean_slide_count, picked.size)
                    },
                    enabled = true,
                    onConfirm = onClean,
                )
            }
        }

        ToolSheet(
            visible = sheet,
            title = stringResource(R.string.t_customize),
            onClose = { sheet = false },
            footer = {
                SheetTextButton(
                    stringResource(R.string.t_reset_defaults),
                    onClick = {
                        val fresh = ToolPrefs()
                        onPrefs(
                            prefs.copy(
                                cleanOff = fresh.cleanOff, cleanLargeMb = fresh.cleanLargeMb, cleanLargeDays = fresh.cleanLargeDays,
                                cleanDownloadDays = fresh.cleanDownloadDays, cleanShotDays = fresh.cleanShotDays,
                                cleanArchiveDays = fresh.cleanArchiveDays, cleanSettleHours = fresh.cleanSettleHours,
                                extraJunk = fresh.extraJunk,
                            ),
                        )
                    },
                )
            },
        ) {
            SheetLabel(stringResource(R.string.t_clean_look_for))
            for (kind in CleanKind.entries) {
                ToolSwitchRow(
                    title = stringResource(kind.titleRes()),
                    note = kind.hint(prefs),
                    checked = kind !in prefs.cleanOff,
                    onChange = { on -> onPrefs(prefs.copy(cleanOff = if (on) prefs.cleanOff - kind else prefs.cleanOff + kind)) },
                )
            }

            SheetLabel(stringResource(R.string.t_clean_numbers))
            StepSetting(
                title = stringResource(R.string.t_clean_large_size),
                note = stringResource(R.string.t_clean_large_size_note),
                values = listOf(50, 100, 250, 500, 1024),
                value = prefs.cleanLargeMb,
                label = { mbLabel(it) },
                onChange = { onPrefs(prefs.copy(cleanLargeMb = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_clean_large_days),
                note = null,
                values = listOf(30, 60, 90, 180, 365),
                value = prefs.cleanLargeDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(cleanLargeDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_clean_download_days),
                note = null,
                values = listOf(14, 30, 60, 90, 180),
                value = prefs.cleanDownloadDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(cleanDownloadDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_clean_shot_days),
                note = null,
                values = listOf(7, 14, 30, 60, 90),
                value = prefs.cleanShotDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(cleanShotDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_clean_archive_days),
                note = null,
                values = listOf(7, 14, 30, 60, 90),
                value = prefs.cleanArchiveDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(cleanArchiveDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_clean_settle),
                note = stringResource(R.string.t_clean_settle_note),
                values = listOf(1, 6, 24, 72, 168),
                value = prefs.cleanSettleHours,
                label = { hoursLabel(context, it) },
                onChange = { onPrefs(prefs.copy(cleanSettleHours = it)) },
            )

            SheetLabel(stringResource(R.string.t_clean_yours))
            ExtraJunkEditor(prefs, onPrefs)
            ProtectedFoldersEditor(rootPath, prefs, onPrefs)
        }
    }
}

internal fun daysLabel(context: android.content.Context, days: Int): String = when {
    days >= 365 && days % 365 == 0 -> toolCount(context, R.plurals.t_years, days / 365)
    days >= 14 && days % 7 == 0 -> toolCount(context, R.plurals.t_weeks, days / 7)
    else -> toolCount(context, R.plurals.t_days, days)
}

internal fun hoursLabel(context: android.content.Context, hours: Int): String =
    if (hours >= 24 && hours % 24 == 0) toolCount(context, R.plurals.t_days, hours / 24) else toolCount(context, R.plurals.t_hours, hours)

/** The folder a thing sits in, written from the top of storage: "Download/old". */
private fun locationOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}

/** The name of a group, a "Safe" or "Look first" badge, what it holds, and Select / fold buttons. */
@Composable
private fun GroupHeader(
    group: CleanGroup,
    prefs: ToolPrefs,
    open: Boolean,
    allPicked: Boolean,
    onToggle: () -> Unit,
    onFold: () -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val meta = if (group.kind == CleanKind.EmptyFolders) {
        toolCount(context, R.plurals.cleaner_folders, group.folders.size)
    } else {
        toolCount(context, R.plurals.timeline_files, group.files.size) + " · " + formatFileSize(group.bytes)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ToolBadge(group.kind.hue(), group.kind.glyph(), size = 44.dp)
            Column(
                Modifier
                    .weight(1f)
                    .clickable(role = Role.Button, onClick = onFold)
                    .padding(horizontal = 14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        stringResource(group.kind.titleRes()),
                        color = IxColors.TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Text(
                        stringResource(if (group.kind.safe) R.string.t_clean_safe else R.string.t_clean_look_first),
                        color = Hue.Ink,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (group.kind.safe) Hue.Mint else Hue.Peach)
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
                Text(meta, color = IxColors.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(
                Modifier
                    .height(36.dp)
                    .clip(CircleShape)
                    .background(IxColors.Chip)
                    .clickable(role = Role.Button, onClick = onToggle)
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    stringResource(if (allPicked) R.string.cleaner_deselect else R.string.cleaner_select),
                    color = IxColors.TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
        }
        if (open) {
            Text(
                group.kind.hint(prefs),
                color = IxColors.TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp, start = 2.dp),
            )
        }
    }
}

/** One line of the list: a pastel badge, the name, where it is, and the orange tick. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CleanRow(
    title: String,
    meta: String,
    glyph: List<String>,
    hue: Color,
    picked: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (picked) IxColors.Accent.copy(alpha = 0.10f) else Color.Transparent)
            .combinedClickable(role = Role.Checkbox, onClick = onToggle, onLongClick = onOpen)
            .semantics { selected = picked }
            .padding(horizontal = 20.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ToolBadge(hue, glyph, size = 44.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        CheckCircle(on = picked)
    }
}
