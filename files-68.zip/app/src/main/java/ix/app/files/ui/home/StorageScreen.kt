package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import ix.app.files.data.StorageInfo
import ix.app.files.data.StorageReport
import ix.app.files.data.ToolPrefs
import ix.app.files.insights.AgeBand
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.Figtree
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import ix.app.files.util.formatStorage

private val FileKind.category: Category?
    get() = when (this) {
        FileKind.Image -> Category.Images
        FileKind.Video -> Category.Videos
        FileKind.Audio -> Category.Audio
        FileKind.Document -> Category.Docs
        FileKind.App -> Category.Apps
        FileKind.Other -> null
    }

/** The sections of the page the person can hide, by the name they are saved under. */
private val StorageSections = listOf("tiles", "largest", "big", "types", "folders", "ages")

private fun sectionTitle(name: String): Int = when (name) {
    "tiles" -> R.string.t_storage_by_type
    "largest" -> R.string.storage_largest
    "big" -> R.string.t_storage_big_files
    "types" -> R.string.t_storage_types
    "folders" -> R.string.t_storage_folders
    else -> R.string.t_storage_ages
}

private fun AgeBand.titleRes(): Int = when (this) {
    AgeBand.UnderMonth -> R.string.t_age_month
    AgeBand.Months1To6 -> R.string.t_age_1_6
    AgeBand.Months6To12 -> R.string.t_age_6_12
    AgeBand.OverYear -> R.string.t_age_year
}

private fun AgeBand.hue() = when (this) {
    AgeBand.UnderMonth -> Hue.Mint
    AgeBand.Months1To6 -> Hue.Yellow
    AgeBand.Months6To12 -> Hue.Peach
    AgeBand.OverYear -> Hue.Pink
}

/**
 * What takes the space. A pastel hero with the used space, tiles by kind of file, the biggest files, and
 * (each can be switched off under Customize) the file types, folders and ages that add up to it.
 */
@Composable
fun StorageScreen(
    storage: StorageInfo,
    report: StorageReport?,
    scanning: Boolean,
    favorites: Set<String>,
    selection: Selection,
    rootPath: String,
    prefs: ToolPrefs,
    onPrefs: (ToolPrefs) -> Unit,
    onBack: () -> Unit,
    onOpenCategory: (Category) -> Unit,
    onFileClick: (FileItem) -> Unit,
    onCleaner: () -> Unit,
    onDuplicates: () -> Unit,
    onInsights: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    var sheet by remember { mutableStateOf(false) }
    val rootLabel = stringResource(R.string.browser_root)
    fun shown(name: String) = name !in prefs.storageOff

    val usedText = formatStorage(storage.usedBytes)
    val usedValue = usedText.substringBefore(' ')
    val usedUnit = usedText.substringAfter(' ', "")

    Box(modifier.toolPage()) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 32.dp)) {
            item(key = "hero") {
                ToolHero(
                    hue = Hue.Lavender,
                    eyebrow = stringResource(R.string.menu_storage),
                    onBack = onBack,
                    action = { HeroIconButton(Glyphs.Sliders, stringResource(R.string.t_customize)) { sheet = true } },
                ) {
                    HeroNumber(usedValue, usedUnit)
                    HeroSub(stringResource(R.string.t_storage_of_used, formatStorage(storage.totalBytes)))
                    Spacer(Modifier.height(20.dp))
                    HeroBar(storage.usedFraction)
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            stringResource(R.string.t_storage_used_label, usedText),
                            color = Hue.Ink,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            stringResource(R.string.t_storage_free_label, formatStorage((storage.totalBytes - storage.usedBytes).coerceAtLeast(0L))),
                            color = Hue.Ink,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    if (report == null || scanning) {
                        Text(
                            stringResource(R.string.scanning),
                            color = Hue.Ink.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 10.dp),
                        )
                    }
                }
            }

            item(key = "actions") {
                ChipRow(Modifier.padding(top = 18.dp)) {
                    ToolChip(stringResource(R.string.t_action_cleanup), selected = true, onClick = onCleaner)
                    ToolChip(stringResource(R.string.t_action_duplicates), selected = false, onClick = onDuplicates)
                    ToolChip(stringResource(R.string.t_action_insights), selected = false, onClick = onInsights)
                }
            }

            if (report != null) {
                val rest = (storage.usedBytes - report.filesBytes).coerceAtLeast(0L)

                if (shown("tiles")) {
                    item(key = "tiles-title") { ToolSection(stringResource(R.string.t_storage_by_type)) }
                    item(key = "kind-bar") {
                        val total = storage.totalBytes.coerceAtLeast(1L).toFloat()
                        val free = (storage.totalBytes - storage.usedBytes).coerceAtLeast(0L)
                        // Weights share the whole width among the slices, so the free space is a slice too, left see-through.
                        StackBar(
                            slices = report.byKind.map { Slice(it.bytes / total, kindHue(it.kind)) } +
                                Slice(rest / total, IxColors.Handle) +
                                Slice(free / total, Color.Transparent),
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }
                    val rows = report.byKind.chunkedForTiles()
                    items(rows.size, key = { "tile-row:$it" }) { index ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            for (entry in rows[index]) {
                                val category = entry.kind.category
                                ColorTile(
                                    hue = kindHue(entry.kind),
                                    title = stringResource(kindTitle(entry.kind)),
                                    big = formatFileSize(entry.bytes),
                                    small = itemsLabel(context, entry.count),
                                    modifier = Modifier.weight(1f),
                                    onClick = if (category != null) ({ onOpenCategory(category) }) else null,
                                    height = if (rows[index].size == 1) 96.dp else 112.dp,
                                )
                            }
                        }
                    }
                    item(key = "rest-tile") {
                        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 10.dp)) {
                            ColorTile(
                                hue = Hue.Slate,
                                title = stringResource(R.string.storage_other_system),
                                big = formatFileSize(rest),
                                small = stringResource(R.string.t_storage_not_scanned),
                                height = 96.dp,
                            )
                        }
                    }
                }

                if (shown("largest") && report.largest.isNotEmpty()) {
                    item(key = "largest-title") { ToolSection(stringResource(R.string.storage_largest)) }
                    item(key = "largest-row") {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            items(report.largest.take(6), key = { "big:" + it.path }) { file ->
                                BigFileCard(file, selection, onClick = { onFileClick(file) })
                            }
                        }
                    }
                    val more = report.largest.drop(6).take((prefs.storageLargest - 6).coerceAtLeast(0))
                    if (more.isNotEmpty()) {
                        item(key = "more-title") { ToolSection(stringResource(R.string.t_storage_more_big)) }
                        items(more, key = { "more:" + it.path }) { file ->
                            FileRow(file, selection = selection, favorite = file.path in favorites, onOpen = { onFileClick(file) })
                        }
                    }
                }

                if (shown("big") && report.bigCount > 0) {
                    item(key = "big-title") { ToolSection(stringResource(R.string.t_storage_big_files)) }
                    item(key = "big-card") {
                        Box(Modifier.padding(horizontal = 16.dp)) {
                            ToolCard {
                                Column(Modifier.padding(20.dp)) {
                                    Text(
                                        formatFileSize(report.bigBytes),
                                        color = IxColors.TextPrimary,
                                        fontFamily = Figtree,
                                        fontSize = 34.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                    )
                                    Text(
                                        stringResource(R.string.t_storage_big_card, report.bigCount),
                                        color = IxColors.TextSecondary,
                                        fontSize = 15.sp,
                                        modifier = Modifier.padding(top = 4.dp),
                                    )
                                    val share = if (report.filesBytes > 0) report.bigBytes.toFloat() / report.filesBytes else 0f
                                    Spacer(Modifier.height(14.dp))
                                    StackBar(listOf(Slice(share, Hue.Peach), Slice(1f - share, Color.Transparent)), height = 10.dp)
                                    Text(
                                        stringResource(R.string.t_storage_big_share, (share * 100).toInt().coerceIn(0, 100)),
                                        color = IxColors.TextSecondary,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(top = 8.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                if (shown("types") && report.extensions.isNotEmpty()) {
                    item(key = "types-title") {
                        ToolSection(stringResource(R.string.t_storage_types), trailing = stringResource(R.string.t_storage_files_total, report.fileCount))
                    }
                    val top = report.extensions.first().bytes.coerceAtLeast(1L).toFloat()
                    items(report.extensions, key = { "ext:" + it.extension }) { ext ->
                        MeterRow(
                            label = if (ext.extension == "-") stringResource(R.string.t_storage_no_ext) else ".${ext.extension}",
                            value = formatFileSize(ext.bytes),
                            fraction = ext.bytes / top,
                            color = Hue.Lavender,
                            note = toolCount(context, R.plurals.timeline_files, ext.count),
                        )
                    }
                }

                if (shown("folders") && report.folders.isNotEmpty()) {
                    item(key = "folders-title") { ToolSection(stringResource(R.string.t_storage_folders)) }
                    val top = report.folders.first().bytes.coerceAtLeast(1L).toFloat()
                    items(report.folders, key = { "folder:" + it.path }) { folder ->
                        MeterRow(
                            label = if (folder.path == rootPath.trimEnd('/')) rootLabel else folder.path.substringAfterLast('/'),
                            value = formatFileSize(folder.bytes),
                            fraction = folder.bytes / top,
                            color = Hue.Mint,
                            note = toolCount(context, R.plurals.timeline_files, folder.files),
                        )
                    }
                }

                if (shown("ages") && report.ages.isNotEmpty()) {
                    item(key = "ages-title") { ToolSection(stringResource(R.string.t_storage_ages)) }
                    val top = (report.ages.maxOfOrNull { it.bytes } ?: 1L).coerceAtLeast(1L).toFloat()
                    items(report.ages, key = { "age:" + it.band.name }) { age ->
                        MeterRow(
                            label = stringResource(age.band.titleRes()),
                            value = formatFileSize(age.bytes),
                            fraction = age.bytes / top,
                            color = age.band.hue(),
                            note = toolCount(context, R.plurals.timeline_files, age.files),
                        )
                    }
                }
            }
        }

        ToolSheet(
            visible = sheet,
            title = stringResource(R.string.t_customize),
            onClose = { sheet = false },
            footer = {
                SheetTextButton(stringResource(R.string.t_reset_defaults), onClick = { onPrefs(prefs.copy(storageOff = emptySet(), storageLargest = 10)) })
            },
        ) {
            SheetLabel(stringResource(R.string.t_sheet_sections))
            for (name in StorageSections) {
                ToolSwitchRow(
                    title = stringResource(sectionTitle(name)),
                    note = null,
                    checked = shown(name),
                    onChange = { on -> onPrefs(prefs.copy(storageOff = if (on) prefs.storageOff - name else prefs.storageOff + name)) },
                )
            }
            SheetLabel(stringResource(R.string.t_sheet_lists))
            StepSetting(
                title = stringResource(R.string.t_storage_largest_count),
                note = stringResource(R.string.t_storage_largest_count_note),
                values = listOf(6, 10, 20, 40),
                value = prefs.storageLargest,
                label = { it.toString() },
                onChange = { onPrefs(prefs.copy(storageLargest = it)) },
            )
        }
    }
}

/** The kinds in rows for the tile grid: the biggest alone and full width, the rest two by two. */
private fun <T> List<T>.chunkedForTiles(): List<List<T>> {
    if (isEmpty()) return emptyList()
    val rows = ArrayList<List<T>>()
    rows.add(listOf(first()))
    rows.addAll(drop(1).chunked(2))
    return rows
}

/** One of the biggest files: a pastel square with its kind, then its name and "size · date". */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BigFileCard(file: FileItem, selection: Selection, onClick: () -> Unit) {
    val picked = file.path in selection.paths
    val label = if (file.extension.isEmpty()) stringResource(kindTitle(file.kind)) else ".${file.extension}"
    Column(
        Modifier
            .width(150.dp)
            .combinedClickable(
                role = Role.Button,
                onClick = { if (selection.active) selection.toggle(file.path) else onClick() },
                onLongClick = { selection.toggle(file.path) },
            ),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(112.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(kindHue(file.kind)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = label,
                color = Hue.Ink,
                fontFamily = Figtree,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 10.dp),
            )
            if (selection.active) {
                CheckCircle(on = picked, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).size(24.dp))
            }
        }
        Text(
            file.name,
            color = IxColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            formatFileSize(file.sizeBytes) + " · " + modifiedLabel(file.modifiedMillis),
            color = IxColors.TextSecondary,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
