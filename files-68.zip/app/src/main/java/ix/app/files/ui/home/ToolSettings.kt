package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.ToolPrefs
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import java.io.File

/** A one-line text box in the look of the tool pages, with an orange "Add" pill beside it. */
@Composable
internal fun AddField(
    hint: String,
    action: String,
    onAdd: (String) -> Boolean,
    modifier: Modifier = Modifier,
) {
    var text by remember { mutableStateOf("") }
    fun submit() {
        if (text.isNotBlank() && onAdd(text)) text = ""
    }
    Row(modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .weight(1f)
                .height(48.dp)
                .clip(CircleShape)
                .background(IxColors.Chip)
                .padding(horizontal = 18.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 15.sp),
                cursorBrush = SolidColor(IxColors.Accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) Text(hint, color = IxColors.TextSecondary, fontSize = 15.sp, maxLines = 1)
                        inner()
                    }
                },
            )
        }
        Box(
            Modifier
                .padding(start = 8.dp)
                .height(48.dp)
                .clip(CircleShape)
                .background(IxColors.Accent)
                .clickable(role = Role.Button) { submit() }
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(action, color = Hue.Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** A removable chip: the label, and an x. Tapping it takes the entry away. */
@Composable
internal fun RemovableChip(label: String, onRemove: () -> Unit) {
    Row(
        Modifier
            .height(38.dp)
            .clip(CircleShape)
            .background(IxColors.Chip)
            .clickable(role = Role.Button, onClick = onRemove)
            .padding(start = 14.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(label, color = IxColors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        PathIcon(Glyphs.Close, tint = IxColors.TextSecondary, size = 14.dp, strokeWidth = 2.4f)
    }
}

/**
 * Folders no tool page offers anything from: the Cleaner, Duplicates and Insights all skip them.
 * Entered as a path under the top of storage ("Documents/Taxes"); only folders that exist are accepted.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ProtectedFoldersEditor(rootPath: String, prefs: ToolPrefs, onPrefs: (ToolPrefs) -> Unit) {
    val root = rootPath.trimEnd('/')
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(stringResource(R.string.t_protect_title), color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(stringResource(R.string.t_protect_note), color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        if (prefs.protectedFolders.isNotEmpty()) {
            FlowRow(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (path in prefs.protectedFolders.sorted()) {
                    RemovableChip(path.removePrefix(root).trim('/').ifEmpty { path }) {
                        onPrefs(prefs.copy(protectedFolders = prefs.protectedFolders - path))
                    }
                }
            }
        }
        AddField(
            hint = stringResource(R.string.t_protect_hint),
            action = stringResource(R.string.t_add),
            onAdd = { typed ->
                val relative = typed.trim().trim('/').replace('\\', '/')
                val full = "$root/$relative"
                if (relative.isEmpty() || relative.split('/').any { it == ".." || it == "." } || !File(full).isDirectory) {
                    error = true
                    false
                } else {
                    error = false
                    onPrefs(prefs.copy(protectedFolders = prefs.protectedFolders + full))
                    true
                }
            },
        )
        if (error) {
            Text(stringResource(R.string.t_protect_error), color = IxColors.Danger, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, start = 6.dp))
        }
    }
}

/** Extensions the Cleaner treats as leftovers on top of its own list. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ExtraJunkEditor(prefs: ToolPrefs, onPrefs: (ToolPrefs) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(stringResource(R.string.t_junk_title), color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(stringResource(R.string.t_junk_note), color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        if (prefs.extraJunk.isNotEmpty()) {
            FlowRow(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (ext in prefs.extraJunk.sorted()) {
                    RemovableChip(".$ext") { onPrefs(prefs.copy(extraJunk = prefs.extraJunk - ext)) }
                }
            }
        }
        AddField(
            hint = stringResource(R.string.t_junk_hint),
            action = stringResource(R.string.t_add),
            onAdd = { typed ->
                val clean = typed.trim().trimStart('.').lowercase()
                if (clean.isEmpty() || clean.length > 12 || clean.any { !it.isLetterOrDigit() }) {
                    false
                } else {
                    onPrefs(prefs.copy(extraJunk = prefs.extraJunk + clean))
                    true
                }
            },
        )
    }
}

/** "50 MB", "1 GB": a size in megabytes as a chip label. */
internal fun mbLabel(mb: Int): String = if (mb >= 1024 && mb % 1024 == 0) "${mb / 1024} GB" else "$mb MB"

/** A small hint line under a group of settings. */
@Composable
internal fun SheetHint(text: String) {
    Text(text, color = IxColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
}

/** A pill-shaped search box with a magnifier. */
@Composable
internal fun SearchPill(value: String, onValue: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(CircleShape)
            .background(IxColors.Field)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PathIcon(Glyphs.Search, tint = IxColors.TextSecondary, size = 20.dp, strokeWidth = 2.2f)
        Box(Modifier.weight(1f).padding(start = 12.dp), contentAlignment = Alignment.CenterStart) {
            BasicTextField(
                value = value,
                onValueChange = onValue,
                singleLine = true,
                textStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 16.sp),
                cursorBrush = SolidColor(IxColors.Accent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (value.isEmpty()) Text(hint, color = IxColors.TextSecondary, fontSize = 16.sp, maxLines = 1)
                        inner()
                    }
                },
            )
        }
        if (value.isNotEmpty()) {
            Box(
                Modifier
                    .clip(CircleShape)
                    .clickable(role = Role.Button) { onValue("") }
                    .padding(6.dp),
            ) {
                PathIcon(Glyphs.Close, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 2.4f)
            }
        }
    }
}
