package ix.app.files.data

import android.content.Context
import androidx.compose.runtime.Immutable

/** Which copy of a set of duplicates is the one that stays when the extras are ticked. */
enum class DupKeep { Oldest, Newest, ShortName, Shallow }

/** How the duplicate groups are ordered on the Duplicates page. */
enum class DupSort { Wasted, Copies, Name }

/** What the Trash page is ordered by. */
enum class TrashSort { Newest, Oldest, Biggest, Name }

/** Which apps the Apps page lists, besides the search box. */
enum class AppFilter { All, Large, Stale, Recent }

/**
 * Everything the person can tune on the tool pages: the Cleaner, Duplicates, Insights, Apps and Trash.
 * One small immutable value, saved as a whole, so a page can change one thing with [copy] and hand it back.
 */
@Immutable
data class ToolPrefs(
    // ---- Storage ----
    /** Names of Storage page sections the person hid. */
    val storageOff: Set<String> = emptySet(),
    /** How many of the biggest files the Storage page lists. */
    val storageLargest: Int = 10,

    // ---- Cleaner ----
    /** Kinds of leftovers the Cleaner does not look for. */
    val cleanOff: Set<CleanKind> = emptySet(),
    val cleanLargeMb: Int = 100,
    val cleanLargeDays: Int = 90,
    val cleanDownloadDays: Int = 60,
    val cleanShotDays: Int = 30,
    val cleanArchiveDays: Int = 30,
    /** A file changed within this many hours may still be in use, so it is left alone. */
    val cleanSettleHours: Int = 24,
    /** Extra extensions (no dot, lowercase) the person wants treated as leftovers. */
    val extraJunk: Set<String> = emptySet(),
    /** Folders (full paths) no tool page ever offers anything from. */
    val protectedFolders: Set<String> = emptySet(),

    // ---- Duplicates ----
    val dupMinKb: Int = 100,
    val dupKeep: DupKeep = DupKeep.Oldest,
    val dupSort: DupSort = DupSort.Wasted,
    /** Kinds of file the search looks at. Empty means every kind. */
    val dupKinds: Set<FileKind> = emptySet(),

    // ---- Insights ----
    /** Names of suggestion kinds the person turned off. */
    val insightsOff: Set<String> = emptySet(),
    val insightsBigMb: Int = 100,
    val insightsBigDays: Int = 180,
    val insightsStaleDays: Int = 120,
    val insightsGrowthMb: Int = 500,
    val insightsDownloadDays: Int = 60,
    val insightsShotDays: Int = 30,

    // ---- Apps ----
    val appsSort: AppSort = AppSort.Size,
    val appsFilter: AppFilter = AppFilter.All,
    val appsSystem: Boolean = false,
    val appsLargeMb: Int = 100,
    val appsStaleMonths: Int = 6,

    // ---- Trash ----
    val trashSort: TrashSort = TrashSort.Newest,
    val trashWarnDays: Int = 3,
) {
    val cleanLargeBytes: Long get() = cleanLargeMb * 1024L * 1024L
    val dupMinBytes: Long get() = dupMinKb * 1024L
}

/** Keeps [ToolPrefs] in the app's own preferences file. */
class ToolPrefsStore(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("ix_tool_prefs", Context.MODE_PRIVATE)

    fun load(): ToolPrefs {
        val d = ToolPrefs()
        return try {
            ToolPrefs(
                storageOff = stringSet(KEY_STORAGE_OFF),
                storageLargest = prefs.getInt(KEY_STORAGE_LARGEST, d.storageLargest),
                cleanOff = enumSet(KEY_CLEAN_OFF) { name -> CleanKind.entries.firstOrNull { it.name == name } },
                cleanLargeMb = prefs.getInt(KEY_CLEAN_LARGE_MB, d.cleanLargeMb),
                cleanLargeDays = prefs.getInt(KEY_CLEAN_LARGE_DAYS, d.cleanLargeDays),
                cleanDownloadDays = prefs.getInt(KEY_CLEAN_DOWNLOAD_DAYS, d.cleanDownloadDays),
                cleanShotDays = prefs.getInt(KEY_CLEAN_SHOT_DAYS, d.cleanShotDays),
                cleanArchiveDays = prefs.getInt(KEY_CLEAN_ARCHIVE_DAYS, d.cleanArchiveDays),
                cleanSettleHours = prefs.getInt(KEY_CLEAN_SETTLE, d.cleanSettleHours),
                extraJunk = stringSet(KEY_EXTRA_JUNK),
                protectedFolders = stringSet(KEY_PROTECTED),
                dupMinKb = prefs.getInt(KEY_DUP_MIN_KB, d.dupMinKb),
                dupKeep = enumOf(KEY_DUP_KEEP, d.dupKeep) { DupKeep.valueOf(it) },
                dupSort = enumOf(KEY_DUP_SORT, d.dupSort) { DupSort.valueOf(it) },
                dupKinds = enumSet(KEY_DUP_KINDS) { name -> FileKind.entries.firstOrNull { it.name == name } },
                insightsOff = stringSet(KEY_INS_OFF),
                insightsBigMb = prefs.getInt(KEY_INS_BIG_MB, d.insightsBigMb),
                insightsBigDays = prefs.getInt(KEY_INS_BIG_DAYS, d.insightsBigDays),
                insightsStaleDays = prefs.getInt(KEY_INS_STALE_DAYS, d.insightsStaleDays),
                insightsGrowthMb = prefs.getInt(KEY_INS_GROWTH_MB, d.insightsGrowthMb),
                insightsDownloadDays = prefs.getInt(KEY_INS_DOWNLOAD_DAYS, d.insightsDownloadDays),
                insightsShotDays = prefs.getInt(KEY_INS_SHOT_DAYS, d.insightsShotDays),
                appsSort = enumOf(KEY_APPS_SORT, d.appsSort) { AppSort.valueOf(it) },
                appsFilter = enumOf(KEY_APPS_FILTER, d.appsFilter) { AppFilter.valueOf(it) },
                appsSystem = prefs.getBoolean(KEY_APPS_SYSTEM, d.appsSystem),
                appsLargeMb = prefs.getInt(KEY_APPS_LARGE_MB, d.appsLargeMb),
                appsStaleMonths = prefs.getInt(KEY_APPS_STALE_MONTHS, d.appsStaleMonths),
                trashSort = enumOf(KEY_TRASH_SORT, d.trashSort) { TrashSort.valueOf(it) },
                trashWarnDays = prefs.getInt(KEY_TRASH_WARN, d.trashWarnDays),
            )
        } catch (e: Exception) {
            d
        }
    }

    fun save(p: ToolPrefs) {
        prefs.edit()
            .putString(KEY_STORAGE_OFF, p.storageOff.joinToString(","))
            .putInt(KEY_STORAGE_LARGEST, p.storageLargest)
            .putString(KEY_CLEAN_OFF, p.cleanOff.joinToString(",") { it.name })
            .putInt(KEY_CLEAN_LARGE_MB, p.cleanLargeMb)
            .putInt(KEY_CLEAN_LARGE_DAYS, p.cleanLargeDays)
            .putInt(KEY_CLEAN_DOWNLOAD_DAYS, p.cleanDownloadDays)
            .putInt(KEY_CLEAN_SHOT_DAYS, p.cleanShotDays)
            .putInt(KEY_CLEAN_ARCHIVE_DAYS, p.cleanArchiveDays)
            .putInt(KEY_CLEAN_SETTLE, p.cleanSettleHours)
            .putString(KEY_EXTRA_JUNK, p.extraJunk.joinToString(","))
            // Paths can hold commas, so folders are kept one per line.
            .putString(KEY_PROTECTED, p.protectedFolders.joinToString("\n"))
            .putInt(KEY_DUP_MIN_KB, p.dupMinKb)
            .putString(KEY_DUP_KEEP, p.dupKeep.name)
            .putString(KEY_DUP_SORT, p.dupSort.name)
            .putString(KEY_DUP_KINDS, p.dupKinds.joinToString(",") { it.name })
            .putString(KEY_INS_OFF, p.insightsOff.joinToString(","))
            .putInt(KEY_INS_BIG_MB, p.insightsBigMb)
            .putInt(KEY_INS_BIG_DAYS, p.insightsBigDays)
            .putInt(KEY_INS_STALE_DAYS, p.insightsStaleDays)
            .putInt(KEY_INS_GROWTH_MB, p.insightsGrowthMb)
            .putInt(KEY_INS_DOWNLOAD_DAYS, p.insightsDownloadDays)
            .putInt(KEY_INS_SHOT_DAYS, p.insightsShotDays)
            .putString(KEY_APPS_SORT, p.appsSort.name)
            .putString(KEY_APPS_FILTER, p.appsFilter.name)
            .putBoolean(KEY_APPS_SYSTEM, p.appsSystem)
            .putInt(KEY_APPS_LARGE_MB, p.appsLargeMb)
            .putInt(KEY_APPS_STALE_MONTHS, p.appsStaleMonths)
            .putString(KEY_TRASH_SORT, p.trashSort.name)
            .putInt(KEY_TRASH_WARN, p.trashWarnDays)
            .apply()
    }

    private fun stringSet(key: String): Set<String> {
        val text = prefs.getString(key, null).orEmpty()
        if (text.isEmpty()) return emptySet()
        val separator = if (key == KEY_PROTECTED) '\n' else ','
        return text.split(separator).map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    private fun <T> enumSet(key: String, find: (String) -> T?): Set<T> {
        val text = prefs.getString(key, null).orEmpty()
        if (text.isEmpty()) return emptySet()
        return text.split(',').mapNotNull { find(it.trim()) }.toSet()
    }

    private fun <T> enumOf(key: String, fallback: T, parse: (String) -> T): T {
        val text = prefs.getString(key, null) ?: return fallback
        return try {
            parse(text)
        } catch (e: IllegalArgumentException) {
            fallback
        }
    }

    private companion object {
        const val KEY_STORAGE_OFF = "storage_off"
        const val KEY_STORAGE_LARGEST = "storage_largest"
        const val KEY_CLEAN_OFF = "clean_off"
        const val KEY_CLEAN_LARGE_MB = "clean_large_mb"
        const val KEY_CLEAN_LARGE_DAYS = "clean_large_days"
        const val KEY_CLEAN_DOWNLOAD_DAYS = "clean_download_days"
        const val KEY_CLEAN_SHOT_DAYS = "clean_shot_days"
        const val KEY_CLEAN_ARCHIVE_DAYS = "clean_archive_days"
        const val KEY_CLEAN_SETTLE = "clean_settle_hours"
        const val KEY_EXTRA_JUNK = "extra_junk"
        const val KEY_PROTECTED = "protected_folders"
        const val KEY_DUP_MIN_KB = "dup_min_kb"
        const val KEY_DUP_KEEP = "dup_keep"
        const val KEY_DUP_SORT = "dup_sort"
        const val KEY_DUP_KINDS = "dup_kinds"
        const val KEY_INS_OFF = "ins_off"
        const val KEY_INS_BIG_MB = "ins_big_mb"
        const val KEY_INS_BIG_DAYS = "ins_big_days"
        const val KEY_INS_STALE_DAYS = "ins_stale_days"
        const val KEY_INS_GROWTH_MB = "ins_growth_mb"
        const val KEY_INS_DOWNLOAD_DAYS = "ins_download_days"
        const val KEY_INS_SHOT_DAYS = "ins_shot_days"
        const val KEY_APPS_SORT = "apps_sort"
        const val KEY_APPS_FILTER = "apps_filter"
        const val KEY_APPS_SYSTEM = "apps_system"
        const val KEY_APPS_LARGE_MB = "apps_large_mb"
        const val KEY_APPS_STALE_MONTHS = "apps_stale_months"
        const val KEY_TRASH_SORT = "trash_sort"
        const val KEY_TRASH_WARN = "trash_warn_days"
    }
}
