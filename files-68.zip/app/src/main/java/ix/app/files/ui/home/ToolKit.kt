package ix.app.files.ui.home

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileKind
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.Figtree
import ix.app.files.ui.theme.IxColors
import kotlin.math.roundToInt

/**
 * The look the six tool pages share: a pastel hero with a big number, dark cards, pill buttons and a sheet
 * for tuning. Colors are the ones from the Round 3 mockups.
 */
internal object Hue {
    val Lavender = Color(0xFFC3B1F0)
    val Mint = Color(0xFFA8D5BA)
    val Yellow = Color(0xFFF2D07A)
    val Pink = Color(0xFFF4A6B8)
    val Blue = Color(0xFF9CCBEF)
    val Peach = Color(0xFFFFB48A)
    val Slate = Color(0xFFC9CDD6)
    val Grey = Color(0xFFD4D4DC)

    /** Text and shapes on a pastel hero. Same in the light and dark look, because the hero is always pastel. */
    val Ink = Color(0xFF14141A)
}

/** The pastel tile color of a kind of file, as in the Storage mockup. */
internal fun kindHue(kind: FileKind): Color = when (kind) {
    FileKind.Image -> Hue.Mint
    FileKind.Video -> Hue.Pink
    FileKind.Audio -> Hue.Lavender
    FileKind.Document -> Hue.Yellow
    FileKind.App -> Hue.Blue
    FileKind.Other -> Hue.Grey
}

internal fun kindGlyph(kind: FileKind): List<String> = when (kind) {
    FileKind.Image -> Glyphs.Images
    FileKind.Video -> Glyphs.Videos
    FileKind.Audio -> Glyphs.Audio
    FileKind.Document -> Glyphs.Docs
    FileKind.App -> Glyphs.Apps
    FileKind.Other -> Glyphs.Stack
}

internal fun kindTitle(kind: FileKind): Int = when (kind) {
    FileKind.Image -> R.string.category_images
    FileKind.Video -> R.string.category_videos
    FileKind.Audio -> R.string.category_audio
    FileKind.Document -> R.string.category_docs
    FileKind.App -> R.string.category_apps
    FileKind.Other -> R.string.kind_other
}

/** "3 files", "1 file": a plural from the resources, with the number formatted for the locale. */
internal fun toolCount(context: Context, plural: Int, count: Int): String =
    context.resources.getQuantityString(plural, count, java.text.NumberFormat.getIntegerInstance().format(count))

/** A full-screen page that swallows taps, so nothing underneath reacts. */
internal fun Modifier.toolPage(): Modifier = this
    .fillMaxSize()
    .background(IxColors.Background)
    .pointerInput(Unit) { detectTapGestures { } }

/**
 * The pastel top of a page: back button, optional action on the right, then whatever [content] puts there
 * (usually an [HeroNumber] and a [HeroSub]). It reaches under the status bar.
 */
@Composable
internal fun ToolHero(
    hue: Color,
    eyebrow: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val backDescription = stringResource(R.string.back_description)
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp))
            .background(hue)
            .statusBarsPadding()
            .padding(start = 14.dp, end = 14.dp, bottom = 26.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Hue.Ink.copy(alpha = 0.10f))
                    .clickable(role = Role.Button, onClick = onBack)
                    .semantics { contentDescription = backDescription },
                contentAlignment = Alignment.Center,
            ) {
                PathIcon(Glyphs.ChevronLeft, tint = Hue.Ink, size = 24.dp, strokeWidth = 2.4f)
            }
            Spacer(Modifier.weight(1f))
            if (action != null) action()
        }
        Column(Modifier.padding(horizontal = 6.dp)) {
            Text(
                text = eyebrow,
                color = Hue.Ink.copy(alpha = 0.72f),
                fontFamily = Figtree,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
            )
            content()
        }
    }
}

/** The round button at the right of a hero. */
@Composable
internal fun HeroIconButton(glyph: List<String>, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Hue.Ink.copy(alpha = 0.10f))
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = Hue.Ink, size = 22.dp, strokeWidth = 2.1f)
    }
}

/** The huge number of a hero: "206" with a smaller " GB" after it. */
@Composable
internal fun HeroNumber(value: String, unit: String = "", modifier: Modifier = Modifier) {
    Text(
        text = buildAnnotatedString {
            append(value)
            if (unit.isNotEmpty()) {
                withStyle(SpanStyle(fontSize = 28.sp, letterSpacing = 0.sp)) { append(" $unit") }
            }
        },
        color = Hue.Ink,
        fontFamily = Figtree,
        fontSize = 60.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = (-2).sp,
        lineHeight = 64.sp,
        modifier = modifier.padding(top = 2.dp, bottom = 4.dp),
    )
}

@Composable
internal fun HeroSub(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = Hue.Ink.copy(alpha = 0.78f),
        fontFamily = Figtree,
        fontSize = 17.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier,
    )
}

/** A pill on a hero. [filled] is the dark one, the other is a see-through ink wash. */
@Composable
internal fun HeroPill(label: String, filled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Box(
        modifier
            .height(46.dp)
            .clip(CircleShape)
            .background(if (filled) Hue.Ink else Hue.Ink.copy(alpha = 0.10f))
            .then(if (enabled) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (filled) Color.White.copy(alpha = if (enabled) 1f else 0.5f) else Hue.Ink.copy(alpha = if (enabled) 1f else 0.5f),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** A thin bar on a hero: [fraction] of the width in ink on a faint ink track. */
@Composable
internal fun HeroBar(fraction: Float, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Hue.Ink.copy(alpha = 0.15f)),
    ) {
        Box(
            Modifier
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(RoundedCornerShape(7.dp))
                .background(Hue.Ink),
        )
    }
}

/** The small bold title between blocks of a page, with an optional note on the right. */
@Composable
internal fun ToolSection(text: String, modifier: Modifier = Modifier, trailing: String? = null, onTrailing: (() -> Unit)? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = text,
            color = IxColors.TextPrimary,
            fontFamily = Figtree,
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f),
        )
        if (trailing != null) {
            Text(
                text = trailing,
                color = if (onTrailing != null) IxColors.Accent else IxColors.TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = if (onTrailing != null) {
                    Modifier
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onTrailing)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                } else {
                    Modifier
                },
            )
        }
    }
}

/** A rounded dark card, the background of most blocks on the pages. */
@Composable
internal fun ToolCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(IxColors.Field)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier),
        content = content,
    )
}

/** A colored tile with a name at the top and a big number and a small line at the bottom. */
@Composable
internal fun ColorTile(
    hue: Color,
    title: String,
    big: String,
    small: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    height: Dp = 112.dp,
) {
    Column(
        modifier
            .height(height)
            .clip(RoundedCornerShape(28.dp))
            .background(hue)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(title, color = Hue.Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Column {
            Text(big, color = Hue.Ink, fontFamily = Figtree, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp, maxLines = 1)
            Text(small, color = Hue.Ink.copy(alpha = 0.75f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** A filter chip. The picked one is orange. */
@Composable
internal fun ToolChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, count: String? = null) {
    Row(
        modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(if (selected) IxColors.Accent else IxColors.Chip)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = label,
            color = if (selected) Hue.Ink else IxColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
        if (count != null) {
            Text(
                text = count,
                color = if (selected) Hue.Ink.copy(alpha = 0.7f) else IxColors.TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
            )
        }
    }
}

/** A row of chips that scrolls sideways. */
@Composable
internal fun ChipRow(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/** Two or three choices in one pill; the picked one is filled with [active]. */
@Composable
internal fun ToolSegmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    active: Color = IxColors.Accent,
    activeText: Color = Hue.Ink,
) {
    Row(
        modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(IxColors.Chip)
            .padding(3.dp),
    ) {
        options.forEachIndexed { index, label ->
            val on = index == selected
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(if (on) active else Color.Transparent)
                    .clickable(role = Role.Tab) { onSelect(index) }
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    color = if (on) activeText else IxColors.TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** The tick circle at the right of a row, orange when on, as in the mockups. */
@Composable
internal fun CheckCircle(on: Boolean, modifier: Modifier = Modifier, round: Boolean = true) {
    val shape = if (round) CircleShape else RoundedCornerShape(8.dp)
    Box(
        modifier
            .size(26.dp)
            .clip(shape)
            .then(
                if (on) {
                    Modifier.background(IxColors.Accent)
                } else {
                    Modifier.border(BorderStroke(2.dp, IxColors.Handle), shape)
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (on) PathIcon(Glyphs.Check, tint = Hue.Ink, size = 16.dp, strokeWidth = 2.8f)
    }
}

/** A pastel square with a glyph, the "thumbnail" of a group or an app on the pages. */
@Composable
internal fun ToolBadge(hue: Color, glyph: List<String>, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.34f))
            .background(hue),
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = Hue.Ink, size = size * 0.5f, strokeWidth = 2f)
    }
}

/** A line with a title, a quiet note, and a switch. */
@Composable
internal fun ToolSwitchRow(title: String, note: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Switch) { onChange(!checked) }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (note != null) Text(note, color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Hue.Ink,
                checkedTrackColor = IxColors.Accent,
                checkedBorderColor = IxColors.Accent,
                uncheckedThumbColor = IxColors.TextSecondary,
                uncheckedTrackColor = IxColors.Chip,
                uncheckedBorderColor = IxColors.Outline,
            ),
        )
    }
}

/** A setting with a few ready values to pick from, such as 50 MB, 100 MB, 250 MB. */
@Composable
internal fun StepSetting(
    title: String,
    note: String?,
    values: List<Int>,
    value: Int,
    label: (Int) -> String,
    onChange: (Int) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(title, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        if (note != null) Text(note, color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // A value the person had before the list changed still shows, so the page never hides what is set.
            val shown = if (value in values) values else (values + value).sorted()
            for (v in shown) ToolChip(label = label(v), selected = v == value, onClick = { onChange(v) })
        }
    }
}

/** A setting with a few named choices. */
@Composable
internal fun <T> ChoiceSetting(
    title: String,
    note: String?,
    options: List<Pair<String, T>>,
    selected: T,
    onSelect: (T) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(title, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        if (note != null) Text(note, color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for ((text, option) in options) ToolChip(label = text, selected = option == selected, onClick = { onSelect(option) })
        }
    }
}

/** A quiet label above a group of settings inside a sheet. */
@Composable
internal fun SheetLabel(text: String) {
    Text(
        text = text.uppercase(),
        color = IxColors.TextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 2.dp),
    )
}

/**
 * A panel that slides up over the page, for tuning. Tap outside or press back to close it. Nothing in
 * it needs a Save button: every change is kept as soon as it is made.
 */
@Composable
internal fun ToolSheet(
    visible: Boolean,
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    footer: (@Composable ColumnScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    BackHandler(enabled = visible, onBack = onClose)
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    Box(modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose),
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = screenHeight * 0.88f)
                    .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                    .background(IxColors.Sheet)
                    // Taps inside the sheet must not reach the scrim.
                    .pointerInput(Unit) { detectTapGestures { } }
                    .navigationBarsPadding(),
            ) {
                Box(
                    Modifier
                        .padding(top = 10.dp)
                        .align(Alignment.CenterHorizontally)
                        .size(width = 40.dp, height = 5.dp)
                        .clip(CircleShape)
                        .background(IxColors.Handle),
                )
                Text(
                    text = title,
                    color = IxColors.TextPrimary,
                    fontFamily = Figtree,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 14.dp),
                )
                Column(
                    Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 12.dp),
                    content = content,
                )
                if (footer != null) {
                    Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 16.dp), content = footer)
                }
            }
        }
    }
}

/** The text button at the foot of a sheet ("Reset to defaults"). */
@Composable
internal fun SheetTextButton(label: String, onClick: () -> Unit, danger: Boolean = false) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (danger) IxColors.Danger else IxColors.TextSecondary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/**
 * The big orange button of a page that clears something: drag the dark knob across to do it.
 * A screen reader can double-tap it instead. [label] says what will happen.
 */
@Composable
internal fun SlideToConfirm(label: String, enabled: Boolean, onConfirm: () -> Unit, modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    var trackWidth by remember { mutableIntStateOf(0) }
    var dragged by remember { mutableFloatStateOf(0f) }
    val knob = 52.dp
    val inset = 4.dp
    val knobPx = with(density) { knob.toPx() }
    val insetPx = with(density) { inset.toPx() }
    val travel = (trackWidth - knobPx - insetPx * 2).coerceAtLeast(0f)
    val fill = if (enabled) IxColors.Accent else IxColors.Chip
    Box(
        modifier
            .fillMaxWidth()
            .height(60.dp)
            .clip(CircleShape)
            .background(fill)
            .onSizeChanged { trackWidth = it.width }
            .semantics(mergeDescendants = true) {
                contentDescription = label
                role = Role.Button
                onClick(label = label) {
                    if (enabled) {
                        onConfirm()
                        true
                    } else {
                        false
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (enabled) Hue.Ink else IxColors.TextSecondary,
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(start = 64.dp, end = 24.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset { IntOffset((insetPx + dragged).roundToInt(), 0) }
                .size(knob)
                .clip(CircleShape)
                .background(if (enabled) Hue.Ink else IxColors.Handle)
                .pointerInput(enabled, travel) {
                    if (enabled) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                val done = travel > 0f && dragged >= travel * 0.85f
                                dragged = 0f
                                if (done) onConfirm()
                            },
                            onDragCancel = { dragged = 0f },
                        ) { change, amount ->
                            change.consume()
                            dragged = (dragged + amount).coerceIn(0f, travel)
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.ChevronRight, tint = if (enabled) Color.White else IxColors.TextSecondary, size = 22.dp, strokeWidth = 2.6f)
        }
    }
}

/** One slice of a [StackBar]. */
internal class Slice(val weight: Float, val color: Color)

/** A bar made of colored slices, widths in proportion to their weights. */
@Composable
internal fun StackBar(slices: List<Slice>, modifier: Modifier = Modifier, height: Dp = 14.dp, track: Color = IxColors.Chip) {
    Row(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(height / 2))
            .background(track),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        for (slice in slices) {
            if (slice.weight > 0f) {
                Box(
                    Modifier
                        .weight(slice.weight.coerceAtLeast(0.004f))
                        .fillMaxHeight()
                        .background(slice.color),
                )
            }
        }
    }
}

/** A line of a legend: dot, name, and a value on the right. */
@Composable
internal fun LegendRow(color: Color, label: String, value: String, modifier: Modifier = Modifier, note: String? = null, onClick: (() -> Unit)? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color),
        )
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(label, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (note != null) Text(note, color = IxColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(value, color = IxColors.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        if (onClick != null) {
            Spacer(Modifier.width(6.dp))
            PathIcon(Glyphs.ChevronRight, tint = IxColors.Handle, size = 16.dp, strokeWidth = 2.2f)
        }
    }
}

/** A short horizontal bar with a label above and a value, for "where it went" lists. */
@Composable
internal fun MeterRow(
    label: String,
    value: String,
    fraction: Float,
    color: Color,
    modifier: Modifier = Modifier,
    note: String? = null,
    onClick: (() -> Unit)? = null,
) {
    Column(
        modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text(value, color = IxColors.TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(CircleShape)
                .background(IxColors.Chip),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction.coerceIn(0.01f, 1f))
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(color),
            )
        }
        if (note != null) Text(note, color = IxColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Vertical bars, one per value, with a small label under each. */
@Composable
internal fun MiniBars(values: List<Long>, labels: List<String>, color: Color, modifier: Modifier = Modifier, barHeight: Dp = 84.dp) {
    val top = (values.maxOrNull() ?: 0L).coerceAtLeast(1L).toFloat()
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        values.forEachIndexed { index, v ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.height(barHeight).fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height((barHeight * (v / top)).coerceAtLeast(if (v > 0) 6.dp else 3.dp))
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (v > 0) color else IxColors.Chip),
                    )
                }
                Text(
                    labels.getOrElse(index) { "" },
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp),
                    maxLines = 1,
                )
            }
        }
    }
}

/** A centered note for an empty or still-working page. */
@Composable
internal fun ToolNote(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 40.dp), contentAlignment = Alignment.Center) {
        Text(text, color = IxColors.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

/** A wide pill for the bar at the foot of the page. */
@Composable
internal fun ActionPill(label: String, fill: Color, text: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(56.dp)
            .clip(CircleShape)
            .background(fill)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = text, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
