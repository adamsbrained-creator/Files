package ix.app.files.transfer

import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface

enum class TransferPhase { Off, Counting, Sharing, Failed }

enum class TransferProblem { None, NoNetwork, NothingToSend, Other }

/** What the "Send to PC" window and the notification show. */
data class TransferState(
    val phase: TransferPhase = TransferPhase.Off,
    val problem: TransferProblem = TransferProblem.None,
    val url: String = "",
    val counted: Int = 0,
    val files: Int = 0,
    val bytes: Long = 0,
    val items: Int = 0,
    val sentBytes: Long = 0,
    val filesDone: Int = 0,
    val client: String = "",
    val connections: Int = 0,
    val currentFile: String = "",
)

/**
 * The one place the screens and the foreground service meet for "Send to PC". The phone becomes a small web
 * server (see [TransferServer]) and shows the address to open on the PC. It lives in the app process, so plain
 * flows work, like [ix.app.files.cast.CastHub].
 */
object TransferHub {

    private const val IDLE_LIMIT_MS = 30 * 60 * 1000L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow(TransferState())
    val state: StateFlow<TransferState> get() = _state

    private var server: TransferServer? = null
    private var job: Job? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var app: Context

    val active: Boolean get() = _state.value.phase == TransferPhase.Counting || _state.value.phase == TransferPhase.Sharing

    /**
     * Counts what [paths] hold and starts sharing it. [skip] leaves out paths that must never leave the phone
     * (the locked Private folder). Does nothing when a session is already running.
     */
    @Synchronized
    fun start(context: Context, paths: List<String>, skip: (String) -> Boolean) {
        if (active) return
        app = context.applicationContext
        val address = lanAddress()
        if (address == null) {
            _state.value = TransferState(phase = TransferPhase.Failed, problem = TransferProblem.NoNetwork)
            return
        }
        _state.value = TransferState(phase = TransferPhase.Counting)
        runCatching { ContextCompat.startForegroundService(app, Intent(app, TransferService::class.java)) }
        acquireLocks()

        job = scope.launch {
            try {
                val plan = TransferPlanner.plan(
                    paths = paths,
                    skip = skip,
                    cancelled = { !isActive },
                    progress = { n -> _state.value = _state.value.copy(counted = n) },
                    storageRoots = storageRoots(),
                    looseName = "Selected files",
                )
                if (!isActive) return@launch
                if (plan.totalFiles == 0) {
                    fail(TransferProblem.NothingToSend)
                    return@launch
                }
                val s = TransferServer(
                    plan = plan,
                    phoneName = Build.MODEL?.takeIf { it.isNotBlank() } ?: "Phone",
                    page = { asset("transfer/index.html") },
                    script = { asset("transfer/get.ps1") },
                )
                s.start()
                server = s
                val url = "http://$address:${s.port}/${s.token}/"
                _state.value = TransferState(
                    phase = TransferPhase.Sharing, url = url,
                    files = plan.totalFiles, bytes = plan.totalBytes, items = plan.roots.size,
                )
                watch(s)
            } catch (e: Exception) {
                if (isActive) fail(TransferProblem.Other)
            }
        }
    }

    /** Stops the server and the notification. Safe to call any time. */
    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        runCatching { server?.stop() }
        server = null
        releaseLocks()
        _state.value = TransferState()
        if (::app.isInitialized) runCatching { app.stopService(Intent(app, TransferService::class.java)) }
    }

    /** Clears an error so the window can offer the choices again. */
    fun dismissProblem() {
        if (_state.value.phase == TransferPhase.Failed) _state.value = TransferState()
    }

    private fun fail(problem: TransferProblem) {
        runCatching { server?.stop() }
        server = null
        releaseLocks()
        _state.value = TransferState(phase = TransferPhase.Failed, problem = problem)
        if (::app.isInitialized) runCatching { app.stopService(Intent(app, TransferService::class.java)) }
    }

    /** Keeps the numbers fresh, and ends the session when nobody has used it for half an hour. */
    private suspend fun watch(s: TransferServer) {
        var lastBytes = -1L
        var lastActivity = System.currentTimeMillis()
        while (currentCoroutineContext().isActive && s.running) {
            val st = s.stats
            val bytes = st.bytesSent.get()
            val connections = st.connections.get()
            if (bytes != lastBytes || connections > 0) lastActivity = System.currentTimeMillis()
            lastBytes = bytes
            _state.value = _state.value.copy(
                sentBytes = bytes,
                filesDone = st.filesDone.get(),
                client = st.lastClient,
                connections = connections,
                currentFile = st.lastFile,
            )
            if (System.currentTimeMillis() - lastActivity > IDLE_LIMIT_MS) {
                stop()
                return
            }
            delay(1000)
        }
    }

    // ---- helpers -----------------------------------------------------------------------------

    private fun asset(name: String): String =
        app.assets.open(name).use { it.readBytes().toString(Charsets.UTF_8) }

    /** The storage roots, so "Music/Artist/song.mp3" on the PC matches the phone. */
    @Suppress("DEPRECATION")
    private fun storageRoots(): List<File> {
        val roots = ArrayList<File>()
        roots += Environment.getExternalStorageDirectory()
        File("/storage").listFiles()?.forEach { v ->
            if (v.isDirectory && v.name != "self" && v.name != "emulated") roots += v // SD cards and USB drives
        }
        return roots
    }

    /**
     * The phone's address on the home network: Wi-Fi first, then a hotspot the phone itself makes, then Ethernet.
     * Mobile data is never used, so nothing is offered to the internet. Null when there is no such network.
     */
    fun lanAddress(): String? {
        val candidates = ArrayList<Pair<Int, String>>()
        val interfaces = runCatching { NetworkInterface.getNetworkInterfaces()?.toList() }.getOrNull().orEmpty()
        for (nif in interfaces) {
            if (!runCatching { nif.isUp && !nif.isLoopback }.getOrDefault(false)) continue
            val name = nif.name.lowercase()
            val rank = when {
                name.startsWith("wlan") || name.startsWith("swlan") -> 0
                name.startsWith("ap") || name.startsWith("softap") -> 1
                name.startsWith("eth") -> 2
                else -> continue // rmnet, tun, dummy...: mobile data and VPNs
            }
            for (ia in nif.inetAddresses) {
                val a = ia as? Inet4Address ?: continue
                if (!a.isLoopbackAddress && !a.isLinkLocalAddress) {
                    candidates += rank to a.hostAddress.orEmpty()
                }
            }
        }
        return candidates.filter { it.second.isNotEmpty() }.minByOrNull { it.first }?.second
    }

    private fun acquireLocks() {
        runCatching {
            val pm = app.getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ixfiles:transfer")
                .apply { setReferenceCounted(false); acquire(IDLE_LIMIT_MS * 8) }
        }
        runCatching {
            @Suppress("DEPRECATION")
            val mode = WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = app.getSystemService(WifiManager::class.java)
                .createWifiLock(mode, "ixfiles-transfer").apply { setReferenceCounted(false); acquire() }
        }
    }

    private fun releaseLocks() {
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        runCatching { wifiLock?.let { if (it.isHeld) it.release() } }
        wakeLock = null
        wifiLock = null
    }
}
