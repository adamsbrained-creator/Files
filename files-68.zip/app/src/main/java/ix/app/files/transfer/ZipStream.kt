package ix.app.files.transfer

import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Calendar
import java.util.zip.CRC32

/**
 * Writes a zip file straight into a network connection, one file after the other, without ever holding more than
 * a small buffer. Files are stored, not compressed: music, photos and video are compressed already, and storing
 * keeps the phone's processor free and makes the size of the whole zip known in advance, so the browser on the PC
 * can show a real progress bar.
 *
 * Every entry uses the zip64 form, so there is no 4 GB limit on a file or on the whole archive and no limit on
 * the number of files. [Layout] says exactly how many bytes the archive will be.
 */
object ZipLayout {
    private const val LOCAL_FIXED = 30L
    private const val LOCAL_EXTRA = 20L // zip64 extra: id, size, uncompressed size, compressed size
    private const val DESCRIPTOR = 24L // signature, crc, two 8-byte sizes
    private const val CENTRAL_FIXED = 46L
    private const val CENTRAL_EXTRA = 28L // zip64 extra: id, size, uncompressed, compressed, header offset
    private const val END = 56L + 20L + 22L // zip64 end record, its locator, the classic end record

    fun nameBytes(name: String): ByteArray = name.toByteArray(Charsets.UTF_8)

    fun entryBytes(nameLength: Int, dataSize: Long): Long =
        LOCAL_FIXED + nameLength + LOCAL_EXTRA + dataSize + DESCRIPTOR + CENTRAL_FIXED + nameLength + CENTRAL_EXTRA

    /** The exact length of an archive holding these (name, size) pairs. */
    fun archiveBytes(items: List<Pair<String, Long>>): Long {
        var total = END
        for ((name, size) in items) total += entryBytes(nameBytes(name).size, size)
        return total
    }
}

class ZipStreamWriter(
    private val out: OutputStream,
    private val cancelled: () -> Boolean = { false },
) {
    private class Done(val name: ByteArray, val crc: Long, val size: Long, val dosTime: Int, val dosDate: Int, val offset: Long)

    private val done = ArrayList<Done>()
    private var position = 0L
    private val buffer = ByteArray(256 * 1024)

    /**
     * Adds [file], writing exactly [size] bytes of it. If the file turns out shorter than that (it was changed while
     * the zip was being sent) this throws, so the download fails visibly instead of delivering a damaged file.
     */
    fun add(name: String, file: File, size: Long, modified: Long, onBytes: (Int) -> Unit = {}) {
        val nameBytes = ZipLayout.nameBytes(name)
        val (dosTime, dosDate) = dosTimeOf(modified)
        val offset = position

        // Local header: sizes and checksum come after the data, in the descriptor (flag bit 3).
        val h = ByteBuffer.allocate(30 + nameBytes.size + 20).order(ByteOrder.LITTLE_ENDIAN)
        h.putInt(0x04034b50)
        h.putShort(45)
        h.putShort(FLAGS)
        h.putShort(0) // stored
        h.putShort(dosTime.toShort())
        h.putShort(dosDate.toShort())
        h.putInt(0) // crc, in the descriptor
        h.putInt(-1) // sizes: 0xFFFFFFFF means "see the zip64 extra"
        h.putInt(-1)
        h.putShort(nameBytes.size.toShort())
        h.putShort(20)
        h.put(nameBytes)
        h.putShort(1)
        h.putShort(16)
        h.putLong(0)
        h.putLong(0)
        write(h.array())

        val crc = CRC32()
        var left = size
        FileInputStream(file).use { input ->
            while (left > 0) {
                if (cancelled()) throw IOException("cancelled")
                val n = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
                if (n < 0) throw IOException("${file.name} is shorter than expected")
                crc.update(buffer, 0, n)
                out.write(buffer, 0, n)
                position += n
                left -= n
                onBytes(n)
            }
        }

        val d = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        d.putInt(0x08074b50)
        d.putInt(crc.value.toInt())
        d.putLong(size)
        d.putLong(size)
        write(d.array())
        done += Done(nameBytes, crc.value, size, dosTime, dosDate, offset)
    }

    /** Writes the table of contents at the end. Call once, after the last [add]. */
    fun finish() {
        val cdStart = position
        for (e in done) {
            val c = ByteBuffer.allocate(46 + e.name.size + 28).order(ByteOrder.LITTLE_ENDIAN)
            c.putInt(0x02014b50)
            c.putShort(45) // made by
            c.putShort(45) // needed
            c.putShort(FLAGS)
            c.putShort(0)
            c.putShort(e.dosTime.toShort())
            c.putShort(e.dosDate.toShort())
            c.putInt(e.crc.toInt())
            c.putInt(-1)
            c.putInt(-1)
            c.putShort(e.name.size.toShort())
            c.putShort(28)
            c.putShort(0) // comment
            c.putShort(0) // disk
            c.putShort(0) // internal attributes
            c.putInt(0) // external attributes
            c.putInt(-1) // header offset: in the zip64 extra
            c.put(e.name)
            c.putShort(1)
            c.putShort(24)
            c.putLong(e.size)
            c.putLong(e.size)
            c.putLong(e.offset)
            write(c.array())
        }
        val cdSize = position - cdStart
        val zip64Start = position

        val z = ByteBuffer.allocate(56 + 20 + 22).order(ByteOrder.LITTLE_ENDIAN)
        z.putInt(0x06064b50)
        z.putLong(44)
        z.putShort(45)
        z.putShort(45)
        z.putInt(0)
        z.putInt(0)
        z.putLong(done.size.toLong())
        z.putLong(done.size.toLong())
        z.putLong(cdSize)
        z.putLong(cdStart)
        z.putInt(0x07064b50)
        z.putInt(0)
        z.putLong(zip64Start)
        z.putInt(1)
        z.putInt(0x06054b50)
        z.putShort(0)
        z.putShort(0)
        z.putShort(-1)
        z.putShort(-1)
        z.putInt(-1)
        z.putInt(-1)
        z.putShort(0)
        write(z.array())
        out.flush()
    }

    private fun write(bytes: ByteArray) {
        out.write(bytes)
        position += bytes.size
    }

    private fun dosTimeOf(millis: Long): Pair<Int, Int> {
        val c = Calendar.getInstance()
        c.timeInMillis = if (millis > 0) millis else System.currentTimeMillis()
        val year = c.get(Calendar.YEAR)
        if (year < 1980) return 0 to ((1 shl 5) or 1) // zip can not store earlier dates: 1980-01-01
        val time = (c.get(Calendar.HOUR_OF_DAY) shl 11) or (c.get(Calendar.MINUTE) shl 5) or (c.get(Calendar.SECOND) / 2)
        val date = ((year - 1980) shl 9) or ((c.get(Calendar.MONTH) + 1) shl 5) or c.get(Calendar.DAY_OF_MONTH)
        return time to date
    }

    private companion object {
        /** Bit 3: sizes follow the data. Bit 11: file names are UTF-8. */
        const val FLAGS: Short = 0x0808
    }
}
