package ix.app.files.data

import android.content.Context
import androidx.compose.runtime.Immutable
import org.json.JSONArray
import org.json.JSONObject

/**
 * How the user changed one Home folder. A null field means "use the default":
 * the built-in name, the gray folder, the built-in icon.
 */
@Immutable
data class FolderStyle(
    val name: String? = null,
    /** ARGB color of the folder, or null for the default gray. */
    val color: Int? = null,
    /** A key from [FolderIconChoice], or null for the folder's own icon. */
    val icon: String? = null,
    /** ARGB color of the icon drawn on the folder, or null for the default. */
    val iconColor: Int? = null,
) {
    val isDefault: Boolean get() = name == null && color == null && icon == null && iconColor == null
}

/**
 * A folder the user added to the Home screen. It points at a real folder on the storage at [path];
 * [style] only changes how its tile looks. Removing the tile never touches the folder itself.
 */
@Immutable
data class CustomFolder(val id: String, val path: String, val style: FolderStyle)

/** The key that stands for a built-in Home folder in the saved tile order. */
fun Category.orderKey(): String = "b:$name"

/** The key that stands for an added Home folder in the saved tile order. */
fun CustomFolder.orderKey(): String = "x:$id"

/**
 * Where a tile sits on the Home canvas. Both numbers are fractions of the canvas width, so the spot keeps its
 * place on a different screen size: [x] counts from the left edge, [y] from the top edge.
 */
@Immutable
data class CanvasSpot(val x: Float, val y: Float)

/** What the folder editor is open for. */
sealed interface FolderEditTarget {
    data class Builtin(val category: Category) : FolderEditTarget
    data class Custom(val id: String) : FolderEditTarget
    data object New : FolderEditTarget
}

/** Remembers the look of each Home folder on the device. */
class FolderStyleStore(context: Context) {

    private val prefs = context.getSharedPreferences("folder_styles", Context.MODE_PRIVATE)

    fun load(): Map<Category, FolderStyle> {
        val out = HashMap<Category, FolderStyle>()
        for (category in Category.entries) {
            val raw = prefs.getString(category.name, null) ?: continue
            try {
                val json = JSONObject(raw)
                val style = FolderStyle(
                    name = json.optString(NAME, "").takeIf { it.isNotBlank() },
                    color = if (json.has(COLOR)) json.getInt(COLOR) else null,
                    icon = json.optString(ICON, "").takeIf { it.isNotBlank() },
                    iconColor = if (json.has(ICON_COLOR)) json.getInt(ICON_COLOR) else null,
                )
                if (!style.isDefault) out[category] = style
            } catch (e: Exception) {
                // A damaged entry just falls back to the default look.
            }
        }
        return out
    }

    fun save(category: Category, style: FolderStyle) {
        if (style.isDefault) {
            prefs.edit().remove(category.name).apply()
            return
        }
        val json = JSONObject()
        style.name?.let { json.put(NAME, it) }
        style.color?.let { json.put(COLOR, it) }
        style.icon?.let { json.put(ICON, it) }
        style.iconColor?.let { json.put(ICON_COLOR, it) }
        prefs.edit().putString(category.name, json.toString()).apply()
    }

    fun loadCustom(): List<CustomFolder> {
        val raw = prefs.getString(CUSTOM, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.getJSONObject(i)
                val path = o.optString("path", "")
                val id = o.optString("id", "")
                if (path.isEmpty() || id.isEmpty()) return@mapNotNull null
                CustomFolder(
                    id = id,
                    path = path,
                    style = FolderStyle(
                        name = o.optString(NAME, "").takeIf { it.isNotBlank() },
                        color = if (o.has(COLOR)) o.getInt(COLOR) else null,
                        icon = o.optString(ICON, "").takeIf { it.isNotBlank() },
                        iconColor = if (o.has(ICON_COLOR)) o.getInt(ICON_COLOR) else null,
                    ),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveCustom(folders: List<CustomFolder>) {
        val array = JSONArray()
        folders.forEach { f ->
            val o = JSONObject().put("id", f.id).put("path", f.path)
            f.style.name?.let { o.put(NAME, it) }
            f.style.color?.let { o.put(COLOR, it) }
            f.style.icon?.let { o.put(ICON, it) }
            f.style.iconColor?.let { o.put(ICON_COLOR, it) }
            array.put(o)
        }
        prefs.edit().putString(CUSTOM, array.toString()).apply()
    }

    /** The order of the Home tiles, as keys: "b:<Category>" for a built-in folder, "x:<id>" for an added one. */
    fun loadOrder(): List<String> {
        val raw = prefs.getString(ORDER, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { array.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveOrder(order: List<String>) {
        prefs.edit().putString(ORDER, JSONArray(order).toString()).apply()
    }

    fun loadSpots(): Map<String, CanvasSpot> {
        val raw = prefs.getString(SPOTS, null) ?: return emptyMap()
        return try {
            val json = JSONObject(raw)
            val out = HashMap<String, CanvasSpot>()
            for (key in json.keys()) {
                val pair = json.getJSONArray(key)
                out[key] = CanvasSpot(pair.getDouble(0).toFloat(), pair.getDouble(1).toFloat())
            }
            out
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveSpots(spots: Map<String, CanvasSpot>) {
        val json = JSONObject()
        spots.forEach { (key, spot) -> json.put(key, JSONArray().put(spot.x.toDouble()).put(spot.y.toDouble())) }
        prefs.edit().putString(SPOTS, json.toString()).apply()
    }

    private companion object {
        const val SPOTS = "home_spots"
        const val ORDER = "home_order"
        const val CUSTOM = "custom_folders"
        const val NAME = "name"
        const val COLOR = "color"
        const val ICON = "icon"
        const val ICON_COLOR = "icon_color"
    }
}

/** The longest name a folder can be given. */
const val FOLDER_NAME_MAX = 24

/** Colors offered in the editor. The first entry (null) is the default gray. */
val FolderColorChoices: List<Int?> = listOf(
    null,
    0xFFFF6A2B.toInt(), // orange
    0xFFF5B83D.toInt(), // amber
    0xFF4CC38A.toInt(), // green
    0xFF2EC4C4.toInt(), // teal
    0xFF4C8DFF.toInt(), // blue
    0xFF8B6CFF.toInt(), // violet
    0xFFE862B0.toInt(), // pink
    0xFFF0554F.toInt(), // red
)
