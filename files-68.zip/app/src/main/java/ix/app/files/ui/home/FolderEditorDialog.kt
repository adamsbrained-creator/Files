package ix.app.files.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FOLDER_NAME_MAX
import ix.app.files.data.FolderColorChoices
import ix.app.files.data.FolderEditTarget
import ix.app.files.data.FolderStyle
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.FolderIconChoices
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import java.io.File
import kotlin.math.roundToInt

/** Opens the editor for whatever [target] is: a built-in folder, one the user added, or a brand new one. */
@Composable
fun FolderEditorHost(target: FolderEditTarget, state: HomeState, viewModel: HomeViewModel) {
    when (target) {
        is FolderEditTarget.Builtin -> {
            val category = target.category
            FolderEditorDialog(
                title = stringResource(R.string.folder_edit_title),
                defaultName = stringResource(category.titleRes),
                defaultGlyph = category.glyph,
                current = state.folderStyles[category],
                secondaryLabel = if (state.folderStyles[category]?.isDefault == false) {
                    stringResource(R.string.folder_edit_reset)
                } else {
                    null
                },
                onSecondary = { viewModel.setFolderStyle(category, FolderStyle()) },
                onSave = { viewModel.setFolderStyle(category, it) },
                onDismiss = viewModel::closeFolderEditor,
                onArrange = if (state.homeFreeform) null else viewModel::startArranging,
            )
        }

        is FolderEditTarget.Custom -> {
            val folder = state.customFolders.firstOrNull { it.id == target.id } ?: return
            FolderEditorDialog(
                title = stringResource(R.string.folder_edit_title),
                defaultName = File(folder.path).name,
                defaultGlyph = Glyphs.Folder,
                current = folder.style,
                secondaryLabel = stringResource(R.string.folder_edit_remove),
                onSecondary = { viewModel.removeCustomFolder(folder.id) },
                onSave = { viewModel.updateCustomFolder(folder.id, it) },
                onDismiss = viewModel::closeFolderEditor,
                onArrange = if (state.homeFreeform) null else viewModel::startArranging,
            )
        }

        FolderEditTarget.New -> FolderEditorDialog(
            title = stringResource(R.string.new_folder),
            defaultName = "",
            defaultGlyph = Glyphs.Folder,
            current = null,
            secondaryLabel = null,
            onSecondary = {},
            onSave = { viewModel.createCustomFolder(it) },
            onDismiss = viewModel::closeFolderEditor,
            confirmLabel = stringResource(R.string.new_folder_confirm),
        )
    }
}

/** The color the sliders start from when a folder has no color of its own. */
private val DefaultFolderRgb = 0xFF8E8CA6.toInt()
private val DefaultIconRgb = 0xFFFFFFFF.toInt()

/** Colors offered for the icon: white and black first, then the folder colors. */
private val IconColorChoices: List<Int?> = listOf(null, 0xFFFFFFFF.toInt(), 0xFF000000.toInt()) + FolderColorChoices.drop(1)

/**
 * The folder editor, as a bottom sheet in the same look as New folder and Details. A live preview sits on top, then the
 * name, a switch between the folder color and the icon color, quick colors, three RGB sliders with the hex code, and
 * the icons. Save keeps whatever differs from the default. [secondaryLabel] is an extra button (Reset or Remove);
 * it is hidden when null. [showName] hides the name field for folders whose name is the real one on the storage.
 */
@Composable
fun FolderEditorDialog(
    title: String,
    defaultName: String,
    defaultGlyph: List<String>,
    current: FolderStyle?,
    secondaryLabel: String?,
    onSecondary: () -> Unit,
    onSave: (FolderStyle) -> Unit,
    onDismiss: () -> Unit,
    confirmLabel: String = stringResource(R.string.folder_edit_save),
    onArrange: (() -> Unit)? = null,
    showName: Boolean = true,
) {
    var name by remember { mutableStateOf(current?.name ?: defaultName) }
    var color by remember { mutableStateOf(current?.color) }
    var iconColor by remember { mutableStateOf(current?.iconColor) }
    var icon by remember { mutableStateOf(current?.icon) }
    var editingIcon by remember { mutableStateOf(false) }

    val shownGlyph = glyphFor(FolderStyle(icon = icon), defaultGlyph)
    val shownColor = if (editingIcon) iconColor else color
    val rgb = shownColor ?: if (editingIcon) DefaultIconRgb else DefaultFolderRgb
    val setShown: (Int?) -> Unit = { value -> if (editingIcon) iconColor = value else color = value }
    val canSave = !showName || name.isNotBlank()

    GlassSheet(onDismiss = onDismiss) {
        Column(
            Modifier
                .weight(1f, fill = false)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(title, color = IxColors.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(128.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(IxColors.Tile),
                contentAlignment = Alignment.Center,
            ) {
                FolderIcon(
                    glyph = shownGlyph,
                    modifier = Modifier.size(width = 96.dp, height = 80.dp),
                    tint = color?.let { Color(it) },
                    glyphTint = iconColor?.let { Color(it) },
                )
            }

            if (showName) {
                val fieldShape = RoundedCornerShape(18.dp)
                BasicTextField(
                    value = name,
                    onValueChange = { if (it.length <= FOLDER_NAME_MAX) name = it },
                    singleLine = true,
                    textStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 18.sp),
                    cursorBrush = SolidColor(IxColors.Violet),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .clip(fieldShape)
                        .background(IxColors.Tile)
                        .border(1.5.dp, IxColors.Violet, fieldShape),
                    decorationBox = { inner ->
                        Box(Modifier.padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart) { inner() }
                    },
                )
            }

            // Folder color or icon color: the swatches and sliders below edit whichever is on.
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(IxColors.Glass)
                    .padding(3.dp),
            ) {
                for (iconMode in listOf(false, true)) {
                    val on = iconMode == editingIcon
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(19.dp))
                            .background(if (on) IxColors.TileBorder.copy(alpha = 0.18f) else Color.Transparent)
                            .clickable(role = Role.Button) { editingIcon = iconMode },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = stringResource(if (iconMode) R.string.folder_edit_icon_color else R.string.folder_edit_folder_color),
                            color = if (on) IxColors.TextPrimary else IxColors.TextSecondary,
                            fontSize = 16.sp,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        )
                    }
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                (if (editingIcon) IconColorChoices else FolderColorChoices).forEach { choice ->
                    ColorDot(choice = choice, selected = choice == shownColor, onClick = { setShown(choice) })
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                SectionLabel(stringResource(R.string.folder_edit_rgb))
                Spacer(Modifier.weight(1f))
                Text(
                    text = "#%06X".format(rgb and 0xFFFFFF),
                    color = IxColors.TextPrimary,
                    fontSize = 15.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(IxColors.Chip)
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                )
            }
            RgbSlider("R", Color(0xFFFF6B6B), rgb, 0, setShown)
            RgbSlider("G", Color(0xFF5BE07A), rgb, 1, setShown)
            RgbSlider("B", Color(0xFF5AA0FF), rgb, 2, setShown)

            SectionLabel(stringResource(R.string.folder_edit_icon))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // "Default" is the folder's own icon, shown first.
                IconCell(glyph = defaultGlyph, selected = icon == null, onClick = { icon = null })
                FolderIconChoices.forEach { choice ->
                    IconCell(glyph = choice.glyph, selected = icon == choice.key, onClick = { icon = choice.key })
                }
            }

            if (onArrange != null || secondaryLabel != null) {
                Row {
                    if (onArrange != null) {
                        TextButton(onClick = onArrange) {
                            Text(stringResource(R.string.folder_edit_arrange), color = IxColors.TextPrimary)
                        }
                    }
                    if (secondaryLabel != null) {
                        TextButton(onClick = onSecondary) { Text(secondaryLabel, color = IxColors.Danger) }
                    }
                }
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SecondaryPill(stringResource(R.string.cancel), Modifier.weight(1f), onClick = onDismiss)
            PrimaryPill(confirmLabel, Modifier.weight(1f), enabled = canSave) {
                onSave(
                    FolderStyle(
                        name = name.trim().takeIf { showName && it != defaultName },
                        color = color,
                        icon = icon,
                        iconColor = iconColor,
                    ),
                )
            }
        }
    }
}

/** One red, green or blue slider. The track shows the colors the slider can reach, with the other two kept as they are. */
@Composable
private fun RgbSlider(label: String, labelColor: Color, rgb: Int, channel: Int, onChange: (Int?) -> Unit) {
    val shift = 16 - 8 * channel
    val value = (rgb shr shift) and 0xFF
    Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = labelColor, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(22.dp))
        Box(Modifier.weight(1f).height(34.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(withChannel(rgb, shift, 0)), Color(withChannel(rgb, shift, 255))),
                        ),
                    ),
            )
            Slider(
                value = value.toFloat(),
                onValueChange = { onChange(withChannel(rgb, shift, it.roundToInt().coerceIn(0, 255))) },
                valueRange = 0f..255f,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.Transparent,
                    inactiveTrackColor = Color.Transparent,
                    activeTickColor = Color.Transparent,
                    inactiveTickColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Text(
            text = value.toString(),
            color = IxColors.TextPrimary,
            fontSize = 16.sp,
            modifier = Modifier.width(40.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End,
        )
    }
}

/** [rgb] with one channel (found by its bit [shift]) set to [value], fully opaque. */
private fun withChannel(rgb: Int, shift: Int, value: Int): Int =
    (0xFF shl 24) or (rgb and 0x00FFFFFF and (0xFF shl shift).inv()) or (value shl shift)

@Composable
private fun SectionLabel(text: String) {
    Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun ColorDot(choice: Int?, selected: Boolean, onClick: () -> Unit) {
    val fill = choice?.let { Color(it) } ?: IxColors.FolderFrontBottom
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(fill)
            .border(
                BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) IxColors.TextPrimary else IxColors.Outline),
                CircleShape,
            )
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            val onFill = if (fill.red * 0.299f + fill.green * 0.587f + fill.blue * 0.114f > 0.6f) Color.Black else Color.White
            PathIcon(Glyphs.Check, tint = onFill, size = 18.dp, strokeWidth = 2.4f)
        }
    }
}

@Composable
private fun IconCell(glyph: List<String>, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .size(48.dp)
            .clip(shape)
            .background(if (selected) IxColors.Violet.copy(alpha = 0.3f) else IxColors.Tile)
            .border(BorderStroke(if (selected) 1.5.dp else 0.dp, if (selected) IxColors.Violet else Color.Transparent), shape)
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
    }
}
