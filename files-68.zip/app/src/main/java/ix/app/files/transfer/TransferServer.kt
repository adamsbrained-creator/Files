package ix.app.files.transfer

import ix.app.files.cast.RangeHeader
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Live numbers for the screen and the notification. Plain atomics, so any thread can read them. */
class TransferStats {
    val bytesSent = AtomicLong()
    val filesDone = AtomicInteger()
    val connections = AtomicInteger()

    @Volatile
    var lastClient: String = ""

    @Volatile
    var lastFile: String = ""

    @Volatile
    var failures = 0
}

/**
 * The phone as a small web server for the PC. Whatever the person picked is offered as:
 *  - a page to open in any browser (one big zip button, one zip per folder, every single file),
 *  - a zip of everything or of one folder, streamed, with no limit on the number or size of files,
 *  - the plain list of files, and a Windows script that copies them into a folder and skips what it already has.
 *
 * Every address starts with a random token, so only someone who was shown the address can fetch anything.
 * The server only ever reads: nothing can be written to, changed on or deleted from the phone through it.
 */
class TransferServer(
    private val plan: TransferPlan,
    private val phoneName: String,
    private val page: () -> String,
    private val script: () -> String,
    private val preferredPort: Int = 8765,
) {
    val stats = TransferStats()

    @Volatile
    var token = ""
        private set

    @Volatile
    var port = 0
        private set

    private var serverSocket: ServerSocket? = null
    private var pool: ExecutorService? = null
    private val open = ConcurrentHashMap.newKeySet<Socket>()

    val running: Boolean get() = serverSocket != null

    @Synchronized
    fun start() {
        if (serverSocket != null) return
        val ss = try {
            ServerSocket(preferredPort, 50)
        } catch (e: IOException) {
            ServerSocket(0, 50) // the usual port is taken: any free one will do
        }
        serverSocket = ss
        port = ss.localPort
        token = newToken()
        val p = Executors.newCachedThreadPool()
        pool = p
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (e: IOException) { break }
                try { p.execute { serve(s) } } catch (e: RejectedExecutionException) { runCatching { s.close() }; break }
            }
        }, "ixfiles-transfer-server").apply { isDaemon = true }.start()
    }

    @Synchronized
    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        pool?.shutdownNow()
        pool = null
        for (s in open) runCatching { s.close() }
        open.clear()
        port = 0
    }

    // ---- requests ----------------------------------------------------------------------------

    private fun serve(s: Socket) {
        open += s
        stats.connections.incrementAndGet()
        try {
            s.soTimeout = 30_000
            s.sendBufferSize = 256 * 1024
            val input = BufferedInputStream(s.getInputStream())
            val requestLine = readLine(input) ?: return
            val h = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) h[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }
            val parts = requestLine.split(' ')
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val out = BufferedOutputStream(s.getOutputStream(), 64 * 1024)
            if (method != "GET" && method != "HEAD") return status(out, 405, "Method Not Allowed")
            val head = method == "HEAD"

            val rawPath = parts[1].substringBefore('?')
            val segs = rawPath.split('/').filter { it.isNotEmpty() }
            if (segs.isEmpty() || segs[0] != token) return status(out, 404, "Not Found")
            stats.lastClient = s.inetAddress?.hostAddress.orEmpty()

            if (segs.size == 1 && !rawPath.endsWith("/")) {
                // "/token" with no slash: the page's relative links would break, so send them to the right address.
                return header(out, 302, "Found", "Location: /$token/", "Content-Length: 0")
            }
            val host = h["host"] ?: "localhost:$port"
            when (segs.getOrNull(1)) {
                null -> sendText(out, "text/html; charset=utf-8", page().replace("__PHONE__", escapeHtml(phoneName)), head)
                "api" -> when (segs.getOrNull(2)) {
                    "roots.json" -> sendText(out, "application/json; charset=utf-8", rootsJson(), head)
                    "files.tsv" -> sendText(out, "text/tab-separated-values; charset=utf-8", filesTsv(), head)
                    else -> status(out, 404, "Not Found")
                }
                "get.ps1" -> sendText(
                    out, "text/plain; charset=utf-8",
                    script().replace("__BASE__", "http://$host/$token"), head,
                    attachment = "Copy-from-phone.ps1",
                )
                "f" -> serveFile(out, segs.getOrNull(2)?.toIntOrNull(), head, h)
                "zip" -> serveZip(out, if (segs.size > 2) segs[2].toIntOrNull() ?: -1 else null, head)
                else -> status(out, 404, "Not Found")
            }
        } catch (e: IOException) {
            // The PC closed the connection (the person cancelled, or the browser opened a new one): normal.
        } catch (e: Exception) {
            stats.failures++
        } finally {
            open -= s
            stats.connections.decrementAndGet()
            runCatching { s.close() }
        }
    }

    private fun serveFile(out: OutputStream, id: Int?, head: Boolean, h: Map<String, String>) {
        val entry = id?.let { plan.entry(it) } ?: return status(out, 404, "Not Found")
        val raf = try { RandomAccessFile(entry.file, "r") } catch (e: IOException) { return status(out, 404, "Not Found") }
        raf.use { f ->
            val size = f.length()
            val span = RangeHeader.resolve(h["range"], size)
                ?: return header(out, 416, "Range Not Satisfiable", "Content-Range: bytes */$size", "Content-Length: 0")
            val name = entry.rel.substringAfterLast('/')
            val lines = arrayListOf(
                "Content-Type: application/octet-stream",
                "Content-Length: ${span.length}",
                "Accept-Ranges: bytes",
                "Content-Disposition: ${disposition(name)}",
                "Last-Modified: ${httpDate(entry.modified)}",
            )
            if (span.partial) lines += "Content-Range: bytes ${span.start}-${span.end}/$size"
            header(out, if (span.partial) 206 else 200, if (span.partial) "Partial Content" else "OK", *lines.toTypedArray())
            if (head || span.length <= 0) { out.flush(); return }

            stats.lastFile = name
            f.seek(span.start)
            val buf = ByteArray(256 * 1024)
            var remaining = span.length
            while (remaining > 0) {
                val n = f.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (n <= 0) throw IOException("file changed")
                out.write(buf, 0, n)
                stats.bytesSent.addAndGet(n.toLong())
                remaining -= n
            }
            out.flush()
            stats.filesDone.incrementAndGet()
        }
    }

    /** [root] null: everything. Otherwise that one picked item. */
    private fun serveZip(out: OutputStream, root: Int?, head: Boolean) {
        val entries = if (root == null) plan.entries else plan.entriesOf(root)
        val zipName = if (root == null) {
            "$phoneName.zip"
        } else {
            (plan.roots.getOrNull(root) ?: return status(out, 404, "Not Found")).name + ".zip"
        }
        if (root != null && root < 0) return status(out, 404, "Not Found")
        val length = ZipLayout.archiveBytes(entries.map { it.rel to it.size })
        header(
            out, 200, "OK",
            "Content-Type: application/zip",
            "Content-Length: $length",
            "Accept-Ranges: none",
            "Content-Disposition: ${disposition(zipName)}",
        )
        if (head) { out.flush(); return }

        val zip = ZipStreamWriter(out)
        for (e in entries) {
            stats.lastFile = e.rel.substringAfterLast('/')
            zip.add(e.rel, e.file, e.size, e.modified) { stats.bytesSent.addAndGet(it.toLong()) }
            stats.filesDone.incrementAndGet()
        }
        zip.finish()
    }

    // ---- listings ----------------------------------------------------------------------------

    private fun rootsJson(): String {
        val sb = StringBuilder("{\"phone\":").append(jsonString(phoneName))
        sb.append(",\"files\":").append(plan.totalFiles)
        sb.append(",\"bytes\":").append(plan.totalBytes)
        sb.append(",\"roots\":[")
        plan.roots.forEachIndexed { i, r ->
            if (i > 0) sb.append(',')
            sb.append("{\"i\":").append(r.index)
            sb.append(",\"name\":").append(jsonString(r.name))
            sb.append(",\"folder\":").append(r.isFolder)
            sb.append(",\"files\":").append(r.files)
            sb.append(",\"bytes\":").append(r.bytes).append('}')
        }
        return sb.append("]}").toString()
    }

    /** One file per line: id, size, modified (seconds), path. Tabs and newlines in names become spaces. */
    private fun filesTsv(): String {
        val sb = StringBuilder(plan.entries.size * 64)
        for (e in plan.entries) {
            sb.append(e.id).append('\t').append(e.size).append('\t').append(e.modified / 1000).append('\t')
                .append(e.rel.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')).append('\n')
        }
        return sb.toString()
    }

    // ---- low level ---------------------------------------------------------------------------

    private fun sendText(out: OutputStream, type: String, body: String, head: Boolean, attachment: String? = null) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val lines = arrayListOf("Content-Type: $type", "Content-Length: ${bytes.size}", "Cache-Control: no-store")
        if (attachment != null) lines += "Content-Disposition: ${disposition(attachment)}"
        header(out, 200, "OK", *lines.toTypedArray())
        if (!head) out.write(bytes)
        out.flush()
    }

    private fun status(out: OutputStream, code: Int, reason: String) {
        header(out, code, reason, "Content-Length: 0")
        out.flush()
    }

    private fun header(out: OutputStream, code: Int, reason: String, vararg lines: String) {
        val sb = StringBuilder("HTTP/1.1 $code $reason\r\n")
        for (l in lines) sb.append(l).append("\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val c = input.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(c.toChar())
        }
        return sb.toString()
    }

    companion object {
        private const val TOKEN_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789" // no look-alikes (l, 1, o, 0, i)

        fun newToken(): String {
            val r = SecureRandom()
            return buildString { repeat(8) { append(TOKEN_ALPHABET[r.nextInt(TOKEN_ALPHABET.length)]) } }
        }

        /** A header value that survives any file name: a plain fallback plus the real name in UTF-8. */
        fun disposition(name: String): String {
            val fallback = name.map { if (it.code in 32..126 && it != '"' && it != '\\' && it != '%') it else '_' }.joinToString("")
            val encoded = buildString {
                for (b in name.toByteArray(Charsets.UTF_8)) {
                    val c = b.toInt() and 0xFF
                    if ((c in 'a'.code..'z'.code) || (c in 'A'.code..'Z'.code) || (c in '0'.code..'9'.code) ||
                        c == '.'.code || c == '-'.code || c == '_'.code
                    ) {
                        append(c.toChar())
                    } else {
                        append('%').append("0123456789ABCDEF"[c shr 4]).append("0123456789ABCDEF"[c and 15])
                    }
                }
            }
            return "attachment; filename=\"$fallback\"; filename*=UTF-8''$encoded"
        }

        fun httpDate(millis: Long): String {
            val f = java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", java.util.Locale.US)
            f.timeZone = java.util.TimeZone.getTimeZone("GMT")
            return f.format(java.util.Date(if (millis > 0) millis else 0L))
        }

        fun jsonString(s: String): String = buildString {
            append('"')
            for (ch in s) when {
                ch == '"' -> append("\\\"")
                ch == '\\' -> append("\\\\")
                ch.code < 32 -> append("\\u%04x".format(ch.code))
                else -> append(ch)
            }
            append('"')
        }

        fun escapeHtml(s: String): String =
            s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    }
}
