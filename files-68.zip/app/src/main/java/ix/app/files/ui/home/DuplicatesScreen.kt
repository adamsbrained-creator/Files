package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.DupKeep
import ix.app.files.data.DupSort
import ix.app.files.data.DuplicateGroup
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import ix.app.files.data.ToolPrefs
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File

private fun DuplicateGroup.title(): String {
    val first = files.first()
    return if (first.extension.isEmpty()) first.name else first.name + "." + first.extension
}

private fun toggledKinds(prefs: ToolPrefs, kind: FileKind): Set<FileKind> {
    val all = FileKind.entries.toSet()
    val current = if (prefs.dupKinds.isEmpty()) all else prefs.dupKinds
    val next = if (kind in current) current - kind else current + kind
    // Nothing left to look at would make the page pointless, and "everything" is saved as the empty set.
    return if (next.isEmpty() || next == all) emptySet() else next
}

/**
 * Files that exist more than once. Each file has a Keep / Remove switch; a group can never have all its copies
 * set to Remove. "Auto-select" sets the extras by the keep rule from Customize. Removing moves the copies to
 * the Trash, where Undo and the Trash page can bring them back.
 */
@Composable
fun DuplicatesScreen(
    groups: List<DuplicateGroup>,
    loading: Boolean,
    scanning: Boolean,
    rootPath: String,
    selection: Selection,
    prefs: ToolPrefs,
    onPrefs: (ToolPrefs) -> Unit,
    onBack: () -> Unit,
    onSelectExtrasOf: (List<DuplicateGroup>) -> Unit,
    onDelete: () -> Unit,
    onFileClick: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)
    var only by remember { mutableStateOf<FileKind?>(null) }
    var sheet by remember { mutableStateOf(false) }

    val kindsPresent = remember(groups) { groups.map { it.files.first().kind }.toSet() }
    val filter = only?.takeIf { it in kindsPresent }
    val visible = remember(groups, filter, prefs.dupSort) {
        val list = if (filter == null) groups else groups.filter { it.files.first().kind == filter }
        when (prefs.dupSort) {
            DupSort.Wasted -> list.sortedByDescending { it.extraBytes }
            DupSort.Copies -> list.sortedWith(compareByDescending<DuplicateGroup> { it.files.size }.thenByDescending { it.extraBytes })
            DupSort.Name -> list.sortedBy { it.title().lowercase() }
        }
    }

    val wasted = groups.sumOf { it.extraBytes }
    val extraCopies = groups.sumOf { it.files.size - 1 }
    val sizeOf = remember(groups) {
        val map = HashMap<String, Long>()
        for (g in groups) for (f in g.files) map[f.path] = f.sizeBytes
        map
    }
    val picked = selection.paths
    val pickedBytes = remember(picked, sizeOf) { picked.sumOf { sizeOf[it] ?: 0L } }
    val hasPick = picked.isNotEmpty()

    Box(modifier.toolPage()) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 120.dp)) {
            item(key = "hero") {
                ToolHero(
                    hue = Hue.Pink,
                    eyebrow = stringResource(R.string.dup_title),
                    onBack = onBack,
                    action = { HeroIconButton(Glyphs.Sliders, stringResource(R.string.t_customize)) { sheet = true } },
                ) {
                    when {
                        loading -> {
                            HeroNumber("…")
                            HeroSub(stringResource(R.string.dup_loading))
                        }

                        groups.isEmpty() -> {
                            HeroNumber("0", "B")
                            HeroSub(stringResource(R.string.dup_empty))
                        }

                        else -> {
                            val text = formatFileSize(if (hasPick) pickedBytes else wasted)
                            HeroNumber(text.substringBefore(' '), text.substringAfter(' ', ""))
                            HeroSub(
                                if (hasPick) {
                                    stringResource(R.string.t_dup_selected_of, formatFileSize(wasted))
                                } else {
                                    stringResource(R.string.t_dup_summary, groups.size, extraCopies)
                                },
                            )
                            Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                HeroPill(
                                    label = stringResource(R.string.t_dup_auto),
                                    filled = true,
                                    onClick = { onSelectExtrasOf(visible) },
                                )
                                if (hasPick) {
                                    HeroPill(
                                        label = stringResource(R.string.t_dup_clear),
                                        filled = false,
                                        onClick = { selection.toggleMany(picked.toList()) },
                                    )
                                }
                            }
                        }
                    }
                    if (scanning && !loading) {
                        HeroSub(stringResource(R.string.dup_scanning_note), Modifier.padding(top = 12.dp))
                    }
                }
            }

            if (!loading && groups.isNotEmpty()) {
                item(key = "chips") {
                    ChipRow(Modifier.padding(top = 18.dp)) {
                        ToolChip(stringResource(R.string.t_all), selected = filter == null, count = groups.size.toString(), onClick = { only = null })
                        for (kind in FileKind.entries) {
                            if (kind !in kindsPresent) continue
                            ToolChip(
                                label = stringResource(kindTitle(kind)),
                                selected = filter == kind,
                                count = groups.count { it.files.first().kind == kind }.toString(),
                                onClick = { only = if (filter == kind) null else kind },
                            )
                        }
                    }
                }
                item(key = "sort") {
                    ToolSegmented(
                        options = listOf(
                            stringResource(R.string.t_dup_sort_waste),
                            stringResource(R.string.t_dup_sort_copies),
                            stringResource(R.string.t_dup_sort_name),
                        ),
                        selected = prefs.dupSort.ordinal,
                        onSelect = { onPrefs(prefs.copy(dupSort = DupSort.entries[it])) },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                    )
                }
            }

            items(visible, key = { "g:" + it.files.first().path }) { group ->
                GroupCard(
                    group = group,
                    selection = selection,
                    rootPath = rootPath,
                    rootLabel = rootLabel,
                    onOpen = onFileClick,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
                )
            }
        }

        if (hasPick) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, IxColors.Background)))
                    .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = bottomInset + 14.dp),
            ) {
                SlideToConfirm(
                    label = stringResource(R.string.t_dup_slide, toolCount(context, R.plurals.dup_copies, picked.size), formatFileSize(pickedBytes)),
                    enabled = true,
                    onConfirm = onDelete,
                )
            }
        }

        ToolSheet(
            visible = sheet,
            title = stringResource(R.string.t_customize),
            onClose = { sheet = false },
            footer = {
                SheetTextButton(
                    stringResource(R.string.t_reset_defaults),
                    onClick = {
                        val fresh = ToolPrefs()
                        onPrefs(prefs.copy(dupMinKb = fresh.dupMinKb, dupKeep = fresh.dupKeep, dupSort = fresh.dupSort, dupKinds = fresh.dupKinds))
                    },
                )
            },
        ) {
            SheetLabel(stringResource(R.string.t_dup_rule))
            ChoiceSetting(
                title = stringResource(R.string.t_dup_keep_title),
                note = stringResource(R.string.t_dup_keep_note),
                options = listOf(
                    stringResource(R.string.t_dup_keep_oldest) to DupKeep.Oldest,
                    stringResource(R.string.t_dup_keep_newest) to DupKeep.Newest,
                    stringResource(R.string.t_dup_keep_short) to DupKeep.ShortName,
                    stringResource(R.string.t_dup_keep_shallow) to DupKeep.Shallow,
                ),
                selected = prefs.dupKeep,
                onSelect = { onPrefs(prefs.copy(dupKeep = it)) },
            )

            SheetLabel(stringResource(R.string.t_dup_search))
            StepSetting(
                title = stringResource(R.string.t_dup_min_title),
                note = stringResource(R.string.t_dup_min_note),
                values = listOf(10, 100, 1024, 5120, 25600),
                value = prefs.dupMinKb,
                label = { if (it >= 1024) mbLabel(it / 1024) else "$it KB" },
                onChange = { onPrefs(prefs.copy(dupMinKb = it)) },
            )
            Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text(stringResource(R.string.t_dup_kinds_title), color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(stringResource(R.string.t_dup_kinds_note), color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                ChipRowInSheet {
                    for (kind in FileKind.entries) {
                        ToolChip(
                            label = stringResource(kindTitle(kind)),
                            selected = prefs.dupKinds.isEmpty() || kind in prefs.dupKinds,
                            onClick = { onPrefs(prefs.copy(dupKinds = toggledKinds(prefs, kind))) },
                        )
                    }
                }
            }
            SheetLabel(stringResource(R.string.t_clean_yours))
            ProtectedFoldersEditor(rootPath, prefs, onPrefs)
        }
    }
}

/** The chips of a sheet, scrolling sideways, without the page's side padding. */
@Composable
private fun ChipRowInSheet(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        content = content,
    )
}

/** One set of identical files in a card: its name and size on top, then a Keep / Remove switch for each copy. */
@Composable
private fun GroupCard(
    group: DuplicateGroup,
    selection: Selection,
    rootPath: String,
    rootLabel: String,
    onOpen: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val removedCount = group.files.count { it.path in selection.paths }
    val lastStays = removedCount >= group.files.size - 1 && removedCount > 0
    val keep = stringResource(R.string.t_dup_keep)
    val remove = stringResource(R.string.t_dup_remove)
    ToolCard(modifier) {
        Column(Modifier.padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 6.dp)) {
            Text(group.title(), color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                stringResource(R.string.dup_group_meta, toolCount(context, R.plurals.dup_copies, group.files.size), formatFileSize(group.size)),
                color = IxColors.Accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        for (file in group.files) {
            val removed = file.path in selection.paths
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(
                    Modifier
                        .weight(1f)
                        .clickable(role = Role.Button) { onOpen(file) }
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                ) {
                    Text(
                        locationOf(file.path, rootPath, rootLabel),
                        color = IxColors.TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        (if (file.extension.isEmpty()) file.name else file.name + "." + file.extension) + " · " + modifiedLabel(file.modifiedMillis),
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                ToolSegmented(
                    options = listOf(keep, remove),
                    selected = if (removed) 1 else 0,
                    onSelect = { index ->
                        val wantRemove = index == 1
                        // Never let the last copy go.
                        if (wantRemove != removed && !(wantRemove && removedCount >= group.files.size - 1)) {
                            selection.toggle(file.path)
                        }
                    },
                    modifier = Modifier.width(150.dp),
                    active = if (removed) IxColors.Danger else Hue.Mint,
                    activeText = if (removed) Color.White else Hue.Ink,
                )
            }
        }
        if (lastStays) {
            Text(
                stringResource(R.string.t_dup_last_stays),
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 4.dp),
            )
        }
        Spacer(Modifier.height(10.dp))
    }
}

/** The folder a file sits in, written from the top of storage: "DCIM/Camera". */
private fun locationOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}
