package ix.app.files.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.PathParser
import ix.app.files.ui.theme.IxColors

private const val VIEW_W = 96f
private const val VIEW_H = 80f

private fun parse(data: String): Path = PathParser().parsePathString(data).toPath()

private val folderBack = parse("M6 14a8 8 0 0 1 8-8h22l8 8h38a8 8 0 0 1 8 8v46a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8z")
private val folderFront = parse("M6 30a8 8 0 0 1 8-8h68a8 8 0 0 1 8 8v38a8 8 0 0 1-8 8H14a8 8 0 0 1-8-8z")

/**
 * The gray folder from the Files canvas mockup, with a type glyph embossed on the front.
 * Drawn on a 96 x 80 grid and scaled to whatever size the caller gives it.
 */
@Composable
fun FolderIcon(glyph: List<String>, modifier: Modifier = Modifier, tint: Color? = null, glyphTint: Color? = null) {
    val glyphPaths = remember(glyph) { glyph.map(::parse) }
    // A custom color replaces the gray. Every shade is worked out from that one color.
    val back = if (tint == null) IxColors.FolderBack else tint.shade(0.78f)
    val paper = if (tint == null) IxColors.FolderPaper else lerp(tint, Color.White, 0.85f)
    val frontTop = if (tint == null) IxColors.FolderFrontTop else lerp(tint, Color.White, 0.22f)
    val frontBottom = if (tint == null) IxColors.FolderFrontBottom else tint.shade(0.92f)
    val glyphColor = glyphTint ?: when {
        tint == null -> IxColors.FolderGlyph
        tint.luminance() > 0.55f -> tint.shade(0.35f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val glyphHighlight = if (glyphTint != null) {
        Color.Black.copy(alpha = 0.18f)
    } else if (tint != null && tint.luminance() <= 0.55f) {
        Color.Black.copy(alpha = 0.25f)
    } else {
        Color.White.copy(alpha = 0.8f)
    }

    Canvas(modifier) {
        val factor = size.width / VIEW_W
        scale(factor, factor, pivot = Offset.Zero) {
            drawPath(folderBack, back)
            drawRoundRect(
                color = paper,
                topLeft = Offset(16f, 14f),
                size = Size(64f, 38f),
                cornerRadius = CornerRadius(4f, 4f),
            )
            drawPath(
                folderFront,
                Brush.verticalGradient(
                    colors = listOf(frontTop, frontBottom),
                    startY = 22f,
                    endY = 76f,
                ),
            )

            // The glyph is 24 units wide, shown at 1.2x and centered on the front panel.
            val stroke = Stroke(width = 1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            translate(33.6f, 35.6f) {
                scale(1.2f, pivot = Offset.Zero) {
                    glyphPaths.forEach { drawPath(it, glyphHighlight, style = stroke) }
                }
            }
            translate(33.6f, 34.6f) {
                scale(1.2f, pivot = Offset.Zero) {
                    glyphPaths.forEach { drawPath(it, glyphColor, style = stroke) }
                }
            }
        }
    }
}

/** The same color, darkened. 1 keeps it, 0 is black. */
private fun Color.shade(amount: Float): Color = Color(red * amount, green * amount, blue * amount, alpha)
