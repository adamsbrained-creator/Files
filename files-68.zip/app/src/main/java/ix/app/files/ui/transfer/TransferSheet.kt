package ix.app.files.ui.transfer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ix.app.files.R
import ix.app.files.cast.CastHub
import ix.app.files.transfer.TransferHub
import ix.app.files.transfer.TransferPhase
import ix.app.files.transfer.TransferProblem
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.text.NumberFormat

/** One ready-made thing to send from the list: a label, how many files it holds, and the files themselves. */
class TransferChoice(val label: String, val count: Int, val paths: List<String>)

/**
 * "Send to PC". With [paths] it starts sharing exactly those files and folders; without, it shows what is being
 * shared now, or offers the [choices] when nothing is. Sharing keeps going when the window is closed.
 */
@Composable
fun TransferSheet(
    paths: List<String>?,
    choices: List<TransferChoice>,
    isPrivate: (String) -> Boolean,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val s by TransferHub.state.collectAsStateWithLifecycle()
    val granted by CastHub.localNetworkGranted.collectAsStateWithLifecycle()
    var askedForNetwork by remember { mutableStateOf(false) }
    var askedForNotifications by remember { mutableStateOf(false) }
    // What to start once the permissions are settled: from the caller at first, later from a tapped choice.
    var pending by remember { mutableStateOf(paths) }

    val networkLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        CastHub.refreshPermission()
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        CastHub.refreshPermission()
        if (!CastHub.localNetworkGranted.value) {
            askedForNetwork = true
            networkLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
        }
    }
    // Coming back from the settings page.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { CastHub.refreshPermission() }

    LaunchedEffect(granted) {
        // Android 13 and up asks before showing the "Sending" notification. Asked once, and sharing works without it.
        if (granted && !askedForNotifications) {
            askedForNotifications = true
            if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
            ) {
                notificationLauncher.launch("android.permission.POST_NOTIFICATIONS")
            }
        }
    }

    LaunchedEffect(pending, granted) {
        val list = pending
        if (list != null && granted) {
            pending = null
            // New files were picked while an older share runs: the new pick replaces it.
            if (TransferHub.active) TransferHub.stop()
            TransferHub.start(context, list, isPrivate)
        }
    }

    val sharing = granted && s.phase == TransferPhase.Sharing
    val counting = granted && (s.phase == TransferPhase.Counting || pending != null)
    val failed = granted && !counting && s.phase == TransferPhase.Failed

    // Closing never stops a running share. After an error it also clears the error.
    val close: () -> Unit = {
        if (failed) TransferHub.dismissProblem()
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = close,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(stringResource(if (!sharing && !counting && !failed && granted) R.string.transfer_pick_title else R.string.transfer_title)) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                when {
                    !granted -> {
                        Text(stringResource(R.string.cast_permission), color = IxColors.TextPrimary, fontSize = 14.sp)
                        TextButton(
                            onClick = {
                                if (askedForNetwork) openAppSettings(context) else {
                                    askedForNetwork = true
                                    networkLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
                                }
                            },
                        ) {
                            Text(
                                stringResource(if (askedForNetwork) R.string.cast_open_settings else R.string.cast_allow),
                                color = IxColors.TextPrimary,
                            )
                        }
                    }

                    sharing -> SharingBody(context, s.url, s.files, s.bytes, s.items, s.sentBytes, s.filesDone, s.client, s.connections)

                    counting -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        CircularProgressIndicator(
                            color = IxColors.TextPrimary,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(28.dp),
                        )
                        Text(
                            text = if (s.counted > 0) {
                                stringResource(R.string.transfer_counting_n, NumberFormat.getIntegerInstance().format(s.counted))
                            } else {
                                stringResource(R.string.transfer_counting)
                            },
                            color = IxColors.TextPrimary,
                            fontSize = 15.sp,
                        )
                    }

                    failed -> Text(
                        text = stringResource(
                            when (s.problem) {
                                TransferProblem.NoNetwork -> R.string.transfer_problem_network
                                TransferProblem.NothingToSend -> R.string.transfer_problem_nothing
                                else -> R.string.transfer_problem_other
                            },
                        ),
                        color = IxColors.TextPrimary,
                        fontSize = 14.sp,
                    )

                    else -> {
                        for (choice in choices) {
                            ChoiceRow(choice) { if (choice.paths.isNotEmpty()) pending = choice.paths }
                        }
                        Text(stringResource(R.string.transfer_pick_hint), fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            when {
                sharing || counting -> TextButton(onClick = { TransferHub.stop() }) {
                    Text(stringResource(R.string.transfer_stop), color = IxColors.Danger)
                }
                failed -> TextButton(
                    onClick = {
                        TransferHub.dismissProblem()
                        pending = paths // the same files again (after joining the Wi-Fi), or the list of choices
                    },
                ) {
                    Text(stringResource(R.string.transfer_try_again), color = IxColors.TextPrimary)
                }
                else -> Unit
            }
        },
        dismissButton = {
            TextButton(onClick = close) { Text(stringResource(R.string.transfer_close), color = IxColors.TextPrimary) }
        },
    )
}

@Composable
private fun SharingBody(
    context: Context,
    url: String,
    files: Int,
    bytes: Long,
    items: Int,
    sent: Long,
    done: Int,
    client: String,
    connections: Int,
) {
    val number = NumberFormat.getIntegerInstance()
    Text(stringResource(R.string.transfer_open_on_pc), color = IxColors.TextSecondary, fontSize = 13.sp)

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(IxColors.Field)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        SelectionContainer {
            Text(
                text = url.removePrefix("http://").trimEnd('/'),
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
            )
        }
        Text(
            text = stringResource(R.string.transfer_copy),
            color = IxColors.Accent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(role = Role.Button) {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("address", url))
                    Toast.makeText(context, R.string.transfer_copied, Toast.LENGTH_SHORT).show()
                }
                .padding(vertical = 4.dp),
        )
    }

    Text(
        text = stringResource(R.string.transfer_summary, number.format(files), formatFileSize(bytes)),
        color = IxColors.TextPrimary,
        fontSize = 15.sp,
        fontWeight = FontWeight.Medium,
    )

    // A thin bar, like the storage bar in the menu. It can pass full when the same files are fetched twice.
    val fraction = if (bytes > 0) (sent.toFloat() / bytes.toFloat()).coerceIn(0f, 1f) else 0f
    Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(IxColors.Chip)) {
        Box(Modifier.fillMaxWidth(fraction).height(6.dp).clip(CircleShape).background(IxColors.Accent))
    }
    Text(
        text = if (sent > 0) {
            stringResource(R.string.transfer_progress, formatFileSize(sent), number.format(done))
        } else {
            stringResource(R.string.transfer_waiting)
        },
        color = IxColors.TextSecondary,
        fontSize = 13.sp,
    )
    if (client.isNotEmpty() && (connections > 0 || sent > 0)) {
        Text(stringResource(R.string.transfer_pc_connected, client), color = IxColors.TextSecondary, fontSize = 13.sp)
    }
    Text(stringResource(R.string.transfer_hint), fontSize = 12.sp)
}

@Composable
private fun ChoiceRow(choice: TransferChoice, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(IxColors.Field)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PathIcon(Glyphs.Laptop, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.8f)
        Text(
            text = choice.label,
            color = IxColors.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        if (choice.count > 0) {
            Text(
                text = NumberFormat.getIntegerInstance().format(choice.count),
                color = IxColors.TextSecondary,
                fontSize = 13.sp,
            )
        }
    }
}

private fun openAppSettings(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}
