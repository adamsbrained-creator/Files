package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileKind
import ix.app.files.data.FileKinds
import ix.app.files.data.ToolPrefs
import ix.app.files.data.TrashItem
import ix.app.files.data.TrashSort
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File

/** How long deleted things stay in the Trash, in days. Zero means they are removed as soon as Undo is gone. */
val TrashKeepChoices = listOf(0, 7, 14, 30, 60, 90)

private const val DAY_MILLIS = 24L * 60 * 60 * 1000

/** A line of the list: a day heading, or one deleted item. */
private sealed interface TrashLine {
    class Heading(val title: Int) : TrashLine
    class Entry(val item: TrashItem) : TrashLine
}

private fun TrashItem.kind(): FileKind =
    if (isDirectory) FileKind.Other else FileKinds.kindOf(name.substringAfterLast('.', "").lowercase())

private fun daysLeft(item: TrashItem, keepDays: Int, now: Long): Int {
    val left = keepDays * DAY_MILLIS - (now - item.deletedAt)
    return if (left <= 0L) 0 else ((left + DAY_MILLIS - 1) / DAY_MILLIS).toInt()
}

/**
 * Everything that was deleted and is still waiting. Tap a line to tick it, then put it back or delete it for
 * good. The card under the top says how long things are kept, and what is about to go is marked.
 */
@Composable
fun TrashScreen(
    trashItems: List<TrashItem>,
    loading: Boolean,
    keepDays: Int,
    rootPath: String,
    prefs: ToolPrefs,
    onPrefs: (ToolPrefs) -> Unit,
    onBack: () -> Unit,
    onRestore: (Set<String>) -> Unit,
    onDelete: (Set<String>) -> Unit,
    onEmpty: () -> Unit,
    onKeepDays: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)

    // Ticks start again whenever the list is made anew, for instance after something was restored.
    var picked by remember(trashItems) { mutableStateOf(setOf<String>()) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pendingKeep by remember { mutableStateOf<Int?>(null) }
    var sheet by remember { mutableStateOf(false) }
    var kindFilter by remember { mutableStateOf<FileKind?>(null) }
    var foldersOnly by remember { mutableStateOf(false) }
    var expiringOnly by remember { mutableStateOf(false) }

    val now = remember(trashItems) { System.currentTimeMillis() }
    val totalBytes = trashItems.sumOf { it.bytes }
    val expiring = remember(trashItems, keepDays, prefs.trashWarnDays) {
        if (keepDays <= 0) emptyList() else trashItems.filter { daysLeft(it, keepDays, now) <= prefs.trashWarnDays }
    }
    val kindsPresent = remember(trashItems) { trashItems.filter { !it.isDirectory }.map { it.kind() }.toSet() }
    val hasFolders = remember(trashItems) { trashItems.any { it.isDirectory } }
    val kindBytes = remember(trashItems) {
        val map = HashMap<FileKind, Long>()
        for (i in trashItems) if (!i.isDirectory) map[i.kind()] = (map[i.kind()] ?: 0L) + i.bytes
        map
    }
    val folderBytes = remember(trashItems) { trashItems.filter { it.isDirectory }.sumOf { it.bytes } }

    val shown = remember(trashItems, prefs.trashSort, kindFilter, foldersOnly, expiringOnly, expiring) {
        var list = trashItems
        if (expiringOnly) list = list.filter { it in expiring }
        if (foldersOnly) list = list.filter { it.isDirectory } else if (kindFilter != null) list = list.filter { !it.isDirectory && it.kind() == kindFilter }
        when (prefs.trashSort) {
            TrashSort.Newest -> list.sortedByDescending { it.deletedAt }
            TrashSort.Oldest -> list.sortedBy { it.deletedAt }
            TrashSort.Biggest -> list.sortedByDescending { it.bytes }
            TrashSort.Name -> list.sortedBy { it.name.lowercase() }
        }
    }
    val lines = remember(shown, prefs.trashSort) {
        val out = ArrayList<TrashLine>()
        val byTime = prefs.trashSort == TrashSort.Newest || prefs.trashSort == TrashSort.Oldest
        var last = -1
        for (item in shown) {
            if (byTime) {
                val age = (now - item.deletedAt) / DAY_MILLIS
                val group = when {
                    age <= 0L -> 0
                    age == 1L -> 1
                    age < 7L -> 2
                    else -> 3
                }
                if (group != last) {
                    last = group
                    out.add(
                        TrashLine.Heading(
                            when (group) {
                                0 -> R.string.t_trash_today
                                1 -> R.string.t_trash_yesterday
                                2 -> R.string.t_trash_week
                                else -> R.string.t_trash_older
                            },
                        ),
                    )
                }
            }
            out.add(TrashLine.Entry(item))
        }
        out
    }
    val pickedBytes = trashItems.filter { it.storedPath in picked }.sumOf { it.bytes }
    val allShownPicked = shown.isNotEmpty() && shown.all { it.storedPath in picked }

    Box(modifier.toolPage()) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 120.dp)) {
            item(key = "hero") {
                ToolHero(
                    hue = Hue.Slate,
                    eyebrow = stringResource(R.string.trash_title),
                    onBack = onBack,
                    action = { HeroIconButton(Glyphs.Sliders, stringResource(R.string.t_customize)) { sheet = true } },
                ) {
                    when {
                        loading -> {
                            HeroNumber("…")
                            HeroSub(stringResource(R.string.trash_loading))
                        }

                        trashItems.isEmpty() -> {
                            HeroNumber("0", "B")
                            HeroSub(stringResource(R.string.trash_empty_note))
                        }

                        else -> {
                            val text = formatFileSize(if (picked.isNotEmpty()) pickedBytes else totalBytes)
                            HeroNumber(text.substringBefore(' '), text.substringAfter(' ', ""))
                            HeroSub(
                                if (picked.isNotEmpty()) {
                                    stringResource(R.string.t_trash_selected_of, picked.size, formatFileSize(totalBytes))
                                } else {
                                    toolCount(context, R.plurals.trash_items, trashItems.size)
                                },
                            )
                            if (keepDays > 0) {
                                val soonest = trashItems.minOf { daysLeft(it, keepDays, now) }
                                HeroSub(
                                    if (soonest <= 0) {
                                        stringResource(R.string.t_trash_next_today)
                                    } else {
                                        stringResource(R.string.t_trash_next_in, toolCount(context, R.plurals.t_days, soonest))
                                    },
                                    Modifier.padding(top = 2.dp),
                                )
                            }
                            Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                HeroPill(stringResource(R.string.trash_empty), filled = true, onClick = { confirmEmpty = true })
                                HeroPill(
                                    label = stringResource(if (allShownPicked) R.string.cleaner_deselect else R.string.cleaner_select),
                                    filled = false,
                                    onClick = {
                                        picked = if (allShownPicked) picked - shown.map { it.storedPath }.toSet() else picked + shown.map { it.storedPath }
                                    },
                                )
                            }
                        }
                    }
                }
            }

            // How long things are kept.
            item(key = "keep") {
                Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp)) {
                    ToolCard {
                        Column(Modifier.padding(vertical = 16.dp)) {
                            Text(
                                stringResource(R.string.trash_keep_label),
                                color = IxColors.TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 18.dp),
                            )
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(horizontal = 18.dp)
                                    .padding(top = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                val choices = if (keepDays in TrashKeepChoices) TrashKeepChoices else (TrashKeepChoices + keepDays).sorted()
                                for (days in choices) {
                                    ToolChip(
                                        label = if (days == 0) {
                                            stringResource(R.string.trash_keep_off)
                                        } else {
                                            daysLabel(context, days)
                                        },
                                        selected = days == keepDays,
                                        onClick = {
                                            if (days != keepDays) {
                                                // A shorter time deletes things that are in the Trash right now, so ask first.
                                                val wouldGo = trashItems.any { now - it.deletedAt >= days * DAY_MILLIS }
                                                if (wouldGo) pendingKeep = days else onKeepDays(days)
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (!loading && trashItems.isNotEmpty()) {
                // Filters.
                item(key = "chips") {
                    ChipRow(Modifier.padding(top = 18.dp)) {
                        ToolChip(
                            stringResource(R.string.t_all),
                            selected = kindFilter == null && !foldersOnly && !expiringOnly,
                            count = trashItems.size.toString(),
                            onClick = {
                                kindFilter = null
                                foldersOnly = false
                                expiringOnly = false
                            },
                        )
                        if (expiring.isNotEmpty()) {
                            ToolChip(
                                stringResource(R.string.t_trash_expiring),
                                selected = expiringOnly,
                                count = expiring.size.toString(),
                                onClick = { expiringOnly = !expiringOnly },
                            )
                        }
                        if (hasFolders) {
                            ToolChip(
                                stringResource(R.string.t_trash_folders),
                                selected = foldersOnly,
                                onClick = {
                                    foldersOnly = !foldersOnly
                                    kindFilter = null
                                },
                            )
                        }
                        for (kind in FileKind.entries) {
                            if (kind !in kindsPresent) continue
                            ToolChip(
                                stringResource(kindTitle(kind)),
                                selected = kindFilter == kind,
                                onClick = {
                                    kindFilter = if (kindFilter == kind) null else kind
                                    foldersOnly = false
                                },
                            )
                        }
                    }
                }

                // What is in it.
                if (kindBytes.isNotEmpty() || folderBytes > 0L) {
                    item(key = "mix-title") { ToolSection(stringResource(R.string.t_trash_mix)) }
                    val top = (kindBytes.values.maxOrNull() ?: 0L).coerceAtLeast(folderBytes).coerceAtLeast(1L).toFloat()
                    for ((kind, bytes) in kindBytes.entries.sortedByDescending { it.value }) {
                        item(key = "mix:" + kind.name) {
                            MeterRow(stringResource(kindTitle(kind)), formatFileSize(bytes), bytes / top, kindHue(kind))
                        }
                    }
                    if (folderBytes > 0L) {
                        item(key = "mix:folders") {
                            MeterRow(stringResource(R.string.t_trash_folders), formatFileSize(folderBytes), folderBytes / top, Hue.Grey)
                        }
                    }
                }

                item(key = "list-title") {
                    ToolSection(
                        stringResource(R.string.t_trash_deleted_title),
                        trailing = stringResource(R.string.t_trash_sorted, stringResource(sortLabel(prefs.trashSort))),
                        onTrailing = { sheet = true },
                    )
                }
            }

            items(lines, key = { line ->
                when (line) {
                    is TrashLine.Heading -> "h:" + line.title
                    is TrashLine.Entry -> "e:" + line.item.storedPath
                }
            }) { line ->
                when (line) {
                    is TrashLine.Heading -> Text(
                        stringResource(line.title),
                        color = IxColors.TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 12.dp, bottom = 2.dp),
                    )

                    is TrashLine.Entry -> {
                        val item = line.item
                        val left = if (keepDays > 0) daysLeft(item, keepDays, now) else -1
                        TrashRow(
                            item = item,
                            picked = item.storedPath in picked,
                            from = fromLabel(item.originalPath, rootPath, rootLabel),
                            warning = when {
                                left < 0 -> null
                                left <= prefs.trashWarnDays && left == 0 -> stringResource(R.string.t_trash_goes_today)
                                left <= prefs.trashWarnDays -> stringResource(R.string.t_trash_goes_in, toolCount(context, R.plurals.t_days, left))
                                else -> null
                            },
                            onToggle = {
                                picked = if (item.storedPath in picked) picked - item.storedPath else picked + item.storedPath
                            },
                        )
                    }
                }
            }

            if (!loading && trashItems.isEmpty()) {
                item(key = "empty") { ToolNote(stringResource(R.string.t_trash_empty_hint)) }
            }
        }

        if (picked.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, IxColors.Background)))
                    .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = bottomInset + 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ActionPill(
                    label = stringResource(R.string.trash_restore),
                    fill = IxColors.Accent,
                    text = Hue.Ink,
                    onClick = { onRestore(picked) },
                    modifier = Modifier.weight(1f),
                )
                ActionPill(
                    label = stringResource(R.string.trash_delete_forever),
                    fill = IxColors.Danger,
                    text = Color.White,
                    onClick = { confirmDelete = true },
                    modifier = Modifier.weight(1f),
                )
            }
        }

        ToolSheet(
            visible = sheet,
            title = stringResource(R.string.t_customize),
            onClose = { sheet = false },
            footer = {
                SheetTextButton(
                    stringResource(R.string.t_reset_defaults),
                    onClick = { onPrefs(prefs.copy(trashSort = ToolPrefs().trashSort, trashWarnDays = ToolPrefs().trashWarnDays)) },
                )
            },
        ) {
            SheetLabel(stringResource(R.string.t_sheet_lists))
            ChoiceSetting(
                title = stringResource(R.string.t_trash_sort_title),
                note = null,
                options = TrashSort.entries.map { stringResource(sortLabel(it)) to it },
                selected = prefs.trashSort,
                onSelect = { onPrefs(prefs.copy(trashSort = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_trash_warn_title),
                note = stringResource(R.string.t_trash_warn_note),
                values = listOf(1, 3, 7, 14),
                value = prefs.trashWarnDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(trashWarnDays = it)) },
            )
        }
    }

    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.trash_empty_title)) },
            text = { Text(stringResource(R.string.trash_empty_ask)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmEmpty = false
                    onEmpty()
                }) { Text(stringResource(R.string.trash_empty), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmEmpty = false }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.trash_delete_forever)) },
            text = { Text(toolCount(context, R.plurals.trash_delete_ask, picked.size)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(picked)
                }) { Text(stringResource(R.string.trash_delete_forever), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    val shorter = pendingKeep
    if (shorter != null) {
        AlertDialog(
            onDismissRequest = { pendingKeep = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.trash_keep_title)) },
            text = {
                Text(
                    if (shorter == 0) {
                        stringResource(R.string.trash_keep_ask_off)
                    } else {
                        context.resources.getQuantityString(R.plurals.trash_keep_ask, shorter, shorter)
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingKeep = null
                    onKeepDays(shorter)
                }) { Text(stringResource(R.string.trash_keep_confirm), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { pendingKeep = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

private fun sortLabel(sort: TrashSort): Int = when (sort) {
    TrashSort.Newest -> R.string.t_trash_sort_newest
    TrashSort.Oldest -> R.string.t_trash_sort_oldest
    TrashSort.Biggest -> R.string.t_trash_sort_biggest
    TrashSort.Name -> R.string.t_trash_sort_name
}

/** One deleted item: pastel badge, name, "size · deleted when", where it came from, a warning if it goes soon, a tick. */
@Composable
private fun TrashRow(item: TrashItem, picked: Boolean, from: String?, warning: String?, onToggle: () -> Unit) {
    val kind = item.kind()
    val deleted = modifiedLabel(item.deletedAt)
    val meta = formatFileSize(item.bytes) + " · " + stringResource(R.string.trash_deleted, deleted)
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (picked) IxColors.Accent.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(role = Role.Checkbox, onClick = onToggle)
            .semantics { selected = picked }
            .padding(horizontal = 20.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ToolBadge(if (item.isDirectory) Hue.Grey else kindHue(kind), if (item.isDirectory) Glyphs.Folder else kindGlyph(kind), size = 44.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(item.name, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (from != null) {
                Text(stringResource(R.string.trash_from, from), color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (warning != null) {
                Text(warning, color = IxColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
        CheckCircle(on = picked)
    }
}

/** The folder an item was deleted from, written from the top of storage: "Download/old". Null if unknown. */
private fun fromLabel(originalPath: String?, rootPath: String, rootLabel: String): String? {
    val parent = originalPath?.let { File(it).parent } ?: return null
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}
