package ix.app.files.cast

/** The part of a file a request asks for. [partial] is true when the answer is a 206. */
class ByteSpan(val start: Long, val end: Long, val partial: Boolean) {
    val length: Long get() = end - start + 1
}

/** Works out which bytes a "Range:" header asks for. Null means the range can not be satisfied (416). */
object RangeHeader {
    private val pattern = Regex("^\\s*bytes\\s*=\\s*(\\d*)\\s*-\\s*(\\d*)\\s*(,.*)?$", RegexOption.IGNORE_CASE)

    fun resolve(header: String?, size: Long): ByteSpan? {
        if (size <= 0) return if (header == null) ByteSpan(0, -1, false) else null
        val m = header?.let { pattern.find(it) } ?: return ByteSpan(0, size - 1, false)
        val a = m.groupValues[1]
        val b = m.groupValues[2]
        return when {
            a.isEmpty() && b.isEmpty() -> ByteSpan(0, size - 1, false)
            // "the last N bytes"
            a.isEmpty() -> {
                val n = b.toLongOrNull() ?: return null
                if (n <= 0) null else ByteSpan((size - n).coerceAtLeast(0), size - 1, true)
            }
            else -> {
                val start = a.toLongOrNull() ?: return null
                val end = if (b.isEmpty()) size - 1 else minOf(b.toLongOrNull() ?: return null, size - 1)
                if (start >= size || start > end) null else ByteSpan(start, end, true)
            }
        }
    }
}
