package ix.app.files.transfer

import java.io.File
import java.nio.file.Files

/** One file that can be fetched. [rel] always uses "/" and starts with the name of the root it belongs to. */
class TransferEntry(
    val id: Int,
    val root: Int,
    val rel: String,
    val file: File,
    val size: Long,
    val modified: Long,
)

/** One thing the person picked: a folder (everything inside it) or a single file. */
class TransferRoot(
    val index: Int,
    val name: String,
    val isFolder: Boolean,
    var files: Int = 0,
    var bytes: Long = 0,
)

/** Everything one "Send to PC" session offers. Built once, so the numbers on the phone and the PC always agree. */
class TransferPlan(val roots: List<TransferRoot>, val entries: List<TransferEntry>) {
    val totalFiles: Int get() = entries.size
    val totalBytes: Long get() = entries.sumOf { it.size }
    private val byId: Map<Int, TransferEntry> = entries.associateBy { it.id }
    fun entry(id: Int): TransferEntry? = byId[id]
    fun entriesOf(root: Int): List<TransferEntry> = entries.filter { it.root == root }
}

object TransferPlanner {

    /**
     * Walks the picked files and folders.
     *
     * A picked folder becomes one item and keeps its name. Files picked one by one (for example "select all" in
     * Music) are gathered into a single item called [looseName], and they keep the folders they sit in, counted
     * from the root of their storage ([storageRoots], e.g. /storage/emulated/0). So a backup on the PC looks like
     * the phone: Music/Artist/Album/song.mp3, not one flat heap.
     *
     * Folders are read all the way down, without following links, so a link that points back up can not loop
     * forever. Anything for which [skip] is true (the locked Private folder) is left out, and a file that is
     * reached twice (picked on its own and inside a picked folder) is listed once. [cancelled] is checked often,
     * because a whole phone can take a while to walk.
     */
    fun plan(
        paths: Collection<String>,
        skip: (String) -> Boolean = { false },
        cancelled: () -> Boolean = { false },
        progress: (Int) -> Unit = {},
        storageRoots: List<File> = emptyList(),
        looseName: String = "Selected files",
    ): TransferPlan {
        val roots = ArrayList<TransferRoot>()
        val entries = ArrayList<TransferEntry>()
        val usedRoots = HashSet<String>()
        val usedRel = HashSet<String>()
        val seen = HashSet<String>()
        var nextId = 1
        var loose: TransferRoot? = null

        fun add(root: TransferRoot, rel: String, file: File) {
            if (!seen.add(file.path)) return
            val size = file.length()
            entries += TransferEntry(nextId++, root.index, uniqueRel(rel, usedRel), file, size, file.lastModified())
            root.files++
            root.bytes += size
            if (entries.size % 500 == 0) progress(entries.size)
        }

        // Folders first, so a file picked on its own that also sits inside a picked folder stays with the folder.
        for (path in paths) {
            if (cancelled()) break
            val top = File(path)
            if (skip(path) || !top.exists() || !top.isDirectory) continue

            val name = uniqueName(top.name.ifBlank { "Storage" }, usedRoots)
            val root = TransferRoot(roots.size, name, true)
            roots += root

            // An explicit stack: a folder tree can be deep and the phone's thread stacks are small.
            val stack = ArrayDeque<Pair<File, String>>()
            stack.addLast(top to name)
            while (stack.isNotEmpty()) {
                if (cancelled()) break
                val (dir, prefix) = stack.removeLast()
                val children = dir.listFiles() ?: continue
                for (child in children) {
                    if (skip(child.path)) continue
                    val rel = prefix + "/" + child.name
                    val link = runCatching { Files.isSymbolicLink(child.toPath()) }.getOrDefault(false)
                    if (child.isDirectory) {
                        if (!link) stack.addLast(child to rel)
                    } else if (child.isFile && child.canRead()) {
                        add(root, rel, child)
                    }
                }
            }
        }
        for (path in paths) {
            if (cancelled()) break
            val file = File(path)
            if (skip(path) || !file.isFile || !file.canRead() || file.path in seen) continue
            val group = loose ?: TransferRoot(roots.size, uniqueName(looseName, usedRoots), false)
                .also { loose = it; roots += it }
            add(group, relativeToStorage(file, storageRoots), file)
        }
        // A stable order, so every download (the zip, the script) lists the same files the same way.
        entries.sortWith(compareBy({ it.root }, { it.rel.lowercase() }, { it.rel }))
        return TransferPlan(roots, entries)
    }

    /** "Music/Artist/song.mp3" for /storage/emulated/0/Music/Artist/song.mp3; just the name when it is on no known storage. */
    internal fun relativeToStorage(file: File, storageRoots: List<File>): String {
        val path = file.path
        val root = storageRoots
            .filter { path.startsWith(it.path.trimEnd('/') + "/") }
            .maxByOrNull { it.path.length }
        return if (root == null) file.name else path.substring(root.path.trimEnd('/').length + 1)
    }

    private fun uniqueName(name: String, used: MutableSet<String>): String {
        var candidate = name
        var n = 2
        while (!used.add(candidate.lowercase())) candidate = "$name ($n)".also { n++ }
        return candidate
    }

    /** Two different files must never get the same path in the archive (Windows ignores upper/lower case). */
    private fun uniqueRel(rel: String, used: MutableSet<String>): String {
        if (used.add(rel.lowercase())) return rel
        val slash = rel.lastIndexOf('/')
        val dir = if (slash >= 0) rel.substring(0, slash + 1) else ""
        val file = rel.substring(slash + 1)
        val dot = file.lastIndexOf('.')
        val stem = if (dot > 0) file.substring(0, dot) else file
        val ext = if (dot > 0) file.substring(dot) else ""
        var n = 2
        while (true) {
            val candidate = "$dir$stem ($n)$ext"
            if (used.add(candidate.lowercase())) return candidate
            n++
        }
    }
}
