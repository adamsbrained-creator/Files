package ix.app.files.data

import androidx.compose.runtime.Immutable
import java.io.File
import java.nio.file.Files

/**
 * The kinds of leftovers the Cleaner looks for, in the order they are shown.
 * [safe] kinds are almost always fine to clear; the others deserve a look first.
 */
enum class CleanKind(val safe: Boolean) {
    Installers(true),
    Leftovers(true),
    EmptyFolders(true),
    CopyNames(false),
    Screenshots(false),
    Archives(false),
    OldDownloads(false),
    LargeOld(false),
}

/** What the person tuned on the Cleaner page. The defaults are what the Cleaner always did. */
class CleanOptions(
    val enabled: Set<CleanKind> = CleanKind.entries.toSet(),
    val largeBytes: Long = CleanerEngine.LARGE_BYTES,
    val largeDays: Int = CleanerEngine.OLD_DAYS,
    val downloadDays: Int = 60,
    val screenshotDays: Int = 30,
    val archiveDays: Int = 30,
    val settleMillis: Long = CleanerEngine.SETTLE_MILLIS,
    val extraJunk: Set<String> = emptySet(),
    /** Full paths of folders nothing is ever offered from. */
    val protectedPaths: Set<String> = emptySet(),
) {
    fun isProtected(path: String): Boolean {
        if (protectedPaths.isEmpty()) return false
        for (p in protectedPaths) {
            if (path == p || path.startsWith("$p/")) return true
        }
        return false
    }
}

/** One kind of leftover and what was found. Empty folders come as [folders], everything else as [files]. */
@Immutable
class CleanGroup(val kind: CleanKind, val files: List<FileItem>, val folders: List<FolderItem>) {
    val count: Int get() = files.size + folders.size
    val bytes: Long get() = files.sumOf { it.sizeBytes }
    val paths: List<String> get() = folders.map { it.path } + files.map { it.path }
}

/**
 * Finds things that are very likely safe to clear, from the list of files the last scan made.
 * Nothing is deleted here: the screen lists them and the usual delete (with Undo) does the work.
 *
 * Every file is listed in one group only, the first that fits, so no space is counted twice.
 */
object CleanerEngine {

    /** Files this big that nobody touched for [OLD_DAYS] days are offered for review. */
    const val LARGE_BYTES = 100L * 1024 * 1024
    const val OLD_DAYS = 90

    /** Half-written downloads and the like are left alone for a day, since they may still be in use. */
    const val SETTLE_MILLIS = 24L * 60 * 60 * 1000

    private const val DAY_MILLIS = 24L * 60 * 60 * 1000

    private val installerExtensions = setOf("apk", "xapk", "apks", "apkm")

    /** Extensions that mean "temporary", "backup" or "unfinished". */
    private val leftoverExtensions = setOf(
        "tmp", "temp", "bak", "old", "crdownload", "part", "partial", "download", "dmp", "swp", "log",
    )

    /** Folders at the top of storage that Android and apps expect to find, even when empty. */
    private val standardFolders = setOf(
        "alarms", "audiobooks", "dcim", "documents", "download", "downloads", "movies", "music",
        "notifications", "pictures", "podcasts", "recordings", "ringtones",
    )

    /**
     * Looks through [scan]. [rootPath] is the top of storage: its standard folders are never offered.
     * [active] is asked now and then; once it returns false the work stops and returns nothing.
     * Call off the main thread: empty folders are double-checked on disk.
     */
    fun find(
        scan: ScanData,
        rootPath: String,
        now: Long = System.currentTimeMillis(),
        active: () -> Boolean = { true },
        options: CleanOptions = CleanOptions(),
    ): List<CleanGroup> {
        val buckets = HashMap<CleanKind, ArrayList<FileItem>>()
        fun put(kind: CleanKind, file: FileItem) {
            if (kind in options.enabled) buckets.getOrPut(kind) { ArrayList() }.add(file)
        }

        val root = rootPath.trimEnd('/')
        val downloads = "$root/Download/"
        val everyPath = HashSet<String>(scan.files.size * 2)
        if (CleanKind.CopyNames in options.enabled) for (file in scan.files) everyPath.add(file.path)

        val settled = now - options.settleMillis
        for (file in scan.files) {
            if (options.isProtected(file.path)) continue
            val ext = file.extension
            when {
                isLeftover(file, settled, options.extraJunk) -> put(CleanKind.Leftovers, file)
                ext in installerExtensions -> put(CleanKind.Installers, file)
                CleanKind.CopyNames in options.enabled && isNameCopy(file, everyPath) -> put(CleanKind.CopyNames, file)
                file.kind == FileKind.Image && file.path.contains("/Screenshots/", ignoreCase = true) &&
                    file.modifiedMillis < now - options.screenshotDays * DAY_MILLIS -> put(CleanKind.Screenshots, file)
                ext in archiveExtensions && file.modifiedMillis < now - options.archiveDays * DAY_MILLIS ->
                    put(CleanKind.Archives, file)
                file.sizeBytes >= options.largeBytes && file.modifiedMillis < now - options.largeDays * DAY_MILLIS ->
                    put(CleanKind.LargeOld, file)
                file.path.startsWith(downloads) && file.modifiedMillis < now - options.downloadDays * DAY_MILLIS ->
                    put(CleanKind.OldDownloads, file)
            }
        }
        if (!active()) return emptyList()
        val empty = if (CleanKind.EmptyFolders in options.enabled) emptyFolders(scan, rootPath, settled, options, active) else emptyList()
        if (!active()) return emptyList()

        val groups = ArrayList<CleanGroup>()
        for (kind in CleanKind.entries) {
            if (kind == CleanKind.EmptyFolders) {
                if (empty.isNotEmpty()) groups.add(CleanGroup(kind, emptyList(), empty))
                continue
            }
            val list = buckets[kind] ?: continue
            if (list.isNotEmpty()) groups.add(CleanGroup(kind, list.sortedByDescending { it.sizeBytes }, emptyList()))
        }
        return groups
    }

    private val archiveExtensions = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")

    /** "photo (1).jpg", "photo - Copy.jpg" and "Copy of photo.jpg" next to a "photo.jpg" that is still there. */
    internal fun isNameCopy(file: FileItem, everyPath: Set<String>): Boolean {
        val name = file.name
        val base = when {
            name.startsWith("Copy of ") -> name.removePrefix("Copy of ")
            else -> copySuffix.replace(name, "")
        }
        if (base.isEmpty() || base == name) return false
        val dir = file.path.substringBeforeLast('/')
        val original = if (file.extension.isEmpty()) "$dir/$base" else "$dir/$base.${file.extension}"
        return original != file.path && original in everyPath
    }

    private val copySuffix = Regex("""( \(\d+\)| - Copy( \(\d+\))?| copy( \d+)?)$""", RegexOption.IGNORE_CASE)

    /** Temporary, backup and unfinished files, and files with nothing in them, once they have settled. */
    private fun isLeftover(file: FileItem, settled: Long, extra: Set<String>): Boolean {
        if (file.modifiedMillis > settled) return false
        if (file.sizeBytes == 0L) return true
        if (file.extension in leftoverExtensions || file.extension in extra) return true
        // Editors leave "notes.txt~" behind.
        return file.name.endsWith("~") || file.extension.endsWith("~")
    }

    /**
     * Folders with no file anywhere inside them, only the top one of a nest of empty folders.
     * The scan skips hidden names, so a folder that only looks empty is checked on disk before it is offered.
     */
    private fun emptyFolders(scan: ScanData, rootPath: String, settled: Long, options: CleanOptions, active: () -> Boolean): List<FolderItem> {
        // Every folder that has a file somewhere below it.
        val withFiles = HashSet<String>()
        for (file in scan.files) {
            var parent = File(file.path).parent
            while (parent != null && withFiles.add(parent)) {
                parent = File(parent).parent
            }
        }

        val candidates = scan.folders
            .filter { it.path !in withFiles && it.modifiedMillis <= settled && !isStandard(it.path, rootPath) && !options.isProtected(it.path) }
            .sortedBy { it.path.length }

        // Shortest paths first, so a folder inside an already chosen one is skipped.
        val chosen = HashSet<String>()
        val result = ArrayList<FolderItem>()
        for (folder in candidates) {
            if (!active()) return emptyList()
            var inside = false
            var parent = File(folder.path).parent
            while (parent != null) {
                if (parent in chosen) {
                    inside = true
                    break
                }
                parent = File(parent).parent
            }
            if (inside) continue
            if (!holdsNoFiles(File(folder.path))) continue
            chosen.add(folder.path)
            result.add(folder)
        }
        return result.sortedBy { it.path.lowercase() }
    }

    private fun isStandard(path: String, rootPath: String): Boolean {
        val parent = File(path).parent ?: return true
        return parent == rootPath && File(path).name.lowercase() in standardFolders
    }

    /** True when the folder and everything below it are folders only: no file, hidden or not, and no link. */
    internal fun holdsNoFiles(dir: File): Boolean {
        if (!dir.isDirectory || Files.isSymbolicLink(dir.toPath())) return false
        val children = dir.listFiles() ?: return false
        for (child in children) {
            if (Files.isSymbolicLink(child.toPath()) || !child.isDirectory) return false
            if (!holdsNoFiles(child)) return false
        }
        return true
    }
}
