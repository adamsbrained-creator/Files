package ix.app.files.provider

import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Point
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsContract
import android.provider.DocumentsProvider
import android.content.res.AssetFileDescriptor
import android.webkit.MimeTypeMap
import ix.app.files.R
import ix.app.files.data.FileOps
import ix.app.files.data.StorageAccess
import java.io.File
import java.io.FileNotFoundException

/**
 * Makes the app show up in the system file picker (the "Open", "Save as" and "Attach" screens of other apps) as a
 * place to browse, open, create, rename, copy, move and delete files, like Google Files does.
 *
 * It serves shared storage only. Private lives in the app's own storage, outside this root, so it can never be
 * reached from here. A document id is simply the file's absolute path, and every id is checked to stay inside storage.
 */
class IxDocumentsProvider : DocumentsProvider() {

    private val storage: File get() = StorageAccess.root()
    private val authority: String get() = context!!.packageName + ".documents"

    override fun onCreate(): Boolean = true

    // ---- Roots ----

    override fun queryRoots(projection: Array<String>?): Cursor {
        val cursor = MatrixCursor(projection ?: DEFAULT_ROOT_PROJECTION)
        val context = context ?: return cursor
        // Without "All files access" there is nothing to show, so the place stays out of the picker.
        if (!StorageAccess.hasAccess(context)) return cursor
        val root = storage
        cursor.newRow().apply {
            add(Root.COLUMN_ROOT_ID, ROOT_ID)
            add(Root.COLUMN_DOCUMENT_ID, root.absolutePath)
            add(Root.COLUMN_TITLE, context.getString(R.string.app_name))
            add(Root.COLUMN_SUMMARY, context.getString(R.string.browser_root))
            add(Root.COLUMN_ICON, R.mipmap.ic_launcher)
            add(Root.COLUMN_MIME_TYPES, "*/*")
            add(Root.COLUMN_AVAILABLE_BYTES, root.freeSpace)
            add(
                Root.COLUMN_FLAGS,
                Root.FLAG_LOCAL_ONLY or Root.FLAG_SUPPORTS_CREATE or Root.FLAG_SUPPORTS_IS_CHILD or
                    Root.FLAG_SUPPORTS_SEARCH,
            )
        }
        return cursor
    }

    // ---- Browsing ----

    override fun queryDocument(documentId: String, projection: Array<String>?): Cursor {
        val cursor = MatrixCursor(projection ?: DEFAULT_DOCUMENT_PROJECTION)
        addRow(cursor, resolve(documentId))
        return cursor
    }

    override fun queryChildDocuments(parentDocumentId: String, projection: Array<String>?, sortOrder: String?): Cursor {
        val cursor = MatrixCursor(projection ?: DEFAULT_DOCUMENT_PROJECTION)
        val parent = resolve(parentDocumentId)
        val children = parent.listFiles() ?: return cursor
        for (child in children) {
            if (child.name.startsWith(".")) continue
            addRow(cursor, child)
        }
        return cursor
    }

    override fun querySearchDocuments(rootId: String, query: String, projection: Array<String>?): Cursor {
        val cursor = MatrixCursor(projection ?: DEFAULT_DOCUMENT_PROJECTION)
        val root = storage
        val androidDir = File(root, "Android")
        var found = 0
        root.walkTopDown()
            .onEnter { dir -> !dir.name.startsWith(".") && dir != androidDir }
            .forEach { file ->
                if (found >= SEARCH_LIMIT) return@forEach
                if (file != root && !file.name.startsWith(".") && file.name.contains(query, ignoreCase = true)) {
                    addRow(cursor, file)
                    found++
                }
            }
        return cursor
    }

    override fun isChildDocument(parentDocumentId: String, documentId: String): Boolean = try {
        val parent = resolve(parentDocumentId).canonicalPath
        val child = resolve(documentId).canonicalPath
        child == parent || child.startsWith("$parent/")
    } catch (e: Exception) {
        false
    }

    override fun getDocumentType(documentId: String): String = mimeOf(resolve(documentId))

    // ---- Reading and writing ----

    override fun openDocument(documentId: String, mode: String, signal: CancellationSignal?): ParcelFileDescriptor {
        val file = resolve(documentId)
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.parseMode(mode))
    }

    override fun openDocumentThumbnail(
        documentId: String,
        sizeHint: Point,
        signal: CancellationSignal?,
    ): AssetFileDescriptor {
        val file = resolve(documentId)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw FileNotFoundException("Not a picture")
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= sizeHint.x && bounds.outHeight / (sample * 2) >= sizeHint.y) sample *= 2
        val bitmap = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw FileNotFoundException("Could not read the picture")
        val cache = File(context!!.cacheDir, "doc-thumbs").apply { mkdirs() }
        val out = File.createTempFile("t", ".jpg", cache)
        try {
            out.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        } finally {
            bitmap.recycle()
        }
        val descriptor = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_READ_ONLY)
        // The open descriptor keeps the data readable, so the temporary file can go right away.
        out.delete()
        return AssetFileDescriptor(descriptor, 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    // ---- Changing ----

    override fun createDocument(parentDocumentId: String, mimeType: String, displayName: String): String {
        val parent = resolve(parentDocumentId)
        if (!parent.isDirectory) throw FileNotFoundException("Not a folder")
        val target = FileOps.uniqueTarget(parent, cleanName(displayName))
        val created = if (mimeType == Document.MIME_TYPE_DIR) target.mkdir() else target.createNewFile()
        if (!created) throw FileNotFoundException("Could not create ${target.name}")
        notifyChildren(parent)
        return target.absolutePath
    }

    override fun deleteDocument(documentId: String) {
        val file = resolve(documentId)
        if (file == storage) throw SecurityException("Storage itself can not be deleted")
        if (!file.deleteRecursively()) throw FileNotFoundException("Could not delete ${file.name}")
        file.parentFile?.let { notifyChildren(it) }
    }

    override fun renameDocument(documentId: String, displayName: String): String? {
        val file = resolve(documentId)
        if (file == storage) throw SecurityException("Storage itself can not be renamed")
        val parent = file.parentFile ?: throw FileNotFoundException()
        val target = File(parent, cleanName(displayName))
        if (target.exists()) throw FileNotFoundException("${target.name} already exists")
        if (!file.renameTo(target)) throw FileNotFoundException("Could not rename ${file.name}")
        notifyChildren(parent)
        return target.absolutePath
    }

    override fun copyDocument(sourceDocumentId: String, targetParentDocumentId: String): String {
        val source = resolve(sourceDocumentId)
        val parent = resolve(targetParentDocumentId)
        val target = FileOps.uniqueTarget(parent, source.name)
        if (!source.copyRecursively(target, overwrite = false)) throw FileNotFoundException("Could not copy ${source.name}")
        notifyChildren(parent)
        return target.absolutePath
    }

    override fun moveDocument(
        sourceDocumentId: String,
        sourceParentDocumentId: String,
        targetParentDocumentId: String,
    ): String {
        val source = resolve(sourceDocumentId)
        val parent = resolve(targetParentDocumentId)
        val target = FileOps.uniqueTarget(parent, source.name)
        if (!source.renameTo(target)) {
            // A different volume can not rename, so copy and then remove the original.
            if (!source.copyRecursively(target, overwrite = false) || !source.deleteRecursively()) {
                throw FileNotFoundException("Could not move ${source.name}")
            }
        }
        notifyChildren(parent)
        notifyChildren(resolve(sourceParentDocumentId))
        return target.absolutePath
    }

    // ---- Helpers ----

    /** The file for [documentId], only if it really sits inside shared storage. Everything else is refused. */
    private fun resolve(documentId: String): File {
        val root = storage.canonicalFile
        val file = File(documentId).canonicalFile
        if (file != root && !file.path.startsWith(root.path + "/")) {
            throw SecurityException("$documentId is outside shared storage")
        }
        if (!file.exists()) throw FileNotFoundException("$documentId does not exist")
        return file
    }

    private fun addRow(cursor: MatrixCursor, file: File) {
        val isRoot = file == storage.canonicalFile
        var flags = 0
        if (file.isDirectory) {
            if (file.canWrite()) flags = flags or Document.FLAG_DIR_SUPPORTS_CREATE
        } else if (file.canWrite()) {
            flags = flags or Document.FLAG_SUPPORTS_WRITE
        }
        val mime = mimeOf(file)
        if (!isRoot) {
            flags = flags or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME or
                Document.FLAG_SUPPORTS_COPY or Document.FLAG_SUPPORTS_MOVE
        }
        if (mime.startsWith("image/")) flags = flags or Document.FLAG_SUPPORTS_THUMBNAIL
        cursor.newRow().apply {
            add(Document.COLUMN_DOCUMENT_ID, file.absolutePath)
            add(
                Document.COLUMN_DISPLAY_NAME,
                if (isRoot) context!!.getString(R.string.browser_root) else file.name,
            )
            add(Document.COLUMN_SIZE, if (file.isDirectory) null else file.length())
            add(Document.COLUMN_MIME_TYPE, mime)
            add(Document.COLUMN_LAST_MODIFIED, file.lastModified())
            add(Document.COLUMN_FLAGS, flags)
        }
    }

    private fun mimeOf(file: File): String {
        if (file.isDirectory) return Document.MIME_TYPE_DIR
        val extension = file.extension.lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: "application/octet-stream"
    }

    /** A name with no slashes, so a new file can never land outside the folder it was made in. */
    private fun cleanName(name: String): String = name.replace('/', '_').ifBlank { "Untitled" }

    private fun notifyChildren(parent: File) {
        val uri = DocumentsContract.buildChildDocumentsUri(authority, parent.absolutePath)
        context?.contentResolver?.notifyChange(uri, null)
    }

    private companion object {
        const val ROOT_ID = "storage"
        const val SEARCH_LIMIT = 100

        val DEFAULT_ROOT_PROJECTION = arrayOf(
            Root.COLUMN_ROOT_ID, Root.COLUMN_FLAGS, Root.COLUMN_ICON, Root.COLUMN_TITLE, Root.COLUMN_SUMMARY,
            Root.COLUMN_DOCUMENT_ID, Root.COLUMN_MIME_TYPES, Root.COLUMN_AVAILABLE_BYTES,
        )
        val DEFAULT_DOCUMENT_PROJECTION = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_MIME_TYPE, Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS, Document.COLUMN_SIZE,
        )
    }
}
