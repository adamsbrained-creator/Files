package ix.app.files.ui.home

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.ToolPrefs
import ix.app.files.insights.AgeBand
import ix.app.files.insights.InsightsReport
import ix.app.files.insights.RuleAction
import ix.app.files.insights.RulePresets
import ix.app.files.insights.SortRule
import ix.app.files.insights.Suggestion
import ix.app.files.insights.SuggestionAction
import ix.app.files.insights.SuggestionKind
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** How many files of a suggestion are listed on its card. The buttons act on all of them. */
private const val PREVIEW_ROWS = 3

/** Which suggestions the chips under "Suggestions" show. */
private enum class InsightGroup { All, Free, Organize, Folders }

/** The blocks of the page the person can hide. They are kept in the same saved set as the switched-off suggestions. */
private val InsightSections = listOf("week", "tiles", "space", "growth", "habits", "rules")

private fun ToolPrefs.sectionOn(name: String): Boolean = "sec:$name" !in insightsOff

private fun sectionTitleRes(name: String): Int = when (name) {
    "week" -> R.string.t_ins_week
    "tiles" -> R.string.t_ins_numbers
    "space" -> R.string.insights_section_storage
    "growth" -> R.string.insights_growth
    "habits" -> R.string.insights_section_habits
    else -> R.string.insights_section_rules
}

/** The suggestion kinds the person can switch off, in the order the sheet lists them. Rules have their own switches. */
private val SwitchableKinds = listOf(
    SuggestionKind.Misplaced,
    SuggestionKind.OldScreenshots,
    SuggestionKind.OldDownloads,
    SuggestionKind.BigUntouched,
    SuggestionKind.BigVideos,
    SuggestionKind.Installers,
    SuggestionKind.Archives,
    SuggestionKind.CopyNames,
    SuggestionKind.DeleteHabit,
    SuggestionKind.FrequentFolder,
    SuggestionKind.StaleFolder,
    SuggestionKind.Growing,
)

private fun SuggestionKind.hue(): Color = when (this) {
    SuggestionKind.Rule -> Hue.Lavender
    SuggestionKind.Misplaced -> Hue.Blue
    SuggestionKind.OldScreenshots -> Hue.Mint
    SuggestionKind.DeleteHabit -> Hue.Pink
    SuggestionKind.OldDownloads -> Hue.Peach
    SuggestionKind.BigUntouched -> Hue.Slate
    SuggestionKind.FrequentFolder -> Hue.Yellow
    SuggestionKind.StaleFolder -> Hue.Grey
    SuggestionKind.Growing -> Hue.Peach
    SuggestionKind.Installers -> Hue.Blue
    SuggestionKind.Archives -> Hue.Lavender
    SuggestionKind.BigVideos -> Hue.Pink
    SuggestionKind.CopyNames -> Hue.Mint
}

private fun SuggestionKind.glyph(): List<String> = when (this) {
    SuggestionKind.Rule -> Glyphs.Funnel
    SuggestionKind.Misplaced -> Glyphs.Move
    SuggestionKind.OldScreenshots -> Glyphs.Images
    SuggestionKind.DeleteHabit -> Glyphs.Trash
    SuggestionKind.OldDownloads -> Glyphs.Downloads
    SuggestionKind.BigUntouched -> Glyphs.Pie
    SuggestionKind.FrequentFolder -> Glyphs.Star
    SuggestionKind.StaleFolder -> Glyphs.Folder
    SuggestionKind.Growing -> Glyphs.Trend
    SuggestionKind.Installers -> Glyphs.Apps
    SuggestionKind.Archives -> Glyphs.Archive
    SuggestionKind.BigVideos -> Glyphs.Videos
    SuggestionKind.CopyNames -> Glyphs.Copy
}

private fun SuggestionKind.switchTitle(): Int = when (this) {
    SuggestionKind.Rule -> R.string.insights_section_rules
    SuggestionKind.Misplaced -> R.string.t_ins_sw_misplaced
    SuggestionKind.OldScreenshots -> R.string.t_ins_sw_screenshots
    SuggestionKind.DeleteHabit -> R.string.t_ins_sw_habit
    SuggestionKind.OldDownloads -> R.string.t_ins_sw_downloads
    SuggestionKind.BigUntouched -> R.string.t_ins_sw_big
    SuggestionKind.FrequentFolder -> R.string.t_ins_sw_frequent
    SuggestionKind.StaleFolder -> R.string.t_ins_sw_stale
    SuggestionKind.Growing -> R.string.t_ins_sw_growing
    SuggestionKind.Installers -> R.string.t_ins_sw_installers
    SuggestionKind.Archives -> R.string.t_ins_sw_archives
    SuggestionKind.BigVideos -> R.string.t_ins_sw_videos
    SuggestionKind.CopyNames -> R.string.t_ins_sw_copies
}

private fun groupOf(s: Suggestion, report: InsightsReport): InsightGroup = when {
    s.id in report.reclaimIds -> InsightGroup.Free
    s.kind == SuggestionKind.StaleFolder || s.kind == SuggestionKind.Growing || s.kind == SuggestionKind.FrequentFolder -> InsightGroup.Folders
    else -> InsightGroup.Organize
}

/**
 * What the app has worked out about your files, in a pastel page: how much could go, how much came in lately,
 * suggestions with a button each, where the space went, what you open most, and the sorting rules. Nothing is
 * moved or deleted until you tap a button and confirm; "Review" hands the files to the usual selection bar,
 * whose Delete can be undone. Every number behind the suggestions can be tuned under Customize.
 */
@Composable
fun InsightsScreen(
    report: InsightsReport?,
    loading: Boolean,
    scanning: Boolean,
    rootPath: String,
    favorites: Set<String>,
    selection: Selection,
    rules: List<SortRule>,
    habitsOn: Boolean,
    ruleEditor: SortRule?,
    prefs: ToolPrefs,
    onPrefs: (ToolPrefs) -> Unit,
    onBack: () -> Unit,
    onToggleFiles: (List<String>) -> Unit,
    onApply: (Suggestion) -> Unit,
    onDismiss: (Suggestion) -> Unit,
    onFileClick: (FileItem) -> Unit,
    onFolderClick: (String) -> Unit,
    onHabitsOn: (Boolean) -> Unit,
    onClearHabits: () -> Unit,
    onEditRule: (SortRule) -> Unit,
    onRuleEnabled: (SortRule, Boolean) -> Unit,
    onSaveRule: (SortRule) -> Unit,
    onDeleteRule: (String) -> Unit,
    onCloseRuleEditor: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)
    var confirm by remember { mutableStateOf<Suggestion?>(null) }
    var sheet by remember { mutableStateOf(false) }
    var group by remember { mutableStateOf(InsightGroup.All) }

    val reclaimPaths = remember(report) {
        if (report == null) {
            emptyList()
        } else {
            report.suggestions.filter { it.id in report.reclaimIds }.flatMap { s -> s.files.map { it.path } }.distinct()
        }
    }
    val allReclaimPicked = reclaimPaths.isNotEmpty() && reclaimPaths.all { it in selection.paths }

    Box(modifier.toolPage()) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 120.dp)) {
            item(key = "hero") {
                ToolHero(
                    hue = Hue.Yellow,
                    eyebrow = stringResource(R.string.insights_title),
                    onBack = onBack,
                    action = { HeroIconButton(Glyphs.Sliders, stringResource(R.string.t_customize)) { sheet = true } },
                ) {
                    if (loading || report == null) {
                        HeroNumber("…")
                        HeroSub(stringResource(R.string.insights_loading))
                    } else if (report.reclaimBytes > 0L) {
                        val text = formatFileSize(report.reclaimBytes)
                        HeroNumber(text.substringBefore(' '), text.substringAfter(' ', ""))
                        HeroSub(stringResource(R.string.t_ins_reclaim_sub, report.reclaimIds.size))
                        Row(Modifier.padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            HeroPill(
                                label = stringResource(if (allReclaimPicked) R.string.cleaner_deselect else R.string.t_ins_review_all),
                                filled = true,
                                onClick = { onToggleFiles(reclaimPaths) },
                            )
                        }
                    } else {
                        val text = formatFileSize(report.totalBytes)
                        HeroNumber(text.substringBefore(' '), text.substringAfter(' ', ""))
                        HeroSub(toolCount(context, R.plurals.timeline_files, report.fileCount))
                    }
                    if (scanning && !loading) {
                        HeroSub(stringResource(R.string.insights_scanning_note), Modifier.padding(top = 12.dp))
                    }
                }
            }

            if (!loading && report != null) {
                // ---- Numbers ----
                if (prefs.sectionOn("tiles")) {
                    item(key = "tiles") {
                        Column(
                            Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ColorTile(
                                    hue = Hue.Mint,
                                    title = stringResource(R.string.t_ins_tile_week),
                                    big = formatFileSize(report.addedWeekBytes),
                                    small = toolCount(context, R.plurals.timeline_files, report.addedWeekCount),
                                    modifier = Modifier.weight(1f),
                                )
                                ColorTile(
                                    hue = Hue.Lavender,
                                    title = stringResource(R.string.t_ins_tile_month),
                                    big = formatFileSize(report.addedMonthBytes),
                                    small = toolCount(context, R.plurals.timeline_files, report.addedMonthCount),
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                val top = report.biggest.firstOrNull()
                                ColorTile(
                                    hue = Hue.Pink,
                                    title = stringResource(R.string.t_ins_tile_biggest),
                                    big = if (top != null) formatFileSize(top.sizeBytes) else "0 B",
                                    small = top?.name.orEmpty(),
                                    modifier = Modifier.weight(1f),
                                    onClick = if (top != null) ({ onFileClick(top) }) else null,
                                )
                                val oldest = report.oldestFile
                                ColorTile(
                                    hue = Hue.Blue,
                                    title = stringResource(R.string.t_ins_tile_oldest),
                                    big = if (oldest != null) ageText(context, oldest.modifiedMillis) else "-",
                                    small = if (report.emptyFiles > 0) {
                                        toolCount(context, R.plurals.t_empty_files, report.emptyFiles)
                                    } else {
                                        oldest?.name.orEmpty()
                                    },
                                    modifier = Modifier.weight(1f),
                                    onClick = if (oldest != null) ({ onFileClick(oldest) }) else null,
                                )
                            }
                        }
                    }
                }

                // ---- This week ----
                if (prefs.sectionOn("week")) {
                    item(key = "week-title") { ToolSection(stringResource(R.string.t_ins_week), trailing = formatFileSize(report.addedWeekBytes)) }
                    item(key = "week") {
                        val labels = remember {
                            val format = SimpleDateFormat("EEE", Locale.getDefault())
                            (6 downTo 0).map { back ->
                                val day = Calendar.getInstance()
                                day.add(Calendar.DAY_OF_YEAR, -back)
                                format.format(day.time).take(3)
                            }
                        }
                        Box(Modifier.padding(horizontal = 16.dp)) {
                            ToolCard {
                                MiniBars(
                                    values = report.weekDays,
                                    labels = labels,
                                    color = Hue.Yellow,
                                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 14.dp),
                                )
                            }
                        }
                    }
                }

                // ---- Suggestions ----
                item(key = "h:suggestions") {
                    ToolSection(stringResource(R.string.insights_section_suggestions), trailing = report.suggestions.size.toString())
                }
                if (report.suggestions.isNotEmpty()) {
                    item(key = "group-chips") {
                        ChipRow {
                            val free = report.suggestions.count { groupOf(it, report) == InsightGroup.Free }
                            val organize = report.suggestions.count { groupOf(it, report) == InsightGroup.Organize }
                            val folders = report.suggestions.count { groupOf(it, report) == InsightGroup.Folders }
                            ToolChip(stringResource(R.string.t_all), group == InsightGroup.All, { group = InsightGroup.All }, count = report.suggestions.size.toString())
                            if (free > 0) ToolChip(stringResource(R.string.t_ins_group_free), group == InsightGroup.Free, { group = InsightGroup.Free }, count = free.toString())
                            if (organize > 0) ToolChip(stringResource(R.string.t_ins_group_organize), group == InsightGroup.Organize, { group = InsightGroup.Organize }, count = organize.toString())
                            if (folders > 0) ToolChip(stringResource(R.string.t_ins_group_folders), group == InsightGroup.Folders, { group = InsightGroup.Folders }, count = folders.toString())
                        }
                    }
                }
                if (report.suggestions.isEmpty()) {
                    item(key = "none") { ToolNote(stringResource(R.string.insights_none)) }
                }
                val visibleSuggestions = if (group == InsightGroup.All) report.suggestions else report.suggestions.filter { groupOf(it, report) == group }
                items(visibleSuggestions, key = { "s:" + it.id }) { s ->
                    val paths = s.files.map { it.path }
                    SuggestionCard(
                        suggestion = s,
                        frees = s.id in report.reclaimIds,
                        allSelected = paths.isNotEmpty() && paths.all { it in selection.paths },
                        prefs = prefs,
                        rootPath = rootPath,
                        rootLabel = rootLabel,
                        onPrimary = {
                            when (s.action) {
                                is SuggestionAction.Review -> onToggleFiles(paths)
                                is SuggestionAction.MoveTo, SuggestionAction.Trash -> confirm = s
                                else -> onApply(s)
                            }
                        },
                        onDismiss = { onDismiss(s) },
                        onFileClick = onFileClick,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                }

                // ---- Where the space is ----
                if (prefs.sectionOn("space")) {
                    item(key = "h:storage") { ToolSection(stringResource(R.string.insights_section_storage)) }

                    if (report.kinds.isNotEmpty()) {
                        item(key = "sub-kinds") { SubTitle(stringResource(R.string.t_ins_by_kind)) }
                        val top = report.kinds.first().bytes.coerceAtLeast(1L).toFloat()
                        items(report.kinds, key = { "kind:" + it.kind.name }) { stat ->
                            MeterRow(stringResource(kindTitle(stat.kind)), formatFileSize(stat.bytes), stat.bytes / top, kindHue(stat.kind), note = toolCount(context, R.plurals.timeline_files, stat.count))
                        }
                    }
                    if (report.extensions.isNotEmpty()) {
                        item(key = "sub-ext") { SubTitle(stringResource(R.string.t_storage_types)) }
                        val top = report.extensions.first().bytes.coerceAtLeast(1L).toFloat()
                        items(report.extensions.take(5), key = { "ext:" + it.extension }) { ext ->
                            MeterRow(
                                if (ext.extension == "-") stringResource(R.string.t_storage_no_ext) else ".${ext.extension}",
                                formatFileSize(ext.bytes),
                                ext.bytes / top,
                                Hue.Lavender,
                                note = toolCount(context, R.plurals.timeline_files, ext.count),
                            )
                        }
                    }
                    if (report.folders.isNotEmpty()) {
                        item(key = "sub-folders") { SubTitle(stringResource(R.string.insights_where)) }
                        val top = report.folders.maxOf { it.bytes }.coerceAtLeast(1L).toFloat()
                        items(report.folders, key = { "folder:" + it.path }) { folder ->
                            MeterRow(
                                label = File(folder.path).name.ifEmpty { rootLabel },
                                value = formatFileSize(folder.bytes),
                                fraction = folder.bytes / top,
                                color = Hue.Mint,
                                onClick = { onFolderClick(folder.path) },
                            )
                        }
                    }
                    if (report.ages.isNotEmpty()) {
                        item(key = "sub-age") { SubTitle(stringResource(R.string.insights_age)) }
                        val top = report.ages.maxOf { it.bytes }.coerceAtLeast(1L).toFloat()
                        items(report.ages, key = { "age:" + it.band.name }) { age ->
                            MeterRow(stringResource(ageLabel(age.band)), formatFileSize(age.bytes), age.bytes / top, Hue.Yellow, note = toolCount(context, R.plurals.timeline_files, age.files))
                        }
                    }
                    if (report.biggest.isNotEmpty()) {
                        item(key = "sub-biggest") { SubTitle(stringResource(R.string.t_ins_biggest_files)) }
                        items(report.biggest, key = { "big:" + it.path }) { file ->
                            FileRow(file, selection = selection, favorite = file.path in favorites, onOpen = { onFileClick(file) }, hint = placeOf(file.path, rootPath, rootLabel))
                        }
                    }
                }

                // ---- What grew ----
                if (prefs.sectionOn("growth")) {
                    item(key = "growth-title") { ToolSection(stringResource(R.string.insights_growth)) }
                    val since = report.growthSince
                    when {
                        since == null -> item(key = "growth-wait") { ToolNote(stringResource(R.string.insights_growth_wait)) }

                        report.growth.isEmpty() -> item(key = "growth-none") { ToolNote(stringResource(R.string.insights_growth_none)) }

                        else -> {
                            item(key = "growth-since") {
                                Text(
                                    stringResource(R.string.insights_growth_since, DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(since))),
                                    color = IxColors.TextSecondary,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp),
                                )
                            }
                            val top = report.growth.maxOf { it.deltaBytes }.coerceAtLeast(1L).toFloat()
                            items(report.growth.take(5), key = { "growth:" + it.path }) { g ->
                                MeterRow(
                                    label = g.path.removePrefix(rootPath).trim('/'),
                                    value = "+" + formatFileSize(g.deltaBytes),
                                    fraction = g.deltaBytes / top,
                                    color = Hue.Peach,
                                    onClick = { onFolderClick(g.path) },
                                )
                            }
                        }
                    }
                }

                // ---- Habits ----
                if (prefs.sectionOn("habits")) {
                    item(key = "h:habits") { ToolSection(stringResource(R.string.insights_section_habits)) }
                    item(key = "habits-card") {
                        Box(Modifier.padding(horizontal = 16.dp)) {
                            ToolCard {
                                Column(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
                                    ToolSwitchRow(
                                        title = stringResource(R.string.insights_habits_on),
                                        note = stringResource(R.string.insights_habits_hint),
                                        checked = habitsOn,
                                        onChange = onHabitsOn,
                                    )
                                }
                            }
                        }
                    }
                    if (report.topFolders.isEmpty() && report.topFiles.isEmpty()) {
                        item(key = "habits-empty") { ToolNote(stringResource(R.string.insights_habits_empty)) }
                    } else {
                        if (report.topFolders.isNotEmpty()) {
                            item(key = "habits-folders-label") { SubTitle(stringResource(R.string.insights_habits_folders)) }
                            items(report.topFolders, key = { "hf:" + it.path }) { folder ->
                                HabitRow(File(folder.path).name.ifEmpty { rootLabel }, placeOf(folder.path, rootPath, rootLabel), folder.count) { onFolderClick(folder.path) }
                            }
                        }
                        if (report.topFiles.isNotEmpty()) {
                            item(key = "habits-files-label") { SubTitle(stringResource(R.string.insights_habits_files)) }
                            items(report.topFiles, key = { "hg:" + it.file.path }) { entry ->
                                HabitRow(
                                    entry.file.name + if (entry.file.extension.isEmpty()) "" else "." + entry.file.extension,
                                    placeOf(entry.file.path, rootPath, rootLabel),
                                    entry.count,
                                ) { onFileClick(entry.file) }
                            }
                        }
                    }
                    item(key = "habits-clear") {
                        Box(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                            InsightPill(stringResource(R.string.insights_habits_clear), danger = true, onClick = onClearHabits)
                        }
                    }
                }

                // ---- Rules ----
                if (prefs.sectionOn("rules")) {
                    item(key = "h:rules") { ToolSection(stringResource(R.string.insights_section_rules)) }
                    item(key = "rules-hint") {
                        Text(
                            stringResource(R.string.insights_rules_hint),
                            color = IxColors.TextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp),
                        )
                    }
                    if (rules.isNotEmpty()) {
                        item(key = "rules-card") {
                            Box(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                                ToolCard {
                                    for (rule in rules) {
                                        RuleRow(rule, onClick = { onEditRule(rule) }, onEnabled = { onRuleEnabled(rule, it) })
                                    }
                                }
                            }
                        }
                    }
                    item(key = "rules-add") {
                        Column(
                            Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            InsightPill(stringResource(R.string.insights_rule_add), filled = true, onClick = { onEditRule(blankRule()) })
                            val unused = RulePresets.all.filter { preset -> rules.none { it.id == preset.id } }
                            if (unused.isNotEmpty()) {
                                Text(stringResource(R.string.insights_rules_presets), color = IxColors.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    for (preset in unused) InsightPill(preset.name, onClick = { onSaveRule(preset) })
                                }
                            }
                        }
                    }
                }
            }
        }

        ToolSheet(
            visible = sheet,
            title = stringResource(R.string.t_customize),
            onClose = { sheet = false },
            footer = {
                SheetTextButton(
                    stringResource(R.string.t_reset_defaults),
                    onClick = {
                        val fresh = ToolPrefs()
                        onPrefs(
                            prefs.copy(
                                insightsOff = fresh.insightsOff, insightsBigMb = fresh.insightsBigMb, insightsBigDays = fresh.insightsBigDays,
                                insightsStaleDays = fresh.insightsStaleDays, insightsGrowthMb = fresh.insightsGrowthMb,
                                insightsDownloadDays = fresh.insightsDownloadDays, insightsShotDays = fresh.insightsShotDays,
                            ),
                        )
                    },
                )
            },
        ) {
            SheetLabel(stringResource(R.string.t_sheet_sections))
            for (name in InsightSections) {
                ToolSwitchRow(
                    title = stringResource(sectionTitleRes(name)),
                    note = null,
                    checked = prefs.sectionOn(name),
                    onChange = { on -> onPrefs(prefs.copy(insightsOff = if (on) prefs.insightsOff - "sec:$name" else prefs.insightsOff + "sec:$name")) },
                )
            }

            SheetLabel(stringResource(R.string.t_ins_suggest))
            for (kind in SwitchableKinds) {
                ToolSwitchRow(
                    title = stringResource(kind.switchTitle()),
                    note = null,
                    checked = kind.name !in prefs.insightsOff,
                    onChange = { on -> onPrefs(prefs.copy(insightsOff = if (on) prefs.insightsOff - kind.name else prefs.insightsOff + kind.name)) },
                )
            }

            SheetLabel(stringResource(R.string.t_clean_numbers))
            StepSetting(
                title = stringResource(R.string.t_ins_big_size),
                note = stringResource(R.string.t_ins_big_size_note),
                values = listOf(50, 100, 250, 500, 1024),
                value = prefs.insightsBigMb,
                label = { mbLabel(it) },
                onChange = { onPrefs(prefs.copy(insightsBigMb = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_ins_big_days),
                note = null,
                values = listOf(30, 90, 180, 365),
                value = prefs.insightsBigDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(insightsBigDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_ins_download_days),
                note = null,
                values = listOf(14, 30, 60, 90, 180),
                value = prefs.insightsDownloadDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(insightsDownloadDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_clean_shot_days),
                note = null,
                values = listOf(7, 14, 30, 60, 90),
                value = prefs.insightsShotDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(insightsShotDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_ins_stale_days),
                note = stringResource(R.string.t_ins_stale_days_note),
                values = listOf(30, 60, 120, 240),
                value = prefs.insightsStaleDays,
                label = { daysLabel(context, it) },
                onChange = { onPrefs(prefs.copy(insightsStaleDays = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_ins_growth),
                note = stringResource(R.string.t_ins_growth_note),
                values = listOf(100, 250, 500, 1024, 2048),
                value = prefs.insightsGrowthMb,
                label = { mbLabel(it) },
                onChange = { onPrefs(prefs.copy(insightsGrowthMb = it)) },
            )

            SheetLabel(stringResource(R.string.t_clean_yours))
            ProtectedFoldersEditor(rootPath, prefs, onPrefs)
        }
    }

    val asking = confirm
    if (asking != null) {
        val moving = asking.action is SuggestionAction.MoveTo
        val target = (asking.action as? SuggestionAction.MoveTo)?.destPath?.removePrefix(rootPath)?.trim('/').orEmpty()
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(if (moving) R.string.insights_confirm_move_title else R.string.insights_confirm_trash_title)) },
            text = {
                Text(
                    if (moving) {
                        context.getString(R.string.insights_confirm_move, asking.count, formatFileSize(asking.bytes), target)
                    } else {
                        context.getString(R.string.insights_confirm_trash, asking.count, formatFileSize(asking.bytes))
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    onApply(asking)
                }) {
                    Text(
                        stringResource(if (moving) R.string.insights_move else R.string.insights_trash),
                        color = if (moving) IxColors.TextPrimary else IxColors.Danger,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    if (ruleEditor != null) {
        RuleEditor(
            rule = ruleEditor,
            existing = rules.any { it.id == ruleEditor.id },
            onSave = onSaveRule,
            onDelete = onDeleteRule,
            onDismiss = onCloseRuleEditor,
        )
    }
}

/** A rule with nothing filled in yet, for the editor. */
private fun blankRule(): SortRule = SortRule(
    id = "rule-" + System.currentTimeMillis(),
    name = "",
    fromFolder = "",
    kinds = emptySet(),
    extensions = emptySet(),
    nameContains = "",
    olderThanDays = 0,
    action = RuleAction.Move,
    destFolder = "",
)

private fun ageLabel(band: AgeBand): Int = when (band) {
    AgeBand.UnderMonth -> R.string.insights_age_under_month
    AgeBand.Months1To6 -> R.string.insights_age_1_6
    AgeBand.Months6To12 -> R.string.insights_age_6_12
    AgeBand.OverYear -> R.string.insights_age_over_year
}

/** "3 years", "5 months", "12 days": how long ago, in the largest unit that fits. */
private fun ageText(context: Context, millis: Long): String {
    val days = ((System.currentTimeMillis() - millis) / (24L * 60 * 60 * 1000)).coerceAtLeast(0L).toInt()
    return when {
        days >= 730 -> toolCount(context, R.plurals.t_years, days / 365)
        days >= 60 -> toolCount(context, R.plurals.t_months, days / 30)
        else -> toolCount(context, R.plurals.t_days, days)
    }
}

/** The folder a thing sits in, written from the top of storage: "Download/old". */
private fun placeOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}

private fun titleOf(context: Context, s: Suggestion): String = when (s.kind) {
    SuggestionKind.Rule -> s.subject
    SuggestionKind.Misplaced -> context.getString(R.string.insights_misplaced_title, s.count)
    SuggestionKind.OldScreenshots -> context.getString(R.string.insights_screenshots_title, s.count)
    SuggestionKind.DeleteHabit -> context.getString(R.string.insights_deletes_title, s.subject)
    SuggestionKind.OldDownloads -> context.getString(R.string.insights_old_downloads_title, s.count)
    SuggestionKind.BigUntouched -> context.getString(R.string.insights_big_title, s.count)
    SuggestionKind.FrequentFolder -> context.getString(R.string.insights_frequent_title, File(s.subject).name)
    SuggestionKind.StaleFolder -> context.getString(R.string.insights_stale_title, File(s.subject).name, formatFileSize(s.bytes))
    SuggestionKind.Growing -> context.getString(R.string.insights_growing_title, File(s.subject).name, formatFileSize(s.bytes))
    SuggestionKind.Installers -> context.getString(R.string.t_ins_installers_title, s.count)
    SuggestionKind.Archives -> context.getString(R.string.t_ins_archives_title, s.count)
    SuggestionKind.BigVideos -> context.getString(R.string.t_ins_videos_title, s.count)
    SuggestionKind.CopyNames -> context.getString(R.string.t_ins_copies_title, s.count)
}

private fun detailOf(context: Context, s: Suggestion, prefs: ToolPrefs): String = when (s.kind) {
    SuggestionKind.Rule ->
        if (s.action is SuggestionAction.Trash) {
            context.getString(R.string.insights_rule_trash, s.count, formatFileSize(s.bytes))
        } else {
            val dest = (s.action as? SuggestionAction.MoveTo)?.destPath?.substringAfterLast('/').orEmpty()
            context.getString(R.string.insights_rule_move, s.count, formatFileSize(s.bytes), dest)
        }
    SuggestionKind.Misplaced -> {
        val dest = s.subject
        val kindWord = when (dest) {
            "Pictures" -> R.string.insights_kind_pictures
            "Movies" -> R.string.insights_kind_videos
            "Music" -> R.string.insights_kind_songs
            else -> R.string.insights_kind_documents
        }
        context.getString(R.string.insights_misplaced_detail, formatFileSize(s.bytes), context.getString(kindWord), dest)
    }
    SuggestionKind.OldScreenshots -> context.getString(R.string.t_ins_screenshots_detail, formatFileSize(s.bytes), prefs.insightsShotDays)
    SuggestionKind.DeleteHabit -> context.getString(R.string.insights_deletes_detail, s.count, formatFileSize(s.bytes))
    SuggestionKind.OldDownloads -> context.getString(R.string.t_ins_old_downloads_detail, formatFileSize(s.bytes), prefs.insightsDownloadDays)
    SuggestionKind.BigUntouched ->
        context.getString(R.string.t_ins_big_detail, formatFileSize(s.bytes), formatFileSize(prefs.insightsBigMb * 1024L * 1024L), prefs.insightsBigDays)
    SuggestionKind.FrequentFolder -> context.getString(R.string.insights_frequent_detail)
    SuggestionKind.StaleFolder -> context.getString(R.string.t_ins_stale_detail, prefs.insightsStaleDays)
    SuggestionKind.Growing -> context.getString(R.string.insights_growing_detail)
    SuggestionKind.Installers -> context.getString(R.string.t_ins_installers_detail, formatFileSize(s.bytes))
    SuggestionKind.Archives -> context.getString(R.string.t_ins_archives_detail, formatFileSize(s.bytes))
    SuggestionKind.BigVideos -> context.getString(R.string.t_ins_videos_detail, formatFileSize(s.bytes))
    SuggestionKind.CopyNames -> context.getString(R.string.t_ins_copies_detail, formatFileSize(s.bytes))
}

/** One suggestion in a card: what it is, a few of its files, and its buttons. */
@Composable
private fun SuggestionCard(
    suggestion: Suggestion,
    frees: Boolean,
    allSelected: Boolean,
    prefs: ToolPrefs,
    rootPath: String,
    rootLabel: String,
    onPrimary: () -> Unit,
    onDismiss: () -> Unit,
    onFileClick: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val primary = when (suggestion.action) {
        is SuggestionAction.Review -> stringResource(if (allSelected) R.string.cleaner_deselect else R.string.cleaner_select)
        is SuggestionAction.MoveTo -> stringResource(R.string.insights_move)
        is SuggestionAction.Trash -> stringResource(R.string.insights_trash)
        is SuggestionAction.AddToHome -> stringResource(R.string.insights_add_home)
        is SuggestionAction.OpenFolder -> stringResource(R.string.apps_open)
    }
    ToolCard(modifier) {
        Row(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp), verticalAlignment = Alignment.Top) {
            ToolBadge(suggestion.kind.hue(), suggestion.kind.glyph(), size = 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(titleOf(context, suggestion), color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(detailOf(context, suggestion, prefs), color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
            }
            if (suggestion.bytes > 0L) {
                Text(
                    (if (suggestion.kind == SuggestionKind.Growing) "+" else "") + formatFileSize(suggestion.bytes),
                    color = if (frees) IxColors.Accent else IxColors.TextSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                )
            }
        }
        if (suggestion.files.isNotEmpty()) {
            Column(Modifier.padding(top = 10.dp)) {
                for (file in suggestion.files.take(PREVIEW_ROWS)) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(role = Role.Button) { onFileClick(file) }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (file.extension.isEmpty()) file.name else file.name + "." + file.extension,
                                color = IxColors.TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(placeOf(file.path, rootPath, rootLabel), color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(formatFileSize(file.sizeBytes), color = IxColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
                    }
                }
                if (suggestion.files.size > PREVIEW_ROWS) {
                    Text(
                        context.getString(R.string.apps_and_more, suggestion.files.size - PREVIEW_ROWS),
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(start = 16.dp, top = 2.dp),
                    )
                }
            }
        }
        Row(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            InsightPill(primary, danger = suggestion.action is SuggestionAction.Trash, filled = !allSelected, onClick = onPrimary)
            InsightPill(stringResource(R.string.insights_not_now), onClick = onDismiss)
        }
    }
}

@Composable
private fun RuleRow(rule: SortRule, onClick: () -> Unit, onEnabled: (Boolean) -> Unit) {
    val context = LocalContext.current
    val from = rule.fromFolder.ifBlank { context.getString(R.string.insights_everywhere) }
    val to = if (rule.action == RuleAction.Trash) context.getString(R.string.insights_rule_to_trash) else rule.destFolder
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(rule.name, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$from  →  $to", color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
        androidx.compose.material3.Switch(
            checked = rule.enabled,
            onCheckedChange = onEnabled,
            colors = androidx.compose.material3.SwitchDefaults.colors(
                checkedThumbColor = Hue.Ink,
                checkedTrackColor = IxColors.Accent,
                checkedBorderColor = IxColors.Accent,
                uncheckedThumbColor = IxColors.TextSecondary,
                uncheckedTrackColor = IxColors.Chip,
                uncheckedBorderColor = IxColors.Outline,
            ),
        )
    }
}

@Composable
private fun HabitRow(title: String, subtitle: String, count: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(LocalContext.current.getString(R.string.insights_times, count), color = IxColors.Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

/** A small orange label that opens a block inside a section. */
@Composable
private fun SubTitle(text: String) {
    Text(
        text = text,
        color = IxColors.Accent,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 2.dp),
    )
}

/** A pill under a suggestion or a section. [filled] is the orange one. */
@Composable
internal fun InsightPill(label: String, danger: Boolean = false, filled: Boolean = false, onClick: () -> Unit) {
    val fill = when {
        danger && filled -> IxColors.Danger
        filled -> IxColors.Accent
        else -> IxColors.Chip
    }
    val ink = when {
        danger && filled -> Color.White
        filled -> Hue.Ink
        danger -> IxColors.Danger
        else -> IxColors.TextPrimary
    }
    Box(
        Modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(fill)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
