package ix.app.files

import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import ix.app.files.data.FileOps
import ix.app.files.data.StorageAccess

/**
 * The "Files" entry in other apps' Share sheets. Whatever is shared (one file, several, or plain text) is saved
 * into the Download folder, and a short message says how it went. It has no screen of its own.
 */
class ReceiveActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!StorageAccess.hasAccess(this)) {
            // Saving needs "All files access". The main screen asks for it.
            Toast.makeText(this, R.string.receive_need_access, Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        val sent = sharedItems(intent)
        if (sent.uris.isEmpty() && sent.text == null) {
            finish()
            return
        }
        Toast.makeText(this, R.string.receive_saving, Toast.LENGTH_SHORT).show()
        // Copying can take a while for big files, so it runs off the main thread. The screen stays until it is done.
        Thread {
            val saved = save(sent)
            runOnUiThread {
                val message = if (saved > 0) {
                    resources.getQuantityString(R.plurals.receive_saved, saved, saved)
                } else {
                    getString(R.string.receive_failed)
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }

    private class Shared(val uris: List<Uri>, val text: String?)

    @Suppress("DEPRECATION")
    private fun sharedItems(intent: Intent): Shared {
        val uris = ArrayList<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val one: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
                if (one != null) uris.add(one)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val many: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                }
                if (many != null) uris.addAll(many)
            }
        }
        // Some apps only put the link in the clip.
        if (uris.isEmpty()) {
            val clip: ClipData? = intent.clipData
            if (clip != null) for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { uris.add(it) }
        }
        val text = if (uris.isEmpty()) intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString() else null
        return Shared(uris, text?.takeIf { it.isNotBlank() })
    }

    /** Copies everything shared into Download. Returns how many items were saved. */
    @Suppress("DEPRECATION")
    private fun save(sent: Shared): Int {
        val folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!folder.exists() && !folder.mkdirs()) return 0
        var saved = 0
        if (sent.text != null) {
            try {
                FileOps.uniqueTarget(folder, "Shared text.txt").writeText(sent.text)
                saved++
            } catch (e: Exception) {
                // Counted as not saved.
            }
        }
        for (uri in sent.uris) {
            try {
                val target = FileOps.uniqueTarget(folder, nameOf(uri))
                val input = contentResolver.openInputStream(uri) ?: continue
                input.use { source -> target.outputStream().use { out -> source.copyTo(out) } }
                saved++
            } catch (e: Exception) {
                // One bad file does not stop the others.
            }
        }
        return saved
    }

    /** The name the sender gave the file, or a made-up one with the right extension. */
    private fun nameOf(uri: Uri): String {
        var name: String? = null
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) name = cursor.getString(0)
                }
            } catch (e: Exception) {
                // Fall through to the other ways of naming it.
            }
        }
        if (name.isNullOrBlank()) name = uri.lastPathSegment?.substringAfterLast('/')
        if (name.isNullOrBlank()) {
            val extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(contentResolver.getType(uri))
            name = "Shared file" + (extension?.let { ".$it" } ?: "")
        }
        return name!!.replace('/', '_')
    }
}
