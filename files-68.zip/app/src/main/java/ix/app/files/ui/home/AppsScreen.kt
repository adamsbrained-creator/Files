package ix.app.files.ui.home

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.AppEntry
import ix.app.files.data.AppFilter
import ix.app.files.data.AppSort
import ix.app.files.data.AppsEngine
import ix.app.files.data.ToolPrefs
import ix.app.files.data.UninstallQueue
import ix.app.files.ui.components.AppIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize

private const val DAY_MILLIS = 24L * 60 * 60 * 1000

/**
 * Installed apps with the size of their apk files. Tap a line to tick it. Ticked apps can be backed up (their
 * apk files are copied to Download/App backups); a single app can also be opened or looked at in the system's
 * app info. Ticked apps can be uninstalled: the system asks about each one in turn.
 *
 * The filters (big, not updated for a while, new) and their numbers can be tuned under Customize.
 */
@Composable
fun AppsScreen(
    apps: List<AppEntry>,
    loading: Boolean,
    prefs: ToolPrefs,
    onPrefs: (ToolPrefs) -> Unit,
    onBack: () -> Unit,
    onBackup: (List<AppEntry>) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var query by remember { mutableStateOf("") }
    var sheet by remember { mutableStateOf(false) }
    // Ticks start again whenever the list is read anew, for instance after an app was uninstalled.
    var picked by remember(apps) { mutableStateOf(setOf<String>()) }
    var confirmUninstall by remember { mutableStateOf<AppEntry?>(null) }
    var confirmMany by remember { mutableStateOf<List<AppEntry>?>(null) }
    // Several apps are removed one after another. The queue lives here, not in the ticks, because the list is
    // read anew (and the ticks cleared) every time the system comes back from one of its questions.
    var queue by remember { mutableStateOf<UninstallQueue?>(null) }
    val uninstallAnswer = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val q = queue
        val asked = q?.current
        if (q != null && asked != null) {
            // The app being gone is the sure sign of success, since some phones answer "cancelled" either way.
            val gone = !isInstalled(context, asked)
            queue = q.after(gone = gone, declined = !gone && result.resultCode == Activity.RESULT_CANCELED)
        }
    }
    LaunchedEffect(queue) {
        val q = queue ?: return@LaunchedEffect
        val next = q.current
        if (next == null) {
            val message = if (q.removed == q.total) {
                context.getString(R.string.apps_uninstalled_all, q.total)
            } else {
                context.getString(R.string.apps_uninstalled_some, q.removed, q.total)
            }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            queue = null
            picked = emptySet()
        } else {
            try {
                uninstallAnswer.launch(
                    Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$next"))
                        .putExtra(Intent.EXTRA_RETURN_RESULT, true),
                )
            } catch (e: Exception) {
                queue = q.after(gone = false, declined = false)
            }
        }
    }

    val now = remember(apps) { System.currentTimeMillis() }
    val largeBytes = prefs.appsLargeMb * 1024L * 1024L
    val staleBefore = now - prefs.appsStaleMonths * 30L * DAY_MILLIS
    val recentAfter = now - 30L * DAY_MILLIS

    val base = remember(apps, prefs.appsSort, prefs.appsSystem, query) { AppsEngine.view(apps, prefs.appsSort, prefs.appsSystem, query) }
    val largeCount = remember(base, largeBytes) { base.count { it.bytes >= largeBytes } }
    val staleCount = remember(base, staleBefore) { base.count { it.updatedAt < staleBefore } }
    val recentCount = remember(base, recentAfter) { base.count { it.installedAt >= recentAfter } }
    val shown = remember(base, prefs.appsFilter, largeBytes, staleBefore, recentAfter) {
        when (prefs.appsFilter) {
            AppFilter.All -> base
            AppFilter.Large -> base.filter { it.bytes >= largeBytes }
            AppFilter.Stale -> base.filter { it.updatedAt < staleBefore }
            AppFilter.Recent -> base.filter { it.installedAt >= recentAfter }
        }
    }
    val chosen = shown.filter { it.packageName in picked }
    val systemCount = remember(apps) { apps.count { it.isSystem } }
    val biggest = remember(base) { base.sortedByDescending { it.bytes }.take(4) }
    val showBiggest = prefs.appsFilter == AppFilter.All && query.isBlank() && biggest.size >= 2

    fun toggle(app: AppEntry) {
        picked = if (app.packageName in picked) picked - app.packageName else picked + app.packageName
    }

    Box(modifier.toolPage()) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = bottomInset + 120.dp)) {
            item(key = "hero") {
                ToolHero(
                    hue = Hue.Blue,
                    eyebrow = stringResource(R.string.apps_title),
                    onBack = onBack,
                    action = { HeroIconButton(Glyphs.Sliders, stringResource(R.string.t_customize)) { sheet = true } },
                ) {
                    if (loading) {
                        HeroNumber("…")
                        HeroSub(stringResource(R.string.apps_loading))
                    } else {
                        val text = formatFileSize(base.sumOf { it.bytes })
                        HeroNumber(text.substringBefore(' '), text.substringAfter(' ', ""))
                        HeroSub(toolCount(context, R.plurals.apps_count, base.size))
                        if (staleCount > 0) {
                            HeroSub(
                                stringResource(R.string.t_apps_stale_line, staleCount, prefs.appsStaleMonths),
                                Modifier.padding(top = 2.dp),
                            )
                        }
                    }
                }
            }

            item(key = "search") {
                SearchPill(
                    value = query,
                    onValue = { query = it },
                    hint = stringResource(R.string.apps_search),
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp),
                )
            }

            item(key = "filters") {
                ChipRow(Modifier.padding(top = 14.dp)) {
                    ToolChip(stringResource(R.string.t_all), prefs.appsFilter == AppFilter.All, { onPrefs(prefs.copy(appsFilter = AppFilter.All)) }, count = base.size.toString())
                    ToolChip(stringResource(R.string.t_apps_large), prefs.appsFilter == AppFilter.Large, { onPrefs(prefs.copy(appsFilter = AppFilter.Large)) }, count = largeCount.toString())
                    ToolChip(stringResource(R.string.t_apps_stale), prefs.appsFilter == AppFilter.Stale, { onPrefs(prefs.copy(appsFilter = AppFilter.Stale)) }, count = staleCount.toString())
                    ToolChip(stringResource(R.string.t_apps_recent), prefs.appsFilter == AppFilter.Recent, { onPrefs(prefs.copy(appsFilter = AppFilter.Recent)) }, count = recentCount.toString())
                }
            }
            item(key = "sorts") {
                ChipRow(Modifier.padding(top = 10.dp)) {
                    ToolChip(stringResource(R.string.apps_sort_name), prefs.appsSort == AppSort.Name, { onPrefs(prefs.copy(appsSort = AppSort.Name)) })
                    ToolChip(stringResource(R.string.apps_sort_size), prefs.appsSort == AppSort.Size, { onPrefs(prefs.copy(appsSort = AppSort.Size)) })
                    ToolChip(stringResource(R.string.apps_sort_updated), prefs.appsSort == AppSort.Updated, { onPrefs(prefs.copy(appsSort = AppSort.Updated)) })
                    ToolChip(stringResource(R.string.apps_show_system), prefs.appsSystem, { onPrefs(prefs.copy(appsSystem = !prefs.appsSystem)) }, count = systemCount.toString())
                }
            }

            if (!loading && showBiggest) {
                item(key = "biggest-title") { ToolSection(stringResource(R.string.t_apps_biggest)) }
                val rows = biggest.chunked(2)
                items(rows.size, key = { "big-row:$it" }) { index ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        for (app in rows[index]) {
                            BigAppTile(app, app.packageName in picked, { toggle(app) }, Modifier.weight(1f))
                        }
                        if (rows[index].size == 1) Box(Modifier.weight(1f))
                    }
                }
            }

            if (!loading) {
                item(key = "list-title") {
                    ToolSection(
                        stringResource(R.string.t_apps_all_title),
                        trailing = if (shown.isNotEmpty()) toolCount(context, R.plurals.apps_count, shown.size) else null,
                    )
                }
                if (shown.isEmpty()) {
                    item(key = "empty") { ToolNote(stringResource(R.string.apps_empty)) }
                }
                items(shown, key = { it.packageName }) { app ->
                    AppRow(app = app, picked = app.packageName in picked, stale = app.updatedAt < staleBefore, staleMonths = prefs.appsStaleMonths, onToggle = { toggle(app) })
                }
            }
        }

        if (chosen.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, IxColors.Background)))
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = bottomInset + 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val single = chosen.singleOrNull()
                if (single == null) {
                    val allPicked = chosen.size == shown.size
                    ActionPill(
                        label = stringResource(if (allPicked) R.string.cleaner_deselect else R.string.cleaner_select),
                        fill = IxColors.Chip,
                        text = IxColors.TextPrimary,
                        onClick = { picked = if (allPicked) emptySet() else shown.map { it.packageName }.toSet() },
                    )
                } else {
                    ActionPill(stringResource(R.string.apps_open), IxColors.Chip, IxColors.TextPrimary, { launchApp(context, single.packageName) })
                    ActionPill(stringResource(R.string.apps_info), IxColors.Chip, IxColors.TextPrimary, { openAppInfo(context, single.packageName) })
                }
                ActionPill(stringResource(R.string.apps_backup), IxColors.Accent, Hue.Ink, { onBackup(chosen) })
                // System apps are left out: the system does not let them be removed like this.
                val removable = chosen.filter { !it.isSystem }
                if (single != null && !single.isSystem) {
                    ActionPill(stringResource(R.string.apps_uninstall), IxColors.Danger, Color.White, { confirmUninstall = single })
                } else if (single == null && removable.isNotEmpty()) {
                    ActionPill(
                        context.getString(R.string.apps_uninstall_count, removable.size),
                        IxColors.Danger,
                        Color.White,
                        { confirmMany = removable },
                    )
                }
            }
        }

        ToolSheet(
            visible = sheet,
            title = stringResource(R.string.t_customize),
            onClose = { sheet = false },
            footer = {
                SheetTextButton(
                    stringResource(R.string.t_reset_defaults),
                    onClick = {
                        val fresh = ToolPrefs()
                        onPrefs(
                            prefs.copy(
                                appsSort = fresh.appsSort, appsFilter = fresh.appsFilter, appsSystem = fresh.appsSystem,
                                appsLargeMb = fresh.appsLargeMb, appsStaleMonths = fresh.appsStaleMonths,
                            ),
                        )
                    },
                )
            },
        ) {
            SheetLabel(stringResource(R.string.t_sheet_lists))
            ChoiceSetting(
                title = stringResource(R.string.t_apps_sort_title),
                note = null,
                options = listOf(
                    stringResource(R.string.apps_sort_name) to AppSort.Name,
                    stringResource(R.string.apps_sort_size) to AppSort.Size,
                    stringResource(R.string.apps_sort_updated) to AppSort.Updated,
                ),
                selected = prefs.appsSort,
                onSelect = { onPrefs(prefs.copy(appsSort = it)) },
            )
            ToolSwitchRow(
                title = stringResource(R.string.apps_show_system),
                note = stringResource(R.string.t_apps_system_note),
                checked = prefs.appsSystem,
                onChange = { onPrefs(prefs.copy(appsSystem = it)) },
            )
            SheetLabel(stringResource(R.string.t_apps_filters))
            StepSetting(
                title = stringResource(R.string.t_apps_large_title),
                note = stringResource(R.string.t_apps_large_note),
                values = listOf(25, 50, 100, 250, 500),
                value = prefs.appsLargeMb,
                label = { mbLabel(it) },
                onChange = { onPrefs(prefs.copy(appsLargeMb = it)) },
            )
            StepSetting(
                title = stringResource(R.string.t_apps_stale_title),
                note = stringResource(R.string.t_apps_stale_note),
                values = listOf(3, 6, 12, 24),
                value = prefs.appsStaleMonths,
                label = { toolCount(context, R.plurals.t_months, it) },
                onChange = { onPrefs(prefs.copy(appsStaleMonths = it)) },
            )
        }
    }

    val askingMany = confirmMany
    if (askingMany != null) {
        val names = askingMany.take(8).joinToString("\n") { "• ${it.label}" } +
            if (askingMany.size > 8) "\n" + context.getString(R.string.apps_and_more, askingMany.size - 8) else ""
        AlertDialog(
            onDismissRequest = { confirmMany = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(context.getString(R.string.apps_uninstall_many_title, askingMany.size)) },
            text = { Text(context.getString(R.string.apps_uninstall_many_ask, names)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmMany = null
                    queue = UninstallQueue.of(askingMany.map { it.packageName })
                }) { Text(stringResource(R.string.apps_uninstall), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmMany = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    val asking = confirmUninstall
    if (asking != null) {
        AlertDialog(
            onDismissRequest = { confirmUninstall = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.apps_uninstall)) },
            text = { Text(context.getString(R.string.apps_uninstall_ask, asking.label)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmUninstall = null
                    uninstallApp(context, asking.packageName)
                }) { Text(stringResource(R.string.apps_uninstall), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmUninstall = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

/** One of the biggest apps: a white tile with its icon, name and size. */
@Composable
private fun BigAppTile(app: AppEntry, picked: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(120.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White)
            .clickable(role = Role.Checkbox, onClick = onToggle)
            .semantics { selected = picked }
            .padding(16.dp),
    ) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(app.label, color = Hue.Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(formatFileSize(app.bytes), color = Hue.Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        }
        AppIcon(app.packageName, app.updatedAt, 40.dp, Modifier.align(Alignment.TopStart))
        if (picked) CheckCircle(on = true, modifier = Modifier.align(Alignment.TopEnd))
    }
}

/** Icon, name, "version · size", "updated when" (or a note that it is old), and the orange tick. */
@Composable
private fun AppRow(app: AppEntry, picked: Boolean, stale: Boolean, staleMonths: Int, onToggle: () -> Unit) {
    val context = LocalContext.current
    val updated = modifiedLabel(app.updatedAt)
    val meta = context.getString(R.string.file_meta, app.versionName.ifEmpty { app.packageName }, formatFileSize(app.bytes))
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (picked) IxColors.Accent.copy(alpha = 0.10f) else Color.Transparent)
            .clickable(role = Role.Checkbox, onClick = onToggle)
            .semantics { selected = picked }
            .padding(horizontal = 20.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        AppIcon(app.packageName, app.updatedAt, 44.dp)
        Column(Modifier.weight(1f)) {
            Text(app.label, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
            Text(
                text = if (stale) toolCount(context, R.plurals.t_apps_not_updated, staleMonths) else context.getString(R.string.apps_updated, updated),
                color = if (stale) IxColors.Accent else IxColors.TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (stale) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        CheckCircle(on = picked, modifier = Modifier.size(26.dp))
    }
}

/** Starts the app, if it has something to start (many system services have not). */
private fun launchApp(context: Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
    }
}

/** The system's own page about the app: storage, permissions, force stop. */
private fun openAppInfo(context: Context, packageName: String) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
    }
}

/** True while the app is still on the phone. */
private fun isInstalled(context: Context, packageName: String): Boolean =
    try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

/** Hands the uninstall to the system, which asks the person once more. */
private fun uninstallApp(context: Context, packageName: String) {
    val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
    }
}
