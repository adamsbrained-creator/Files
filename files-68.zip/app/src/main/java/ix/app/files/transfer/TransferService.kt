package ix.app.files.transfer

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import ix.app.files.R
import ix.app.files.util.formatFileSize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Keeps the app alive while the phone is sharing files with a PC. The phone is the file server, so if Android
 * stopped the app with the screen off, the download on the PC would break. The notification shows the progress
 * and has a Stop button.
 */
class TransferService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, build(TransferHub.state.value),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0,
        )
        scope.launch {
            // Updating the notification for every byte would only waste battery: about every 5 MB is plenty.
            var last = ""
            TransferHub.state.collect { s ->
                if (s.phase == TransferPhase.Off || s.phase == TransferPhase.Failed) {
                    stopSelf()
                    return@collect
                }
                val key = "${s.phase}|${s.url}|${s.filesDone}|${s.sentBytes / 5_000_000}"
                if (key != last) {
                    last = key
                    notify(build(s))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            TransferHub.stop()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    /** Android 15 limits how long a data transfer service may run. When the time is up, sharing ends cleanly. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        TransferHub.stop()
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    @SuppressLint("MissingPermission")
    private fun notify(n: Notification) {
        // Without the notification permission (Android 13 and up) this is simply not shown; sharing still works.
        runCatching { NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, n) }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.transfer_channel), NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun build(s: TransferState): Notification {
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val stop = PendingIntent.getService(
            this, 2, Intent(this, TransferService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = when (s.phase) {
            TransferPhase.Sharing -> getString(
                R.string.transfer_notification_sharing,
                formatFileSize(s.sentBytes), formatFileSize(s.bytes), s.url.removePrefix("http://").trimEnd('/'),
            )
            else -> getString(R.string.transfer_counting)
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(getString(R.string.transfer_title))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .addAction(0, getString(R.string.transfer_stop), stop)
        if (s.phase == TransferPhase.Sharing && s.bytes > 0) {
            // Bytes can top the Int range, so the bar counts in kilobytes.
            builder.setProgress(((s.bytes / 1024).coerceAtMost(Int.MAX_VALUE.toLong())).toInt(),
                ((s.sentBytes / 1024).coerceAtMost(Int.MAX_VALUE.toLong())).toInt(), false)
        } else {
            builder.setProgress(0, 0, true)
        }
        return builder.build()
    }

    companion object {
        private const val CHANNEL_ID = "transfer"
        private const val NOTIFICATION_ID = 4108
        private const val ACTION_STOP = "ix.app.files.transfer.STOP"
    }
}
