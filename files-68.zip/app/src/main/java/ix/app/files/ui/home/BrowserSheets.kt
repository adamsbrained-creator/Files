package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import kotlinx.coroutines.delay

// The pop-ups and bottom sheets of the browser list, drawn after the "R2 Sort menu" and "R3 New folder" mockups.
// GlassSheet, PrimaryPill and SecondaryPill are shared with the selection sheets (More, Details).

private val SheetShape = RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)

/** A bottom sheet with the mockup's dark gradient, rounded top and a grabber. The sheet's own insets are off. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GlassSheet(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        shape = SheetShape,
        containerColor = Color.Transparent,
        scrimColor = IxColors.Scrim,
        dragHandle = null,
        contentWindowInsets = { WindowInsets(0.dp, 0.dp, 0.dp, 0.dp) },
    ) {
        Column(
            modifier
                .fillMaxWidth()
                .clip(SheetShape)
                .background(Brush.verticalGradient(listOf(IxColors.SheetTop, IxColors.SheetBottom)))
                .border(1.dp, IxColors.GlassBorder, SheetShape)
                .navigationBarsPadding()
                .imePadding()
                .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 22.dp),
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 18.dp)
                    .size(width = 40.dp, height = 5.dp)
                    .clip(CircleShape)
                    .background(IxColors.Handle),
            )
            content()
        }
    }
}

/** The big violet button of a sheet ("Create", "Close"). Dimmed and inert when [enabled] is false. */
@Composable
internal fun PrimaryPill(label: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier
            .height(56.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFFA98FFF), Color(0xFF7650F5))))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** The quiet frosted button next to a [PrimaryPill] ("Cancel"). */
@Composable
internal fun SecondaryPill(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier
            .height(56.dp)
            .clip(shape)
            .background(IxColors.Glass)
            .border(1.dp, IxColors.GlassBorder, shape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, color = IxColors.TextPrimary, fontSize = 18.sp)
    }
}

/**
 * The sort menu: the screen dims, and a frosted card under the header lists the five sort fields with the
 * active one highlighted, then an Ascending / Descending switch. Picking anything applies it and closes the menu.
 */
@Composable
internal fun SortMenu(sort: SortSpec, onSortSelected: (SortField) -> Unit, onDismiss: () -> Unit) {
    BackHandler(onBack = onDismiss)
    val shape = RoundedCornerShape(24.dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(IxColors.Scrim)
            .pointerInput(Unit) { detectTapGestures { onDismiss() } },
    ) {
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(top = 56.dp, end = 16.dp)
                .width(300.dp)
                .clip(shape)
                .background(IxColors.Glass)
                .border(1.dp, IxColors.GlassBorder, shape)
                // Taps on the card itself must not reach the dim behind it.
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(14.dp),
        ) {
            Text(
                text = stringResource(R.string.sort_by).uppercase(),
                color = IxColors.TextSecondary,
                fontSize = 14.sp,
                modifier = Modifier.height(30.dp),
            )
            SortField.entries.forEach { field ->
                val active = field == sort.field
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (active) IxColors.Violet.copy(alpha = 0.22f) else Color.Transparent)
                        .clickable(role = Role.Button) {
                            // The active field stays as it is. Only the switch below changes the direction.
                            if (!active) onSortSelected(field)
                            onDismiss()
                        }
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(field.labelRes),
                        color = IxColors.TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.weight(1f),
                    )
                    if (active) PathIcon(Glyphs.Check, tint = IxColors.VioletText, size = 20.dp, strokeWidth = 2.4f)
                }
            }
            Spacer(Modifier.height(10.dp))
            DirectionSwitch(
                ascending = sort.ascending,
                onPick = { wantAscending ->
                    // Selecting the active field again flips its direction.
                    if (wantAscending != sort.ascending) onSortSelected(sort.field)
                    onDismiss()
                },
            )
        }
    }
}

@Composable
private fun DirectionSwitch(ascending: Boolean, onPick: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(IxColors.Tile)
            .padding(3.dp),
    ) {
        for (asc in listOf(true, false)) {
            val on = asc == ascending
            Box(
                Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(19.dp))
                    .background(if (on) IxColors.TileBorder.copy(alpha = 0.18f) else Color.Transparent)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        role = Role.Button,
                    ) { onPick(asc) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(if (asc) R.string.sort_ascending_label else R.string.sort_descending_label),
                    color = if (on) IxColors.TextPrimary else IxColors.TextSecondary,
                    fontSize = 16.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

/** "New folder": a violet folder and title, a name field with a violet outline, and Cancel / Create. */
@Composable
internal fun NewFolderSheet(onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        // The sheet is still sliding in, so the field is not ready for focus at the very first frame.
        delay(150)
        try {
            focus.requestFocus()
        } catch (e: Exception) {
            // The person can still tap the field.
        }
    }
    val canCreate = name.isNotBlank()

    GlassSheet(onDismiss = onDismiss) {
        Row(
            Modifier.padding(bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            ListFolderIcon(top = Color(0xFFB7A2FF), bottom = Color(0xFF6B46F0), width = 44.dp)
            Text(
                text = stringResource(R.string.new_folder),
                color = IxColors.TextPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        val fieldShape = RoundedCornerShape(18.dp)
        BasicTextField(
            value = name,
            onValueChange = { name = it },
            singleLine = true,
            textStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 18.sp),
            cursorBrush = SolidColor(IxColors.Violet),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { if (canCreate) onConfirm(name) }),
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .clip(fieldShape)
                .background(IxColors.Tile)
                .border(2.dp, IxColors.Violet, fieldShape)
                .focusRequester(focus),
            decorationBox = { inner ->
                Box(Modifier.padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart) {
                    if (name.isEmpty()) {
                        Text(
                            text = stringResource(R.string.folder_name_hint),
                            color = IxColors.TextSecondary,
                            fontSize = 18.sp,
                        )
                    }
                    inner()
                }
            },
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SecondaryPill(stringResource(R.string.cancel), Modifier.weight(1f), onClick = onDismiss)
            PrimaryPill(
                stringResource(R.string.new_folder_confirm),
                Modifier.weight(1f),
                enabled = canCreate,
            ) { onConfirm(name) }
        }
    }
}
