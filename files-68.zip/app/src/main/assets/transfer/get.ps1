# Copies everything your phone is sharing into a folder on this PC.
# Run it again whenever you like: files that are already here (same size) are skipped,
# so it only copies what is new, or what was left unfinished last time.

$Dest = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Phone backup'
$Base = '__BASE__'

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::Expect100Continue = $false
$wc = New-Object System.Net.WebClient
$wc.Encoding = [System.Text.Encoding]::UTF8

Write-Host 'Reading the list of files from your phone...'
$text = $wc.DownloadString("$Base/api/files.tsv")
$lines = @($text -split "`n" | Where-Object { $_.Trim() -ne '' })
$total = $lines.Count
Write-Host "$total files. Copying to $Dest"

$epoch = New-Object DateTime 1970, 1, 1, 0, 0, 0, ([DateTimeKind]::Utc)
$i = 0; $copied = 0; $skipped = 0; $failed = 0

foreach ($line in $lines) {
    $i++
    $p = $line.TrimEnd("`r").Split("`t", 4)
    $id = $p[0]
    $size = [int64]$p[1]
    $mtime = [int64]$p[2]
    $rel = $p[3]
    # Android allows some characters in names that Windows does not.
    $parts = $rel.Split('/') | ForEach-Object { ($_ -replace '[<>:"|?*\\]', '_').TrimEnd('. ') }
    $target = Join-Path $Dest ($parts -join '\')
    $tmp = ''

    if ((Test-Path -LiteralPath $target) -and ((Get-Item -LiteralPath $target).Length -eq $size)) {
        $skipped++
        continue
    }

    Write-Progress -Activity 'Copying from your phone' -Status "$i of $total  -  $rel" -PercentComplete ([int](100 * $i / $total))
    try {
        $dir = Split-Path -Parent $target
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $tmp = $target + '.part'
        $wc.DownloadFile("$Base/f/$id", $tmp)
        Move-Item -LiteralPath $tmp -Destination $target -Force
        if ($mtime -gt 0) { (Get-Item -LiteralPath $target).LastWriteTimeUtc = $epoch.AddSeconds($mtime) }
        $copied++
    }
    catch {
        $failed++
        Write-Host "Could not copy ${rel}: $($_.Exception.Message)" -ForegroundColor Yellow
        if ($tmp -and (Test-Path -LiteralPath $tmp)) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}

Write-Progress -Activity 'Copying from your phone' -Completed
Write-Host "Done. Copied $copied, already there $skipped, failed $failed."
Write-Host "Folder: $Dest"
if ($failed -gt 0) { Write-Host 'Run it again to retry the ones that failed.' }
