package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class CleanerEngineTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val day = 24L * 60 * 60 * 1000
    private val now = 1_000L * day

    private fun scanOf(files: List<FileItem> = emptyList(), folders: List<FolderItem> = emptyList()) =
        ScanData(emptyMap(), emptyList(), files, folders)

    private fun groupOf(groups: List<CleanGroup>, kind: CleanKind) = groups.firstOrNull { it.kind == kind }

    @Test
    fun sortsFilesIntoGroups_eachFileInOneGroupOnly() {
        val files = listOf(
            fileItem("/s/app.apk", size = 5_000_000, modified = now - 2 * day),
            fileItem("/s/download.crdownload", size = 3_000, modified = now - 3 * day),
            fileItem("/s/empty.txt", size = 0, modified = now - 3 * day),
            fileItem("/s/notes.txt~", size = 10, modified = now - 3 * day),
            fileItem("/s/film.mkv", size = CleanerEngine.LARGE_BYTES, modified = now - 120 * day),
            // An old, big installer is an installer only.
            fileItem("/s/big.apk", size = CleanerEngine.LARGE_BYTES * 2, modified = now - 400 * day),
            fileItem("/s/keep.jpg", size = 4_000, modified = now - 5 * day),
        )
        val groups = CleanerEngine.find(scanOf(files), "/s", now)
        assertEquals(listOf("/s/big.apk", "/s/app.apk"), groupOf(groups, CleanKind.Installers)!!.files.map { it.path })
        assertEquals(
            setOf("/s/download.crdownload", "/s/empty.txt", "/s/notes.txt~"),
            groupOf(groups, CleanKind.Leftovers)!!.files.map { it.path }.toSet(),
        )
        assertEquals(listOf("/s/film.mkv"), groupOf(groups, CleanKind.LargeOld)!!.files.map { it.path })
    }

    @Test
    fun recentLeftoversAndRecentBigFilesAreLeftAlone() {
        val files = listOf(
            fileItem("/s/loading.crdownload", size = 3_000, modified = now - day / 2),
            fileItem("/s/film.mkv", size = CleanerEngine.LARGE_BYTES * 2, modified = now - 10 * day),
        )
        assertTrue(CleanerEngine.find(scanOf(files), "/s", now).isEmpty())
    }

    @Test
    fun emptyFolders_onlyTheTopOneOfANest_andOnlyWhenReallyEmpty() {
        val nest = File(tmp.root, "nest/inner/deeper").also { it.mkdirs() }
        val hiddenContent = File(tmp.root, "looksEmpty").also { it.mkdirs() }
        File(hiddenContent, ".secret").writeBytes(byteArrayOf(1))
        val full = File(tmp.root, "full").also { it.mkdirs() }
        File(full, "a.txt").writeBytes(byteArrayOf(1, 2))
        val old = now - 10 * day
        fun folder(f: File) = FolderItem(f.path, f.name, 0, old)
        val scan = scanOf(
            files = listOf(fileItem(File(full, "a.txt").path, size = 2, modified = old)),
            folders = listOf(
                folder(File(tmp.root, "nest")), folder(File(tmp.root, "nest/inner")), folder(nest),
                folder(hiddenContent), folder(full),
            ),
        )
        val group = groupOf(CleanerEngine.find(scan, tmp.root.path, now), CleanKind.EmptyFolders)!!
        assertEquals(listOf(File(tmp.root, "nest").path), group.folders.map { it.path })
    }

    @Test
    fun standardTopFoldersAndFreshFoldersAreNotOffered() {
        val download = File(tmp.root, "Download").also { it.mkdirs() }
        val fresh = File(tmp.root, "fresh").also { it.mkdirs() }
        val scan = scanOf(
            folders = listOf(
                FolderItem(download.path, "Download", 0, now - 50 * day),
                FolderItem(fresh.path, "fresh", 0, now - 1000),
            ),
        )
        assertTrue(CleanerEngine.find(scan, tmp.root.path, now).isEmpty())
    }

    @Test
    fun holdsNoFiles_falseForFilesAndMissingFolders() {
        val dir = File(tmp.root, "d").also { it.mkdirs() }
        assertTrue(CleanerEngine.holdsNoFiles(dir))
        File(dir, "x").writeBytes(byteArrayOf(1))
        assertFalse(CleanerEngine.holdsNoFiles(dir))
        assertFalse(CleanerEngine.holdsNoFiles(File(tmp.root, "missing")))
    }

    @Test
    fun stopsWhenAskedTo() {
        val files = listOf(fileItem("/s/a.apk", modified = now - 2 * day))
        assertTrue(CleanerEngine.find(scanOf(files), "/s", now, active = { false }).isEmpty())
    }

    @Test
    fun copiesByName_onlyWhenTheOriginalIsStillThere() {
        val files = listOf(
            fileItem("/s/photo.jpg", size = 4_000, modified = now - 5 * day),
            fileItem("/s/photo (1).jpg", size = 4_000, modified = now - 5 * day),
            fileItem("/s/Copy of photo.jpg", size = 4_000, modified = now - 5 * day),
            fileItem("/s/lonely (1).jpg", size = 4_000, modified = now - 5 * day),
        )
        val group = groupOf(CleanerEngine.find(scanOf(files), "/s", now), CleanKind.CopyNames)!!
        assertEquals(setOf("/s/photo (1).jpg", "/s/Copy of photo.jpg"), group.files.map { it.path }.toSet())
    }

    @Test
    fun oldScreenshots_followTheDaysTheyAreGiven() {
        val files = listOf(fileItem("/s/Pictures/Screenshots/a.png", size = 4_000, modified = now - 40 * day))
        assertEquals(
            listOf("/s/Pictures/Screenshots/a.png"),
            groupOf(CleanerEngine.find(scanOf(files), "/s", now), CleanKind.Screenshots)!!.files.map { it.path },
        )
        val patient = CleanOptions(screenshotDays = 60)
        assertTrue(CleanerEngine.find(scanOf(files), "/s", now, options = patient).isEmpty())
    }

    @Test
    fun archivesAndOldDownloads_arePickedByAge() {
        val files = listOf(
            fileItem("/s/backup.zip", size = 4_000, modified = now - 45 * day),
            fileItem("/s/Download/report.pdf", size = 4_000, modified = now - 90 * day),
            fileItem("/s/Download/new.pdf", size = 4_000, modified = now - 5 * day),
        )
        val groups = CleanerEngine.find(scanOf(files), "/s", now)
        assertEquals(listOf("/s/backup.zip"), groupOf(groups, CleanKind.Archives)!!.files.map { it.path })
        assertEquals(listOf("/s/Download/report.pdf"), groupOf(groups, CleanKind.OldDownloads)!!.files.map { it.path })
    }

    @Test
    fun switchedOffKinds_areNotLookedFor() {
        val files = listOf(fileItem("/s/app.apk", size = 5_000_000, modified = now - 2 * day))
        val options = CleanOptions(enabled = CleanKind.entries.toSet() - CleanKind.Installers)
        assertTrue(CleanerEngine.find(scanOf(files), "/s", now, options = options).isEmpty())
    }

    @Test
    fun protectedFolders_areNeverOffered() {
        val files = listOf(
            fileItem("/s/Keep/app.apk", size = 5_000_000, modified = now - 2 * day),
            fileItem("/s/Other/app.apk", size = 5_000_000, modified = now - 2 * day),
        )
        val options = CleanOptions(protectedPaths = setOf("/s/Keep"))
        val group = groupOf(CleanerEngine.find(scanOf(files), "/s", now, options = options), CleanKind.Installers)!!
        assertEquals(listOf("/s/Other/app.apk"), group.files.map { it.path })
    }

    @Test
    fun extraLeftoverExtensions_countAsLeftovers() {
        val files = listOf(fileItem("/s/data.foo", size = 100, modified = now - 3 * day))
        assertTrue(CleanerEngine.find(scanOf(files), "/s", now).isEmpty())
        val group = groupOf(CleanerEngine.find(scanOf(files), "/s", now, options = CleanOptions(extraJunk = setOf("foo"))), CleanKind.Leftovers)!!
        assertEquals(listOf("/s/data.foo"), group.files.map { it.path })
    }

    @Test
    fun safeKinds_areTheOnesAlmostAlwaysFineToClear() {
        assertEquals(
            listOf(CleanKind.Installers, CleanKind.Leftovers, CleanKind.EmptyFolders),
            CleanKind.entries.filter { it.safe },
        )
    }
}
