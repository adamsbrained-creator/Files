package ix.app.files.transfer

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipFile

class TransferTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun file(rel: String, bytes: ByteArray): File {
        val f = File(tmp.root, rel)
        f.parentFile.mkdirs()
        f.writeBytes(bytes)
        return f
    }

    private fun bytes(n: Int, seed: Int = 1) = ByteArray(n) { ((it * 31 + seed) and 0xFF).toByte() }

    // ---- planner -----------------------------------------------------------------------------

    @Test
    fun planner_keepsFolderStructureAndNamesTheFolder() {
        file("Music/A/one.mp3", bytes(10))
        file("Music/A/B/two.mp3", bytes(20))
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "Music").path))
        assertEquals(listOf("Music"), plan.roots.map { it.name })
        assertEquals(listOf("Music/A/B/two.mp3", "Music/A/one.mp3"), plan.entries.map { it.rel })
        assertEquals(30L, plan.totalBytes)
    }

    @Test
    fun planner_gathersSingleFilesIntoOneItemThatMirrorsTheirFolders() {
        val a = file("Music/Artist/a.mp3", bytes(5))
        val b = file("Other/b.mp3", bytes(6))
        val plan = TransferPlanner.plan(listOf(a.path, b.path), storageRoots = listOf(tmp.root))
        assertEquals(1, plan.roots.size)
        assertEquals("Selected files", plan.roots[0].name)
        assertFalse(plan.roots[0].isFolder)
        assertEquals(listOf("Music/Artist/a.mp3", "Other/b.mp3"), plan.entries.map { it.rel })
    }

    @Test
    fun planner_listsAFileOnceWhenItIsAlsoInsideAPickedFolder() {
        val inside = file("Music/x.mp3", bytes(5))
        val plan = TransferPlanner.plan(listOf(inside.path, File(tmp.root, "Music").path), storageRoots = listOf(tmp.root))
        assertEquals(1, plan.totalFiles)
        assertEquals("Music/x.mp3", plan.entries[0].rel)
        assertEquals(1, plan.roots.size) // no empty "Selected files" item is left behind
    }

    @Test
    fun planner_renamesTwoFoldersWithTheSameName() {
        file("one/Music/a.mp3", bytes(1))
        file("two/Music/b.mp3", bytes(1))
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "one/Music").path, File(tmp.root, "two/Music").path))
        assertEquals(listOf("Music", "Music (2)"), plan.roots.map { it.name })
        assertEquals(setOf("Music/a.mp3", "Music (2)/b.mp3"), plan.entries.map { it.rel }.toSet())
    }

    @Test
    fun planner_skipsWhatItIsToldTo() {
        val keep = file("Pics/keep.jpg", bytes(3))
        file("Pics/Private/secret.jpg", bytes(3))
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "Pics").path), skip = { it.contains("/Private") })
        assertEquals(listOf("Pics/keep.jpg"), plan.entries.map { it.rel })
        assertNotNull(keep)
    }

    @Test
    fun planner_neverGivesTwoFilesTheSamePath() {
        val a = file("a/song.mp3", bytes(1))
        val b = file("b/song.mp3", bytes(2))
        // Neither is under a known storage, so both would be called "song.mp3".
        val plan = TransferPlanner.plan(listOf(a.path, b.path))
        assertEquals(setOf("song.mp3", "song (2).mp3"), plan.entries.map { it.rel }.toSet())
    }

    // ---- zip ---------------------------------------------------------------------------------

    @Test
    fun zip_isReadableByStandardTools_andItsLengthIsKnownInAdvance() {
        val one = file("one.bin", bytes(1000, 1))
        val two = file("sub/dir/two.txt", bytes(0))
        val three = file("sub/ünï cödé 日本.dat", bytes(300_000, 3))
        val items = listOf(
            Triple("one.bin", one, one.length()),
            Triple("sub/dir/two.txt", two, two.length()),
            Triple("sub/ünï cödé 日本.dat", three, three.length()),
        )
        val out = ByteArrayOutputStream()
        val zip = ZipStreamWriter(out)
        for ((name, f, size) in items) zip.add(name, f, size, f.lastModified())
        zip.finish()

        assertEquals(ZipLayout.archiveBytes(items.map { it.first to it.third }), out.size().toLong())

        val target = tmp.newFile("out.zip")
        target.writeBytes(out.toByteArray())
        ZipFile(target).use { z ->
            assertEquals(3, z.size())
            for ((name, f, _) in items) {
                val entry = z.getEntry(name)
                assertNotNull(name, entry)
                assertEquals(f.length(), entry.size)
                assertArrayEquals(name, f.readBytes(), z.getInputStream(entry).readBytes()) // also checks the CRC
            }
        }
    }

    @Test
    fun zip_ofNothingIsStillAValidArchive() {
        val out = ByteArrayOutputStream()
        ZipStreamWriter(out).finish()
        assertEquals(ZipLayout.archiveBytes(emptyList()), out.size().toLong())
        val target = tmp.newFile("empty.zip")
        target.writeBytes(out.toByteArray())
        ZipFile(target).use { assertEquals(0, it.size()) }
    }

    @Test
    fun zip_failsLoudlyWhenAFileShrinksBeforeItIsSent() {
        val f = file("a.bin", bytes(100))
        val out = ByteArrayOutputStream()
        val zip = ZipStreamWriter(out)
        try {
            zip.add("a.bin", f, 200, 0) // announced as 200 bytes, only 100 exist
            throw AssertionError("expected a failure")
        } catch (e: java.io.IOException) {
            assertTrue(e.message!!.contains("shorter"))
        }
    }

    @Test
    fun zip_storesDatesBefore1980AsTheEarliestOneZipCanHold() {
        val f = file("old.txt", bytes(4))
        val out = ByteArrayOutputStream()
        val zip = ZipStreamWriter(out)
        zip.add("old.txt", f, 4, 1000L) // 1970
        zip.finish()
        val target = tmp.newFile("old.zip")
        target.writeBytes(out.toByteArray())
        ZipFile(target).use { assertTrue(it.getEntry("old.txt").time >= 0) }
    }

    // ---- server ------------------------------------------------------------------------------

    private fun serverFor(plan: TransferPlan): TransferServer {
        val s = TransferServer(plan, "Test phone", { "<html>__PHONE__</html>" }, { "Base='__BASE__'" }, 0)
        s.start()
        return s
    }

    private fun get(url: String, headers: Map<String, String> = emptyMap(), method: String = "GET"): Triple<Int, Map<String, List<String>>, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = false
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        val code = c.responseCode
        val body = if (method == "HEAD") ByteArray(0) else (if (code < 400) c.inputStream else c.errorStream)?.readBytes() ?: ByteArray(0)
        return Triple(code, c.headerFields.filterKeys { it != null }, body)
    }

    @Test
    fun server_onlyAnswersWithTheRightToken() {
        file("a.txt", bytes(10))
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "a.txt").path))
        val s = serverFor(plan)
        try {
            val base = "http://127.0.0.1:${s.port}"
            assertEquals(404, get("$base/").first)
            assertEquals(404, get("$base/wrong/").first)
            assertEquals(404, get("$base/wrong/f/1").first)
            assertEquals(200, get("$base/${s.token}/").first)
            val redirect = get("$base/${s.token}")
            assertEquals(302, redirect.first)
            assertEquals(405, get("$base/${s.token}/", method = "POST").first.let { if (it == 405) 405 else it })
        } finally {
            s.stop()
        }
    }

    @Test
    fun server_sendsFilesWithRangeSupportForResuming() {
        val data = bytes(5000, 7)
        file("movie.mkv", data)
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "movie.mkv").path))
        val s = serverFor(plan)
        try {
            val url = "http://127.0.0.1:${s.port}/${s.token}/f/1"
            val whole = get(url)
            assertEquals(200, whole.first)
            assertArrayEquals(data, whole.third)
            val part = get(url, mapOf("Range" to "bytes=1000-1999"))
            assertEquals(206, part.first)
            assertArrayEquals(data.copyOfRange(1000, 2000), part.third)
            assertEquals(416, get(url, mapOf("Range" to "bytes=9000-")).first)
            assertEquals(404, get("http://127.0.0.1:${s.port}/${s.token}/f/99").first)
            assertEquals(404, get("http://127.0.0.1:${s.port}/${s.token}/f/abc").first)
        } finally {
            s.stop()
        }
    }

    @Test
    fun server_zipOfEverythingMatchesItsAnnouncedLength_andCountsWhatWasSent() {
        file("Music/a.mp3", bytes(4000, 1))
        file("Music/sub/b.mp3", bytes(70_000, 2))
        file("Photos/c.jpg", bytes(123, 3))
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "Music").path, File(tmp.root, "Photos").path))
        val s = serverFor(plan)
        try {
            val base = "http://127.0.0.1:${s.port}/${s.token}"
            val r = get("$base/zip")
            assertEquals(200, r.first)
            assertEquals(r.third.size.toString(), r.second["Content-Length"]!![0])
            val target = tmp.newFile("all.zip")
            target.writeBytes(r.third)
            ZipFile(target).use { z ->
                assertEquals(setOf("Music/a.mp3", "Music/sub/b.mp3", "Photos/c.jpg"), z.entries().toList().map { it.name }.toSet())
            }
            assertEquals(3, s.stats.filesDone.get())
            assertEquals(4000L + 70_000 + 123, s.stats.bytesSent.get())

            val one = get("$base/zip/1")
            assertEquals(200, one.first)
            val target2 = tmp.newFile("photos.zip")
            target2.writeBytes(one.third)
            ZipFile(target2).use { assertEquals(listOf("Photos/c.jpg"), it.entries().toList().map { e -> e.name }) }
            assertEquals(404, get("$base/zip/9").first)
            // A HEAD request tells the size without sending the archive.
            assertEquals(r.third.size.toString(), get("$base/zip", method = "HEAD").second["Content-Length"]!![0])
        } finally {
            s.stop()
        }
    }

    @Test
    fun server_listsFilesForTheScript_andFillsInTheAddress() {
        file("Docs/one two.txt", bytes(11))
        val plan = TransferPlanner.plan(listOf(File(tmp.root, "Docs").path))
        val s = serverFor(plan)
        try {
            val base = "http://127.0.0.1:${s.port}/${s.token}"
            val line = String(get("$base/api/files.tsv").third, Charsets.UTF_8).trim().split('\t')
            assertEquals(4, line.size)
            assertEquals("11", line[1])
            assertEquals("Docs/one two.txt", line[3])
            assertEquals("Base='http://127.0.0.1:${s.port}/${s.token}'", String(get("$base/get.ps1").third))
            val json = String(get("$base/api/roots.json").third)
            assertTrue(json.contains("\"name\":\"Docs\"") && json.contains("\"files\":1"))
            assertEquals("<html>Test phone</html>", String(get("$base/").third))
        } finally {
            s.stop()
        }
    }

    @Test
    fun server_stopsAnswering() {
        file("a.txt", bytes(1))
        val s = serverFor(TransferPlanner.plan(listOf(File(tmp.root, "a.txt").path)))
        val port = s.port
        s.stop()
        assertFalse(s.running)
        assertNull(runCatching { get("http://127.0.0.1:$port/x/") }.getOrNull())
    }

    // ---- helpers -----------------------------------------------------------------------------

    @Test
    fun disposition_survivesAnyFileName() {
        val d = TransferServer.disposition("Beyoncé \"Halo\" 100%.mp3")
        assertTrue(d.startsWith("attachment; filename=\""))
        val fallback = Regex("filename=\"(.*)\"; filename\\*").find(d)!!.groupValues[1]
        assertFalse(fallback.contains('"') || fallback.contains('%') || fallback.any { it.code > 126 })
        assertTrue(d.contains("filename*=UTF-8''Beyonc%C3%A9%20%22Halo%22%20100%25.mp3"))
    }

    @Test
    fun tokens_areEightCharactersWithoutLookAlikes() {
        repeat(50) {
            val t = TransferServer.newToken()
            assertEquals(8, t.length)
            assertTrue(t.none { it in "l1o0i" })
        }
    }
}
