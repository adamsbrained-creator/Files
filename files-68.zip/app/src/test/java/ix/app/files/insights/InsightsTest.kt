package ix.app.files.insights

import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private const val ROOT = "/storage/emulated/0"
private const val DAY = 24L * 60 * 60 * 1000
private const val NOW = 1_800_000_000_000L
private const val MB = 1024L * 1024

private fun file(path: String, mb: Long = 1, ageDays: Int = 100, kind: FileKind? = null): FileItem {
    val full = if (path.startsWith("/")) path else "$ROOT/$path"
    val fileName = full.substringAfterLast('/')
    val dot = fileName.lastIndexOf('.')
    val ext = if (dot > 0) fileName.substring(dot + 1).lowercase() else ""
    val k = kind ?: when (ext) {
        "jpg", "png" -> FileKind.Image
        "mp4", "mkv" -> FileKind.Video
        "mp3" -> FileKind.Audio
        "pdf", "docx", "txt" -> FileKind.Document
        "apk" -> FileKind.App
        else -> FileKind.Other
    }
    return FileItem(full, if (dot > 0) fileName.substring(0, dot) else fileName, ext, mb * MB, NOW - ageDays * DAY, k)
}

private fun input(
    files: List<FileItem>,
    habits: Habits = Habits(),
    rules: List<SortRule> = emptyList(),
    home: Set<String> = emptySet(),
    baseline: StorageSnapshot? = null,
    dismissed: Set<String> = emptySet(),
    tuning: InsightsTuning = InsightsTuning(),
): InsightsInput {
    val folders = HashSet<String>()
    for (f in files) {
        var p = f.path.substringBeforeLast('/')
        while (p.length > ROOT.length) {
            folders.add(p)
            p = p.substringBeforeLast('/')
        }
    }
    return InsightsInput(files, folders, ROOT, habits, rules, home, baseline, dismissed, NOW, tuning)
}

class HabitsTest {

    @Test
    fun countsOpensAndRemembersWhenLast() {
        var h = Habits()
        h = h.openedFile("$ROOT/a.txt", 100)
        h = h.openedFile("$ROOT/a.txt", 200)
        h = h.openedFolder("$ROOT/Download", 300)
        assertEquals(2, h.files.getValue("$ROOT/a.txt").count)
        assertEquals(200L, h.files.getValue("$ROOT/a.txt").lastMillis)
        assertEquals(1, h.folders.getValue("$ROOT/Download").count)
        assertEquals(100L, h.sinceMillis)
        assertEquals(2, h.useCounts()["$ROOT/a.txt"])
    }

    @Test
    fun savesAndReadsBackAndIgnoresDamagedLines() {
        val h = Habits().openedFile("$ROOT/My Files/a b.txt", 5).openedFile("$ROOT/My Files/a b.txt", 6)
            .openedFolder("$ROOT/My Files", 7).deleted(listOf("$ROOT/x.apk", "$ROOT/y.apk"), 8)
        val back = Habits.decode(h.encode())
        assertEquals(2, back.files.getValue("$ROOT/My Files/a b.txt").count)
        assertEquals(6L, back.files.getValue("$ROOT/My Files/a b.txt").lastMillis)
        assertEquals(1, back.folders.size)
        assertEquals(2, back.deletedExtensions["apk"])
        assertEquals(5L, back.sinceMillis)
        val damaged = Habits.decode("IXHABITS1\nf\tnope\t1\t/a\nf\t1\t2\t/b\ngarbage\n")
        assertEquals(setOf("/b"), damaged.files.keys)
        assertTrue(Habits.decode("something else").isEmpty)
    }

    @Test
    fun pathsThatCouldBreakTheFormatAreNotRecorded() {
        val h = Habits().openedFile("/odd\tname", 1).openedFile("/odd\nname", 1).openedFolder("", 1)
        assertTrue(h.isEmpty)
    }

    @Test
    fun deletingCountsExtensionsAndForgetsWhatWasDeleted() {
        val h = Habits().openedFile("$ROOT/Old/a.apk", 1).openedFile("$ROOT/Keep/b.txt", 1).openedFolder("$ROOT/Old", 1)
            .deleted(listOf("$ROOT/Old", "$ROOT/z.zip"), 2)
        assertNull(h.files["$ROOT/Old/a.apk"])
        assertNull(h.folders["$ROOT/Old"])
        assertNotNull(h.files["$ROOT/Keep/b.txt"])
        assertEquals(1, h.deletedExtensions["zip"])
    }

    @Test
    fun movingCarriesWhatIsKnownToTheNewPlace() {
        val h = Habits().openedFile("$ROOT/Download/a.pdf", 1).openedFile("$ROOT/Download/sub/b.pdf", 1)
            .openedFolder("$ROOT/Download/sub", 1)
            .moved(listOf("$ROOT/Download/a.pdf" to "$ROOT/Documents/a.pdf", "$ROOT/Download/sub" to "$ROOT/Docs/sub"))
        assertNotNull(h.files["$ROOT/Documents/a.pdf"])
        assertNotNull(h.files["$ROOT/Docs/sub/b.pdf"])
        assertNotNull(h.folders["$ROOT/Docs/sub"])
        assertNull(h.files["$ROOT/Download/a.pdf"])
    }

    @Test
    fun recentOpensRankAboveOldOnesAndTheListStaysSmall() {
        var h = Habits()
        repeat(10) { h = h.openedFile("$ROOT/old.txt", NOW - 400 * DAY) }
        repeat(3) { h = h.openedFile("$ROOT/new.txt", NOW - DAY) }
        assertEquals("$ROOT/new.txt", h.topFiles(5, NOW).first().first)
        var many = Habits()
        for (i in 0 until Habits.MAX_FILES + 50) many = many.openedFile("$ROOT/f$i.txt", NOW + i)
        assertTrue(many.files.size <= Habits.MAX_FILES)
        assertNotNull("the newest stays", many.files["$ROOT/f${Habits.MAX_FILES + 49}.txt"])
    }
}

class StorageInsightsTest {

    @Test
    fun foldersAtTheTopAreAddedUpBiggestFirst() {
        val files = listOf(file("Download/a.zip", 50), file("Download/x/b.zip", 30), file("DCIM/1.jpg", 10), file("loose.txt", 5))
        val sizes = StorageInsights.folderSizes(files, ROOT)
        assertEquals(listOf("$ROOT/Download", "$ROOT/DCIM", ROOT), sizes.map { it.path })
        assertEquals(80 * MB, sizes[0].bytes)
        assertEquals(2, sizes[0].files)
    }

    @Test
    fun growthNamesTheSubfolderWhereTheSpaceWent() {
        val before = StorageInsights.snapshot(listOf(file("Download/a.zip", 100), file("Download/x/b.zip", 100)), ROOT, 1)
        val after = StorageInsights.snapshot(
            listOf(file("Download/a.zip", 100), file("Download/x/b.zip", 100), file("Download/x/c.zip", 900), file("Pics/p.jpg", 700)),
            ROOT, 2,
        )
        val grown = StorageInsights.growth(before, after, 500 * MB)
        assertEquals(listOf("$ROOT/Download/x", "$ROOT/Pics"), grown.map { it.path })
        assertFalse("parent is left out when one child holds the growth", grown.any { it.path == "$ROOT/Download" })
        assertTrue(StorageInsights.growth(null, after, 1).isEmpty())
    }

    @Test
    fun snapshotsSurviveSavingAndReading() {
        val s = StorageInsights.snapshot(listOf(file("A B/c d/e.txt", 3)), ROOT, 42)
        val back = StorageSnapshot.decode(s.encode())!!
        assertEquals(42L, back.takenMillis)
        assertEquals(s.folderBytes, back.folderBytes)
        assertNull(StorageSnapshot.decode("nope"))
    }

    @Test
    fun ageBandsOnlyListWhatIsThere() {
        val bands = StorageInsights.ageBands(listOf(file("a.txt", 1, 3), file("b.txt", 2, 200), file("c.txt", 4, 800)), NOW)
        assertEquals(listOf(AgeBand.UnderMonth, AgeBand.Months6To12, AgeBand.OverYear), bands.map { it.band })
        assertEquals(4 * MB, bands.last().bytes)
    }
}

class SortRulesTest {

    private val photos = SortRule("r", "Photos", "Download", setOf(FileKind.Image), emptySet(), "", 3, RuleAction.Move, "Pictures")

    @Test
    fun matchesOnFolderKindAgeAndLeavesFreshFilesAlone() {
        assertTrue(photos.matches(file("Download/a.jpg", ageDays = 10), ROOT, NOW))
        assertTrue("in a subfolder too", photos.matches(file("Download/x/a.jpg", ageDays = 10), ROOT, NOW))
        assertFalse(photos.matches(file("Documents/a.jpg", ageDays = 10), ROOT, NOW))
        assertFalse(photos.matches(file("Download/a.mp4", ageDays = 10), ROOT, NOW))
        assertFalse("too new for the rule", photos.matches(file("Download/a.jpg", ageDays = 1), ROOT, NOW))
        assertFalse("already in the destination", photos.copy(fromFolder = "").matches(file("Pictures/a.jpg", ageDays = 10), ROOT, NOW))
        val fresh = file("Download/a.jpg").copy(modifiedMillis = NOW - 1000)
        assertFalse("maybe still being written", photos.copy(olderThanDays = 0).matches(fresh, ROOT, NOW))
    }

    @Test
    fun extensionAndNameFiltersIgnoreCase() {
        val rule = photos.copy(kinds = emptySet(), extensions = RuleText.extensions("JPG, .png"), nameContains = "holiday", olderThanDays = 0)
        assertTrue(rule.matches(file("Download/Holiday 1.JPG", ageDays = 5), ROOT, NOW))
        assertFalse(rule.matches(file("Download/work.jpg", ageDays = 5), ROOT, NOW))
        assertFalse(rule.matches(file("Download/Holiday.gif", ageDays = 5), ROOT, NOW))
    }

    @Test
    fun foldersAreCleanedAndAnythingPointingOutsideStorageIsRefused() {
        assertEquals("Pictures/Screenshots", RuleText.cleanFolder(" /Pictures//Screenshots/ "))
        assertEquals("Download", RuleText.cleanFolder("/storage/emulated/0/Download"))
        assertEquals("Music", RuleText.cleanFolder("sdcard/Music"))
        assertEquals("", RuleText.cleanFolder("  "))
        assertNull(RuleText.cleanFolder("../secret"))
        assertNull(RuleText.cleanFolder("A/../../b"))
        assertFalse(photos.copy(destFolder = "../x").valid)
        assertFalse("moving needs a destination", photos.copy(destFolder = "").valid)
        assertTrue(photos.copy(action = RuleAction.Trash, destFolder = "").valid)
        assertEquals("$ROOT/Pictures", photos.destPath(ROOT))
        assertNull(photos.copy(action = RuleAction.Trash).destPath(ROOT))
    }

    @Test
    fun rulesSurviveSavingAndReading() {
        val rules = listOf(photos.copy(name = "Tabs\tand\nlines", extensions = setOf("jpg", "png")), RulePresets.all.last().copy(enabled = false))
        val back = RuleText.decode(RuleText.encode(rules))
        assertEquals(2, back.size)
        assertEquals("Tabs and lines", back[0].name)
        assertEquals(setOf("jpg", "png"), back[0].extensions)
        assertEquals(setOf(FileKind.Image), back[0].kinds)
        assertEquals(RuleAction.Trash, back[1].action)
        assertFalse(back[1].enabled)
        assertTrue(RuleText.decode("junk").isEmpty())
    }

    @Test
    fun everyPresetIsAValidRule() {
        assertTrue(RulePresets.all.all { it.valid })
        assertEquals(RulePresets.all.size, RulePresets.all.map { it.id }.toSet().size)
    }
}

class InsightsEngineTest {

    private fun ids(r: InsightsReport) = r.suggestions.map { it.id }

    @Test
    fun aRuleBecomesASuggestionToMoveTheMatchingFilesAndNothingMoves() {
        val photo = SortRule("p", "Photos", "Download", setOf(FileKind.Image), emptySet(), "", 3, RuleAction.Move, "Pictures")
        val files = listOf(file("Download/a.jpg", ageDays = 20), file("Download/b.jpg", ageDays = 20), file("Download/c.pdf", ageDays = 20))
        val report = InsightsEngine.build(input(files, rules = listOf(photo)))
        val s = report.suggestions.first()
        assertEquals("rule:p", s.id)
        assertEquals(2, s.count)
        assertEquals("$ROOT/Pictures", (s.action as SuggestionAction.MoveTo).destPath)
    }

    @Test
    fun disabledAndBrokenRulesStaySilent() {
        val off = SortRule("p", "Photos", "Download", setOf(FileKind.Image), emptySet(), "", 3, RuleAction.Move, "Pictures", enabled = false)
        val broken = off.copy(id = "q", enabled = true, destFolder = "../x")
        val files = listOf(file("Download/a.jpg", ageDays = 20))
        assertTrue(InsightsEngine.build(input(files, rules = listOf(off, broken))).suggestions.none { it.kind == SuggestionKind.Rule })
    }

    @Test
    fun aFileIsOfferedOnlyOnce() {
        val rule = SortRule("p", "Photos", "Download", setOf(FileKind.Image), emptySet(), "", 3, RuleAction.Move, "Pictures")
        val files = (1..6).map { file("Download/p$it.jpg", ageDays = 90) }
        val report = InsightsEngine.build(input(files, rules = listOf(rule)))
        val paths = report.suggestions.flatMap { it.files }.map { it.path }
        assertEquals(paths.size, paths.toSet().size)
        assertEquals("rule:p", report.suggestions.first().id)
    }

    @Test
    fun manyPicturesInDownloadAreOfferedAMoveToPicturesButFewAreNot() {
        val many = (1..5).map { file("Download/p$it.jpg", ageDays = 10) }
        val s = InsightsEngine.build(input(many)).suggestions.single { it.kind == SuggestionKind.Misplaced }
        assertEquals("$ROOT/Pictures", (s.action as SuggestionAction.MoveTo).destPath)
        assertTrue(InsightsEngine.build(input(many.take(4))).suggestions.none { it.kind == SuggestionKind.Misplaced })
        assertTrue("nested files stay", InsightsEngine.build(input((1..5).map { file("Download/x/p$it.jpg", ageDays = 10) })).suggestions.none { it.kind == SuggestionKind.Misplaced })
    }

    @Test
    fun oldScreenshotsNeedAPileBeforeTheyAreMentioned() {
        val files = (1..10).map { file("Pictures/Screenshots/s$it.png", ageDays = 40) }
        val s = InsightsEngine.build(input(files)).suggestions.single { it.kind == SuggestionKind.OldScreenshots }
        assertTrue(s.action is SuggestionAction.Review)
        assertTrue(InsightsEngine.build(input(files.take(9))).suggestions.isEmpty())
    }

    @Test
    fun deletingTheSameKindOfFileOverAndOverMakesMoreOfItASuggestion() {
        val files = (1..3).map { file("Documents/old$it.zip", ageDays = 30) } + file("Documents/new.zip", ageDays = 1)
        val habits = Habits().deleted(listOf("$ROOT/a.zip", "$ROOT/b.zip", "$ROOT/c.zip"), NOW)
        val s = InsightsEngine.build(input(files, habits)).suggestions.single { it.kind == SuggestionKind.DeleteHabit }
        assertEquals("zip", s.subject)
        assertEquals(3, s.count)
        assertTrue("without the habit there is nothing to say", InsightsEngine.build(input(files)).suggestions.none { it.kind == SuggestionKind.DeleteHabit })
    }

    @Test
    fun deletingPhotosOftenNeverMakesTheAppSuggestDeletingPhotos() {
        val files = (1..20).map { file("DCIM/p$it.jpg", ageDays = 400) }
        val habits = Habits().deleted((1..30).map { "$ROOT/x$it.jpg" }, NOW)
        assertTrue(InsightsEngine.build(input(files, habits)).suggestions.none { it.kind == SuggestionKind.DeleteHabit })
    }

    @Test
    fun bigFilesYouHaveOpenedAreNotCalledUntouched() {
        val big = file("Movies/film.mkv", 800, 300)
        val other = file("Movies/other.mkv", 500, 300)
        val habits = Habits().openedFile(big.path, NOW - 200 * DAY)
        val s = InsightsEngine.build(input(listOf(big, other), habits)).suggestions.single { it.kind == SuggestionKind.BigUntouched }
        assertEquals(listOf(other.path), s.files.map { it.path })
    }

    @Test
    fun aFolderOpenedOftenIsOfferedForHomeUnlessItIsThereOrStandard() {
        val files = listOf(file("Projects/mock/a.html", ageDays = 2), file("Download/x.txt", ageDays = 2))
        var habits = Habits()
        repeat(6) { habits = habits.openedFolder("$ROOT/Projects/mock", NOW - DAY).openedFolder("$ROOT/Download", NOW - DAY) }
        val s = InsightsEngine.build(input(files, habits)).suggestions
        val frequent = s.filter { it.kind == SuggestionKind.FrequentFolder }
        assertEquals(listOf("$ROOT/Projects/mock"), frequent.map { it.subject })
        assertEquals("$ROOT/Projects/mock", (frequent[0].action as SuggestionAction.AddToHome).path)
        assertTrue(InsightsEngine.build(input(files, habits, home = setOf("$ROOT/Projects/mock"))).suggestions.none { it.kind == SuggestionKind.FrequentFolder })
        assertTrue(InsightsEngine.build(input(files, habits, dismissed = setOf("frequent:$ROOT/Projects/mock"))).suggestions.none { it.kind == SuggestionKind.FrequentFolder })
    }

    @Test
    fun aBigFolderNobodyHasTouchedForMonthsIsNamed() {
        val files = listOf(file("Backup/old/a.bin", 600, 300), file("Backup/old/b.bin", 10, 300), file("Notes/a.txt", 1, 1))
        val stale = InsightsEngine.build(input(files)).suggestions.filter { it.kind == SuggestionKind.StaleFolder }
        assertEquals(listOf("$ROOT/Backup"), stale.map { it.subject })
        val opened = Habits().openedFolder("$ROOT/Backup", NOW - 10 * DAY)
        assertTrue(InsightsEngine.build(input(files, opened)).suggestions.none { it.kind == SuggestionKind.StaleFolder && it.subject == "$ROOT/Backup" })
    }

    @Test
    fun growthShowsAgainstAnOldEnoughSnapshotOnly() {
        val before = listOf(file("Download/a.zip", 100))
        val after = before + file("Download/b.zip", 900)
        val old = StorageInsights.snapshot(before, ROOT, NOW - 5 * DAY)
        val report = InsightsEngine.build(input(after, baseline = old))
        assertTrue(report.suggestions.any { it.kind == SuggestionKind.Growing })
        assertEquals(NOW - 5 * DAY, report.growthSince)
        val tooNew = StorageInsights.snapshot(before, ROOT, NOW - 1000)
        val quiet = InsightsEngine.build(input(after, baseline = tooNew))
        assertTrue(quiet.growth.isEmpty())
        assertNull(quiet.growthSince)
    }

    @Test
    fun theReportAddsUpAndListsTheHabits() {
        val a = file("Download/a.pdf", 5, 2)
        val files = listOf(a, file("DCIM/b.jpg", 7, 2))
        val habits = Habits().openedFile(a.path, NOW).openedFile("$ROOT/Gone/x.txt", NOW).openedFolder("$ROOT/Download", NOW)
        val report = InsightsEngine.build(input(files, habits))
        assertEquals(12 * MB, report.totalBytes)
        assertEquals(2, report.fileCount)
        assertEquals(listOf(a.path), report.topFiles.map { it.file.path })
        assertEquals(listOf("$ROOT/Download"), report.topFolders.map { it.path })
        assertEquals("$ROOT/Download", report.folders.last().path)
    }

    @Test
    fun ruleSuggestionsComeFirstThenTheBiggest() {
        val rule = SortRule("t", "Old installers", "", emptySet(), setOf("apk"), "", 7, RuleAction.Trash, "")
        val files = listOf(file("Download/a.apk", 5, 30)) + (1..5).map { file("Download/big$it.pdf", 300, 100) }
        val ordered = InsightsEngine.build(input(files, rules = listOf(rule))).suggestions
        assertEquals("rule:t", ordered.first().id)
        assertTrue(ordered.first().action is SuggestionAction.Trash)
        assertTrue(ordered.drop(1).zipWithNext().all { (x, y) -> x.bytes >= y.bytes })
    }

    @Test
    fun installers_areSuggestedFromTwoOnwards() {
        val two = listOf(file("Download/a.apk", 5, 10), file("Download/b.apk", 5, 10))
        val s = InsightsEngine.build(input(two)).suggestions.single { it.kind == SuggestionKind.Installers }
        assertEquals(2, s.count)
        assertTrue(InsightsEngine.build(input(two.take(1))).suggestions.none { it.kind == SuggestionKind.Installers })
    }

    @Test
    fun copiesByName_needTheirOriginalNextToThem() {
        val files = listOf(
            file("Pictures/a.jpg", 1, 10), file("Pictures/a (1).jpg", 1, 10),
            file("Pictures/b.jpg", 1, 10), file("Pictures/b (1).jpg", 1, 10),
            file("Pictures/c.jpg", 1, 10), file("Pictures/c - Copy.jpg", 1, 10),
            file("Pictures/orphan (1).jpg", 1, 10),
        )
        val s = InsightsEngine.build(input(files)).suggestions.single { it.kind == SuggestionKind.CopyNames }
        assertEquals(3, s.count)
    }

    @Test
    fun bigVideos_needToBeBigAndUnopened() {
        val files = listOf(file("Movies/long.mp4", 300, 60), file("Movies/short.mp4", 100, 60))
        val s = InsightsEngine.build(input(files)).suggestions.single { it.kind == SuggestionKind.BigVideos }
        assertEquals(listOf("$ROOT/Movies/long.mp4"), s.files.map { it.path })
    }

    @Test
    fun tuning_changesWhatCountsAsBig() {
        val files = listOf(file("Documents/old.pdf", 60, 300))
        assertTrue(InsightsEngine.build(input(files)).suggestions.none { it.kind == SuggestionKind.BigUntouched })
        val loose = InsightsTuning(bigBytes = 50 * MB, bigDays = 200)
        assertTrue(InsightsEngine.build(input(files, tuning = loose)).suggestions.any { it.kind == SuggestionKind.BigUntouched })
    }

    @Test
    fun switchedOffKinds_andProtectedFolders_areLeftOut() {
        val files = listOf(file("Download/a.apk", 5, 10), file("Download/b.apk", 5, 10))
        val off = InsightsTuning(off = setOf(SuggestionKind.Installers))
        assertTrue(InsightsEngine.build(input(files, tuning = off)).suggestions.none { it.kind == SuggestionKind.Installers })
        val protectedDownload = InsightsTuning(protectedPaths = setOf("$ROOT/Download"))
        assertTrue(InsightsEngine.build(input(files, tuning = protectedDownload)).suggestions.isEmpty())
    }

    @Test
    fun report_addsUpKindsAndWhatCouldBeFreed() {
        val files = listOf(
            file("Download/a.apk", 5, 10), file("Download/b.apk", 7, 10),
            file("Pictures/p.jpg", 2, 1), file("Pictures/q.jpg", 3, 2),
        )
        val report = InsightsEngine.build(input(files))
        assertEquals(17L * MB, report.kinds.sumOf { it.bytes })
        assertEquals(FileKind.App, report.kinds.first().kind)
        assertEquals(2, report.addedWeekCount)
        assertEquals(5L * MB, report.addedWeekBytes)
        assertEquals(7, report.weekDays.size)
        assertEquals(5L * MB, report.weekDays.sum())
        assertTrue(report.reclaimBytes >= 12L * MB)
        assertEquals(report.suggestions.filter { it.id in report.reclaimIds }.sumOf { it.bytes }, report.reclaimBytes)
    }
}
