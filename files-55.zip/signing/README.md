# Signing key

`ixfiles.jks` is the key every build of Files is signed with (alias `ixfiles`, store and key password `ixfileskey`).
It lives in the repo on purpose: the same key on every build is what lets a new APK install over the old one.

It is a personal-project key, not a secret. Anyone who can read this repo could sign an app that Android would
accept as an update to yours, so keep the repo private. If the repo ever goes public, make a new key, put it in
repository secrets instead (see the Release section in the main README) and expect one uninstall.

Do not replace or regenerate this file: a different key means Android refuses the update until the app is uninstalled.
