package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UninstallQueueTest {

    @Test
    fun walksThroughEveryAppInOrderAndCountsTheOnesThatAreGone() {
        var q = UninstallQueue.of(listOf("a", "b", "c"))
        assertEquals("a", q.current)
        q = q.after(gone = true, declined = false)
        assertEquals("b", q.current)
        q = q.after(gone = true, declined = false)
        q = q.after(gone = true, declined = false)
        assertTrue(q.finished)
        assertNull(q.current)
        assertEquals(3, q.removed)
        assertEquals(0, q.failed)
        assertEquals(3, q.total)
    }

    @Test
    fun sayingNoStopsTheRestInsteadOfAskingAgain() {
        var q = UninstallQueue.of(listOf("a", "b", "c", "d"))
        q = q.after(gone = true, declined = false)
        q = q.after(gone = false, declined = true)
        assertTrue(q.finished)
        assertNull(q.current)
        assertEquals(1, q.removed)
        assertEquals(0, q.failed)
        assertEquals(4, q.total)
    }

    @Test
    fun anAppThatCouldNotBeRemovedCountsAsFailedAndTheNextOneIsAsked() {
        var q = UninstallQueue.of(listOf("a", "b"))
        q = q.after(gone = false, declined = false)
        assertFalse(q.finished)
        assertEquals("b", q.current)
        q = q.after(gone = true, declined = false)
        assertTrue(q.finished)
        assertEquals(1, q.removed)
        assertEquals(1, q.failed)
    }

    @Test
    fun anAppThatIsGoneCountsEvenIfThePhoneAnsweredCancelled() {
        val q = UninstallQueue.of(listOf("a", "b")).after(gone = true, declined = true)
        assertEquals("b", q.current)
        assertEquals(1, q.removed)
    }

    @Test
    fun repeatedPackagesAreAskedOnceAndAFinishedQueueStaysFinished() {
        var q = UninstallQueue.of(listOf("a", "a", "b"))
        assertEquals(2, q.total)
        q = q.after(true, false).after(true, false)
        assertTrue(q.finished)
        val same = q.after(true, false)
        assertEquals(q, same)
        assertTrue(UninstallQueue.of(emptyList()).finished)
    }
}
