package ix.app.files.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OpenMimeTest {

    @Test
    fun htmlFilesAreOfferedToBrowsersWhateverThePhoneGuesses() {
        assertEquals("text/html", OpenMime.of("mockup.html", null))
        assertEquals("text/html", OpenMime.of("Mockup.HTM", "text/plain"))
        assertEquals("image/svg+xml", OpenMime.of("logo.svg", null))
    }

    @Test
    fun theFixedListBeatsAWrongGuessButAGoodGuessBeatsTheTextFallback() {
        assertEquals("text/markdown", OpenMime.of("notes.md", null))
        assertEquals("application/json", OpenMime.of("data.json", "text/plain"))
        assertEquals("video/mp4", OpenMime.of("clip.mp4", "video/mp4"))
        // "ts" is TypeScript to the reader, but the phone says video, and a file picked as video stays video.
        assertEquals("video/mp2t", OpenMime.of("clip.ts", "video/mp2t"))
    }

    @Test
    fun textTheReaderOpensIsOfferedToTextEditors() {
        assertEquals("text/plain", OpenMime.of("Main.kt", null))
        assertEquals("text/plain", OpenMime.of("build.gradle", ""))
        assertEquals("text/plain", OpenMime.of("README", null))
    }

    @Test
    fun anythingElseIsAnyKind() {
        assertEquals("*/*", OpenMime.of("archive.xyz", null))
        assertEquals("*/*", OpenMime.of("noextension", null))
    }

    @Test
    fun onlyWebPagesGoToABrowser() {
        assertTrue(OpenMime.isWebPage("index.html"))
        assertTrue(OpenMime.isWebPage("page.HTM"))
        assertTrue(OpenMime.isWebPage("a.xhtml"))
        assertTrue(OpenMime.isWebPage("icon.svg"))
        assertFalse(OpenMime.isWebPage("notes.md"))
        assertFalse(OpenMime.isWebPage("html"))
        assertFalse(OpenMime.isWebPage("file.html.bak"))
        assertFalse(OpenMime.isWebPage("trailingdot."))
    }

    @Test
    fun extensionIsLowercaseAndEmptyWhenThereIsNone() {
        assertEquals("html", OpenMime.extensionOf("A.B.HTML"))
        assertEquals("", OpenMime.extensionOf("README"))
        assertEquals("", OpenMime.extensionOf("odd."))
    }
}
