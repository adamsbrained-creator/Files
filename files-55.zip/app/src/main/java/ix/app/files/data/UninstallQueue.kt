package ix.app.files.data

/**
 * Uninstalling several apps one after another. Android has no way to remove many apps with one question, so the
 * system asks about each app in turn and this keeps count: which one is up, how many are gone, how many failed.
 * If the person says no to one of the system's questions the queue stops, so a change of mind does not mean
 * answering "cancel" for every app left.
 */
data class UninstallQueue(
    val packages: List<String>,
    val index: Int = 0,
    val removed: Int = 0,
    val failed: Int = 0,
    val stopped: Boolean = false,
) {
    val total: Int get() = packages.size

    /** The app the system is asked about now, or null when the queue is done or stopped. */
    val current: String? get() = if (stopped) null else packages.getOrNull(index)

    val finished: Boolean get() = current == null

    /**
     * The queue after the system answered for [current]. [gone]: the app is no longer installed.
     * [declined]: the person said no (and the app is still there). Anything else counts as a failure.
     */
    fun after(gone: Boolean, declined: Boolean): UninstallQueue = when {
        finished -> this
        gone -> copy(index = index + 1, removed = removed + 1)
        declined -> copy(stopped = true)
        else -> copy(index = index + 1, failed = failed + 1)
    }

    companion object {
        /** A queue for these packages, each once, in the order given. */
        fun of(packages: List<String>): UninstallQueue = UninstallQueue(packages.distinct())
    }
}
