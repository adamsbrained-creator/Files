package ix.app.files.ui.home

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Arrangement
import ix.app.files.R
import ix.app.files.data.ArchiveFormat
import ix.app.files.data.Checksums
import ix.app.files.data.FileOps
import ix.app.files.data.JobControl
import ix.app.files.data.JobStopped
import ix.app.files.data.RenameRule
import ix.app.files.data.TextFiles
import ix.app.files.data.VaultNames
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.OpenMime
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.format.FormatStyle


private enum class SelectionDialog { None, Rename, RenameMany, Delete, Details }

/**
 * Shown while anything is selected: a bar on top with the count, and a floating bar of actions
 * at the bottom. Back (or the X) leaves selection mode.
 */
@Composable
fun SelectionOverlay(
    paths: Set<String>,
    allFavorite: Boolean,
    inPrivate: Boolean,
    /** Float the actions as round and pill buttons, instead of one rounded bar. */
    pills: Boolean = false,
    /** One folder is selected, so it can be put on Home. */
    canPinHome: Boolean,
    /** That folder is on Home already, so the action takes it off. */
    pinnedHome: Boolean,
    onPinHome: () -> Unit,
    /** At least one selected file is a video, song or picture a TV could show. */
    canCast: Boolean,
    onCast: () -> Unit,
    onClear: () -> Unit,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onShare: () -> Unit,
    onFavorite: () -> Unit,
    onMoveToPrivate: () -> Unit,
    onCompress: () -> Unit,
    onExtract: () -> Unit,
    onRename: (String) -> Unit,
    onRenameMany: (RenameRule) -> Unit,
    onOpenAsText: (String) -> Unit,
    /** One file is selected: pick the app to open it with. */
    onOpenWith: (String) -> Unit,
    /** One web page (.html, .svg) is selected: show it in a browser. */
    onOpenInBrowser: (String) -> Unit,
    onDelete: () -> Unit,
) {
    BackHandler(onBack = onClear)
    var dialog by remember { mutableStateOf(SelectionDialog.None) }
    var moreOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val count = paths.size
    val countLabel = context.resources.getQuantityString(
        R.plurals.selected_count,
        count,
        NumberFormat.getIntegerInstance().format(count),
    )
    val clearDescription = stringResource(R.string.selection_clear)

    // The menu behind the "more" button. The button itself differs between the two looks, so it is passed in.
    val moreBox: @Composable (anchor: @Composable (open: () -> Unit) -> Unit) -> Unit = { anchor ->
        Box {
            anchor { moreOpen = true }
            DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                // One file: choose the app to open it with. Web pages can also go straight to a browser.
                val single = if (count == 1) File(paths.first()) else null
                if (single != null && single.isFile) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_open_with)) },
                        leadingIcon = { PathIcon(Glyphs.OpenWith, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onOpenWith(single.path)
                        },
                    )
                    if (OpenMime.isWebPage(VaultNames.plainName(single))) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_open_in_browser)) },
                            leadingIcon = { PathIcon(Glyphs.Globe, tint = IxColors.TextPrimary, size = 18.dp) },
                            onClick = {
                                moreOpen = false
                                onOpenInBrowser(single.path)
                            },
                        )
                    }
                }
                // Files in Private are locked, so they are never shown on another device.
                if (canCast && !inPrivate) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_cast)) },
                        leadingIcon = { PathIcon(Glyphs.Cast, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onCast()
                        },
                    )
                }
                // Favorites and Private are for things outside Private. Inside it, neither makes sense.
                if (!inPrivate) {
                    DropdownMenuItem(
                        text = {
                            Text(
                                stringResource(
                                    if (allFavorite) R.string.action_unfavorite else R.string.action_favorite,
                                ),
                            )
                        },
                        leadingIcon = { PathIcon(Glyphs.Star, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onFavorite()
                        },
                    )
                    if (canPinHome) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    stringResource(
                                        if (pinnedHome) R.string.action_unpin_home else R.string.action_pin_home,
                                    ),
                                )
                            },
                            leadingIcon = { PathIcon(Glyphs.Home, tint = IxColors.TextPrimary, size = 18.dp) },
                            onClick = {
                                moreOpen = false
                                onPinHome()
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_private)) },
                        leadingIcon = { PathIcon(Glyphs.Lock, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onMoveToPrivate()
                        },
                    )
                }
                // Any single file can be read as text, whatever it is called. Names the reader opens by itself
                // are left out, because tapping them already does it.
                val onlyFile = if (count == 1) File(paths.first()) else null
                if (onlyFile != null && onlyFile.isFile &&
                    !TextFiles.isTextName(VaultNames.plainName(onlyFile))
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_open_as_text)) },
                        leadingIcon = { PathIcon(Glyphs.Docs, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onOpenAsText(onlyFile.path)
                        },
                    )
                }
                if (count >= 1) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_rename)) },
                        leadingIcon = { PathIcon(Glyphs.Edit, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            dialog = if (count == 1) SelectionDialog.Rename else SelectionDialog.RenameMany
                        },
                    )
                }
                // Zipping and extracting read files as they are stored, so they are left out inside Private.
                if (!inPrivate) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_compress)) },
                        leadingIcon = { PathIcon(Glyphs.Archive, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onCompress()
                        },
                    )
                }
                if (!inPrivate && paths.all { ArchiveFormat.of(File(it).name) != null }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_extract)) },
                        leadingIcon = { PathIcon(Glyphs.Downloads, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onExtract()
                        },
                    )
                }
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.action_details)) },
                    leadingIcon = { PathIcon(Glyphs.Info, tint = IxColors.TextPrimary, size = 18.dp) },
                    onClick = {
                        moreOpen = false
                        dialog = SelectionDialog.Details
                    },
                )
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        // Top bar. It covers the screen's own header, so it also swallows taps.
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .background(IxColors.Background)
                .pointerInput(Unit) { detectTapGestures { } }
                .statusBarsPadding()
                .height(64.dp)
                .padding(start = 8.dp, end = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onClear)
                    .semantics { contentDescription = clearDescription },
                contentAlignment = Alignment.Center,
            ) {
                PathIcon(Glyphs.Close, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 2f)
            }
            Text(
                text = countLabel,
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 6.dp),
            )
            Text(
                text = stringResource(R.string.select_all),
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onSelectAll)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            )
        }

        // Floating action bar
        if (pills) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(start = 18.dp, end = 18.dp, bottom = 14.dp)
                    .pointerInput(Unit) { detectTapGestures { } },
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    Modifier.padding(start = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    PathIcon(Glyphs.Docs, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 1.8f)
                    Text(
                        text = NumberFormat.getIntegerInstance().format(count),
                        color = IxColors.TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                val deleteDescription = stringResource(R.string.action_delete)
                Box(
                    Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(IxColors.Danger.copy(alpha = 0.28f))
                        .clickable(role = Role.Button) { dialog = SelectionDialog.Delete }
                        .semantics { contentDescription = deleteDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.Trash, tint = IxColors.Danger, size = 24.dp, strokeWidth = 1.8f)
                }
                PillButton(
                    label = stringResource(R.string.action_move),
                    background = IxColors.Chip,
                    content = IxColors.TextPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onMove,
                )
                PillButton(
                    label = stringResource(R.string.action_share),
                    background = IxColors.TextPrimary,
                    content = IxColors.Background,
                    modifier = Modifier.weight(1f),
                    onClick = onShare,
                )
                moreBox { open ->
                    val moreDescription = stringResource(R.string.action_more)
                    Box(
                        Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(IxColors.Chip)
                            .clickable(role = Role.Button, onClick = open)
                            .semantics { contentDescription = moreDescription },
                        contentAlignment = Alignment.Center,
                    ) {
                        PathIcon(Glyphs.More, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
                    }
                }
            }
        } else {
            val barShape = RoundedCornerShape(30.dp)
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 14.dp)
                    .clip(barShape)
                    .background(IxColors.Sheet)
                    .border(1.dp, IxColors.SheetBorder, barShape)
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            ) {
                ActionButton(Glyphs.Copy, stringResource(R.string.action_copy), onClick = onCopy)
                ActionButton(Glyphs.Move, stringResource(R.string.action_move), onClick = onMove)
                ActionButton(Glyphs.Share, stringResource(R.string.action_share), onClick = onShare)
                ActionButton(
                    Glyphs.Trash,
                    stringResource(R.string.action_delete),
                    tint = IxColors.Danger,
                ) { dialog = SelectionDialog.Delete }

                moreBox { open -> ActionButton(Glyphs.More, stringResource(R.string.action_more)) { open() } }
            }
        }
    }

    when (dialog) {
        SelectionDialog.None -> Unit

        SelectionDialog.Rename -> NameDialog(
            title = stringResource(R.string.action_rename),
            initialName = VaultNames.plainName(File(paths.first())),
            confirmLabel = stringResource(R.string.rename_confirm),
            onConfirm = { name ->
                dialog = SelectionDialog.None
                onRename(name)
            },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.RenameMany -> BatchRenameDialog(
            files = remember(paths) { paths.map { File(it) } },
            onConfirm = { rule ->
                dialog = SelectionDialog.None
                onRenameMany(rule)
            },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.Details -> DetailsDialog(
            paths = remember(paths) { paths.toList() },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = SelectionDialog.None },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.action_delete)) },
            text = {
                // One item is named, so it is clear what is about to go. A folder says it takes its contents too.
                val only = if (count == 1) File(paths.first()) else null
                val onlyName = only?.let { VaultNames.plainName(it) }
                // Anything outside Private can be undone for a few seconds. Private files go for good.
                Text(
                    when {
                        only == null -> context.resources.getQuantityString(
                            if (inPrivate) R.plurals.delete_message else R.plurals.delete_ask,
                            count,
                            NumberFormat.getIntegerInstance().format(count),
                        )
                        only.isDirectory -> context.getString(
                            if (inPrivate) R.string.delete_message_folder else R.string.delete_ask_folder,
                            onlyName,
                        )
                        else -> context.getString(
                            if (inPrivate) R.string.delete_message_file else R.string.delete_ask_file,
                            onlyName,
                        )
                    },
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        dialog = SelectionDialog.None
                        onDelete()
                    },
                ) { Text(stringResource(R.string.action_delete), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { dialog = SelectionDialog.None }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ActionButton(
    glyph: List<String>,
    label: String,
    tint: Color = IxColors.TextPrimary,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .width(64.dp)
            .height(54.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        PathIcon(glyph, tint = tint, size = 22.dp, strokeWidth = 1.9f)
        Text(
            text = label,
            color = tint,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}

/** Name, place, size and date of the selection. A folder's size is added up in the background. */
@Composable
private fun DetailsDialog(paths: List<String>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val details by produceState<FileOps.Details?>(null, paths) { value = FileOps.measure(paths) }
    val number = NumberFormat.getIntegerInstance()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(stringResource(R.string.action_details)) },
        text = {
            val d = details
            Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                if (d == null) {
                    Text(stringResource(R.string.calculating))
                } else {
                    val filesLabel = context.resources.getQuantityString(
                        R.plurals.details_files,
                        d.files,
                        number.format(d.files),
                    )
                    val sizeLabel = if (d.isFolder || d.count > 1) {
                        stringResource(R.string.file_meta, formatFileSize(d.bytes), filesLabel)
                    } else {
                        formatFileSize(d.bytes)
                    }
                    if (d.count == 1) {
                        DetailLine(stringResource(R.string.detail_name), d.name)
                        DetailLine(stringResource(R.string.detail_location), d.location)
                        DetailLine(stringResource(R.string.detail_size), sizeLabel)
                        DetailLine(
                            stringResource(R.string.detail_modified),
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
                                .format(Instant.ofEpochMilli(d.modifiedMillis).atZone(ZoneId.systemDefault())),
                        )
                        if (!d.isFolder) ChecksumBlock(paths.first())
                    } else {
                        DetailLine(stringResource(R.string.detail_selected), itemsLabel(context, d.count))
                        DetailLine(stringResource(R.string.detail_size), sizeLabel)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close), color = IxColors.TextPrimary) }
        },
    )
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column {
        Text(text = label, color = IxColors.TextSecondary, fontSize = 12.sp)
        Text(text = value, color = IxColors.TextPrimary, fontSize = 15.sp)
    }
}

/**
 * MD5, SHA-1 and SHA-256 of one file. Nothing is read until "Calculate" is tapped, because a big file takes a
 * while. Leaving the dialog stops the reading. Tapping a value copies it.
 */
@Composable
private fun ChecksumBlock(path: String) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var started by remember(path) { mutableStateOf(false) }
    var percent by remember(path) { mutableStateOf(0) }
    var result by remember(path) { mutableStateOf<Checksums?>(null) }
    var failed by remember(path) { mutableStateOf(false) }
    val control = remember(path) { JobControl() }
    DisposableEffect(path) { onDispose { control.cancel() } }

    LaunchedEffect(started, path) {
        if (!started) return@LaunchedEffect
        val total = File(path).length()
        control.totalBytes = total
        val poll = launch {
            while (true) {
                delay(200)
                percent = if (total > 0L) ((control.done * 100L) / total).toInt().coerceIn(0, 99) else 0
            }
        }
        try {
            result = withContext(Dispatchers.IO) { Checksums.of(File(path), control) }
        } catch (e: JobStopped) {
            // The dialog was closed.
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failed = true
        } finally {
            poll.cancel()
        }
    }

    Column {
        Text(text = stringResource(R.string.detail_checksums), color = IxColors.TextSecondary, fontSize = 12.sp)
        val done = result
        when {
            failed -> Text(
                text = stringResource(R.string.checksum_failed),
                color = IxColors.Danger,
                fontSize = 14.sp,
            )

            done != null -> {
                val copied = stringResource(R.string.checksum_copied)
                for ((label, value) in listOf("MD5" to done.md5, "SHA-1" to done.sha1, "SHA-256" to done.sha256)) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                clipboard.setText(AnnotatedString(value))
                                Toast.makeText(context, copied, Toast.LENGTH_SHORT).show()
                            }
                            .padding(top = 6.dp),
                    ) {
                        Text(text = label, color = IxColors.TextSecondary, fontSize = 11.sp)
                        Text(
                            text = value,
                            color = IxColors.TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                }
                Text(
                    text = stringResource(R.string.checksum_tap_hint),
                    color = IxColors.TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }

            started -> Text(
                text = context.getString(R.string.checksum_progress, percent.toString()),
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
            )

            else -> Box(
                Modifier
                    .padding(top = 6.dp)
                    .height(36.dp)
                    .clip(CircleShape)
                    .background(IxColors.Button)
                    .clickable(role = Role.Button) { started = true }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(R.string.checksum_calculate),
                    color = IxColors.TextPrimary,
                    fontSize = 13.sp,
                    maxLines = 1,
                )
            }
        }
    }
}

/** A wide rounded button for the floating pill bar. */
@Composable
private fun PillButton(
    label: String,
    background: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .height(60.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, color = content, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}
