package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.DisableSelection
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.TextFiles
import ix.app.files.data.TextMatch
import ix.app.files.data.TextProblem
import ix.app.files.data.TextRow
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.NumberFormat

/**
 * Reads a text file, and edits it. Reading shows line numbers and lets you select and copy; Edit opens the
 * same text in a box you can type in. Back from a box with unsaved typing asks what to do with it.
 */
@Composable
fun TextScreen(
    doc: TextDoc,
    initialDraft: () -> String,
    onClose: () -> Unit,
    onEdit: () -> Unit,
    onEdited: (String) -> Unit,
    onSave: (Boolean) -> Unit,
    onDiscard: () -> Unit,
    onStopEditing: () -> Unit,
    onOpenWith: () -> Unit,
    /** Set for a web page (.html, .svg): shows it in a browser. Null for everything else. */
    onOpenInBrowser: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var askLeave by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var wrap by rememberSaveable { mutableStateOf(true) }
    var fontSize by rememberSaveable { mutableStateOf(14) }
    var findOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val findDescription = stringResource(R.string.text_find)
    val backDescription = stringResource(R.string.back_description)
    val styleDescription = stringResource(R.string.text_style_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    val reading = !doc.loading && doc.problem == null && !doc.editing

    // The rows are cut once here, because both the reader and the search need them.
    val rows by produceState<List<TextRow>?>(null, doc.text, reading) {
        value = if (reading) withContext(Dispatchers.Default) { TextFiles.rows(doc.text) } else null
    }
    // Hits are looked for a moment after typing stops, so typing stays smooth in a big file.
    val matches by produceState(emptyList<TextMatch>(), rows, query, findOpen) {
        val all = rows
        if (!findOpen || query.isEmpty() || all == null) {
            value = emptyList()
        } else {
            delay(150)
            value = withContext(Dispatchers.Default) { TextFiles.findAll(all, query) }
        }
    }
    // Starts again at the first hit whenever the list of hits changes.
    var current by remember(matches) { mutableStateOf(0) }

    // The text being typed lives here, so the find bar can move the cursor and change the text.
    var editValue by remember(doc.session) { mutableStateOf(TextFieldValue(initialDraft())) }
    var replacement by rememberSaveable { mutableStateOf("") }
    var notice by remember(query, replacement) { mutableStateOf<String?>(null) }
    val editText = editValue.text
    val cursor = editValue.selection.min
    // A file that can be edited is at most 512 KB, so while typing the search can run on the spot.
    val editMatches = remember(editText, query, findOpen, doc.editing) {
        if (doc.editing && findOpen && query.isNotEmpty()) TextFiles.findOffsets(editText, query) else emptyList()
    }
    val onEditMatch = editMatches.binarySearch(cursor) >= 0
    val editIndex = remember(editMatches, cursor) {
        editMatches.indexOfFirst { it >= cursor }.let { if (it < 0) 0 else it }
    }

    // Next and previous. While typing, they go by where the cursor is, so typing never gets pulled elsewhere.
    val step: (Int) -> Unit = { delta ->
        if (doc.editing) {
            if (editMatches.isNotEmpty()) {
                val target = if (delta > 0) {
                    editMatches.firstOrNull { if (onEditMatch) it > cursor else it >= cursor } ?: editMatches.first()
                } else {
                    editMatches.lastOrNull { it < cursor } ?: editMatches.last()
                }
                editValue = TextFieldValue(editText, TextRange(target))
            }
        } else if (matches.isNotEmpty()) {
            current = (current + delta + matches.size) % matches.size
        }
    }
    // Replace: the first press goes to a hit, the next one swaps it and moves on to the following hit.
    val replaceCurrent: () -> Unit = {
        if (editMatches.isNotEmpty()) {
            if (!onEditMatch) {
                step(1)
            } else {
                val text = editText.substring(0, cursor) + replacement + editText.substring(cursor + query.length)
                val after = cursor + replacement.length
                val next = TextFiles.findOffsets(text, query).firstOrNull { it >= after }
                editValue = TextFieldValue(text, TextRange(next ?: after))
                onEdited(text)
            }
        }
    }
    val replaceEverywhere: () -> Unit = {
        if (query.isNotEmpty()) {
            val done = TextFiles.replaceAll(editText, query, replacement)
            if (done.count > 0) {
                editValue = TextFieldValue(done.text, TextRange(minOf(cursor, done.text.length)))
                onEdited(done.text)
            }
            notice = context.getString(R.string.text_replaced, NumberFormat.getIntegerInstance().format(done.count))
        }
    }

    val goBack: () -> Unit = {
        when {
            findOpen -> findOpen = false
            doc.editing && doc.dirty -> askLeave = true
            doc.editing -> onStopEditing()
            else -> onClose()
        }
    }
    BackHandler(onBack = goBack)

    val subtitle = when {
        doc.loading || doc.problem != null -> ""
        doc.editing -> stringResource(if (doc.dirty) R.string.text_editing_unsaved else R.string.text_editing)
        else -> stringResource(
            R.string.text_info,
            context.resources.getQuantityString(
                R.plurals.text_lines,
                TextFiles.lineCount(doc.text),
                NumberFormat.getIntegerInstance().format(TextFiles.lineCount(doc.text)),
            ),
            formatFileSize(doc.sizeBytes),
        )
    }

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = goBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = doc.name,
                        color = IxColors.TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(text = subtitle, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
                }
                if (reading || doc.editing) {
                    if (doc.editing || doc.text.isNotEmpty()) {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(IxColors.Button)
                                .clickable(role = Role.Button) { findOpen = !findOpen }
                                .semantics { contentDescription = findDescription },
                            contentAlignment = Alignment.Center,
                        ) {
                            PathIcon(Glyphs.Search, tint = IxColors.TextPrimary, size = 20.dp)
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    Box {
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(IxColors.Button)
                                .clickable(role = Role.Button) { menuOpen = true }
                                .semantics { contentDescription = styleDescription },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("Aa", color = IxColors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            // The box you type in always wraps, so this only matters while reading.
                            if (!doc.editing) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.text_wrap)) },
                                    leadingIcon = {
                                        if (wrap) {
                                            PathIcon(Glyphs.Check, tint = IxColors.Accent, size = 18.dp)
                                        } else {
                                            Spacer(Modifier.size(18.dp))
                                        }
                                    },
                                    onClick = { wrap = !wrap },
                                )
                            }
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.text_smaller)) },
                                onClick = { fontSize = (fontSize - 2).coerceAtLeast(10) },
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.text_larger)) },
                                onClick = { fontSize = (fontSize + 2).coerceAtMost(28) },
                            )
                            if (!doc.editing && onOpenInBrowser != null) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.action_open_in_browser)) },
                                    onClick = {
                                        menuOpen = false
                                        onOpenInBrowser()
                                    },
                                )
                            }
                            if (!doc.editing) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.zip_open_with)) },
                                    onClick = {
                                        menuOpen = false
                                        onOpenWith()
                                    },
                                )
                            }
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                }
                if (doc.editing) {
                    HeaderPill(
                        label = stringResource(R.string.text_save),
                        enabled = doc.dirty && !doc.saving,
                        onClick = { onSave(false) },
                    )
                } else if (doc.canEdit) {
                    HeaderPill(label = stringResource(R.string.text_edit), enabled = true, onClick = onEdit)
                }
            }

            val reason = doc.readOnlyReason
            if (reason != null && !doc.loading && !doc.editing) {
                Text(
                    text = stringResource(reason),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 6.dp),
                )
            }

            if (findOpen && (reading || doc.editing)) {
                val shownCount = if (doc.editing) editMatches.size else matches.size
                FindBar(
                    query = query,
                    onQuery = { query = it },
                    count = shownCount,
                    capped = shownCount >= TextFiles.MAX_MATCHES,
                    current = if (doc.editing) editIndex else current,
                    notice = notice,
                    editing = doc.editing,
                    replacement = replacement,
                    onReplacement = { replacement = it },
                    onReplace = replaceCurrent,
                    onReplaceAll = replaceEverywhere,
                    onPrevious = { step(-1) },
                    onNext = { step(1) },
                    onClose = { findOpen = false },
                )
            }

            when {
                doc.loading -> Message(stringResource(R.string.text_loading))

                doc.problem != null -> ProblemView(doc.problem, onOpenWith)

                doc.editing -> Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding(),
                ) {
                    val hitColor = IxColors.Accent.copy(alpha = 0.30f)
                    val currentColor = IxColors.Accent.copy(alpha = 0.80f)
                    // Hits stay highlighted while typing, and the one the cursor is on stands out.
                    val transformation = remember(editMatches, query, cursor, findOpen) {
                        if (editMatches.isEmpty() || !findOpen) {
                            VisualTransformation.None
                        } else {
                            VisualTransformation { text ->
                                TransformedText(
                                    highlightedEdit(text, editMatches, query.length, cursor, hitColor, currentColor),
                                    OffsetMapping.Identity,
                                )
                            }
                        }
                    }
                    TextEditor(
                        session = doc.session,
                        value = editValue,
                        onValueChange = { next ->
                            val changed = next.text != editValue.text
                            editValue = next
                            if (changed) onEdited(next.text)
                        },
                        fontSize = fontSize,
                        transformation = transformation,
                    )
                }

                doc.text.isEmpty() -> Message(stringResource(R.string.text_empty))

                else -> Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .imePadding(),
                ) {
                    val list = rows
                    if (list == null) {
                        Message(stringResource(R.string.text_loading))
                    } else {
                        TextViewer(
                            rows = list,
                            wrap = wrap,
                            fontSize = fontSize,
                            bottomInset = bottomInset,
                            matches = if (findOpen) matches else emptyList(),
                            current = current,
                        )
                    }
                }
            }
        }
    }

    if (askLeave) {
        AlertDialog(
            onDismissRequest = { askLeave = false },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.text_unsaved_title)) },
            text = { Text(stringResource(R.string.text_unsaved_message, doc.name)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        askLeave = false
                        onSave(true)
                    },
                ) { Text(stringResource(R.string.text_save), color = IxColors.TextPrimary) }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        askLeave = false
                        onDiscard()
                    },
                ) { Text(stringResource(R.string.text_discard), color = IxColors.Danger) }
            },
        )
    }
}

@Composable
private fun HeaderPill(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(IxColors.Button)
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = IxColors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = IxColors.TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ProblemView(problem: TextProblem, onOpenWith: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(
                when (problem) {
                    TextProblem.TooLarge -> R.string.text_too_large
                    TextProblem.Binary -> R.string.text_binary
                    TextProblem.Unreadable -> R.string.text_unreadable
                },
            ),
            color = IxColors.TextSecondary,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        HeaderPill(label = stringResource(R.string.zip_open_with), enabled = true, onClick = onOpenWith)
    }
}

@Composable
private fun TextViewer(
    rows: List<TextRow>,
    wrap: Boolean,
    fontSize: Int,
    bottomInset: Dp,
    matches: List<TextMatch>,
    current: Int,
) {
    val digits = remember(rows) { (rows.lastOrNull { it.number > 0 }?.number ?: 1).toString().length }
    val style = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontSize = fontSize.sp,
        lineHeight = (fontSize * 1.45f).sp,
        color = IxColors.TextPrimary,
    )
    val numberStyle = style.copy(color = IxColors.TextSecondary, textAlign = TextAlign.End)
    val gutter = (digits * fontSize * 0.62f + 6f).dp
    val sideScroll = rememberScrollState()
    val listState: LazyListState = rememberLazyListState()
    val hitColor = IxColors.Accent.copy(alpha = 0.30f)
    val currentColor = IxColors.Accent.copy(alpha = 0.80f)

    // The hits of each row, with their place in the whole list, so the current one can stand out.
    val byRow = remember(matches) { matches.withIndex().groupBy { it.value.row } }

    // Moving to a hit scrolls its row into view, a little below the top edge.
    LaunchedEffect(matches, current) {
        val hit = matches.getOrNull(current)
        if (hit != null) listState.animateScrollToItem(hit.row, scrollOffset = -160)
    }

    SelectionContainer {
        LazyColumn(
            state = listState,
            modifier = (if (wrap) Modifier else Modifier.horizontalScroll(sideScroll)).fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = bottomInset + 32.dp),
        ) {
            items(rows.size) { index ->
                val row = rows[index]
                val hits = byRow[index]
                Row {
                    // Line numbers are not part of what you copy.
                    DisableSelection {
                        Text(
                            text = if (row.number > 0) row.number.toString() else "",
                            style = numberStyle,
                            softWrap = false,
                            modifier = Modifier.width(gutter),
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (hits == null) AnnotatedString(row.text) else highlighted(row.text, hits, current, hitColor, currentColor),
                        style = style,
                        softWrap = wrap,
                        modifier = if (wrap) Modifier.weight(1f) else Modifier,
                    )
                }
            }
        }
    }
}

private fun highlighted(
    text: String,
    hits: List<IndexedValue<TextMatch>>,
    current: Int,
    hitColor: Color,
    currentColor: Color,
): AnnotatedString = buildAnnotatedString {
    append(text)
    for (hit in hits) {
        val end = minOf(hit.value.end, text.length)
        if (hit.value.start < end) {
            addStyle(SpanStyle(background = if (hit.index == current) currentColor else hitColor), hit.value.start, end)
        }
    }
}

/** Colors the hits in the text being typed. [starts] are where they begin, [length] how long each is. */
private fun highlightedEdit(
    text: AnnotatedString,
    starts: List<Int>,
    length: Int,
    cursor: Int,
    hitColor: Color,
    currentColor: Color,
): AnnotatedString = buildAnnotatedString {
    append(text)
    for (start in starts) {
        val end = minOf(start + length, text.length)
        if (start < end) addStyle(SpanStyle(background = if (start == cursor) currentColor else hitColor), start, end)
    }
}

/**
 * The search box under the header: what to find, which hit this is, and buttons to step through them.
 * While editing there is a second row to type what to put instead, with Replace and All.
 */
@Composable
private fun FindBar(
    query: String,
    onQuery: (String) -> Unit,
    count: Int,
    capped: Boolean,
    current: Int,
    notice: String?,
    editing: Boolean,
    replacement: String,
    onReplacement: (String) -> Unit,
    onReplace: () -> Unit,
    onReplaceAll: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit,
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (e: IllegalStateException) {
            // Not on screen yet. Tapping the box works just as well.
        }
    }
    val number = NumberFormat.getIntegerInstance()
    val previousDescription = stringResource(R.string.text_find_previous)
    val nextDescription = stringResource(R.string.text_find_next)
    val closeDescription = stringResource(R.string.text_find_close)
    val fieldStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 15.sp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(IxColors.Field)
                .padding(start = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(stringResource(R.string.text_find_hint), color = IxColors.TextSecondary, fontSize = 15.sp)
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQuery,
                    singleLine = true,
                    textStyle = fieldStyle,
                    cursorBrush = SolidColor(IxColors.Accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { onNext() }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focus),
                )
            }
            if (query.isNotEmpty()) {
                Text(
                    text = when {
                        notice != null -> notice
                        count == 0 -> stringResource(R.string.text_find_none)
                        else -> stringResource(
                            R.string.text_find_position,
                            number.format(current + 1),
                            number.format(count) + if (capped) "+" else "",
                        )
                    },
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                )
            }
            BarButton(Glyphs.ArrowUp, previousDescription, onPrevious)
            BarButton(Glyphs.ArrowDown, nextDescription, onNext)
            BarButton(Glyphs.Close, closeDescription, onClose)
        }
        if (editing) {
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(IxColors.Field)
                    .padding(start = 16.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) {
                    if (replacement.isEmpty()) {
                        Text(stringResource(R.string.text_replace_hint), color = IxColors.TextSecondary, fontSize = 15.sp)
                    }
                    BasicTextField(
                        value = replacement,
                        onValueChange = onReplacement,
                        singleLine = true,
                        textStyle = fieldStyle,
                        cursorBrush = SolidColor(IxColors.Accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                SmallPill(stringResource(R.string.text_replace), enabled = count > 0, onClick = onReplace)
                Spacer(Modifier.width(6.dp))
                SmallPill(stringResource(R.string.text_replace_all), enabled = query.isNotEmpty(), onClick = onReplaceAll)
            }
        }
    }
}

@Composable
private fun SmallPill(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(36.dp)
            .clip(CircleShape)
            .background(IxColors.Button)
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = IxColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BarButton(glyph: List<String>, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = IxColors.TextPrimary, size = 18.dp)
    }
}

@Composable
private fun TextEditor(
    session: Int,
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    fontSize: Int,
    transformation: VisualTransformation,
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(session) {
        try {
            focus.requestFocus()
        } catch (e: IllegalStateException) {
            // The box was not on screen yet. Tapping it works just as well.
        }
    }
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        textStyle = TextStyle(
            fontFamily = FontFamily.Monospace,
            fontSize = fontSize.sp,
            lineHeight = (fontSize * 1.45f).sp,
            color = IxColors.TextPrimary,
        ),
        cursorBrush = SolidColor(IxColors.Accent),
        visualTransformation = transformation,
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .focusRequester(focus),
    )
}
