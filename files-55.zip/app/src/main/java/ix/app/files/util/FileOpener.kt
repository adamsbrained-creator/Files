package ix.app.files.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import ix.app.files.R
import java.io.File

/** Opens a file in whichever app the user has for it. */
fun openFile(context: Context, path: String) {
    val file = File(path)
    try {
        context.startActivity(viewIntent(context, file))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    } catch (e: IllegalArgumentException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    }
}

/**
 * "Open with": the system list of every app that can open this file, so the one to use is picked each time
 * (a text editor, a browser, a viewer), instead of whichever app is the default.
 */
fun openFileWith(context: Context, path: String) {
    val file = File(path)
    try {
        val chooser = Intent.createChooser(viewIntent(context, file), context.getString(R.string.action_open_with))
        context.startActivity(chooser)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    } catch (e: IllegalArgumentException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    }
}

/**
 * Shows a web page (an .html file, or an .svg) in a browser. Only browsers are offered, not text editors.
 * With one browser it opens straight away, with several the system asks which one. Without any, it falls back to
 * the full "Open with" list.
 */
fun openInBrowser(context: Context, path: String) {
    val file = File(path)
    try {
        val view = viewIntent(context, file)
        val pm = context.packageManager
        // Any app that takes a web address like https://example.com is a browser.
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE)
        val targets = pm.queryIntentActivities(probe, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName }
            .distinct()
            .map { Intent(view).setPackage(it) }
            .filter { pm.resolveActivity(it, 0) != null }
        when (targets.size) {
            0 -> openFileWith(context, path)
            1 -> context.startActivity(targets[0])
            else -> {
                val chooser = Intent.createChooser(targets[0], context.getString(R.string.action_open_in_browser))
                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, targets.drop(1).toTypedArray())
                context.startActivity(chooser)
            }
        }
    } catch (e: ActivityNotFoundException) {
        openFileWith(context, path)
    } catch (e: IllegalArgumentException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    }
}

/** Sends files to another app through the system share sheet. Folders are skipped. */
fun shareFiles(context: Context, paths: List<String>) {
    val files = paths.map { File(it) }.filter { it.isFile }
    if (files.isEmpty()) {
        Toast.makeText(context, R.string.share_nothing, Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uris = files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it) }
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND)
                .putExtra(Intent.EXTRA_STREAM, uris[0])
                .setType(mimeOf(files[0]))
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE)
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(uris))
                .setType("*/*")
        }
        // The clip data is what carries the permission to read the files over to the other app.
        val clip = ClipData.newRawUri(null, uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, null))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    } catch (e: IllegalArgumentException) {
        Toast.makeText(context, R.string.open_no_app, Toast.LENGTH_SHORT).show()
    }
}

/** "Show this file": the file as a content address, with permission to read it handed over. */
private fun viewIntent(context: Context, file: File): Intent {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mimeOf(file))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    // The clip data carries the permission through the app chooser to the app that gets picked.
    intent.clipData = ClipData.newRawUri(null, uri)
    return intent
}

private fun mimeOf(file: File): String =
    OpenMime.of(
        file.name,
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()),
    )
