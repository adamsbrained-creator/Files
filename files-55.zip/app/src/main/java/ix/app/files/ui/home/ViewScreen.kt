package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

private val Orange = Color(0xFFFF6A2B)
private val Blue = Color(0xFF4C8DFF)
private val Violet = Color(0xFF8B6CFF)
private val Green = Color(0xFF4CC38A)

/**
 * The View page: how Home looks, how folders look, and how selecting looks, each as small preview cards.
 * Tapping a card changes the setting right away. The chosen card has an orange outline.
 */
@Composable
fun ViewScreen(
    grid: Boolean,
    timeline: Boolean,
    freeform: Boolean,
    selectionPills: Boolean,
    onFreeformChange: (Boolean) -> Unit,
    /** Sets the folder layout: (grid, timeline). List is (false, false), Grid (true, false), Timeline (any, true). */
    onFolderLayout: (grid: Boolean, timeline: Boolean) -> Unit,
    onSelectionPillsChange: (Boolean) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Text(
                    text = stringResource(R.string.view_title),
                    color = IxColors.TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 4.dp),
                )
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = bottomInset + 24.dp),
                verticalArrangement = Arrangement.spacedBy(26.dp),
            ) {
                Section(stringResource(R.string.view_home_layout)) {
                    PreviewCard(stringResource(R.string.menu_home_grid), !freeform, { onFreeformChange(false) }, Modifier.weight(1f)) {
                        TilesPreview()
                    }
                    PreviewCard(stringResource(R.string.menu_home_freeform), freeform, { onFreeformChange(true) }, Modifier.weight(1f)) {
                        FreeformPreview()
                    }
                }
                Section(stringResource(R.string.view_folder_layout)) {
                    PreviewCard(stringResource(R.string.menu_list), !grid && !timeline, { onFolderLayout(false, false) }, Modifier.weight(1f)) {
                        ListPreview()
                    }
                    PreviewCard(stringResource(R.string.menu_grid), grid && !timeline, { onFolderLayout(true, false) }, Modifier.weight(1f)) {
                        TilesPreview()
                    }
                    PreviewCard(stringResource(R.string.menu_timeline), timeline, { onFolderLayout(grid, true) }, Modifier.weight(1f)) {
                        TimelinePreview()
                    }
                }
                Section(stringResource(R.string.view_selecting)) {
                    PreviewCard(stringResource(R.string.menu_selection_bar), !selectionPills, { onSelectionPillsChange(false) }, Modifier.weight(1f)) {
                        BarPreview()
                    }
                    PreviewCard(stringResource(R.string.menu_selection_pills), selectionPills, { onSelectionPillsChange(true) }, Modifier.weight(1f)) {
                        PillsPreview()
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Column {
        Text(
            text = title.uppercase(),
            color = IxColors.TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.padding(start = 8.dp, bottom = 10.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

/** A tappable card with a small drawing of the look and its name under it. */
@Composable
private fun PreviewCard(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    preview: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .semantics { this.selected = selected },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(shape)
                .background(IxColors.Field)
                .border(if (selected) 2.dp else 1.dp, if (selected) Orange else IxColors.Outline, shape)
                .padding(10.dp),
            content = preview,
        )
        Text(
            text = label,
            color = if (selected) IxColors.TextPrimary else IxColors.TextSecondary,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
        )
    }
}

// ---- The small drawings. They are decoration; the label under each card names the choice. ----

@Composable
private fun Block(color: Color, width: Int = 24, height: Int = 18, modifier: Modifier = Modifier) {
    Box(modifier.size(width.dp, height.dp).clip(RoundedCornerShape(5.dp)).background(color))
}

@Composable
private fun BoxScope.TilesPreview() {
    Column(Modifier.align(Alignment.TopStart), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Block(Orange); Block(Blue) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Block(Violet); Block(Green) }
    }
}

@Composable
private fun BoxScope.FreeformPreview() {
    Block(Orange, modifier = Modifier.offset(2.dp, 2.dp).rotate(-5f))
    Block(Blue, modifier = Modifier.offset(40.dp, 30.dp).rotate(4f))
    Block(Green, modifier = Modifier.offset(8.dp, 56.dp).rotate(-2f))
}

@Composable
private fun BoxScope.ListPreview() {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(4) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Block(IxColors.TextSecondary, width = 10, height = 10)
                Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(IxColors.Chip))
            }
        }
    }
}

@Composable
private fun BoxScope.TimelinePreview() {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.width(30.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(IxColors.TextSecondary))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(3) { Block(IxColors.Chip, 18, 24) } }
        Box(Modifier.width(24.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(IxColors.TextSecondary))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeat(2) { Block(IxColors.Chip, 18, 24) } }
    }
}

@Composable
private fun BoxScope.BarPreview() {
    Box(
        Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .height(22.dp)
            .clip(RoundedCornerShape(11.dp))
            .background(IxColors.Chip),
    )
}

@Composable
private fun BoxScope.PillsPreview() {
    Row(
        Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(22.dp).clip(CircleShape).background(IxColors.Danger.copy(alpha = 0.5f)))
        Box(Modifier.weight(1f).height(22.dp).clip(CircleShape).background(IxColors.Chip))
        Box(Modifier.weight(1f).height(22.dp).clip(CircleShape).background(IxColors.TextPrimary))
    }
}
