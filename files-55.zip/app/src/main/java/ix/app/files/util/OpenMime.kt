package ix.app.files.util

import ix.app.files.data.TextFiles

/**
 * What kind of file another app is told it is getting. The right kind decides which apps are offered: a web page
 * is offered to browsers, plain text to text editors. Kept free of Android so it can be tested on its own.
 */
object OpenMime {

    /** Kinds the phone's own table gets wrong or does not know, and that matter for choosing an app. */
    private val fixed = mapOf(
        "html" to "text/html",
        "htm" to "text/html",
        "xhtml" to "application/xhtml+xml",
        "svg" to "image/svg+xml",
        "md" to "text/markdown",
        "markdown" to "text/markdown",
        "json" to "application/json",
        "csv" to "text/csv",
    )

    private val webPages = setOf("html", "htm", "xhtml", "svg")

    fun extensionOf(fileName: String): String {
        val dot = fileName.lastIndexOf('.')
        return if (dot >= 0 && dot < fileName.length - 1) fileName.substring(dot + 1).lowercase() else ""
    }

    /** True for files a browser shows as a page: HTML and SVG. */
    fun isWebPage(fileName: String): Boolean = extensionOf(fileName) in webPages

    /**
     * The kind for [fileName]. [systemGuess] is what the phone's own table says for the extension (null if it does
     * not know). Order: the fixed list, then the phone's guess, then plain text for anything the reader opens
     * as text, then "any kind".
     */
    fun of(fileName: String, systemGuess: String?): String =
        fixed[extensionOf(fileName)]
            ?: systemGuess?.takeIf { it.isNotBlank() }
            ?: if (TextFiles.isTextName(fileName)) "text/plain" else "*/*"
}
