package ix.app.files.ui.home

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ix.app.files.data.Category
import ix.app.files.data.FileItem
import ix.app.files.data.FileScanner
import ix.app.files.data.HomeTab
import ix.app.files.data.ScanData
import ix.app.files.data.SheetAnchor
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.data.StorageAccess
import ix.app.files.data.sortedBySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeState(
    val tab: HomeTab = HomeTab.All,
    val sort: SortSpec = SortSpec(),
    val sheet: SheetAnchor = SheetAnchor.Hidden,
    val hasAccess: Boolean = false,
    val scanning: Boolean = false,
    val scan: ScanData = ScanData.Empty,
    val counts: Map<Category, Int> = emptyMap(),
    val recent: List<FileItem> = emptyList(),
    val openCategory: Category? = null,
    val openFiles: List<FileItem> = emptyList(),
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val scanner = FileScanner()
    private var scanJob: Job? = null
    private var sortJob: Job? = null
    private var lastScanAt = 0L

    private val _state = MutableStateFlow(HomeState(hasAccess = StorageAccess.hasAccess(application)))
    val state: StateFlow<HomeState> = _state.asStateFlow()

    init {
        if (_state.value.hasAccess) startScan()
    }

    /** Call when the app comes back to the front, and after the user answers the permission prompt. */
    fun refreshAccess() {
        val granted = StorageAccess.hasAccess(getApplication())
        _state.update { it.copy(hasAccess = granted) }
        if (!granted) return
        val neverScanned = lastScanAt == 0L
        val stale = SystemClock.elapsedRealtime() - lastScanAt > RESCAN_AFTER_MS
        if (scanJob?.isActive != true && (neverScanned || stale)) startScan()
    }

    fun selectTab(tab: HomeTab) {
        _state.update { it.copy(tab = tab) }
    }

    fun setSheet(anchor: SheetAnchor) {
        _state.update { it.copy(sheet = anchor) }
    }

    fun selectSort(field: SortField) {
        _state.update {
            val spec = it.sort.select(field)
            it.copy(sort = spec, recent = it.scan.recent.sortedBySpec(spec))
        }
        sortOpenFiles()
    }

    fun openCategory(category: Category) {
        _state.update { it.copy(openCategory = category, openFiles = emptyList()) }
        sortOpenFiles()
    }

    fun closeCategory() {
        sortJob?.cancel()
        _state.update { it.copy(openCategory = null, openFiles = emptyList()) }
    }

    private fun startScan() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _state.update { it.copy(scanning = true) }
            try {
                scanner.scan(StorageAccess.root()) { data -> applyScan(data) }
                lastScanAt = SystemClock.elapsedRealtime()
            } finally {
                _state.update { it.copy(scanning = false) }
            }
        }
    }

    /** Called from the scanner's thread. Cheap on purpose: only the small recent list is sorted here. */
    private fun applyScan(data: ScanData) {
        _state.update {
            it.copy(
                scan = data,
                counts = data.byCategory.mapValues { entry -> entry.value.size },
                recent = data.recent.sortedBySpec(it.sort),
            )
        }
        sortOpenFiles()
    }

    /** Sorting a folder with tens of thousands of files happens off the main thread. */
    private fun sortOpenFiles() {
        val current = _state.value
        val category = current.openCategory ?: return
        val source = current.scan.byCategory[category].orEmpty()
        val spec = current.sort
        sortJob?.cancel()
        sortJob = viewModelScope.launch(Dispatchers.Default) {
            val sorted = source.sortedBySpec(spec)
            _state.update { if (it.openCategory == category) it.copy(openFiles = sorted) else it }
        }
    }

    private companion object {
        const val RESCAN_AFTER_MS = 60_000L
    }
}
