package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ix.app.files.R
import ix.app.files.data.HomeTab
import ix.app.files.data.SheetAnchor
import ix.app.files.data.StorageInfo
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.openFile
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Fling speed (px per second) that counts as a "flick" when letting go of the sheet. */
private const val SHEET_FLING_VELOCITY = 700f

@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val storage = remember { StorageInfo.read() }
    val requestAccess = rememberAccessRequester(onResult = viewModel::refreshAccess)

    // Coming back from the "All files access" settings page lands here.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshAccess() }

    Box(
        Modifier
            .fillMaxSize()
            .background(IxColors.Background),
    ) {
        HomeContent(
            state = state,
            viewModel = viewModel,
            storage = storage,
            onRequestAccess = requestAccess,
            onFileClick = { openFile(context, it.path) },
        )

        val open = state.openCategory
        if (open != null) {
            CategoryScreen(
                category = open,
                files = state.openFiles,
                count = state.counts[open] ?: 0,
                sort = state.sort,
                scanning = state.scanning,
                onBack = viewModel::closeCategory,
                onSortSelected = viewModel::selectSort,
                onFileClick = { openFile(context, it.path) },
            )
        }
    }
}

@Composable
private fun HomeContent(
    state: HomeState,
    viewModel: HomeViewModel,
    storage: StorageInfo,
    onRequestAccess: () -> Unit,
    onFileClick: (ix.app.files.data.FileItem) -> Unit,
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val anchor = state.sheet

    // Height of everything above the sheet. The half-open sheet starts right below it,
    // so the layout fits any screen size instead of relying on fixed offsets.
    var topContentPx by remember { mutableIntStateOf(0) }

    // Back closes the sheet step by step: open, then half-open, then hidden.
    BackHandler(enabled = anchor != SheetAnchor.Hidden && state.openCategory == null) {
        viewModel.setSheet(if (anchor == SheetAnchor.Expanded) SheetAnchor.Collapsed else SheetAnchor.Hidden)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // The sheet's top edge, in pixels from the top of the screen. Bigger means lower.
        val hiddenPx = with(density) { maxHeight.toPx() }
        val statusPx = WindowInsets.statusBars.getTop(density).toFloat()
        val expandedPx = statusPx + with(density) { 128.dp.toPx() }
        val collapsedPx = (topContentPx + with(density) { 16.dp.toPx() })
            .coerceAtMost(hiddenPx - with(density) { 280.dp.toPx() })
            .coerceAtLeast(expandedPx + 1f)

        val sheetTop = remember { Animatable(hiddenPx) }

        // Move the sheet whenever the wanted position changes (buttons, Back, or a finished drag).
        LaunchedEffect(anchor, hiddenPx, expandedPx, collapsedPx, topContentPx > 0) {
            val target = when (anchor) {
                SheetAnchor.Hidden -> hiddenPx
                SheetAnchor.Collapsed -> collapsedPx
                SheetAnchor.Expanded -> expandedPx
            }
            if (anchor == SheetAnchor.Hidden || topContentPx > 0) sheetTop.animateTo(target)
        }

        val dragState = rememberDraggableState { delta ->
            scope.launch { sheetTop.snapTo((sheetTop.value + delta).coerceIn(expandedPx, hiddenPx)) }
        }
        val dragModifier = Modifier.draggable(
            state = dragState,
            orientation = Orientation.Vertical,
            onDragStopped = { velocity ->
                val stops = listOf(
                    SheetAnchor.Expanded to expandedPx,
                    SheetAnchor.Collapsed to collapsedPx,
                    SheetAnchor.Hidden to hiddenPx,
                )
                val here = sheetTop.value
                val next = when {
                    // Flick up: the next stop above. Flick down: the next stop below.
                    velocity < -SHEET_FLING_VELOCITY -> stops.lastOrNull { it.second < here - 1f } ?: stops.first()
                    velocity > SHEET_FLING_VELOCITY -> stops.firstOrNull { it.second > here + 1f } ?: stops.last()
                    else -> stops.minBy { abs(it.second - here) }
                }
                viewModel.setSheet(next.first)
                sheetTop.animateTo(next.second)
            },
        )

        // Everything above the sheet
        Column(
            Modifier
                .fillMaxWidth()
                .onSizeChanged { topContentPx = it.height }
                .statusBarsPadding()
                .padding(top = 12.dp),
        ) {
            HomeHeader(storage)
            Spacer(Modifier.height(12.dp))
            SearchRow()
            Spacer(Modifier.height(6.dp))
            HomeTabs(selected = state.tab, onSelect = viewModel::selectTab)
            Spacer(Modifier.height(16.dp))

            when (state.tab) {
                HomeTab.All ->
                    if (state.hasAccess) {
                        CategoryGrid(
                            counts = state.counts,
                            scanning = state.scanning,
                            onCategoryClick = viewModel::openCategory,
                        )
                    } else {
                        AccessCard(onRequestAccess)
                    }

                HomeTab.Favorites -> EmptyNote(stringResource(R.string.favorites_empty))

                HomeTab.Private -> PrivateLocked()
            }
        }

        // While the sheet is hidden, a strip along the bottom edge listens for the swipe up.
        // It sits above the system gesture area and has a very faint handle as the only hint.
        if (anchor == SheetAnchor.Hidden) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(72.dp)
                    .then(dragModifier),
            ) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(IxColors.Handle.copy(alpha = 0.6f)),
                )
            }
        }

        // The sheet keeps its bottom on the screen edge and grows upward as its top edge moves.
        RecentSheet(
            files = state.recent,
            sort = state.sort,
            expanded = anchor == SheetAnchor.Expanded,
            onToggleExpanded = {
                viewModel.setSheet(
                    if (anchor == SheetAnchor.Expanded) SheetAnchor.Collapsed else SheetAnchor.Expanded,
                )
            },
            onSortSelected = viewModel::selectSort,
            onFileClick = onFileClick,
            dragModifier = dragModifier,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .layout { measurable, constraints ->
                    val height = (hiddenPx - sheetTop.value).roundToInt().coerceAtLeast(0)
                    val placeable = measurable.measure(
                        constraints.copy(minHeight = height, maxHeight = height),
                    )
                    layout(placeable.width, height) { placeable.place(0, 0) }
                },
        )
    }
}

/** Shown on the All tab until the user allows file access. */
@Composable
private fun AccessCard(onRequestAccess: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(IxColors.Field),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Folder, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        }
        Text(
            text = stringResource(R.string.access_title),
            color = IxColors.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
        )
        Text(
            text = stringResource(R.string.access_body),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Box(
            Modifier
                .height(48.dp)
                .clip(CircleShape)
                .background(IxColors.TextPrimary)
                .clickable(role = Role.Button, onClick = onRequestAccess)
                .padding(horizontal = 28.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.access_button),
                color = IxColors.Background,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
private fun EmptyNote(text: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}

@Composable
private fun PrivateLocked() {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(IxColors.Field),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Lock, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        }
        Text(
            text = stringResource(R.string.private_locked),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
        )
        Box(
            Modifier
                .height(44.dp)
                .clip(CircleShape)
                .border(1.dp, IxColors.Outline, CircleShape)
                .clickable(role = Role.Button) { /* Later round: biometric unlock */ }
                .padding(horizontal = 28.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.private_unlock),
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}
