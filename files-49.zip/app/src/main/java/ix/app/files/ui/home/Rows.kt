package ix.app.files.ui.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import ix.app.files.data.FolderItem
import ix.app.files.ui.components.FileIcon
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.data.Thumbnails
import ix.app.files.ui.components.Thumbnail
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import android.content.Context
import android.text.format.DateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

/** What is selected right now, and how to select or deselect one more item. */
@Immutable
class Selection(
    val paths: Set<String>,
    val toggle: (String) -> Unit,
    /** Selects all of these, or, when they are all selected already, deselects them. */
    val toggleMany: (List<String>) -> Unit = {},
) {
    val active: Boolean get() = paths.isNotEmpty()
}

/**
 * One file: preview or gray extension icon, name, "size · date".
 * Tap opens it (or selects it, once something is selected). Press and hold starts selecting.
 */
@Composable
fun FileRow(
    file: FileItem,
    selection: Selection,
    favorite: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    hint: String? = null,
) {
    ItemRow(
        path = file.path,
        title = file.name,
        subtitle = withHint(
            hint,
            stringResource(
                R.string.file_meta,
                formatFileSize(file.sizeBytes),
                modifiedLabel(file.modifiedMillis),
            ),
        ),
        favorite = favorite,
        selection = selection,
        onOpen = onOpen,
        modifier = modifier,
        leading = {
            if (Thumbnails.supports(file)) {
                Thumbnail(file, size = 36.dp) { FileIcon(file.extension) }
            } else {
                FileIcon(file.extension)
            }
        },
    )
}

/** One folder: small gray folder, name, "12 items · date". Tap to open it. */
@Composable
fun FolderRow(
    folder: FolderItem,
    selection: Selection,
    favorite: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    hint: String? = null,
) {
    val context = LocalContext.current
    ItemRow(
        path = folder.path,
        title = folder.name,
        subtitle = withHint(
            hint,
            stringResource(
                R.string.file_meta,
                itemsLabel(context, folder.childCount),
                modifiedLabel(folder.modifiedMillis),
            ),
        ),
        favorite = favorite,
        selection = selection,
        onOpen = onOpen,
        modifier = modifier,
        leading = { FolderIcon(emptyList(), Modifier.size(width = 34.dp, height = 28.dp)) },
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ItemRow(
    path: String,
    title: String,
    subtitle: String,
    favorite: Boolean,
    selection: Selection,
    onOpen: () -> Unit,
    modifier: Modifier,
    leading: @Composable () -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val selected = path in selection.paths

    Row(
        modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(if (selected) SelectBlue.copy(alpha = 0.18f) else Color.Transparent)
            .combinedClickable(
                role = Role.Button,
                onClick = { if (selection.active) selection.toggle(path) else onOpen() },
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    selection.toggle(path)
                },
            )
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.width(36.dp), contentAlignment = Alignment.Center) { leading() }
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        if (selection.active) {
            SelectMark(selected)
        } else if (favorite) {
            PathIcon(Glyphs.Star, tint = IxColors.Accent, size = 16.dp, strokeWidth = 2f)
        }
    }
}

/** Search results show where a thing lives: "DCIM/Camera · 1.6 MB · Today, 09:12". */
private fun withHint(hint: String?, subtitle: String): String = if (hint.isNullOrEmpty()) subtitle else "$hint · $subtitle"

/** The blue used for everything selected: the wash behind a row or tile and its check. */
internal val SelectBlue = Color(0xFF1F6BFF)

/** The check on the right of a row while selecting: an empty circle, then a blue square with a tick. */
@Composable
internal fun SelectMark(selected: Boolean) {
    Box(
        Modifier
            .size(22.dp)
            .clip(if (selected) RoundedCornerShape(7.dp) else CircleShape)
            .then(
                if (selected) {
                    Modifier.background(SelectBlue)
                } else {
                    Modifier.border(1.5.dp, IxColors.TextSecondary, CircleShape)
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) PathIcon(Glyphs.Check, tint = Color.White, size = 15.dp, strokeWidth = 2.4f)
    }
}

/** "Today, 09:12", "Yesterday", "Oct 21", or "Oct 21, 2024" for a date in an earlier year. */
@Composable
internal fun modifiedLabel(millis: Long): String {
    val context = LocalContext.current
    // Lists show hundreds of rows, so each label is worked out once per file.
    return remember(millis, context) { formatModified(context, millis) }
}

private fun formatModified(context: Context, millis: Long): String {
    val zone = ZoneId.systemDefault()
    val date = Instant.ofEpochMilli(millis).atZone(zone)
    val today = LocalDate.now(zone)
    return when (date.toLocalDate()) {
        today -> context.getString(
            R.string.date_today,
            DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT).format(date),
        )
        today.minusDays(1) -> context.getString(R.string.date_yesterday)
        else -> {
            // The phone's own order and month names, and the year only when it is not this year.
            val locale = Locale.getDefault()
            val skeleton = if (date.year == today.year) "MMMd" else "yMMMd"
            DateTimeFormatter.ofPattern(DateFormat.getBestDateTimePattern(locale, skeleton), locale).format(date)
        }
    }
}
