package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import ix.app.files.R
import ix.app.files.data.CanvasSpot
import ix.app.files.data.Category
import ix.app.files.data.CustomFolder
import ix.app.files.data.FolderStyle
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import kotlin.math.roundToInt

private val TILE_WIDTH = 96.dp
private val TILE_HEIGHT = 124.dp
private val MENU_BUTTON = 64.dp
private val SNAP = 24.dp

/**
 * The Home folders scattered on a free canvas. Drag a tile to put it anywhere; tap opens it, press and hold
 * edits it. Press and hold an empty spot to get a small menu there: new folder, new file, import.
 * Tiles that were never moved sit in a loose default layout.
 */
@Composable
fun FreeformCanvas(
    counts: Map<Category, Int>,
    scanning: Boolean,
    styles: Map<Category, FolderStyle>,
    customFolders: List<CustomFolder>,
    refreshKey: Any?,
    order: List<String>,
    spots: Map<String, CanvasSpot>,
    onSpotChange: (String, CanvasSpot) -> Unit,
    onCategoryClick: (Category) -> Unit,
    onCategoryLongClick: (Category) -> Unit,
    onCustomClick: (CustomFolder) -> Unit,
    onCustomLongClick: (CustomFolder) -> Unit,
    onNewFolder: (CanvasSpot) -> Unit,
    onNewFile: () -> Unit,
    onImport: () -> Unit,
    onTidy: () -> Unit,
    /** True for a few seconds after Tidy up, while the layout can still be put back. */
    canUndoTidy: Boolean,
    onUndoTidy: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val items = orderedItems(customFolders, order)
    var menuAt by remember { mutableStateOf<Offset?>(null) }

    BackHandler(enabled = menuAt != null) { menuAt = null }

    BoxWithConstraints(
        modifier.pointerInput(Unit) {
            // Tiles take their own touches first, so this only fires on empty canvas.
            detectTapGestures(onLongPress = { menuAt = it })
        },
    ) {
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()
        val tileW = with(density) { TILE_WIDTH.toPx() }
        val tileH = with(density) { TILE_HEIGHT.toPx() }

        fun clamp(point: Offset) = Offset(
            point.x.coerceIn(0f, (widthPx - tileW).coerceAtLeast(0f)),
            point.y.coerceIn(0f, (heightPx - tileH).coerceAtLeast(0f)),
        )

        /** Where tile number [index] sits until the user moves it: three loose columns. */
        fun defaultOffset(index: Int): Offset {
            val gap = (widthPx - COLUMNS * tileW) / (COLUMNS + 1)
            val col = index % COLUMNS
            val row = index / COLUMNS
            val stagger = with(density) { listOf(0.dp, 28.dp, 10.dp)[col].toPx() }
            return Offset(
                gap + col * (tileW + gap),
                with(density) { 24.dp.toPx() } + row * (tileH + with(density) { 28.dp.toPx() }) + stagger,
            )
        }

        items.forEachIndexed { index, item ->
            key(item.key) {
                val saved = spots[item.key]
                val rest = clamp(saved?.let { Offset(it.x * widthPx, it.y * widthPx) } ?: defaultOffset(index))
                var drag by remember { mutableStateOf(Offset.Zero) }
                var dragging by remember { mutableStateOf(false) }
                // After a drop the tile stays where it was dropped until the saved spot arrives.
                var settled by remember { mutableStateOf<Offset?>(null) }
                LaunchedEffect(saved, widthPx) { settled = null }
                val resting = settled ?: rest
                val latestResting by rememberUpdatedState(resting)

                fun drop() {
                    if (dragging) {
                        // A loose grid: tiles settle on multiples of 24 dp so they line up without being rigid.
                        val step = with(density) { SNAP.toPx() }
                        val raw = latestResting + drag
                        val target = clamp(Offset((raw.x / step).roundToInt() * step, (raw.y / step).roundToInt() * step))
                        settled = target
                        onSpotChange(item.key, CanvasSpot(target.x / widthPx, target.y / widthPx))
                    }
                    drag = Offset.Zero
                    dragging = false
                }

                HomeTile(
                    item = item,
                    counts = counts,
                    scanning = scanning,
                    styles = styles,
                    refreshKey = refreshKey,
                    enabled = true,
                    onCategoryClick = onCategoryClick,
                    onCategoryLongClick = onCategoryLongClick,
                    onCustomClick = onCustomClick,
                    onCustomLongClick = onCustomLongClick,
                    modifier = Modifier
                        .offset { IntOffset((resting.x + drag.x).roundToInt(), (resting.y + drag.y).roundToInt()) }
                        .width(TILE_WIDTH)
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer {
                            rotationZ = if (dragging) 0f else tilt(item.key)
                            scaleX = if (dragging) 1.06f else 1f
                            scaleY = if (dragging) 1.06f else 1f
                        }
                        .pointerInput(item.key) {
                            detectDragGestures(
                                onDragStart = { dragging = true },
                                onDragEnd = { drop() },
                                onDragCancel = { drop() },
                                onDrag = { change, amount ->
                                    change.consume()
                                    drag += amount
                                },
                            )
                        },
                )
            }
        }

        if (customFolders.isEmpty() && spots.isEmpty() && menuAt == null) {
            Text(
                text = stringResource(R.string.canvas_menu_hint),
                color = IxColors.TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp, start = 24.dp, end = 24.dp),
            )
        }

        if (canUndoTidy && menuAt == null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(IxColors.Sheet)
                    .border(1.dp, IxColors.SheetBorder, RoundedCornerShape(24.dp))
                    .padding(start = 20.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.canvas_tidy_done),
                    color = IxColors.TextPrimary,
                    fontSize = 14.sp,
                )
                Text(
                    text = stringResource(R.string.canvas_tidy_undo),
                    color = IxColors.Accent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable(role = Role.Button, onClick = onUndoTidy)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                )
            }
        }

        menuAt?.let { point ->
            val button = with(density) { MENU_BUTTON.toPx() }
            val margin = with(density) { 56.dp.toPx() }
            // Near the top edge the buttons open downward so they stay on the screen.
            val dir = if (point.y > with(density) { 190.dp.toPx() }) -1f else 1f

            // The four buttons sit in an arc around the finger. Near a side edge the whole arc slides inward together,
            // so the buttons never land on top of each other.
            val arc = listOf(-132f to 60f, -44f to 118f, 44f to 118f, 132f to 60f).map { (dx, dy) ->
                Offset(
                    point.x + with(density) { dx.dp.toPx() },
                    (point.y + with(density) { (dy * dir).dp.toPx() }).coerceIn(margin, (heightPx - margin).coerceAtLeast(margin)),
                )
            }
            val shift = (margin - arc.minOf { it.x }).coerceAtLeast(0f) -
                (arc.maxOf { it.x } - (widthPx - margin)).coerceAtLeast(0f)
            fun place(index: Int): Offset = Offset(arc[index].x + shift - button / 2, arc[index].y - button / 2)

            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.62f))
                    .pointerInput(Unit) { detectTapGestures { menuAt = null } },
            )
            Box(
                Modifier
                    .offset { IntOffset((point.x - button / 2).roundToInt(), (point.y - button / 2).roundToInt()) }
                    .size(MENU_BUTTON)
                    .border(2.dp, IxColors.Accent, CircleShape),
            )

            val spot = CanvasSpot(
                ((point.x - tileW / 2) / widthPx).coerceIn(0f, ((widthPx - tileW) / widthPx).coerceAtLeast(0f)),
                ((point.y - tileH / 2) / widthPx).coerceAtLeast(0f),
            )
            MenuAction(Glyphs.Folder, stringResource(R.string.canvas_new_folder), place(0)) {
                menuAt = null
                onNewFolder(spot)
            }
            MenuAction(Glyphs.Docs, stringResource(R.string.canvas_new_file), place(1)) {
                menuAt = null
                onNewFile()
            }
            MenuAction(Glyphs.Downloads, stringResource(R.string.canvas_import), place(2)) {
                menuAt = null
                onImport()
            }
            MenuAction(Glyphs.Apps, stringResource(R.string.canvas_tidy), place(3)) {
                menuAt = null
                onTidy()
            }
        }
    }
}

/** A tiny tilt, the same every time for the same tile, between minus three and plus three degrees. */
private fun tilt(key: String): Float = ((key.hashCode() and 0x7fffffff) % 7 - 3).toFloat()

/** One round button of the press-and-hold menu, with its name under it. [topLeft] is the button's corner. */
@Composable
private fun MenuAction(glyph: List<String>, label: String, topLeft: Offset, onClick: () -> Unit) {
    Column(
        Modifier
            .offset { IntOffset(topLeft.x.roundToInt() - 16.dp.roundToPx(), topLeft.y.roundToInt()) }
            .width(MENU_BUTTON + 32.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(20.dp))
            .clickable(role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(MENU_BUTTON)
                .clip(CircleShape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(glyph, tint = IxColors.TextPrimary, size = 26.dp, strokeWidth = 1.8f)
        }
        Text(
            text = label,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp, bottom = 4.dp),
        )
    }
}
