package ix.app.files.ui.home

import android.content.Context
import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.combinedClickable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import java.text.NumberFormat
import java.util.Calendar

private val TIMELINE_TILE = 100.dp

/**
 * The folder as a timeline: a big folder on top, then the subfolders, then the files grouped by the day they
 * were changed, newest day first. Each group is one row of previews that scrolls sideways.
 */
@Composable
internal fun TimelineView(
    folders: List<FolderItem>,
    files: List<FileItem>,
    favorites: Set<String>,
    selection: Selection,
    onOpenFolder: (FolderItem) -> Unit,
    onOpenFile: (FileItem) -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
    headerTitle: String? = null,
    startIndex: Int = 0,
    startOffset: Int = 0,
    onScrolled: ((index: Int, offset: Int) -> Unit)? = null,
) {
    val context = LocalContext.current
    val listState = rememberLazyListState(startIndex, startOffset)
    if (onScrolled != null) {
        LaunchedEffect(listState) {
            snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
                .collect { (index, offset) -> onScrolled(index, offset) }
        }
    }
    val groups = remember(files) {
        files.groupBy { dayStart(it.modifiedMillis) }.toSortedMap(compareByDescending { it })
    }
    val number = NumberFormat.getIntegerInstance()
    val dayList = remember(groups) { groups.entries.toList() }

    /**
     * Press and hold on a day: select everything from the nearest day that already has a selected file
     * up to this one, so a stretch of days takes two touches.
     */
    fun selectRange(index: Int) {
        val anchor = (1 until dayList.size).asSequence()
            .flatMap { distance -> sequenceOf(index - distance, index + distance) }
            .filter { it in dayList.indices }
            .firstOrNull { j -> dayList[j].value.any { it.path in selection.paths } }
        val range = if (anchor == null) index..index else minOf(index, anchor)..maxOf(index, anchor)
        selection.toggleMany(range.flatMap { i -> dayList[i].value.map { it.path } })
    }

    LazyColumn(
        modifier,
        state = listState,
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 8.dp,
            top = 4.dp,
            bottom = contentPadding.calculateBottomPadding(),
        ),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        if (headerTitle != null) {
            item(key = "header") { TimelineHeader(headerTitle, folders.size + files.size) }
        }
        if (folders.isNotEmpty()) {
            item(key = "folders") {
                TimelineSection(
                    selection = selection,
                    paths = folders.map { it.path },
                    title = stringResource(R.string.timeline_folders),
                    subtitle = context.resources.getQuantityString(
                        R.plurals.items_count,
                        folders.size,
                        number.format(folders.size),
                    ),
                ) {
                    LazyRow(contentPadding = PaddingValues(end = 8.dp)) {
                        items(folders, key = { "d:" + it.path }) { folder ->
                            FolderTile(
                                folder,
                                selection = selection,
                                favorite = folder.path in favorites,
                                onOpen = { onOpenFolder(folder) },
                                modifier = Modifier.width(TIMELINE_TILE),
                            )
                        }
                    }
                }
            }
        }
        dayList.forEachIndexed { index, (day, group) ->
            item(key = "day:$day") {
                TimelineSection(
                    onLongClick = { selectRange(index) },
                    selection = selection,
                    paths = group.map { it.path },
                    title = dayLabel(context, day),
                    subtitle = context.resources.getQuantityString(
                        R.plurals.timeline_files,
                        group.size,
                        number.format(group.size),
                    ),
                ) {
                    LazyRow(contentPadding = PaddingValues(end = 8.dp)) {
                        items(group, key = { "f:" + it.path }) { file ->
                            FileTile(
                                file,
                                selection = selection,
                                favorite = file.path in favorites,
                                onOpen = { onOpenFile(file) },
                                modifier = Modifier.width(TIMELINE_TILE),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TimelineHeader(title: String, count: Int) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FolderIcon(
            glyph = Glyphs.Folder,
            modifier = Modifier.size(width = 120.dp, height = 100.dp),
            tint = Color(0xFFFF6A2B),
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = title,
            color = IxColors.TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = itemsLabel(context, count),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
        )
    }
}

/**
 * A day (or "Folders") with a small tick at its left edge, like a ruler running down the screen.
 * Tapping the heading selects everything in it, or deselects it when it is all selected already.
 */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TimelineSection(
    onLongClick: (() -> Unit)? = null,
    selection: Selection,
    paths: List<String>,
    title: String,
    subtitle: String,
    content: @Composable () -> Unit,
) {
    val allSelected = paths.isNotEmpty() && selection.paths.containsAll(paths)
    Row {
        Box(Modifier.padding(top = 11.dp, end = 10.dp)) {
            Box(
                Modifier
                    .width(10.dp)
                    .height(1.dp)
                    .background(IxColors.TextSecondary),
            )
        }
        Column(Modifier.weight(1f)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .combinedClickable(
                        role = Role.Button,
                        onClick = { selection.toggleMany(paths) },
                        onLongClick = onLongClick,
                    )
                    .padding(end = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = IxColors.TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = subtitle,
                        color = IxColors.TextSecondary,
                        fontSize = 13.sp,
                    )
                }
                if (selection.active) SelectMark(allSelected)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

/** Midnight at the start of the day that [millis] falls in. */
internal fun dayStart(millis: Long): Long {
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = millis
    calendar.set(Calendar.HOUR_OF_DAY, 0)
    calendar.set(Calendar.MINUTE, 0)
    calendar.set(Calendar.SECOND, 0)
    calendar.set(Calendar.MILLISECOND, 0)
    return calendar.timeInMillis
}

/** "Monday, September 23", with the year when it is not this year. */
internal fun dayLabel(context: Context, dayMillis: Long): String {
    val thisYear = Calendar.getInstance().get(Calendar.YEAR)
    val dayYear = Calendar.getInstance().apply { timeInMillis = dayMillis }.get(Calendar.YEAR)
    var flags = DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_SHOW_DATE
    if (dayYear != thisYear) flags = flags or DateUtils.FORMAT_SHOW_YEAR
    return DateUtils.formatDateTime(context, dayMillis, flags)
}
