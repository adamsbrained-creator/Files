package ix.app.files.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

internal val SortField.labelRes: Int
    get() = when (this) {
        SortField.Modified -> R.string.sort_modified
        SortField.Name -> R.string.sort_name
        SortField.Size -> R.string.sort_size
        SortField.Type -> R.string.sort_type
    }

/**
 * The "Recent" sheet. It is hidden until the user swipes up from the bottom edge,
 * then rests half-open ("collapsed") or open over the folders ("expanded").
 *
 * [dragModifier] makes the handle and the header draggable. The parent owns the drag, so it can
 * also drive the hidden state and the swipe zone.
 */
@Composable
fun RecentSheet(
    files: List<FileItem>,
    /** Show a day heading above each day of files. */
    timeline: Boolean = false,
    sort: SortSpec,
    expanded: Boolean,
    onToggleExpanded: () -> Unit,
    onSortSelected: (SortField) -> Unit,
    onFileClick: (FileItem) -> Unit,
    favorites: Set<String>,
    selection: Selection,
    dragModifier: Modifier,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val toggleDescription = stringResource(if (expanded) R.string.sheet_collapse else R.string.sheet_expand)

    Box(
        modifier
            .clip(shape)
            .background(IxColors.Sheet)
            .border(1.dp, IxColors.SheetBorder, shape)
            // Swallow taps so they never reach the folders hidden behind the sheet.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(Modifier.fillMaxSize()) {
            // Handle and header: drag here to move the sheet.
            Column(dragModifier) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clickable(role = Role.Button, onClick = onToggleExpanded)
                        .semantics { contentDescription = toggleDescription }
                        .padding(top = 8.dp, bottom = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .width(36.dp)
                            .height(5.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(IxColors.Handle),
                    )
                }

                SheetHeader(
                    sort = sort,
                    expanded = expanded,
                    toggleDescription = toggleDescription,
                    onToggleExpanded = onToggleExpanded,
                    onSortSelected = onSortSelected,
                )
            }

            val context = androidx.compose.ui.platform.LocalContext.current
            LazyColumn(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 120.dp),
            ) {
                if (files.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            text = stringResource(R.string.recent_empty),
                            color = IxColors.TextSecondary,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                        )
                    }
                }
                if (timeline && sort.field == SortField.Modified) {
                    // Newest first: a day heading appears whenever the day changes from the row above.
                    var lastDay = Long.MIN_VALUE
                    files.forEach { file ->
                        val day = dayStart(file.modifiedMillis)
                        if (day != lastDay) {
                            lastDay = day
                            item(key = "day:$day") {
                                // Tapping a day heading selects that day's files.
                                val dayPaths = files.filter { dayStart(it.modifiedMillis) == day }.map { it.path }
                                Text(
                                    text = dayLabel(context, day),
                                    color = IxColors.TextSecondary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(role = androidx.compose.ui.semantics.Role.Button) {
                                            selection.toggleMany(dayPaths)
                                        }
                                        .padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 8.dp),
                                )
                            }
                        }
                        item(key = file.path) {
                            FileRow(
                                file,
                                selection = selection,
                                favorite = file.path in favorites,
                                onOpen = { onFileClick(file) },
                            )
                        }
                    }
                } else {
                    items(files, key = { it.path }) { file ->
                        FileRow(
                            file,
                            selection = selection,
                            favorite = file.path in favorites,
                            onOpen = { onFileClick(file) },
                        )
                    }
                }
            }
        }

        // Soft fade at the bottom edge
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(110.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, IxColors.Sheet))),
        )
    }
}

@Composable
private fun SheetHeader(
    sort: SortSpec,
    expanded: Boolean,
    toggleDescription: String,
    onToggleExpanded: () -> Unit,
    onSortSelected: (SortField) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 12.dp)
            .height(48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = stringResource(R.string.recent_title),
            color = IxColors.TextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            SortButton(sort = sort, onSortSelected = onSortSelected)

            // Expand / collapse
            val rotation by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onToggleExpanded)
                    .semantics { contentDescription = toggleDescription },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(IxColors.Chip),
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(
                        Glyphs.ChevronUp,
                        modifier = Modifier.rotate(rotation),
                        tint = IxColors.TextPrimary,
                        size = 16.dp,
                        strokeWidth = 2.2f,
                    )
                }
            }
        }
    }
}

/** "Modified ↓". Tap to pick a sort field. Tap the active one to flip the direction. */
@Composable
internal fun SortButton(sort: SortSpec, onSortSelected: (SortField) -> Unit) {
    var menuOpen by remember { mutableStateOf(false) }
    val fieldLabel = stringResource(sort.field.labelRes)
    val directionLabel = stringResource(if (sort.ascending) R.string.sort_ascending else R.string.sort_descending)
    val description = stringResource(R.string.sort_description, fieldLabel, directionLabel)

    Box {
        Row(
            Modifier
                .height(40.dp)
                .clip(RoundedCornerShape(20.dp))
                .clickable(role = Role.Button) { menuOpen = true }
                .semantics { contentDescription = description }
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Text(
                text = fieldLabel,
                color = IxColors.SortText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
            )
            PathIcon(
                if (sort.ascending) Glyphs.ArrowUp else Glyphs.ArrowDown,
                tint = IxColors.SortText,
                size = 12.dp,
                strokeWidth = 2.6f,
            )
        }

        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            SortField.entries.forEach { field ->
                val selected = field == sort.field
                DropdownMenuItem(
                    text = {
                        Text(
                            text = stringResource(field.labelRes),
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        )
                    },
                    trailingIcon = if (selected) {
                        {
                            PathIcon(
                                if (sort.ascending) Glyphs.ArrowUp else Glyphs.ArrowDown,
                                tint = IxColors.TextPrimary,
                                size = 14.dp,
                                strokeWidth = 2.4f,
                            )
                        }
                    } else {
                        null
                    },
                    onClick = {
                        onSortSelected(field)
                        menuOpen = false
                    },
                )
            }
        }
    }
}
