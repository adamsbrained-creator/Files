package ix.app.files.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.ui.theme.IxColors

/** The Favorites tab: favorite folders first, then favorite files. Scrolls when the list is long. */
@Composable
fun FavoritesList(
    folders: List<FolderItem>,
    files: List<FileItem>,
    onFolderClick: (FolderItem) -> Unit,
    onFileClick: (FileItem) -> Unit,
    grid: Boolean,
    favorites: Set<String>,
    selection: Selection,
    modifier: Modifier = Modifier,
    /** Show the favorites as days of files, like the folder timeline. */
    timeline: Boolean = false,
) {
    if (folders.isEmpty() && files.isEmpty()) {
        Column(
            modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = stringResource(R.string.favorites_empty),
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
            )
            Text(
                text = stringResource(R.string.favorites_hint),
                color = IxColors.TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
        }
        return
    }

    // Extra room at the bottom so the last row can scroll clear of the swipe-up strip.
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    ItemsView(
        folders = folders,
        files = files,
        grid = grid,
        timeline = timeline,
        favorites = favorites,
        selection = selection,
        onOpenFolder = onFolderClick,
        onOpenFile = onFileClick,
        contentPadding = PaddingValues(bottom = bottomInset + 88.dp),
        modifier = modifier.fillMaxWidth(),
    )
}
