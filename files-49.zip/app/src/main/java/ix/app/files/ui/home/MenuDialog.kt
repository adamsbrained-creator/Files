package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ix.app.files.R
import ix.app.files.data.ThemeMode
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

/** The menu behind the sliders button: layout, hidden files, and which version this is. */
@Composable
fun MenuDialog(
    grid: Boolean,
    timeline: Boolean,
    onTimelineChange: (Boolean) -> Unit,
    selectionPills: Boolean,
    onSelectionPillsChange: (Boolean) -> Unit,
    freeform: Boolean,
    onFreeformChange: (Boolean) -> Unit,
    showHidden: Boolean,
    onGridChange: (Boolean) -> Unit,
    onShowHiddenChange: (Boolean) -> Unit,
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    onStorage: () -> Unit,
    onDuplicates: () -> Unit,
    onCleaner: () -> Unit,
    onApps: () -> Unit,
    onTrash: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val version = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }
    val shape = RoundedCornerShape(28.dp)

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text(
                text = stringResource(R.string.menu_title),
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.menu_home_layout),
                    color = IxColors.TextSecondary,
                    fontSize = 13.sp,
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(IxColors.Field)
                        .padding(4.dp),
                ) {
                    Choice(stringResource(R.string.menu_home_grid), selected = !freeform, modifier = Modifier.weight(1f)) {
                        onFreeformChange(false)
                    }
                    Choice(stringResource(R.string.menu_home_freeform), selected = freeform, modifier = Modifier.weight(1f)) {
                        onFreeformChange(true)
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.menu_layout),
                    color = IxColors.TextSecondary,
                    fontSize = 13.sp,
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(IxColors.Field)
                        .padding(4.dp),
                ) {
                    Choice(stringResource(R.string.menu_list), selected = !grid && !timeline, modifier = Modifier.weight(1f)) {
                        onGridChange(false)
                        onTimelineChange(false)
                    }
                    Choice(stringResource(R.string.menu_grid), selected = grid && !timeline, modifier = Modifier.weight(1f)) {
                        onGridChange(true)
                        onTimelineChange(false)
                    }
                    Choice(stringResource(R.string.menu_timeline), selected = timeline, modifier = Modifier.weight(1f)) {
                        onTimelineChange(true)
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.menu_selection),
                    color = IxColors.TextSecondary,
                    fontSize = 13.sp,
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(IxColors.Field)
                        .padding(4.dp),
                ) {
                    Choice(stringResource(R.string.menu_selection_bar), selected = !selectionPills, modifier = Modifier.weight(1f)) {
                        onSelectionPillsChange(false)
                    }
                    Choice(stringResource(R.string.menu_selection_pills), selected = selectionPills, modifier = Modifier.weight(1f)) {
                        onSelectionPillsChange(true)
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.menu_theme),
                    color = IxColors.TextSecondary,
                    fontSize = 13.sp,
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(IxColors.Field)
                        .padding(4.dp),
                ) {
                    Choice(
                        stringResource(R.string.theme_system),
                        selected = themeMode == ThemeMode.System,
                        modifier = Modifier.weight(1f),
                    ) { onThemeChange(ThemeMode.System) }
                    Choice(
                        stringResource(R.string.theme_light),
                        selected = themeMode == ThemeMode.Light,
                        modifier = Modifier.weight(1f),
                    ) { onThemeChange(ThemeMode.Light) }
                    Choice(
                        stringResource(R.string.theme_dark),
                        selected = themeMode == ThemeMode.Dark,
                        modifier = Modifier.weight(1f),
                    ) { onThemeChange(ThemeMode.Dark) }
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.menu_hidden),
                        color = IxColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        text = stringResource(R.string.menu_hidden_hint),
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
                Switch(
                    checked = showHidden,
                    onCheckedChange = onShowHiddenChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = IxColors.Background,
                        checkedTrackColor = IxColors.TextPrimary,
                        uncheckedThumbColor = IxColors.TextSecondary,
                        uncheckedTrackColor = IxColors.Chip,
                        uncheckedBorderColor = IxColors.Outline,
                    ),
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MenuRow(Glyphs.Pie, stringResource(R.string.menu_storage), onStorage)
                MenuRow(Glyphs.Copy, stringResource(R.string.menu_duplicates), onDuplicates)
                MenuRow(Glyphs.Sparkle, stringResource(R.string.menu_cleaner), onCleaner)
                MenuRow(Glyphs.Apps, stringResource(R.string.menu_apps), onApps)
                MenuRow(Glyphs.Trash, stringResource(R.string.menu_trash), onTrash)
            }

            if (version.isNotEmpty()) {
                Text(
                    text = stringResource(R.string.menu_version, version),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                )
            }
        }
    }
}

/** One tappable line of the menu: an icon, a label and an arrow. */
@Composable
private fun MenuRow(icon: List<String>, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(IxColors.Field)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PathIcon(icon, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.8f)
        Text(
            text = label,
            color = IxColors.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f),
        )
        PathIcon(Glyphs.ChevronRight, tint = IxColors.TextSecondary, size = 16.dp, strokeWidth = 2.2f)
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) IxColors.Button else IxColors.Field)
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) IxColors.TextPrimary else IxColors.TextSecondary,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
        )
    }
}
