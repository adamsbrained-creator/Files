package ix.app.files.data

import android.content.Context

/** What the user picked in the menu, remembered on the device. */
class Settings(
    val grid: Boolean,
    /** True when Home shows the folders scattered on a free canvas, false for the tidy grid. */
    val freeform: Boolean,
    /** True when folders show as a timeline of days instead of a list or grid. */
    val timeline: Boolean,
    /** True when the actions for selected files float as round and pill buttons. */
    val selectionPills: Boolean,
    val showHidden: Boolean,
    val sort: SortSpec,
    val theme: ThemeMode,
    /** How many days deleted things wait in the Trash. Zero means they go as soon as Undo is over. */
    val trashDays: Int,
)

class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): Settings {
        val field = prefs.getString(KEY_SORT_FIELD, null)
            ?.let { name -> SortField.entries.firstOrNull { it.name == name } }
            ?: SortField.Modified
        val ascending = prefs.getBoolean(KEY_SORT_ASCENDING, field.defaultAscending)
        return Settings(
            grid = prefs.getBoolean(KEY_GRID, false),
            freeform = prefs.getBoolean(KEY_FREEFORM, true),
            timeline = prefs.getBoolean(KEY_TIMELINE, false),
            selectionPills = prefs.getBoolean(KEY_PILLS, false),
            showHidden = prefs.getBoolean(KEY_HIDDEN, false),
            sort = SortSpec(field, ascending),
            theme = prefs.getString(KEY_THEME, null)
                ?.let { name -> ThemeMode.entries.firstOrNull { it.name == name } }
                ?: ThemeMode.System,
            trashDays = prefs.getInt(KEY_TRASH_DAYS, DEFAULT_TRASH_DAYS),
        )
    }

    /** True once the user has been through the welcome pages (or skipped them). */
    fun welcomeSeen(): Boolean = prefs.getBoolean(KEY_WELCOME_SEEN, false)

    fun saveWelcomeSeen() {
        prefs.edit().putBoolean(KEY_WELCOME_SEEN, true).apply()
    }

    fun saveTheme(theme: ThemeMode) {
        prefs.edit().putString(KEY_THEME, theme.name).apply()
    }

    fun saveTrashDays(days: Int) {
        prefs.edit().putInt(KEY_TRASH_DAYS, days).apply()
    }

    fun saveTimeline(timeline: Boolean) {
        prefs.edit().putBoolean(KEY_TIMELINE, timeline).apply()
    }

    fun saveSelectionPills(pills: Boolean) {
        prefs.edit().putBoolean(KEY_PILLS, pills).apply()
    }

    fun saveFreeform(freeform: Boolean) {
        prefs.edit().putBoolean(KEY_FREEFORM, freeform).apply()
    }

    fun saveGrid(grid: Boolean) {
        prefs.edit().putBoolean(KEY_GRID, grid).apply()
    }

    fun saveShowHidden(show: Boolean) {
        prefs.edit().putBoolean(KEY_HIDDEN, show).apply()
    }

    fun saveSort(sort: SortSpec) {
        prefs.edit()
            .putString(KEY_SORT_FIELD, sort.field.name)
            .putBoolean(KEY_SORT_ASCENDING, sort.ascending)
            .apply()
    }

    private companion object {
        const val KEY_WELCOME_SEEN = "welcome_seen"
        const val KEY_GRID = "grid"
        const val KEY_FREEFORM = "home_freeform"
        const val KEY_TIMELINE = "timeline"
        const val KEY_PILLS = "selection_pills"
        const val KEY_HIDDEN = "show_hidden"
        const val KEY_SORT_FIELD = "sort_field"
        const val KEY_SORT_ASCENDING = "sort_ascending"
        const val KEY_THEME = "theme"
        const val KEY_TRASH_DAYS = "trash_days"
        const val DEFAULT_TRASH_DAYS = 30
    }
}
