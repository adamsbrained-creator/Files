package ix.app.files.data

/** Looks through the scan's list of files and folders. Fast enough to run on every keystroke. */
object SearchEngine {

    private const val MAX_FILES = 300
    private const val MAX_FOLDERS = 100

    /**
     * Finds files whose name (or extension) and folders whose name contain [needle], ignoring case.
     * Names that start with the text come first, then the rest, newest first within each group.
     */
    fun search(scan: ScanData, needle: String): SearchResults {
        val q = needle.trim()
        if (q.isEmpty()) return SearchResults.Empty
        val hasDot = q.contains('.')

        fun fileMatches(f: FileItem): Boolean {
            if (f.name.contains(q, ignoreCase = true)) return true
            if (f.extension.isEmpty()) return false
            // "report.pdf" is matched against the whole file name, "pdf" against the extension.
            return if (hasDot) {
                "${f.name}.${f.extension}".contains(q, ignoreCase = true)
            } else {
                f.extension.startsWith(q, ignoreCase = true)
            }
        }

        val starting = ArrayList<FileItem>()
        val containing = ArrayList<FileItem>()
        for (file in scan.files) {
            if (!fileMatches(file)) continue
            if (file.name.startsWith(q, ignoreCase = true)) starting.add(file) else containing.add(file)
        }
        val files = (starting.sortedByDescending { it.modifiedMillis } + containing.sortedByDescending { it.modifiedMillis })
            .take(MAX_FILES)

        val folderStarting = ArrayList<FolderItem>()
        val folderContaining = ArrayList<FolderItem>()
        for (folder in scan.folders) {
            if (!folder.name.contains(q, ignoreCase = true)) continue
            if (folder.name.startsWith(q, ignoreCase = true)) folderStarting.add(folder) else folderContaining.add(folder)
        }
        val matchedFolders = folderStarting.sortedByDescending { it.modifiedMillis } +
            folderContaining.sortedByDescending { it.modifiedMillis }
        // The scan does not count what is inside each folder, so that is looked up for the few shown.
        val folders = matchedFolders.take(MAX_FOLDERS).mapNotNull { FolderLister.folderAt(it.path) }

        val total = starting.size + containing.size + matchedFolders.size
        return SearchResults(folders = folders, files = files, total = total)
    }
}
