package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import ix.app.files.data.KindSize
import ix.app.files.data.StorageInfo
import ix.app.files.data.StorageReport
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import ix.app.files.util.formatStorage

private val KindColors = listOf(
    Color(0xFFFF6A2B),
    Color(0xFFD8D8DC),
    Color(0xFFA4A4AB),
    Color(0xFF7C7C84),
    Color(0xFF5A5A61),
    Color(0xFF45454B),
)

private val FileKind.titleRes: Int
    get() = when (this) {
        FileKind.Image -> R.string.category_images
        FileKind.Video -> R.string.category_videos
        FileKind.Audio -> R.string.category_audio
        FileKind.Document -> R.string.category_docs
        FileKind.App -> R.string.category_apps
        FileKind.Other -> R.string.kind_other
    }

/** The Home folder that holds this kind of file, if there is one. */
private val FileKind.category: Category?
    get() = when (this) {
        FileKind.Image -> Category.Images
        FileKind.Video -> Category.Videos
        FileKind.Audio -> Category.Audio
        FileKind.Document -> Category.Docs
        FileKind.App -> Category.Apps
        FileKind.Other -> null
    }

/**
 * What takes the space: a bar and a list by kind of file, then the biggest files,
 * which can be selected and deleted right here.
 */
@Composable
fun StorageScreen(
    storage: StorageInfo,
    report: StorageReport?,
    scanning: Boolean,
    favorites: Set<String>,
    selection: Selection,
    onBack: () -> Unit,
    onOpenCategory: (Category) -> Unit,
    onFileClick: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Column(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(start = 8.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onBack)
                    .semantics { contentDescription = backDescription },
                contentAlignment = Alignment.Center,
            ) {
                PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
            }
            Text(
                text = stringResource(R.string.menu_storage),
                color = IxColors.TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 4.dp),
            )
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = bottomInset + 24.dp),
        ) {
            item(key = "summary") { Summary(storage, report, scanning) }

            if (report != null) {
                val rest = (storage.usedBytes - report.filesBytes).coerceAtLeast(0L)
                items(report.byKind, key = { "k:" + it.kind.name }) { entry ->
                    val index = report.byKind.indexOf(entry)
                    val category = entry.kind.category
                    KindRow(
                        color = KindColors[index.coerceAtMost(KindColors.lastIndex)],
                        label = stringResource(entry.kind.titleRes),
                        count = entry.count,
                        bytes = entry.bytes,
                        onClick = if (category != null) ({ onOpenCategory(category) }) else null,
                    )
                }
                item(key = "rest") {
                    KindRow(
                        color = IxColors.Outline,
                        label = stringResource(R.string.storage_other_system),
                        count = null,
                        bytes = rest,
                        onClick = null,
                    )
                }

                if (report.largest.isNotEmpty()) {
                    item(key = "largest-title") {
                        Text(
                            text = stringResource(R.string.storage_largest),
                            color = IxColors.TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 6.dp),
                        )
                    }
                    items(report.largest, key = { "f:" + it.path }) { file ->
                        FileRow(
                            file,
                            selection = selection,
                            favorite = file.path in favorites,
                            onOpen = { onFileClick(file) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Summary(storage: StorageInfo, report: StorageReport?, scanning: Boolean) {
    val total = storage.totalBytes.coerceAtLeast(1L).toFloat()
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
    ) {
        Text(
            text = stringResource(
                R.string.storage_used,
                formatStorage(storage.usedBytes),
                formatStorage(storage.totalBytes),
            ),
            color = IxColors.TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(14.dp))

        // One segment per kind of file, then everything else that is used, then what is free.
        Row(
            Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(IxColors.Field),
        ) {
            if (report != null) {
                report.byKind.forEachIndexed { index, entry ->
                    if (entry.bytes > 0) {
                        Box(
                            Modifier
                                .weight((entry.bytes / total).coerceAtLeast(0.002f))
                                .height(12.dp)
                                .background(KindColors[index.coerceAtMost(KindColors.lastIndex)]),
                        )
                    }
                }
                val rest = (storage.usedBytes - report.filesBytes).coerceAtLeast(0L)
                if (rest > 0) {
                    Box(
                        Modifier
                            .weight((rest / total).coerceAtLeast(0.002f))
                            .height(12.dp)
                            .background(IxColors.Outline),
                    )
                }
                val free = (storage.totalBytes - storage.usedBytes).coerceAtLeast(0L)
                if (free > 0) Box(Modifier.weight((free / total).coerceAtLeast(0.002f)))
            } else {
                Box(
                    Modifier
                        .weight(storage.usedFraction.coerceIn(0.01f, 1f))
                        .height(12.dp)
                        .background(IxColors.Outline),
                )
                Box(Modifier.weight((1f - storage.usedFraction).coerceAtLeast(0.001f)))
            }
        }

        if (report == null || scanning) {
            Text(
                text = stringResource(R.string.scanning),
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun KindRow(
    color: Color,
    label: String,
    count: Int?,
    bytes: Long,
    onClick: (() -> Unit)?,
) {
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color),
        )
        Column(
            Modifier
                .weight(1f)
                .padding(start = 14.dp),
        ) {
            Text(text = label, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (count != null) {
                Text(text = itemsLabel(context, count), color = IxColors.TextSecondary, fontSize = 12.sp)
            }
        }
        Text(text = formatFileSize(bytes), color = IxColors.TextSecondary, fontSize = 14.sp)
        if (onClick != null) {
            Spacer(Modifier.width(6.dp))
            PathIcon(Glyphs.ChevronRight, tint = IxColors.Handle, size = 16.dp, strokeWidth = 2.2f)
        }
    }
}
