package ix.app.files.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Draws a stroked icon from SVG path data on a 24 x 24 grid.
 * The icons are the same paths used in the design mockup, so the app matches it exactly.
 */
@Composable
fun PathIcon(
    paths: List<String>,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    size: Dp = 24.dp,
    strokeWidth: Float = 1.8f,
) {
    val parsed = remember(paths) {
        paths.map { PathParser().parsePathString(it).toPath() }
    }
    Canvas(modifier.size(size)) {
        val factor = this.size.minDimension / 24f
        scale(factor, factor, pivot = Offset.Zero) {
            val stroke = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
            parsed.forEach { drawPath(it, tint, style = stroke) }
        }
    }
}

/** Path builders so rounded rectangles and circles can sit next to hand-written paths. */
fun roundRectPath(x: Float, y: Float, w: Float, h: Float, r: Float): String =
    "M${x + r} ${y}h${w - 2 * r}a$r $r 0 0 1 $r $r" +
        "v${h - 2 * r}a$r $r 0 0 1 -$r $r" +
        "h${-(w - 2 * r)}a$r $r 0 0 1 -$r -$r" +
        "v${-(h - 2 * r)}a$r $r 0 0 1 $r -${r}z"

fun circlePath(cx: Float, cy: Float, r: Float): String =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

/** Every glyph in the app. All are 24 x 24, stroke only. */
object Glyphs {
    val Search = listOf(circlePath(11f, 11f, 7f), "M20 20l-3.5-3.5")

    /** The "Stack" menu icon chosen from the options board. */
    val Stack = listOf(
        roundRectPath(4f, 8f, 12f, 13f, 2f),
        "M8 8V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",
    )

    /** Two sliders. Used for the menu button. */
    val Sliders = listOf(
        "M4 8h8M18 8h2M4 16h2M12 16h8",
        circlePath(15f, 8f, 2.2f),
        circlePath(9f, 16f, 2.2f),
    )

    val Folder = listOf("M3 7.5a2 2 0 0 1 2-2h4.2l2 2H19a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z")
    val ChevronLeft = listOf("M15 6l-6 6 6 6")
    val ChevronRight = listOf("M9 6l6 6-6 6")
    val Check = listOf("M5.5 12.5l4.2 4.2L18.5 7.5")
    val Close = listOf("M6 6l12 12M18 6L6 18")
    val Play = listOf("M9 6.5v11l9-5.5z")

    // Selection actions
    val Share = listOf("M12 15V4M8 8l4-4 4 4M5 13v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5")
    val Edit = listOf("M4.5 19.5l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8.5 18.5z", "M14.5 6.5l3 3")
    val Copy = listOf(roundRectPath(8f, 8f, 12f, 12f, 2.5f), "M16 8V6.5A2.5 2.5 0 0 0 13.5 4h-7A2.5 2.5 0 0 0 4 6.5v7A2.5 2.5 0 0 0 6.5 16H8")
    val Move = listOf("M4 12h11M11 8l4 4-4 4M20 5v14")
    val More = listOf(circlePath(6f, 12f, 1.3f), circlePath(12f, 12f, 1.3f), circlePath(18f, 12f, 1.3f))
    val Info = listOf(circlePath(12f, 12f, 8f), "M12 11v5M12 8.2v.1")
    val NewFolder = listOf(
        "M3 7.5a2 2 0 0 1 2-2h4.2l2 2H19a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
        "M12 11v5M9.5 13.5h5",
    )
    val Archive = listOf(roundRectPath(4f, 4f, 16f, 16f, 2.5f), "M12 4v7M10.5 7.5h3M10.5 11h3")
    val Pie = listOf(circlePath(12f, 12f, 8f), "M12 4v8l6 4")
    val Trash = listOf("M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12M10.5 11v5M13.5 11v5")

    val Star = listOf("M12 3.8l2.5 5.1 5.6.8-4.1 3.9 1 5.6-5-2.7-5 2.7 1-5.6L3.9 9.7l5.6-.8z")
    val Lock = listOf(roundRectPath(5f, 11f, 14f, 9f, 2.5f), "M8 11V8a4 4 0 0 1 8 0v3")
    val Unlock = listOf(roundRectPath(5f, 11f, 14f, 9f, 2.5f), "M8 11V8a4 4 0 0 1 7.6-1.7")

    val ArrowDown = listOf("M12 5v14M6 13l6 6 6-6")
    val ArrowUp = listOf("M12 19V5M6 11l6-6 6 6")
    val ChevronUp = listOf("M6 15l6-6 6 6")

    // Folder glyphs
    val Downloads = listOf("M12 4.5v10M7.8 10.6L12 14.8l4.2-4.2M5.5 19h13")
    val Images = listOf(
        roundRectPath(4f, 5f, 16f, 14f, 3.5f),
        circlePath(9f, 10f, 1.5f),
        "M4.5 17l4.3-4.3 3.4 3.4 2.8-2.8 4.5 4.5",
    )
    val Videos = listOf(roundRectPath(3.5f, 6f, 17f, 12f, 3.5f), "M10.5 9.6v4.8l4-2.4z")
    val Audio = listOf(
        "M9.5 17.5V6.5l9-2v11",
        circlePath(7f, 17.5f, 2.5f),
        circlePath(16f, 15.5f, 2.5f),
    )
    val Docs = listOf(
        "M7 3.5h6.5L18 8v11.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15a1 1 0 0 1 1-1z",
        "M13.5 3.5V8H18M9 12.5h6M9 16h6",
    )
    val Apps = listOf(
        roundRectPath(4.5f, 4.5f, 6f, 6f, 1.8f),
        roundRectPath(13.5f, 4.5f, 6f, 6f, 1.8f),
        roundRectPath(4.5f, 13.5f, 6f, 6f, 1.8f),
        roundRectPath(13.5f, 13.5f, 6f, 6f, 1.8f),
    )
}
