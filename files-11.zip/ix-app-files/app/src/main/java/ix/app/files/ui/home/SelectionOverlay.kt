package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileOps
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

private val DangerColor = Color(0xFFFF6B6B)

private enum class SelectionDialog { None, Rename, Delete, Details }

/**
 * Shown while anything is selected: a bar on top with the count, and a floating bar of actions
 * at the bottom. Back (or the X) leaves selection mode.
 */
@Composable
fun SelectionOverlay(
    paths: Set<String>,
    allFavorite: Boolean,
    inPrivate: Boolean,
    onClear: () -> Unit,
    onSelectAll: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onShare: () -> Unit,
    onFavorite: () -> Unit,
    onMoveToPrivate: () -> Unit,
    onCompress: () -> Unit,
    onExtract: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
) {
    BackHandler(onBack = onClear)
    var dialog by remember { mutableStateOf(SelectionDialog.None) }
    var moreOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val count = paths.size
    val countLabel = context.resources.getQuantityString(
        R.plurals.selected_count,
        count,
        NumberFormat.getIntegerInstance().format(count),
    )
    val clearDescription = stringResource(R.string.selection_clear)

    Box(Modifier.fillMaxSize()) {
        // Top bar. It covers the screen's own header, so it also swallows taps.
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .background(IxColors.Background)
                .pointerInput(Unit) { detectTapGestures { } }
                .statusBarsPadding()
                .height(64.dp)
                .padding(start = 8.dp, end = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onClear)
                    .semantics { contentDescription = clearDescription },
                contentAlignment = Alignment.Center,
            ) {
                PathIcon(Glyphs.Close, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 2f)
            }
            Text(
                text = countLabel,
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 6.dp),
            )
            Text(
                text = stringResource(R.string.select_all),
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClick = onSelectAll)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            )
        }

        // Floating action bar
        val barShape = RoundedCornerShape(30.dp)
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 14.dp)
                .clip(barShape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, barShape)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(horizontal = 8.dp, vertical = 6.dp),
        ) {
            ActionButton(Glyphs.Copy, stringResource(R.string.action_copy), onClick = onCopy)
            ActionButton(Glyphs.Move, stringResource(R.string.action_move), onClick = onMove)
            ActionButton(Glyphs.Share, stringResource(R.string.action_share), onClick = onShare)
            ActionButton(
                Glyphs.Trash,
                stringResource(R.string.action_delete),
                tint = DangerColor,
            ) { dialog = SelectionDialog.Delete }

            Box {
                ActionButton(Glyphs.More, stringResource(R.string.action_more)) { moreOpen = true }
                DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                    // Favorites and Private are for things outside Private. Inside it, neither makes sense.
                    if (!inPrivate) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    stringResource(
                                        if (allFavorite) R.string.action_unfavorite else R.string.action_favorite,
                                    ),
                                )
                            },
                            leadingIcon = { PathIcon(Glyphs.Star, tint = IxColors.TextPrimary, size = 18.dp) },
                            onClick = {
                                moreOpen = false
                                onFavorite()
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_private)) },
                            leadingIcon = { PathIcon(Glyphs.Lock, tint = IxColors.TextPrimary, size = 18.dp) },
                            onClick = {
                                moreOpen = false
                                onMoveToPrivate()
                            },
                        )
                    }
                    if (count == 1) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_rename)) },
                            leadingIcon = { PathIcon(Glyphs.Edit, tint = IxColors.TextPrimary, size = 18.dp) },
                            onClick = {
                                moreOpen = false
                                dialog = SelectionDialog.Rename
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_compress)) },
                        leadingIcon = { PathIcon(Glyphs.Archive, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            onCompress()
                        },
                    )
                    if (paths.all { it.endsWith(".zip", ignoreCase = true) }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_extract)) },
                            leadingIcon = { PathIcon(Glyphs.Downloads, tint = IxColors.TextPrimary, size = 18.dp) },
                            onClick = {
                                moreOpen = false
                                onExtract()
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.action_details)) },
                        leadingIcon = { PathIcon(Glyphs.Info, tint = IxColors.TextPrimary, size = 18.dp) },
                        onClick = {
                            moreOpen = false
                            dialog = SelectionDialog.Details
                        },
                    )
                }
            }
        }
    }

    when (dialog) {
        SelectionDialog.None -> Unit

        SelectionDialog.Rename -> NameDialog(
            title = stringResource(R.string.action_rename),
            initialName = File(paths.first()).name,
            confirmLabel = stringResource(R.string.rename_confirm),
            onConfirm = { name ->
                dialog = SelectionDialog.None
                onRename(name)
            },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.Details -> DetailsDialog(
            paths = remember(paths) { paths.toList() },
            onDismiss = { dialog = SelectionDialog.None },
        )

        SelectionDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = SelectionDialog.None },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.action_delete)) },
            text = {
                Text(
                    context.resources.getQuantityString(
                        R.plurals.delete_message,
                        count,
                        NumberFormat.getIntegerInstance().format(count),
                    ),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        dialog = SelectionDialog.None
                        onDelete()
                    },
                ) { Text(stringResource(R.string.action_delete), color = DangerColor) }
            },
            dismissButton = {
                TextButton(onClick = { dialog = SelectionDialog.None }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

@Composable
private fun ActionButton(
    glyph: List<String>,
    label: String,
    tint: Color = IxColors.TextPrimary,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .width(64.dp)
            .height(54.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(role = Role.Button, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        PathIcon(glyph, tint = tint, size = 22.dp, strokeWidth = 1.9f)
        Text(
            text = label,
            color = tint,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}

/** Name, place, size and date of the selection. A folder's size is added up in the background. */
@Composable
private fun DetailsDialog(paths: List<String>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val details by produceState<FileOps.Details?>(null, paths) { value = FileOps.measure(paths) }
    val number = NumberFormat.getIntegerInstance()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(stringResource(R.string.action_details)) },
        text = {
            val d = details
            Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                if (d == null) {
                    Text(stringResource(R.string.calculating))
                } else {
                    val filesLabel = context.resources.getQuantityString(
                        R.plurals.details_files,
                        d.files,
                        number.format(d.files),
                    )
                    val sizeLabel = if (d.isFolder || d.count > 1) {
                        stringResource(R.string.file_meta, formatFileSize(d.bytes), filesLabel)
                    } else {
                        formatFileSize(d.bytes)
                    }
                    if (d.count == 1) {
                        DetailLine(stringResource(R.string.detail_name), d.name)
                        DetailLine(stringResource(R.string.detail_location), d.location)
                        DetailLine(stringResource(R.string.detail_size), sizeLabel)
                        DetailLine(
                            stringResource(R.string.detail_modified),
                            DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT)
                                .format(Instant.ofEpochMilli(d.modifiedMillis).atZone(ZoneId.systemDefault())),
                        )
                    } else {
                        DetailLine(stringResource(R.string.detail_selected), itemsLabel(context, d.count))
                        DetailLine(stringResource(R.string.detail_size), sizeLabel)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close), color = IxColors.TextPrimary) }
        },
    )
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column {
        Text(text = label, color = IxColors.TextSecondary, fontSize = 12.sp)
        Text(text = value, color = IxColors.TextPrimary, fontSize = 15.sp)
    }
}
