package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.HomeTab
import ix.app.files.data.StorageInfo
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatStorage

/** "Files" title on the left, storage pill on the right. */
@Composable
fun HomeHeader(storage: StorageInfo, onStorageClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(36.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            text = stringResource(R.string.home_title),
            color = IxColors.TextPrimary,
            fontSize = 28.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = (-0.5).sp,
        )
        StoragePill(storage, onStorageClick)
    }
}

@Composable
private fun StoragePill(storage: StorageInfo, onClick: () -> Unit) {
    val label = buildAnnotatedString {
        withStyle(SpanStyle(color = IxColors.TextPrimary, fontWeight = FontWeight.SemiBold)) {
            append(formatStorage(storage.usedBytes))
        }
        append(" / ")
        append(formatStorage(storage.totalBytes))
    }
    Row(
        Modifier
            .clip(CircleShape)
            .border(1.dp, IxColors.Outline, CircleShape)
            .clickable(
                onClickLabel = stringResource(R.string.storage_browse),
                role = Role.Button,
                onClick = onClick,
            )
            .padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier
                .width(28.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(IxColors.Outline),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(storage.usedFraction.coerceAtLeast(0.06f))
                    .height(4.dp)
                    .background(IxColors.Accent),
            )
        }
        Text(text = label, color = IxColors.TextSecondary, fontSize = 12.sp)
        PathIcon(Glyphs.ChevronRight, tint = IxColors.TextSecondary, size = 14.dp, strokeWidth = 2.2f)
    }
}

/** Search field plus the Stack menu button. */
@Composable
fun SearchRow(
    externalQuery: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    onMenuClick: () -> Unit = {},
) {
    // The field keeps its own text so typing never lags. When the app clears the search
    // from outside (the Back button, say), the text follows.
    var query by remember { mutableStateOf(externalQuery) }
    LaunchedEffect(externalQuery) { if (externalQuery != query) query = externalQuery }

    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val clearDescription = stringResource(R.string.search_clear)

    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            Modifier
                .weight(1f)
                .height(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(IxColors.Field)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            PathIcon(Glyphs.Search, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 2f)
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_hint),
                        color = IxColors.TextSecondary,
                        fontSize = 15.sp,
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onQueryChange(it)
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 15.sp),
                    cursorBrush = SolidColor(IxColors.TextPrimary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            keyboard?.hide()
                            focusManager.clearFocus()
                        },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button) {
                            query = ""
                            onQueryChange("")
                        }
                        .semantics { contentDescription = clearDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.Close, tint = IxColors.TextSecondary, size = 16.dp, strokeWidth = 2.2f)
                }
            }
        }

        val menuDescription = stringResource(R.string.menu_description)
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(IxColors.Button)
                .clickable(role = Role.Button, onClick = onMenuClick)
                .semantics { contentDescription = menuDescription },
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Sliders, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        }
    }
}

/** All / Favorites / Private. */
@Composable
fun HomeTabs(selected: HomeTab, onSelect: (HomeTab) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(26.dp),
    ) {
        TabItem(stringResource(R.string.tab_all), null, selected == HomeTab.All) { onSelect(HomeTab.All) }
        TabItem(stringResource(R.string.tab_favorites), Glyphs.Star, selected == HomeTab.Favorites) {
            onSelect(HomeTab.Favorites)
        }
        TabItem(stringResource(R.string.tab_private), Glyphs.Lock, selected == HomeTab.Private) {
            onSelect(HomeTab.Private)
        }
    }
}

@Composable
private fun TabItem(label: String, glyph: List<String>?, selected: Boolean, onClick: () -> Unit) {
    val color = if (selected) IxColors.TextPrimary else IxColors.TextSecondary
    val indicator = if (selected) IxColors.TextPrimary else Color.Transparent
    // The underline is drawn behind the tab instead of being a child that fills the width.
    // A fill-width child would make the first tab take the whole row and squeeze the others.
    Row(
        Modifier
            .clickable(role = Role.Tab, onClick = onClick)
            .drawBehind {
                val thickness = 2.dp.toPx()
                drawRect(
                    color = indicator,
                    topLeft = Offset(0f, size.height - thickness),
                    size = Size(size.width, thickness),
                )
            }
            .padding(top = 12.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (glyph != null) PathIcon(glyph, tint = color, size = 15.dp, strokeWidth = 2f)
        Text(
            text = label,
            color = color,
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}
