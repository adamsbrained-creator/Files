package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import ix.app.files.R
import ix.app.files.data.StorageInfo
import ix.app.files.data.ThemeMode
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import kotlin.math.roundToInt

/**
 * The full settings page: a storage summary on top, then rows in rounded cards, each with an icon tile,
 * its name, its current value and an arrow. Tools open their own pages on top of this one.
 */
@Composable
fun SettingsScreen(
    storage: StorageInfo,
    freeform: Boolean,
    grid: Boolean,
    timeline: Boolean,
    selectionPills: Boolean,
    themeMode: ThemeMode,
    showHidden: Boolean,
    version: String,
    onBack: () -> Unit,
    onView: () -> Unit,
    /** The name of the Home built in the constructor, or null while the original Home is in use. */
    customHomeName: String?,
    onCustomizeHome: () -> Unit,
    onThemeChange: (ThemeMode) -> Unit,
    onShowHiddenChange: (Boolean) -> Unit,
    onStorage: () -> Unit,
    onDuplicates: () -> Unit,
    onCleaner: () -> Unit,
    onInsights: () -> Unit,
    onApps: () -> Unit,
    onTrash: () -> Unit,
    onPrivate: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    var themeDialog by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val privateValue = stringResource(remember { privateLockLabel(context) })

    val homeValue = stringResource(if (freeform) R.string.menu_home_freeform else R.string.menu_home_grid)
    val folderValue = stringResource(
        when {
            timeline -> R.string.menu_timeline
            grid -> R.string.menu_grid
            else -> R.string.menu_list
        },
    )
    val selectingValue = stringResource(if (selectionPills) R.string.menu_selection_pills else R.string.menu_selection_bar)
    val themeValue = stringResource(
        when (themeMode) {
            ThemeMode.System -> R.string.theme_system
            ThemeMode.Light -> R.string.theme_light
            ThemeMode.Dark -> R.string.theme_dark
        },
    )

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Text(
                    text = stringResource(R.string.settings_title),
                    color = IxColors.TextPrimary,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 4.dp),
                )
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(start = 18.dp, end = 18.dp, top = 4.dp, bottom = bottomInset + 28.dp),
            ) {
                StorageCard(storage, onCleaner)

                GroupLabel(stringResource(R.string.settings_group_view))
                GroupCard {
                    SettingsRow(
                        Glyphs.Sliders,
                        stringResource(R.string.view_customize_home),
                        customHomeName ?: stringResource(R.string.view_customize_home_original),
                        onCustomizeHome,
                    )
                    RowDivider()
                    SettingsRow(Glyphs.Home, stringResource(R.string.view_home_layout), homeValue, onView)
                    RowDivider()
                    SettingsRow(Glyphs.Stack, stringResource(R.string.view_folder_layout), folderValue, onView)
                    RowDivider()
                    SettingsRow(Glyphs.Check, stringResource(R.string.view_selecting), selectingValue, onView)
                }

                GroupLabel(stringResource(R.string.settings_group_look))
                GroupCard {
                    SettingsRow(Glyphs.Palette, stringResource(R.string.settings_appearance), themeValue) { themeDialog = true }
                    RowDivider()
                    SettingsRow(Glyphs.Eye, stringResource(R.string.menu_hidden), "", null) {
                        Switch(
                            checked = showHidden,
                            onCheckedChange = onShowHiddenChange,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = IxColors.Background,
                                checkedTrackColor = IxColors.TextPrimary,
                                uncheckedThumbColor = IxColors.TextSecondary,
                                uncheckedTrackColor = IxColors.Chip,
                                uncheckedBorderColor = IxColors.Outline,
                            ),
                        )
                    }
                }

                GroupLabel(stringResource(R.string.settings_group_tools))
                GroupCard {
                    SettingsRow(Glyphs.Pie, stringResource(R.string.menu_storage), "", onStorage)
                    RowDivider()
                    SettingsRow(Glyphs.Copy, stringResource(R.string.menu_duplicates), "", onDuplicates)
                    RowDivider()
                    SettingsRow(Glyphs.Sparkle, stringResource(R.string.menu_cleaner), "", onCleaner)
                    RowDivider()
                    SettingsRow(Glyphs.Trend, stringResource(R.string.menu_insights), "", onInsights)
                    RowDivider()
                    SettingsRow(Glyphs.Apps, stringResource(R.string.menu_apps), "", onApps)
                    RowDivider()
                    SettingsRow(Glyphs.Trash, stringResource(R.string.menu_trash), "", onTrash)
                }

                GroupLabel(stringResource(R.string.settings_group_private))
                GroupCard {
                    SettingsRow(Glyphs.Lock, stringResource(R.string.settings_private), privateValue, onPrivate)
                }

                if (version.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    GroupCard {
                        SettingsRow(Glyphs.Info, stringResource(R.string.settings_about), version, null)
                    }
                }
            }
        }
    }

    if (themeDialog) {
        ThemeDialog(
            current = themeMode,
            onPick = {
                themeDialog = false
                onThemeChange(it)
            },
            onDismiss = { themeDialog = false },
        )
    }
}

/** The ring and the numbers at the top: how full the phone is, with a shortcut to Clean up. */
@Composable
private fun StorageCard(storage: StorageInfo, onCleaner: () -> Unit) {
    val track = IxColors.Chip
    val progress = Color_Orange
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(IxColors.Field)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 8.dp.toPx()
                val inset = stroke / 2
                val arcSize = Size(size.width - stroke, size.height - stroke)
                drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
                drawArc(
                    progress, -90f, 360f * storage.usedFraction, false, Offset(inset, inset), arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
            Text(
                text = "${(storage.usedFraction * 100).roundToInt()}%",
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
            )
        }
        Column(Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.menu_storage),
                color = IxColors.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = stringResource(
                    R.string.settings_storage_used,
                    formatFileSize(storage.usedBytes),
                    formatFileSize(storage.totalBytes),
                ),
                color = IxColors.TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        Box(
            Modifier
                .height(46.dp)
                .clip(CircleShape)
                .background(IxColors.TextPrimary)
                .clickable(role = Role.Button, onClick = onCleaner)
                .padding(horizontal = 18.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.menu_cleaner),
                color = IxColors.Background,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private val Color_Orange = androidx.compose.ui.graphics.Color(0xFFFF6A2B)

@Composable
private fun GroupLabel(text: String) {
    Text(
        text = text.uppercase(),
        color = IxColors.TextSecondary,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 8.dp, top = 26.dp, bottom = 10.dp),
    )
}

@Composable
private fun GroupCard(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(IxColors.Field),
    ) { content() }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 74.dp)
            .height(1.dp)
            .background(IxColors.Outline),
    )
}

/**
 * One line in a card: an icon tile, the name, the current [value] and an arrow. With a null [onClick] it is
 * not tappable and has no arrow; [trailing] replaces the arrow, for a switch.
 */
@Composable
private fun SettingsRow(
    icon: List<String>,
    title: String,
    value: String,
    onClick: (() -> Unit)?,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(IxColors.Background),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(icon, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.8f)
        }
        Text(
            text = title,
            color = IxColors.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (value.isNotEmpty()) {
            Text(
                text = value,
                color = IxColors.TextSecondary,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
        }
        if (trailing != null) {
            trailing()
        } else if (onClick != null) {
            PathIcon(Glyphs.ChevronRight, tint = IxColors.TextSecondary, size = 16.dp, strokeWidth = 2.2f)
        }
    }
}

/** Light, dark or follow the phone. */
@Composable
private fun ThemeDialog(current: ThemeMode, onPick: (ThemeMode) -> Unit, onDismiss: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = stringResource(R.string.settings_appearance),
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 6.dp),
            )
            listOf(
                ThemeMode.System to R.string.theme_system,
                ThemeMode.Light to R.string.theme_light,
                ThemeMode.Dark to R.string.theme_dark,
            ).forEach { (mode, label) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(IxColors.Field)
                        .clickable(role = Role.RadioButton) { onPick(mode) }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(label),
                        color = IxColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = if (mode == current) FontWeight.SemiBold else FontWeight.Medium,
                        modifier = Modifier.weight(1f),
                    )
                    if (mode == current) {
                        PathIcon(Glyphs.Check, tint = IxColors.TextPrimary, size = 20.dp, strokeWidth = 2.2f)
                    }
                }
            }
        }
    }
}

/**
 * What opens Private on this phone: a strong fingerprint or the screen lock, only the screen lock, or nothing
 * yet because no screen lock is set. The same check the unlock sheet makes.
 */
private fun privateLockLabel(context: android.content.Context): Int {
    val keyguard = context.getSystemService(android.app.KeyguardManager::class.java)
    if (keyguard == null || !keyguard.isDeviceSecure) return R.string.settings_private_none
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
        val biometrics = context.getSystemService(android.hardware.biometrics.BiometricManager::class.java)
        val strong = biometrics?.canAuthenticate(
            android.hardware.biometrics.BiometricManager.Authenticators.BIOMETRIC_STRONG,
        ) == android.hardware.biometrics.BiometricManager.BIOMETRIC_SUCCESS
        if (strong) return R.string.settings_private_biometric
    }
    return R.string.settings_private_value
}
