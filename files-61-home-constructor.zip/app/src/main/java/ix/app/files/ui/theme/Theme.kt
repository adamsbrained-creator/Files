package ix.app.files.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Every color the app draws with, for one look (dark or light). */
class IxPalette(
    val background: Color,
    val sheet: Color,
    val sheetBorder: Color,
    val field: Color,
    val button: Color,
    val chip: Color,
    val outline: Color,
    val handle: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val danger: Color,
    /** The "Modified ↓" sort button text and arrow. */
    val sortText: Color,
    val folderBack: Color,
    val folderPaper: Color,
    val folderFrontTop: Color,
    val folderFrontBottom: Color,
    val folderGlyph: Color,
    val fileTop: Color,
    val fileBottom: Color,
    val fileFold: Color,
    /** Bar and dot colors of the Storage screen, biggest kind first. */
    val kinds: List<Color>,
)

/** Colors lifted from the Home mockup. */
private val DarkPalette = IxPalette(
    background = Color(0xFF0E0E10),
    sheet = Color(0xFF141416),
    sheetBorder = Color(0xFF232327),
    field = Color(0xFF1A1A1D),
    button = Color(0xFF26262A),
    chip = Color(0xFF212125),
    outline = Color(0xFF2C2C31),
    handle = Color(0xFF3A3A40),
    textPrimary = Color(0xFFF3F3F4),
    textSecondary = Color(0xFFA4A4AB),
    accent = Color(0xFFFF6A2B),
    danger = Color(0xFFFF6B6B),
    sortText = Color(0xFFD8D8DC),
    // Gray folder, from the Files canvas mockup
    folderBack = Color(0xFF9A9AA2),
    folderPaper = Color(0xFFECECEE),
    folderFrontTop = Color(0xFFF4F4F5),
    folderFrontBottom = Color(0xFFC9C9CE),
    folderGlyph = Color(0xFF4A4A52),
    // Gray page icon used in the file list
    fileTop = Color(0xFF8A8A92),
    fileBottom = Color(0xFF5A5A61),
    fileFold = Color(0xFFB4B4BC),
    kinds = listOf(
        Color(0xFFFF6A2B),
        Color(0xFFD8D8DC),
        Color(0xFFA4A4AB),
        Color(0xFF7C7C84),
        Color(0xFF5A5A61),
        Color(0xFF45454B),
    ),
)

/**
 * The same roles on a light background. Text flips to near black, the orange gets a little deeper so it
 * stays readable on white, and the folders turn a mid gray so they do not vanish into the page.
 */
private val LightPalette = IxPalette(
    background = Color(0xFFF6F6F8),
    sheet = Color(0xFFFFFFFF),
    sheetBorder = Color(0xFFE0E0E6),
    field = Color(0xFFEDEDF1),
    button = Color(0xFFDEDEE4),
    chip = Color(0xFFE4E4EA),
    outline = Color(0xFFD4D4DA),
    handle = Color(0xFFC6C6CC),
    textPrimary = Color(0xFF111113),
    textSecondary = Color(0xFF66666E),
    accent = Color(0xFFE85A1C),
    danger = Color(0xFFD93A3A),
    sortText = Color(0xFF3A3A41),
    folderBack = Color(0xFF8E8E98),
    folderPaper = Color(0xFFF4F4F7),
    folderFrontTop = Color(0xFFCFCFD6),
    folderFrontBottom = Color(0xFFA0A0AA),
    folderGlyph = Color(0xFF2E2E34),
    fileTop = Color(0xFF8A8A92),
    fileBottom = Color(0xFF5A5A61),
    fileFold = Color(0xFFB4B4BC),
    kinds = listOf(
        Color(0xFFE85A1C),
        Color(0xFF2E2E34),
        Color(0xFF55555C),
        Color(0xFF7E7E86),
        Color(0xFFA2A2AA),
        Color(0xFFC6C6CC),
    ),
)

/**
 * The colors the screens use, as `IxColors.Background` and so on. Each one answers for the look that is
 * switched on right now, and anything that draws with them redraws when the look changes.
 * [IxFilesTheme] flips the switch.
 */
object IxColors {
    /** Backed by Compose state, so reading a color while drawing makes that drawing follow changes. */
    private var dark by mutableStateOf(true)

    /** The accent the person picked in the Home constructor, or null for the app's own orange. */
    private var accentOverride by mutableStateOf<Color?>(null)

    fun setAccent(color: Color?) {
        if (accentOverride != color) accentOverride = color
    }

    private val palette: IxPalette get() = if (dark) DarkPalette else LightPalette

    val isDark: Boolean get() = dark

    fun switchTo(darkLook: Boolean) {
        if (dark != darkLook) dark = darkLook
    }

    val Background: Color get() = palette.background
    val Sheet: Color get() = palette.sheet
    val SheetBorder: Color get() = palette.sheetBorder
    val Field: Color get() = palette.field
    val Button: Color get() = palette.button
    val Chip: Color get() = palette.chip
    val Outline: Color get() = palette.outline
    val Handle: Color get() = palette.handle

    val TextPrimary: Color get() = palette.textPrimary
    val TextSecondary: Color get() = palette.textSecondary

    val Accent: Color get() = accentOverride ?: palette.accent
    val Danger: Color get() = palette.danger
    val SortText: Color get() = palette.sortText

    val FolderBack: Color get() = palette.folderBack
    val FolderPaper: Color get() = palette.folderPaper
    val FolderFrontTop: Color get() = palette.folderFrontTop
    val FolderFrontBottom: Color get() = palette.folderFrontBottom
    val FolderGlyph: Color get() = palette.folderGlyph

    val FileTop: Color get() = palette.fileTop
    val FileBottom: Color get() = palette.fileBottom
    val FileFold: Color get() = palette.fileFold

    /** The color for the [index]th kind on the Storage screen. Past the last one, the last is reused. */
    fun kind(index: Int): Color {
        val list = palette.kinds
        return list[index.coerceIn(0, list.lastIndex)]
    }
}

private val IxDarkColorScheme = darkColorScheme(
    background = DarkPalette.background,
    surface = DarkPalette.sheet,
    surfaceContainer = DarkPalette.button,
    onBackground = DarkPalette.textPrimary,
    onSurface = DarkPalette.textPrimary,
    onSurfaceVariant = DarkPalette.textSecondary,
    primary = DarkPalette.textPrimary,
    onPrimary = DarkPalette.background,
    outline = DarkPalette.outline,
)

private val IxLightColorScheme = lightColorScheme(
    background = LightPalette.background,
    surface = LightPalette.sheet,
    surfaceContainer = LightPalette.sheet,
    onBackground = LightPalette.textPrimary,
    onSurface = LightPalette.textPrimary,
    onSurfaceVariant = LightPalette.textSecondary,
    primary = LightPalette.textPrimary,
    onPrimary = LightPalette.sheet,
    outline = LightPalette.outline,
)

/** [dark] picks the look. The caller works out what "follow the system" means. */
@Composable
fun IxFilesTheme(dark: Boolean, content: @Composable () -> Unit) {
    // Set before anything below is composed, so no frame is painted with the old colors.
    IxColors.switchTo(dark)
    MaterialTheme(
        colorScheme = if (dark) IxDarkColorScheme else IxLightColorScheme,
        content = content,
    )
}
