package ix.app.files.insights

import android.content.Context
import java.io.File
import java.io.IOException

/**
 * Keeps the habits, the sorting rules, the last storage snapshot and the "not now" answers on the phone.
 * The habits live in a small file in the app's own storage; the rest in the app's preferences.
 * Nothing here is ever sent anywhere.
 */
class InsightsStore(context: Context) {

    private val prefs = context.getSharedPreferences("insights", Context.MODE_PRIVATE)
    private val habitsFile = File(context.filesDir, "habits.txt")

    /** Whether the app may keep a history of what is opened and deleted. On by default. */
    var habitsOn: Boolean
        get() = prefs.getBoolean(KEY_HABITS_ON, true)
        set(value) {
            prefs.edit().putBoolean(KEY_HABITS_ON, value).apply()
        }

    fun loadHabits(): Habits = try {
        if (habitsFile.isFile) Habits.decode(habitsFile.readText()) else Habits()
    } catch (e: IOException) {
        Habits()
    }

    fun saveHabits(habits: Habits) {
        try {
            val temp = File(habitsFile.parentFile, habitsFile.name + ".tmp")
            temp.writeText(habits.encode())
            if (!temp.renameTo(habitsFile)) {
                habitsFile.writeText(habits.encode())
                temp.delete()
            }
        } catch (e: IOException) {
            // The history is a convenience. Not saving it once is no harm.
        }
    }

    fun clearHabits() {
        habitsFile.delete()
    }

    fun loadRules(): List<SortRule> = RuleText.decode(prefs.getString(KEY_RULES, null).orEmpty())

    fun saveRules(rules: List<SortRule>) {
        prefs.edit().putString(KEY_RULES, RuleText.encode(rules)).apply()
    }

    fun loadSnapshot(): StorageSnapshot? = prefs.getString(KEY_SNAPSHOT, null)?.let { StorageSnapshot.decode(it) }

    fun saveSnapshot(snapshot: StorageSnapshot) {
        prefs.edit().putString(KEY_SNAPSHOT, snapshot.encode()).apply()
    }

    /** Ids of suggestions answered with "not now", with when. */
    fun loadDismissed(): Map<String, Long> {
        val out = HashMap<String, Long>()
        for (line in prefs.getString(KEY_DISMISSED, null).orEmpty().lineSequence()) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val at = line.substring(0, tab).toLongOrNull() ?: continue
            out[line.substring(tab + 1)] = at
        }
        return out
    }

    fun saveDismissed(map: Map<String, Long>) {
        val text = map.entries.joinToString("\n") { "${it.value}\t${it.key.replace('\n', ' ')}" }
        prefs.edit().putString(KEY_DISMISSED, text).apply()
    }

    private companion object {
        const val KEY_HABITS_ON = "habits_on"
        const val KEY_RULES = "rules"
        const val KEY_SNAPSHOT = "snapshot"
        const val KEY_DISMISSED = "dismissed"
    }
}
