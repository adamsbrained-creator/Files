@file:OptIn(ExperimentalLayoutApi::class)

package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import ix.app.files.data.Block
import ix.app.files.data.BlockType
import ix.app.files.data.HomeCatalog
import ix.app.files.data.HomeLayout
import ix.app.files.data.HomePresets
import ix.app.files.data.IconStyle
import ix.app.files.data.Spacing
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

private val Undo = listOf("M9 14L4 9l5-5", "M4 9h10a6 6 0 0 1 0 12h-3")
private val Redo = listOf("M15 14l5-5-5-5", "M20 9H10a6 6 0 0 0 0 12h3")
private val EyeOff = listOf("M3 3l18 18", "M10 6a9 9 0 0 1 12 6s-1 2-3 4", "M6 8c-3 2-4 4-4 4s4 7 10 7c1 0 2 0 3-.5")
private val Grip = listOf("M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01")

private val OnAccent = Color(0xFF0C0C0E)
private val AccentChoices = listOf(0xFFFF6A2B, 0xFF4D8DFF, 0xFF2DBE82, 0xFFA87BFF, 0xFFFF5C8A, 0xFFFFB92E, 0xFF22C7D6, 0xFFE5484D)
private val BitChoices = listOf(0xFFE4E4E8, 0xFFFFE0D2, 0xFFD6E6FF, 0xFFD5F5E3, 0xFF2A2A30)

/** The width a Home is drawn at inside the previews. Every preview is a shrunk copy of a phone this wide. */
private val DESIGN_WIDTH = 390.dp

/**
 * The Home constructor. It first offers a set of ready layouts, then lets the person change the blocks, their order
 * and the look. Nothing is saved until Done.
 */
@Composable
internal fun HomeConstructor(
    session: ConstructorSession,
    data: HomeData,
    hasSavedLayout: Boolean,
    onDone: (HomeLayout) -> Unit,
    onClose: () -> Unit,
    onUseOriginal: () -> Unit,
) {
    val draft = session.draft
    val style = remember(draft.accent, draft.bitShow, draft.bitBody, draft.round, draft.icons) { draft.toStyle() }

    BackHandler {
        when {
            session.adding -> session.adding = false
            else -> onClose()
        }
    }

    CompositionLocalProvider(LocalHomeStyle provides style, LocalPreviewData provides data) {
        Box(
            Modifier
                .fillMaxSize()
                .background(IxColors.Background)
                // Swallows taps so nothing underneath, such as Settings, reacts to them.
                .pointerInput(Unit) { detectTapGestures { } },
        ) {
            when (session.stage) {
                ConstructorStage.Start -> StartScreen(session, onClose)
                ConstructorStage.Edit -> EditScreen(session, data, hasSavedLayout, onDone, onClose, onUseOriginal)
            }
            if (session.adding) AddBlockSheet(session)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun StartScreen(session: ConstructorSession, onClose: () -> Unit) {
    val st = LocalHomeStyle.current
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Skip",
                    color = IxColors.TextSecondary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(role = Role.Button, onClick = onClose).padding(12.dp),
                )
            }
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Start with a layout", color = IxColors.TextPrimary, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("Pick one, then change any block, color or order.", color = IxColors.TextSecondary, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp))
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 130.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(HomePresets.all, key = { it.key }) { preset ->
                    val on = session.pick == preset.key
                    val layout = remember(preset.key, session.draft.accent, session.draft.round, session.draft.icons) {
                        HomePresets.build(preset.key, look = session.draft)
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .border(2.dp, if (on) st.accent else Color.Transparent, RoundedCornerShape(20.dp))
                            .clickable(role = Role.RadioButton) { session.pick = preset.key }
                            .padding(6.dp),
                    ) {
                        Column {
                            PresetPreview(layout, Modifier.fillMaxWidth().height(250.dp))
                            Text(preset.name, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp))
                            Text(preset.description, color = IxColors.TextSecondary, fontSize = 12.sp)
                        }
                        if (on) {
                            Text(
                                "Selected",
                                color = OnAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 10.dp, end = 10.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(st.accent)
                                    .padding(horizontal = 10.dp, vertical = 3.dp),
                            )
                        }
                    }
                }
            }
        }
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, IxColors.Background)))
                .navigationBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(IxColors.Button)
                    .clickable(role = Role.Button) { session.startBlank() },
                contentAlignment = Alignment.Center,
            ) { PathIcon(Glyphs.Plus, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f) }
            Box(
                Modifier
                    .weight(1f)
                    .height(54.dp)
                    .clip(CircleShape)
                    .background(st.accent)
                    .clickable(role = Role.Button) { session.startWith(session.pick) },
                contentAlignment = Alignment.Center,
            ) {
                Text("Use ${HomePresets.find(session.pick).name} layout", color = OnAccent, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** A whole layout shrunk to a card, drawn with the real blocks. It never reacts to taps. */
@Composable
private fun PresetPreview(layout: HomeLayout, modifier: Modifier) {
    CompositionLocalProvider(LocalHomeStyle provides layout.toStyle()) {
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(IxColors.Background).border(1.dp, IxColors.Outline.copy(alpha = 0.4f), RoundedCornerShape(14.dp))) {
            ScaledBox(DESIGN_WIDTH, Modifier.fillMaxWidth()) {
                Inert(onClick = null) { PreviewColumn(layout, selectedId = null, onSelect = null) }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Edit
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun EditScreen(
    session: ConstructorSession,
    data: HomeData,
    hasSavedLayout: Boolean,
    onDone: (HomeLayout) -> Unit,
    onClose: () -> Unit,
    onUseOriginal: () -> Unit,
) {
    val st = LocalHomeStyle.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val sheetMax = maxHeight * 0.56f
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Top bar
            Row(Modifier.fillMaxWidth().height(60.dp).padding(start = 6.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                RoundIcon(Glyphs.Close, "Close", true, onClose)
                Column(Modifier.weight(1f).padding(start = 6.dp)) {
                    Text("Edit Home", color = IxColors.TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Draft · ${session.draft.visibleBlocks.size} blocks", color = IxColors.TextSecondary, fontSize = 12.sp)
                }
                RoundIcon(Undo, "Undo", session.canUndo) { session.undo() }
                RoundIcon(Redo, "Redo", session.canRedo) { session.redo() }
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .height(40.dp)
                        .clip(CircleShape)
                        .background(st.accent)
                        .clickable(role = Role.Button) { onDone(session.draft) }
                        .padding(horizontal = 22.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Done", color = OnAccent, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
            }
            Segmented(
                options = ConstructorTab.entries.map { it.label },
                selected = session.tab.ordinal,
                onSelect = { session.tab = ConstructorTab.entries[it] },
                modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
            when (session.tab) {
                ConstructorTab.Blocks -> BlocksTab(session, data, sheetMax)
                ConstructorTab.Layout -> LayoutTab(session, data, hasSavedLayout, onUseOriginal)
                ConstructorTab.Style -> StyleTab(session)
            }
        }
    }
}

@Composable
private fun RoundIcon(glyph: List<String>, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .semantics { contentDescription = description }
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        PathIcon(glyph, tint = if (enabled) IxColors.TextPrimary else IxColors.TextSecondary.copy(alpha = 0.4f), size = 24.dp, strokeWidth = 2f)
    }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val st = LocalHomeStyle.current
    Row(
        modifier.fillMaxWidth().height(44.dp).clip(CircleShape).background(IxColors.Field).padding(4.dp),
    ) {
        options.forEachIndexed { i, label ->
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(if (i == selected) st.accent else Color.Transparent)
                    .clickable(role = Role.Tab) { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (i == selected) OnAccent else IxColors.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val st = LocalHomeStyle.current
    Row(
        Modifier.fillMaxWidth().height(52.dp).clickable(role = Role.Switch) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = st.accent,
                uncheckedThumbColor = IxColors.TextSecondary,
                uncheckedTrackColor = IxColors.Chip,
                uncheckedBorderColor = IxColors.Outline,
            ),
        )
    }
}

/** Keeps whatever is inside from reacting to touches, and optionally makes the whole thing one tap target. */
@Composable
private fun Inert(onClick: (() -> Unit)?, content: @Composable () -> Unit) {
    Box {
        content()
        Box(
            Modifier
                .matchParentSize()
                .then(
                    if (onClick != null) {
                        Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
                    } else {
                        Modifier.pointerInput(Unit) { detectTapGestures { } }
                    },
                ),
        )
    }
}

/** The blocks of a layout in a column, as they sit on the Home. In the editor each one can be tapped to select it. */
@Composable
private fun PreviewColumn(layout: HomeLayout, selectedId: Int?, onSelect: ((Int) -> Unit)?) {
    val data = LocalPreviewData.current
    val editable = onSelect != null
    Column(
        Modifier.padding(top = 28.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(if (editable) 26.dp else layout.spacing.dp.dp),
    ) {
        if (layout.visibleBlocks.isEmpty()) {
            Text("No blocks yet", color = IxColors.TextSecondary, fontSize = 16.sp, modifier = Modifier.padding(top = 120.dp).fillMaxWidth().padding(horizontal = 20.dp))
        }
        layout.visibleBlocks.forEach { block ->
            androidx.compose.runtime.key(block.id) {
                if (editable) {
                    EditableBlock(block, data, selected = block.id == selectedId) { onSelect?.invoke(block.id) }
                } else {
                    HomeBlockContent(block, data, HomeActions())
                }
            }
        }
    }
}

/** The data the previews draw. Set once at the top of the constructor. */
internal val LocalPreviewData = androidx.compose.runtime.staticCompositionLocalOf<HomeData> {
    error("The constructor provides the preview data")
}

@Composable
private fun EditableBlock(block: Block, data: HomeData, selected: Boolean, onSelect: () -> Unit) {
    val st = LocalHomeStyle.current
    val dashed = remember { PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) }
    val line = if (selected) st.accent else IxColors.Outline
    Box(
        Modifier
            .padding(horizontal = 6.dp)
            .drawWithContent {
                drawContent()
                val w = (if (selected) 4.dp else 3.dp).toPx()
                drawRoundRect(
                    color = line,
                    topLeft = androidx.compose.ui.geometry.Offset(w / 2, w / 2),
                    size = androidx.compose.ui.geometry.Size(size.width - w, size.height - w),
                    cornerRadius = CornerRadius(30.dp.toPx()),
                    style = Stroke(width = w, pathEffect = if (selected) null else dashed),
                )
            }
            .padding(vertical = 8.dp),
    ) {
        Inert(onClick = onSelect) { HomeBlockContent(block, data, HomeActions()) }
        if (selected) {
            Text(
                block.title,
                color = OnAccent,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 18.dp, y = (-28).dp)
                    .clip(CircleShape)
                    .background(st.accent)
                    .padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
    }
}

/** One style of a block, drawn small. [selected] puts the accent border on it. */
@Composable
private fun StyleThumb(
    type: BlockType,
    styleKey: String,
    opts: Map<String, Boolean>,
    label: String,
    width: Dp,
    height: Dp,
    selected: Boolean,
    badge: String?,
    onClick: () -> Unit,
) {
    val st = LocalHomeStyle.current
    val data = LocalPreviewData.current
    Column(Modifier.width(width), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            Box(
                Modifier
                    .width(width)
                    .height(height)
                    .clip(RoundedCornerShape(14.dp))
                    .background(IxColors.Background)
                    .border(2.dp, if (selected) st.accent else IxColors.Outline.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            ) {
                ScaledBox(DESIGN_WIDTH, Modifier.fillMaxWidth()) {
                    Inert(onClick = onClick) {
                        Box(Modifier.padding(vertical = 10.dp)) { HomeBlockContent(Block(0, type, styleKey, false, opts), data, HomeActions()) }
                    }
                }
                // The thumbnail is small, so a transparent layer over all of it makes the whole card tappable.
                Box(Modifier.matchParentSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick))
            }
            if (badge != null) {
                Text(
                    badge,
                    color = OnAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(st.accent)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
            }
        }
        Text(label, color = if (selected) st.accent else IxColors.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Blocks tab
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun BlocksTab(session: ConstructorSession, data: HomeData, sheetMax: Dp) {
    val draft = session.draft
    run {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth().background(IxColors.Field), contentAlignment = Alignment.TopCenter) {
                Box(
                    Modifier
                        .padding(top = 10.dp)
                        .width(195.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                        .background(IxColors.Background)
                        .verticalScroll(rememberScrollState()),
                ) {
                    ScaledBox(DESIGN_WIDTH, Modifier.fillMaxWidth()) {
                        PreviewColumn(draft, session.selected) { session.selected = it }
                    }
                }
            }
            BlockSheet(session, sheetMax)
        }
    }
}

@Composable
private fun BlockSheet(session: ConstructorSession, maxHeight: Dp) {
    val st = LocalHomeStyle.current
    val block = session.selectedBlock
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = maxHeight)
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(IxColors.Sheet)
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 16.dp),
    ) {
        if (block == null) {
            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Tap a block to edit it", color = IxColors.TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("Pick its style and options right here.", color = IxColors.TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
                Box(
                    Modifier.height(44.dp).clip(CircleShape).background(st.accent).clickable(role = Role.Button) { session.adding = true }.padding(horizontal = 24.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Add block", color = OnAccent, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
            }
            return@Column
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(block.title, color = IxColors.TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                Text(block.styleLabel + if (block.hidden) " · hidden" else "", color = IxColors.TextSecondary, fontSize = 12.sp)
            }
            RoundIcon(Glyphs.Copy, "Duplicate", true) { session.duplicateSelected() }
            RoundIcon(if (block.hidden) Glyphs.Eye else EyeOff, if (block.hidden) "Show" else "Hide", true) {
                session.update(block.copy(hidden = !block.hidden))
            }
            RoundIcon(Glyphs.Trash, "Delete", true) { session.removeSelected() }
        }
        Text("Style", color = IxColors.TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeCatalog.stylesOf(block.type).forEach { s ->
                StyleThumb(block.type, s.key, block.opts, s.label, 112.dp, 66.dp, selected = block.style == s.key, badge = null) {
                    session.update(block.copy(style = s.key))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        HomeCatalog.options.getValue(block.type).forEach { o ->
            SwitchRow(o.label, block.opt(o.key)) { session.update(block.withOpt(o.key, it)) }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Layout tab
// ---------------------------------------------------------------------------------------------------------------

private val ROW_HEIGHT = 76.dp
private val ROW_GAP = 10.dp

@Composable
private fun LayoutTab(session: ConstructorSession, data: HomeData, hasSavedLayout: Boolean, onUseOriginal: () -> Unit) {
    val st = LocalHomeStyle.current
    val draft = session.draft
    val stridePx = with(androidx.compose.ui.platform.LocalDensity.current) { (ROW_HEIGHT + ROW_GAP).toPx() }
    var dragId by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableStateOf(0f) }

    run {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()) {
            Text("Drag to reorder. Tap the eye to hide a block.", color = IxColors.TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 12.dp))
            draft.blocks.forEach { block ->
                androidx.compose.runtime.key(block.id) {
                    val dragging = dragId == block.id
                    val on = session.selected == block.id
                    Row(
                        Modifier
                            .padding(horizontal = 20.dp)
                            .padding(bottom = ROW_GAP)
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                            .fillMaxWidth()
                            .height(ROW_HEIGHT)
                            .clip(RoundedCornerShape(20.dp))
                            .background(IxColors.Field)
                            .border(2.dp, if (on || dragging) st.accent else Color.Transparent, RoundedCornerShape(20.dp))
                            .clickable(role = Role.Button) { session.selected = block.id }
                            .padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Box(
                            Modifier
                                .size(width = 28.dp, height = 56.dp)
                                .pointerInput(block.id) {
                                    detectDragGestures(
                                        onDragStart = {
                                            session.checkpoint()
                                            dragId = block.id
                                            dragOffset = 0f
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragOffset += amount.y
                                            val at = session.draft.blocks.indexOfFirst { it.id == block.id }
                                            when {
                                                dragOffset > stridePx / 2 && at < session.draft.blocks.lastIndex -> {
                                                    session.live { it.moving(at, at + 1) }
                                                    dragOffset -= stridePx
                                                }

                                                dragOffset < -stridePx / 2 && at > 0 -> {
                                                    session.live { it.moving(at, at - 1) }
                                                    dragOffset += stridePx
                                                }
                                            }
                                        },
                                        onDragEnd = { dragId = null; dragOffset = 0f },
                                        onDragCancel = { dragId = null; dragOffset = 0f },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) { PathIcon(Grip, tint = IxColors.TextSecondary, size = 22.dp, strokeWidth = 3f) }
                        Box(Modifier.width(96.dp).height(56.dp).clip(RoundedCornerShape(10.dp)).background(IxColors.Background)) {
                            ScaledBox(DESIGN_WIDTH, Modifier.fillMaxWidth()) {
                                Inert(onClick = null) { Box(Modifier.padding(vertical = 10.dp)) { HomeBlockContent(block, data, HomeActions()) } }
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text(block.title, color = IxColors.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                            Text(block.styleLabel + if (block.hidden) " · hidden" else "", color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
                        }
                        RoundIcon(if (block.hidden) EyeOff else Glyphs.Eye, if (block.hidden) "Show" else "Hide", true) {
                            session.update(block.copy(hidden = !block.hidden))
                        }
                    }
                }
            }
            Row(
                Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.5.dp, IxColors.Outline, RoundedCornerShape(20.dp))
                    .clickable(role = Role.Button) { session.adding = true },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                PathIcon(Glyphs.Plus, tint = IxColors.TextSecondary, size = 20.dp, strokeWidth = 2f)
                Text("  Add block", color = IxColors.TextSecondary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text("Spacing", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 8.dp))
            Segmented(
                options = Spacing.entries.map { it.label },
                selected = draft.spacing.ordinal,
                onSelect = { i -> session.edit { it.copy(spacing = Spacing.entries[i]) } },
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LinkText("Start from another layout") { session.stage = ConstructorStage.Start }
                if (hasSavedLayout) LinkText("Go back to the original Home", onUseOriginal)
            }
        }
    }
}

@Composable
private fun LinkText(text: String, onClick: () -> Unit) {
    Text(
        text,
        color = LocalHomeStyle.current.accent,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(role = Role.Button, onClick = onClick).padding(vertical = 10.dp, horizontal = 4.dp),
    )
}

// ---------------------------------------------------------------------------------------------------------------
// Style tab
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun StyleTab(session: ConstructorSession) {
    val st = LocalHomeStyle.current
    val draft = session.draft
    var sliding by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = 24.dp)) {
        SettingsCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.width(92.dp).height(150.dp).clip(RoundedCornerShape(12.dp)).background(IxColors.Background)) {
                    ScaledBox(DESIGN_WIDTH, Modifier.fillMaxWidth()) { Inert(onClick = null) { PreviewColumn(draft, null, null) } }
                }
                Column {
                    Text("Live preview", color = IxColors.TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Changes apply to your Home as you make them.", color = IxColors.TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                    Text(
                        draft.name,
                        color = IxColors.TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(CircleShape).background(IxColors.Chip).padding(horizontal = 12.dp, vertical = 6.dp),
                    )
                }
            }
        }
        SettingsCard("Accent") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AccentChoices.forEach { c ->
                    Swatch(Color(c), draft.accent == c.toInt()) { session.edit { it.copy(accent = c.toInt()) } }
                }
            }
        }
        SettingsCard("Bit") {
            SwitchRow("Show Bit on Home", draft.bitShow) { on -> session.edit { it.copy(bitShow = on) } }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                BitChoices.forEach { c ->
                    Swatch(Color(c), draft.bitBody == c.toInt()) { session.edit { it.copy(bitBody = c.toInt()) } }
                }
            }
        }
        SettingsCard("Corner roundness") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sharp", color = IxColors.TextSecondary, fontSize = 13.sp)
                Slider(
                    value = draft.round,
                    onValueChange = { v ->
                        if (!sliding) {
                            session.checkpoint()
                            sliding = true
                        }
                        session.live { it.copy(round = v) }
                    },
                    onValueChangeFinished = { sliding = false },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = st.accent,
                        activeTrackColor = st.accent,
                        inactiveTrackColor = IxColors.Outline,
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Text("Round", color = IxColors.TextSecondary, fontSize = 13.sp)
            }
        }
        SettingsCard("Folder icons") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconStyle.entries.forEach { style ->
                    val on = draft.icons == style
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(18.dp))
                            .border(2.dp, if (on) st.accent else Color.Transparent, RoundedCornerShape(18.dp))
                            .background(if (on) Color.Transparent else IxColors.Background)
                            .clickable(role = Role.RadioButton) { session.edit { it.copy(icons = style) } }
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(Glyphs.Downloads to Color(0xFFFFB48A), Glyphs.Images to Color(0xFFA8D5BA)).forEach { (g, fill) ->
                                val shape = RoundedCornerShape(10.dp)
                                when (style) {
                                    IconStyle.Pastel -> Box(Modifier.size(38.dp).clip(shape).background(fill), contentAlignment = Alignment.Center) {
                                        PathIcon(g, tint = Color(0xFF1A1A1E), size = 21.dp, strokeWidth = 2f)
                                    }

                                    IconStyle.Mono -> Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
                                        PathIcon(g, tint = IxColors.TextSecondary, size = 21.dp, strokeWidth = 2f)
                                    }

                                    IconStyle.Outline -> Box(Modifier.size(38.dp).clip(shape).border(2.dp, st.accent, shape), contentAlignment = Alignment.Center) {
                                        PathIcon(g, tint = st.accent, size = 21.dp, strokeWidth = 2f)
                                    }
                                }
                            }
                        }
                        Text(style.label, color = if (on) st.accent else IxColors.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String? = null, content: @Composable () -> Unit) {
    Column(
        Modifier
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(IxColors.Field)
            .padding(16.dp),
    ) {
        if (title != null) Text(title, color = IxColors.TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
        content()
    }
}

@Composable
private fun Swatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(color)
            .then(if (selected) Modifier.border(2.dp, IxColors.TextPrimary, CircleShape) else Modifier)
            .clickable(role = Role.RadioButton, onClick = onClick),
    )
}

// ---------------------------------------------------------------------------------------------------------------
// Add a block
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun AddBlockSheet(session: ConstructorSession) {
    val st = LocalHomeStyle.current
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    val q = query.trim().lowercase()

    val sections = remember(q, group) {
        HomeCatalog.groups
            .filter { group == null || it.label == group }
            .flatMap { g -> g.types.map { g to it } }
            .mapNotNull { (g, type) ->
                val styles = HomeCatalog.stylesOf(type).filter {
                    q.isEmpty() || (type.label + " " + it.label + " " + g.label).lowercase().contains(q)
                }
                if (styles.isEmpty()) null else type to styles
            }
    }

    run {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { session.adding = false },
            contentAlignment = Alignment.BottomCenter,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(IxColors.Sheet)
                    .pointerInput(Unit) { detectTapGestures { } }
                    .imePadding()
                    .padding(horizontal = 20.dp),
            ) {
                Box(Modifier.padding(top = 10.dp).align(Alignment.CenterHorizontally).width(36.dp).height(4.dp).clip(CircleShape).background(IxColors.Handle))
                Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Add a block", color = IxColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    RoundIcon(Glyphs.Close, "Close", true) { session.adding = false }
                }
                Row(
                    Modifier.fillMaxWidth().height(48.dp).clip(CircleShape).background(IxColors.Field).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    PathIcon(Glyphs.Search, tint = IxColors.TextSecondary, size = 20.dp, strokeWidth = 2f)
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Search blocks", color = IxColors.TextSecondary, fontSize = 16.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = IxColors.TextPrimary, fontSize = 16.sp),
                            cursorBrush = SolidColor(st.accent),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    (listOf<String?>(null) + HomeCatalog.groups.map { it.label }).forEach { g ->
                        val on = group == g
                        Box(
                            Modifier
                                .height(40.dp)
                                .clip(CircleShape)
                                .background(if (on) st.accent else IxColors.Field)
                                .clickable(role = Role.Tab) { group = g }
                                .padding(horizontal = 20.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text(g ?: "All", color = if (on) OnAccent else IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
                    if (sections.isEmpty()) {
                        item { Text("No blocks match.", color = IxColors.TextSecondary, fontSize = 15.sp, modifier = Modifier.padding(vertical = 30.dp).fillMaxWidth()) }
                    }
                    items(sections, key = { it.first.key }) { (type, styles) ->
                      Column {
                        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(type.label, color = IxColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                            Text("${styles.size} styles", color = IxColors.TextSecondary, fontSize = 13.sp)
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            styles.forEach { s ->
                                val inUse = session.draft.blocks.any { it.type == type && it.style == s.key }
                                StyleThumb(type, s.key, emptyMap(), s.label, 150.dp, 92.dp, selected = false, badge = if (inUse) "In use" else null) {
                                    session.add(type, s.key)
                                }
                            }
                        }
                      }
                    }
                }
            }
        }
    }
}
