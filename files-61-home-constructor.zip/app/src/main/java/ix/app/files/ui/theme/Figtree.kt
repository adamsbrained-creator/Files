package ix.app.files.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import ix.app.files.R

/**
 * Figtree (SIL Open Font License, see assets/licenses/Figtree-OFL.txt). Only the welcome pages use it.
 * Static Latin files for the four weights those pages draw with.
 */
val Figtree = FontFamily(
    Font(R.font.figtree_regular, FontWeight.Normal),
    Font(R.font.figtree_semibold, FontWeight.SemiBold),
    Font(R.font.figtree_bold, FontWeight.Bold),
    Font(R.font.figtree_extrabold, FontWeight.ExtraBold),
)
