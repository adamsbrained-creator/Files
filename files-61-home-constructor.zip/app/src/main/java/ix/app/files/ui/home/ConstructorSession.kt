package ix.app.files.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ix.app.files.data.Block
import ix.app.files.data.BlockType
import ix.app.files.data.HomeLayout
import ix.app.files.data.HomePresets

enum class ConstructorStage { Start, Edit }

enum class ConstructorTab(val label: String) { Blocks("Blocks"), Layout("Layout"), Style("Style") }

/**
 * The Home the person is building, before it is saved. It lives in the view model, so turning the phone does not lose
 * the draft. Every change goes through [edit] (or [checkpoint] followed by [live]) so it can be undone.
 */
class ConstructorSession(initial: HomeLayout?) {

    /** With no saved layout the person starts by picking one. With one, they go straight to editing it. */
    var stage by mutableStateOf(if (initial == null) ConstructorStage.Start else ConstructorStage.Edit)

    /** The preset highlighted on the start screen. */
    var pick by mutableStateOf("hero")

    var draft by mutableStateOf(initial ?: HomePresets.build("hero"))
        private set

    var tab by mutableStateOf(ConstructorTab.Blocks)

    /** The id of the block being edited. */
    var selected by mutableStateOf<Int?>(null)

    /** True while the "Add a block" sheet is open. */
    var adding by mutableStateOf(false)

    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    private val undoStack = ArrayDeque<HomeLayout>()
    private val redoStack = ArrayDeque<HomeLayout>()

    val selectedBlock: Block? get() = draft.blocks.firstOrNull { it.id == selected }

    private fun refresh() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
        if (selected != null && selectedBlock == null) selected = null
    }

    /** Remembers the draft as it is now, so the change that follows can be undone. */
    fun checkpoint() {
        undoStack.addLast(draft)
        if (undoStack.size > MAX_HISTORY) undoStack.removeFirst()
        redoStack.clear()
        refresh()
    }

    /** One undoable change. */
    fun edit(change: (HomeLayout) -> HomeLayout) {
        checkpoint()
        draft = change(draft)
    }

    /** A change that is part of a gesture already checkpointed, such as dragging a slider or a block. */
    fun live(change: (HomeLayout) -> HomeLayout) {
        draft = change(draft)
    }

    fun undo() {
        val previous = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(draft)
        draft = previous
        refresh()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(draft)
        draft = next
        refresh()
    }

    /** Starts from a preset. The accent, Bit, corners, icons and spacing already chosen stay. */
    fun startWith(key: String) {
        draft = HomePresets.build(key, look = draft)
        undoStack.clear()
        redoStack.clear()
        selected = null
        tab = ConstructorTab.Blocks
        stage = ConstructorStage.Edit
        refresh()
    }

    /** Starts from nothing and opens the block picker. */
    fun startBlank() {
        draft = draft.copy(name = "Custom", blocks = emptyList())
        undoStack.clear()
        redoStack.clear()
        selected = null
        tab = ConstructorTab.Blocks
        stage = ConstructorStage.Edit
        adding = true
        refresh()
    }

    fun add(type: BlockType, style: String) {
        checkpoint()
        val (layout, block) = draft.adding(type, style, after = selected)
        draft = layout
        selected = block.id
        adding = false
    }

    fun duplicateSelected() {
        val id = selected ?: return
        checkpoint()
        val (layout, copy) = draft.duplicating(id)
        draft = layout
        selected = copy?.id ?: selected
    }

    fun removeSelected() {
        val id = selected ?: return
        edit { it.removing(id) }
        selected = null
    }

    fun update(block: Block) = edit { it.withBlock(block) }

    private companion object {
        const val MAX_HISTORY = 60
    }
}
