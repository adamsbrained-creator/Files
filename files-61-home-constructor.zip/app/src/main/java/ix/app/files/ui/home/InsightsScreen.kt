package ix.app.files.ui.home

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.insights.AgeBand
import ix.app.files.insights.InsightsReport
import ix.app.files.insights.RuleAction
import ix.app.files.insights.RulePresets
import ix.app.files.insights.SortRule
import ix.app.files.insights.Suggestion
import ix.app.files.insights.SuggestionAction
import ix.app.files.insights.SuggestionKind
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date

/** How many files of a suggestion are listed under it. The buttons act on all of them. */
private const val PREVIEW_ROWS = 5

/**
 * What the app has worked out about your files: suggestions with a button each, where the space went, what you open
 * most, and the sorting rules. Nothing is moved or deleted until you tap a button and confirm; "Select all" hands
 * the files to the usual selection bar, whose Delete can be undone.
 */
@Composable
fun InsightsScreen(
    report: InsightsReport?,
    loading: Boolean,
    scanning: Boolean,
    rootPath: String,
    favorites: Set<String>,
    selection: Selection,
    rules: List<SortRule>,
    habitsOn: Boolean,
    ruleEditor: SortRule?,
    onBack: () -> Unit,
    onToggleFiles: (List<String>) -> Unit,
    onApply: (Suggestion) -> Unit,
    onDismiss: (Suggestion) -> Unit,
    onFileClick: (FileItem) -> Unit,
    onFolderClick: (String) -> Unit,
    onHabitsOn: (Boolean) -> Unit,
    onClearHabits: () -> Unit,
    onEditRule: (SortRule) -> Unit,
    onRuleEnabled: (SortRule, Boolean) -> Unit,
    onSaveRule: (SortRule) -> Unit,
    onDeleteRule: (String) -> Unit,
    onCloseRuleEditor: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val number = NumberFormat.getIntegerInstance()
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)
    var confirm by remember { mutableStateOf<Suggestion?>(null) }

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.insights_title),
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    Text(
                        text = if (report == null) {
                            ""
                        } else {
                            context.getString(
                                R.string.insights_summary,
                                formatFileSize(report.totalBytes),
                                number.format(report.fileCount),
                            )
                        },
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
            }

            if (loading || report == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = stringResource(R.string.insights_loading),
                        color = IxColors.TextSecondary,
                        fontSize = 14.sp,
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = bottomInset + 96.dp),
                ) {
                    if (scanning) {
                        item(key = "scanning") {
                            Text(
                                text = stringResource(R.string.insights_scanning_note),
                                color = IxColors.TextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                            )
                        }
                    }

                    // ---- Suggestions ----
                    item(key = "h:suggestions") { SectionTitle(R.string.insights_section_suggestions) }
                    if (report.suggestions.isEmpty()) {
                        item(key = "none") { Note(stringResource(R.string.insights_none)) }
                    }
                    for (s in report.suggestions) {
                        val paths = s.files.map { it.path }
                        item(key = "s:" + s.id) {
                            SuggestionHeader(
                                suggestion = s,
                                allSelected = paths.isNotEmpty() && paths.all { it in selection.paths },
                                onPrimary = {
                                    when (s.action) {
                                        is SuggestionAction.Review -> onToggleFiles(paths)
                                        is SuggestionAction.MoveTo, SuggestionAction.Trash -> confirm = s
                                        else -> onApply(s)
                                    }
                                },
                                onDismiss = { onDismiss(s) },
                            )
                        }
                        items(s.files.take(PREVIEW_ROWS), key = { "f:" + s.id + ":" + it.path }) { file ->
                            FileRow(
                                file = file,
                                selection = selection,
                                favorite = file.path in favorites,
                                onOpen = { onFileClick(file) },
                                hint = placeOf(file.path, rootPath, rootLabel),
                            )
                        }
                        if (s.files.size > PREVIEW_ROWS) {
                            item(key = "m:" + s.id) {
                                Text(
                                    text = context.getString(R.string.apps_and_more, s.files.size - PREVIEW_ROWS),
                                    color = IxColors.TextSecondary,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(start = 20.dp, top = 4.dp, bottom = 4.dp),
                                )
                            }
                        }
                    }

                    // ---- Storage ----
                    item(key = "h:storage") { SectionTitle(R.string.insights_section_storage) }
                    item(key = "where") {
                        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Label(R.string.insights_where)
                            val biggest = report.folders.maxOfOrNull { it.bytes } ?: 1L
                            for (folder in report.folders) {
                                BarRow(
                                    label = File(folder.path).name.ifEmpty { rootLabel },
                                    value = formatFileSize(folder.bytes),
                                    fraction = folder.bytes.toFloat() / biggest.coerceAtLeast(1L),
                                    onClick = { onFolderClick(folder.path) },
                                )
                            }
                        }
                    }
                    item(key = "age") {
                        Column(
                            Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Label(R.string.insights_age)
                            val biggest = report.ages.maxOfOrNull { it.bytes } ?: 1L
                            for (age in report.ages) {
                                BarRow(
                                    label = stringResource(ageLabel(age.band)),
                                    value = formatFileSize(age.bytes),
                                    fraction = age.bytes.toFloat() / biggest.coerceAtLeast(1L),
                                    onClick = null,
                                )
                            }
                        }
                    }
                    item(key = "growth") {
                        Column(
                            Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Label(R.string.insights_growth)
                            val since = report.growthSince
                            when {
                                since == null -> Note(stringResource(R.string.insights_growth_wait), padded = false)
                                report.growth.isEmpty() -> Note(stringResource(R.string.insights_growth_none), padded = false)
                                else -> {
                                    Text(
                                        text = context.getString(
                                            R.string.insights_growth_since,
                                            DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(since)),
                                        ),
                                        color = IxColors.TextSecondary,
                                        fontSize = 12.sp,
                                    )
                                    for (g in report.growth.take(5)) {
                                        BarRow(
                                            label = g.path.removePrefix(rootPath).trim('/'),
                                            value = "+" + formatFileSize(g.deltaBytes),
                                            fraction = 0f,
                                            onClick = { onFolderClick(g.path) },
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // ---- Habits ----
                    item(key = "h:habits") { SectionTitle(R.string.insights_section_habits) }
                    item(key = "habits-switch") {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                                Text(
                                    text = stringResource(R.string.insights_habits_on),
                                    color = IxColors.TextPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium,
                                )
                                Text(
                                    text = stringResource(R.string.insights_habits_hint),
                                    color = IxColors.TextSecondary,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(top = 2.dp),
                                )
                            }
                            Switch(
                                checked = habitsOn,
                                onCheckedChange = onHabitsOn,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = IxColors.Background,
                                    checkedTrackColor = IxColors.TextPrimary,
                                    uncheckedThumbColor = IxColors.TextSecondary,
                                    uncheckedTrackColor = IxColors.Chip,
                                    uncheckedBorderColor = IxColors.Outline,
                                ),
                            )
                        }
                    }
                    if (report.topFolders.isEmpty() && report.topFiles.isEmpty()) {
                        item(key = "habits-empty") { Note(stringResource(R.string.insights_habits_empty)) }
                    } else {
                        if (report.topFolders.isNotEmpty()) {
                            item(key = "habits-folders-label") {
                                Box(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 6.dp)) {
                                    Label(R.string.insights_habits_folders)
                                }
                            }
                            items(report.topFolders, key = { "hf:" + it.path }) { folder ->
                                HabitRow(
                                    title = File(folder.path).name.ifEmpty { rootLabel },
                                    subtitle = placeOf(folder.path, rootPath, rootLabel),
                                    count = folder.count,
                                    onClick = { onFolderClick(folder.path) },
                                )
                            }
                        }
                        if (report.topFiles.isNotEmpty()) {
                            item(key = "habits-files-label") {
                                Box(Modifier.padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 6.dp)) {
                                    Label(R.string.insights_habits_files)
                                }
                            }
                            items(report.topFiles, key = { "hg:" + it.file.path }) { entry ->
                                HabitRow(
                                    title = entry.file.name + if (entry.file.extension.isEmpty()) "" else "." + entry.file.extension,
                                    subtitle = placeOf(entry.file.path, rootPath, rootLabel),
                                    count = entry.count,
                                    onClick = { onFileClick(entry.file) },
                                )
                            }
                        }
                    }
                    item(key = "habits-clear") {
                        Box(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                            InsightPill(stringResource(R.string.insights_habits_clear), danger = true, onClick = onClearHabits)
                        }
                    }

                    // ---- Rules ----
                    item(key = "h:rules") { SectionTitle(R.string.insights_section_rules) }
                    item(key = "rules-hint") {
                        Text(
                            text = stringResource(R.string.insights_rules_hint),
                            color = IxColors.TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp),
                        )
                    }
                    items(rules, key = { "r:" + it.id }) { rule ->
                        RuleRow(rule, onClick = { onEditRule(rule) }, onEnabled = { onRuleEnabled(rule, it) })
                    }
                    item(key = "rules-add") {
                        Column(
                            Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            InsightPill(stringResource(R.string.insights_rule_add), onClick = { onEditRule(blankRule()) })
                            val unused = RulePresets.all.filter { preset -> rules.none { it.id == preset.id } }
                            if (unused.isNotEmpty()) {
                                Label(R.string.insights_rules_presets)
                                Row(
                                    Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    for (preset in unused) {
                                        InsightPill(preset.name, onClick = { onSaveRule(preset) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val asking = confirm
    if (asking != null) {
        val moving = asking.action is SuggestionAction.MoveTo
        val target = (asking.action as? SuggestionAction.MoveTo)?.destPath?.removePrefix(rootPath)?.trim('/').orEmpty()
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(if (moving) R.string.insights_confirm_move_title else R.string.insights_confirm_trash_title)) },
            text = {
                Text(
                    if (moving) {
                        context.getString(R.string.insights_confirm_move, asking.count, formatFileSize(asking.bytes), target)
                    } else {
                        context.getString(R.string.insights_confirm_trash, asking.count, formatFileSize(asking.bytes))
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    onApply(asking)
                }) {
                    Text(
                        stringResource(if (moving) R.string.insights_move else R.string.insights_trash),
                        color = if (moving) IxColors.TextPrimary else IxColors.Danger,
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    if (ruleEditor != null) {
        RuleEditor(
            rule = ruleEditor,
            existing = rules.any { it.id == ruleEditor.id },
            onSave = onSaveRule,
            onDelete = onDeleteRule,
            onDismiss = onCloseRuleEditor,
        )
    }
}

/** A rule with nothing filled in yet, for the editor. */
private fun blankRule(): SortRule = SortRule(
    id = "rule-" + System.currentTimeMillis(),
    name = "",
    fromFolder = "",
    kinds = emptySet(),
    extensions = emptySet(),
    nameContains = "",
    olderThanDays = 0,
    action = RuleAction.Move,
    destFolder = "",
)

private fun ageLabel(band: AgeBand): Int = when (band) {
    AgeBand.UnderMonth -> R.string.insights_age_under_month
    AgeBand.Months1To6 -> R.string.insights_age_1_6
    AgeBand.Months6To12 -> R.string.insights_age_6_12
    AgeBand.OverYear -> R.string.insights_age_over_year
}

/** The folder a thing sits in, written from the top of storage: "Download/old". */
private fun placeOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}

private fun titleOf(context: Context, s: Suggestion): String = when (s.kind) {
    SuggestionKind.Rule -> s.subject
    SuggestionKind.Misplaced -> context.getString(R.string.insights_misplaced_title, s.count)
    SuggestionKind.OldScreenshots -> context.getString(R.string.insights_screenshots_title, s.count)
    SuggestionKind.DeleteHabit -> context.getString(R.string.insights_deletes_title, s.subject)
    SuggestionKind.OldDownloads -> context.getString(R.string.insights_old_downloads_title, s.count)
    SuggestionKind.BigUntouched -> context.getString(R.string.insights_big_title, s.count)
    SuggestionKind.FrequentFolder -> context.getString(R.string.insights_frequent_title, File(s.subject).name)
    SuggestionKind.StaleFolder -> context.getString(R.string.insights_stale_title, File(s.subject).name, formatFileSize(s.bytes))
    SuggestionKind.Growing -> context.getString(R.string.insights_growing_title, File(s.subject).name, formatFileSize(s.bytes))
}

private fun detailOf(context: Context, s: Suggestion): String = when (s.kind) {
    SuggestionKind.Rule ->
        if (s.action is SuggestionAction.Trash) {
            context.getString(R.string.insights_rule_trash, s.count, formatFileSize(s.bytes))
        } else {
            val dest = (s.action as? SuggestionAction.MoveTo)?.destPath?.substringAfterLast('/').orEmpty()
            context.getString(R.string.insights_rule_move, s.count, formatFileSize(s.bytes), dest)
        }
    SuggestionKind.Misplaced -> {
        val dest = s.subject
        val kindWord = when (dest) {
            "Pictures" -> R.string.insights_kind_pictures
            "Movies" -> R.string.insights_kind_videos
            "Music" -> R.string.insights_kind_songs
            else -> R.string.insights_kind_documents
        }
        context.getString(R.string.insights_misplaced_detail, formatFileSize(s.bytes), context.getString(kindWord), dest)
    }
    SuggestionKind.OldScreenshots -> context.getString(R.string.insights_screenshots_detail, formatFileSize(s.bytes))
    SuggestionKind.DeleteHabit -> context.getString(R.string.insights_deletes_detail, s.count, formatFileSize(s.bytes))
    SuggestionKind.OldDownloads -> context.getString(R.string.insights_old_downloads_detail, formatFileSize(s.bytes))
    SuggestionKind.BigUntouched -> context.getString(R.string.insights_big_detail, formatFileSize(s.bytes))
    SuggestionKind.FrequentFolder -> context.getString(R.string.insights_frequent_detail)
    SuggestionKind.StaleFolder -> context.getString(R.string.insights_stale_detail)
    SuggestionKind.Growing -> context.getString(R.string.insights_growing_detail)
}

/** The title and explanation of one suggestion, with its buttons. */
@Composable
private fun SuggestionHeader(
    suggestion: Suggestion,
    allSelected: Boolean,
    onPrimary: () -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val primary = when (suggestion.action) {
        is SuggestionAction.Review -> stringResource(if (allSelected) R.string.cleaner_deselect else R.string.cleaner_select)
        is SuggestionAction.MoveTo -> stringResource(R.string.insights_move)
        is SuggestionAction.Trash -> stringResource(R.string.insights_trash)
        is SuggestionAction.AddToHome -> stringResource(R.string.insights_add_home)
        is SuggestionAction.OpenFolder -> stringResource(R.string.apps_open)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 6.dp),
    ) {
        Text(
            text = titleOf(context, suggestion),
            color = IxColors.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = detailOf(context, suggestion),
            color = IxColors.TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 3.dp),
        )
        Row(
            Modifier.padding(top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            InsightPill(primary, danger = suggestion.action is SuggestionAction.Trash, onClick = onPrimary)
            InsightPill(stringResource(R.string.insights_not_now), onClick = onDismiss)
        }
    }
}

@Composable
private fun RuleRow(rule: SortRule, onClick: () -> Unit, onEnabled: (Boolean) -> Unit) {
    val context = LocalContext.current
    val from = rule.fromFolder.ifBlank { context.getString(R.string.insights_everywhere) }
    val to = if (rule.action == RuleAction.Trash) {
        context.getString(R.string.insights_rule_to_trash)
    } else {
        rule.destFolder
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = rule.name,
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "$from  →  $to",
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        Switch(
            checked = rule.enabled,
            onCheckedChange = onEnabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = IxColors.Background,
                checkedTrackColor = IxColors.TextPrimary,
                uncheckedThumbColor = IxColors.TextSecondary,
                uncheckedTrackColor = IxColors.Chip,
                uncheckedBorderColor = IxColors.Outline,
            ),
        )
    }
}

@Composable
private fun HabitRow(title: String, subtitle: String, count: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                color = IxColors.TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(
            text = LocalContext.current.getString(R.string.insights_times, count),
            color = IxColors.Accent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** A name and a size with a bar behind them, as long as the size is next to the biggest one. */
@Composable
private fun BarRow(label: String, value: String, fraction: Float, onClick: (() -> Unit)?) {
    val base = Modifier
        .fillMaxWidth()
        .height(36.dp)
        .clip(RoundedCornerShape(10.dp))
        .background(IxColors.Field)
    Box(if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base) {
        if (fraction > 0f) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction.coerceIn(0.02f, 1f))
                    .background(IxColors.Chip),
            )
        }
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                color = IxColors.TextPrimary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(text = value, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun SectionTitle(label: Int) {
    Text(
        text = stringResource(label),
        color = IxColors.TextPrimary,
        fontSize = 19.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 28.dp, bottom = 4.dp),
    )
}

@Composable
private fun Label(label: Int) {
    Text(
        text = stringResource(label),
        color = IxColors.Accent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
    )
}

@Composable
private fun Note(text: String, padded: Boolean = true) {
    Text(
        text = text,
        color = IxColors.TextSecondary,
        fontSize = 13.sp,
        modifier = if (padded) Modifier.padding(horizontal = 20.dp, vertical = 6.dp) else Modifier,
    )
}

@Composable
internal fun InsightPill(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .height(36.dp)
            .clip(CircleShape)
            .background(IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (danger) IxColors.Danger else IxColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
        )
    }
}
