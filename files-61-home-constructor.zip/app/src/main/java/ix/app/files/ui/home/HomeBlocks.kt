@file:OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)

package ix.app.files.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.data.Block
import ix.app.files.data.BlockType
import ix.app.files.data.Category
import ix.app.files.data.CustomFolder
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.data.FolderStyle
import ix.app.files.data.HomeLayout
import ix.app.files.data.IconStyle
import ix.app.files.data.StorageInfo
import ix.app.files.ui.components.Bit
import ix.app.files.ui.components.BitPose
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import ix.app.files.util.formatStorage
import java.util.Calendar
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------------------------
// Look, data and actions shared by every block
// ---------------------------------------------------------------------------------------------------------------

/** The look the constructor's Style tab sets. Every block reads it, so a change shows everywhere at once. */
@Immutable
internal class HomeStyle(
    val accent: Color,
    val bitBody: Color,
    val bitShow: Boolean,
    val round: Float,
    val icons: IconStyle,
) {
    /** Corner radius of cards, from 10 dp (sharp) to 28 dp (round). */
    val card: Dp get() = (10 + round * 18).dp

    /** Corner radius of small things: icon badges, tiles. */
    val small: Dp get() = (6 + round * 10).dp
}

internal fun HomeLayout.toStyle() = HomeStyle(Color(accent), Color(bitBody), bitShow, round, icons)

internal val LocalHomeStyle = staticCompositionLocalOf { HomeLayout("", emptyList()).toStyle() }

/** What the blocks show. Real data on the Home, the same data in the constructor's previews. */
internal class HomeData(
    val storage: StorageInfo,
    val counts: Map<Category, Int>,
    val scanning: Boolean,
    val folderStyles: Map<Category, FolderStyle>,
    val customFolders: List<CustomFolder>,
    val order: List<String>,
    val refreshKey: Any?,
    val favoriteFolders: List<FolderItem>,
    val favoriteFiles: List<FileItem>,
    val favorites: Set<String>,
    val recent: List<FileItem>,
    val selection: Selection,
    val privateUnlocked: Boolean,
    /** True in the constructor, where the Recent peek bar is drawn as a block instead of being the real sheet. */
    val preview: Boolean = false,
)

/** What the blocks do when tapped. The defaults do nothing, which is what the constructor's previews want. */
internal class HomeActions(
    val onMenu: () -> Unit = {},
    val onStorage: () -> Unit = {},
    val onCleaner: () -> Unit = {},
    val onDuplicates: () -> Unit = {},
    val onInsights: () -> Unit = {},
    val onApps: () -> Unit = {},
    val onTrash: () -> Unit = {},
    val onPrivate: () -> Unit = {},
    val onFavorites: () -> Unit = {},
    val onCategory: (Category) -> Unit = {},
    val onCategoryLong: (Category) -> Unit = {},
    val onCustom: (CustomFolder) -> Unit = {},
    val onCustomLong: (CustomFolder) -> Unit = {},
    val onNewFolder: () -> Unit = {},
    val onFolder: (FolderItem) -> Unit = {},
    val onFile: (FileItem) -> Unit = {},
    val query: String = "",
    val onQuery: (String) -> Unit = {},
    val onFilters: () -> Unit = {},
    val filtersOpen: Boolean = false,
    /** The Type / Size / Date chips, drawn under the search block while the filters are open. */
    val filters: @Composable () -> Unit = {},
)

/** The data the blocks show, taken from the Home state. */
internal fun homeData(state: HomeState, storage: StorageInfo, selection: Selection, preview: Boolean = false) = HomeData(
    storage = storage,
    counts = state.counts,
    scanning = state.scanning,
    folderStyles = state.folderStyles,
    customFolders = state.customFolders,
    order = state.homeOrder,
    refreshKey = state.browserPath,
    favoriteFolders = state.favoriteFolders,
    favoriteFiles = state.favoriteFiles,
    favorites = state.favorites,
    recent = state.recent,
    selection = selection,
    privateUnlocked = state.privateUnlocked,
    preview = preview,
)

private val Ink = Color(0xFF1A1A1E)

private val Pastels = mapOf(
    Category.Downloads to Color(0xFFFFB48A),
    Category.Images to Color(0xFFA8D5BA),
    Category.Videos to Color(0xFFF4A6B8),
    Category.Audio to Color(0xFFC3B1F0),
    Category.Docs to Color(0xFFF2D07A),
    Category.Apps to Color(0xFF9CCBEF),
)
private val CustomPastel = Color(0xFFD6D6DE)

// ---------------------------------------------------------------------------------------------------------------
// The Home as a column of blocks
// ---------------------------------------------------------------------------------------------------------------

/**
 * The Home built from the person's blocks. It scrolls, except while searching: then only the search block stays
 * (in the same place in the tree, so the keyboard stays up) and [results] fills the rest of the screen.
 */
@Composable
internal fun LayoutHome(
    layout: HomeLayout,
    data: HomeData,
    actions: HomeActions,
    searching: Boolean,
    onContentHeight: (Int) -> Unit,
    results: @Composable ColumnScope.() -> Unit,
    modifier: Modifier = Modifier,
) {
    val scroll = rememberScrollState()
    CompositionLocalProvider(LocalHomeStyle provides layout.toStyle()) {
        Column(
            modifier
                .fillMaxSize()
                .statusBarsPadding()
                .then(if (searching) Modifier else Modifier.verticalScroll(scroll)),
        ) {
            Column(
                Modifier
                    .onSizeChanged { if (!searching) onContentHeight(it.height) }
                    .padding(top = 12.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(layout.spacing.dp.dp),
            ) {
                for (block in layout.visibleBlocks) {
                    // The peek bar is the real Recent sheet, which sits on the bottom edge. It takes no room here.
                    if (block.type == BlockType.Recent && block.style == "peek") continue
                    key(block.id) {
                        if (!searching || block.type == BlockType.Search) HomeBlockContent(block, data, actions)
                    }
                }
            }
            if (searching) results() else Spacer(Modifier.navigationBarsPadding().height(96.dp))
        }
    }
}

/** One block, in the style and with the options it was given. */
@Composable
internal fun HomeBlockContent(block: Block, data: HomeData, a: HomeActions) {
    when (block.type) {
        BlockType.Header -> HeaderBlock(block, data, a)
        BlockType.Storage -> StorageBlock(block, data, a)
        BlockType.Search -> SearchBlock(block, a)
        BlockType.Folders -> FoldersBlock(block, data, a)
        BlockType.Favorites -> FavoritesBlock(block, data, a)
        BlockType.Recent -> RecentBlock(block, data, a)
        BlockType.Extra -> ExtraBlock(block, data, a)
    }
}

/**
 * Draws [content] at [designWidth] and shrinks it to the width it is given, so a whole Home fits in a small
 * preview. Taps still land on the right spot; the caller puts its own clickable on top to keep the content inert.
 */
@Composable
internal fun ScaledBox(designWidth: Dp, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Layout(content = content, modifier = modifier.clipToBounds()) { measurables, constraints ->
        val designPx = designWidth.roundToPx()
        val scale = constraints.maxWidth.toFloat() / designPx
        val placeables = measurables.map {
            it.measure(Constraints(minWidth = designPx, maxWidth = designPx, minHeight = 0, maxHeight = Constraints.Infinity))
        }
        val scaledHeight = ((placeables.maxOfOrNull { it.height } ?: 0) * scale).roundToInt()
        layout(constraints.maxWidth, scaledHeight.coerceIn(constraints.minHeight, constraints.maxHeight)) {
            placeables.forEach {
                it.placeWithLayer(0, 0) {
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = TransformOrigin(0f, 0f)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Small pieces
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun BitView(width: Dp, pose: BitPose = BitPose.Hello, modifier: Modifier = Modifier) {
    val st = LocalHomeStyle.current
    if (!st.bitShow) return
    Bit(
        pose = pose,
        description = "Bit",
        modifier = modifier.size(width = width, height = width * 0.875f),
        body = st.bitBody,
        accent = st.accent,
    )
}

@Composable
private fun AccentButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, quiet: Boolean = false) {
    val st = LocalHomeStyle.current
    Box(
        modifier
            .height(38.dp)
            .clip(CircleShape)
            .background(if (quiet) IxColors.Button else st.accent)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (quiet) st.accent else Ink,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
        )
    }
}

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val st = LocalHomeStyle.current
    Box(
        modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(st.card))
            .background(IxColors.Field),
    ) { content() }
}

@Composable
private fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(36.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(title, color = IxColors.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        if (action != null) {
            Text(
                text = action,
                color = LocalHomeStyle.current.accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(role = Role.Button, onClick = onAction)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun MenuButton(onClick: () -> Unit) {
    Box(
        Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { PathIcon(Glyphs.Sliders, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f) }
}

// ---------------------------------------------------------------------------------------------------------------
// Header
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun HeaderBlock(block: Block, data: HomeData, a: HomeActions) {
    val st = LocalHomeStyle.current
    val menu = block.opt("menu")
    val free = (data.storage.totalBytes - data.storage.usedBytes).coerceAtLeast(0L)
    when (block.style) {
        "classic" -> HomeHeader(data.storage, a.onStorage)

        "greeting" -> {
            val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
            val hello = when {
                hour < 12 -> "Good morning"
                hour < 18 -> "Good afternoon"
                else -> "Good evening"
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (st.bitShow) {
                    Box(Modifier.size(52.dp).clip(CircleShape).background(IxColors.Chip), contentAlignment = Alignment.BottomCenter) {
                        BitView(42.dp)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text(hello, color = IxColors.TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text("${formatFileSize(free)} free", color = IxColors.TextSecondary, fontSize = 14.sp)
                }
                if (menu) MenuButton(a.onMenu)
            }
        }

        "big" -> {
            val parts = formatFileSize(free).split(' ')
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(parts[0], color = IxColors.TextPrimary, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-2).sp)
                        Text(
                            " " + parts.getOrElse(1) { "" },
                            color = IxColors.TextSecondary,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                    }
                    Text("free on this phone", color = IxColors.TextSecondary, fontSize = 15.sp)
                }
                if (menu) MenuButton(a.onMenu)
            }
        }

        "tidy" -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            BitView(76.dp)
            Text("Everything’s tidy", color = IxColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text("${formatFileSize(free)} free", color = IxColors.TextSecondary, fontSize = 14.sp)
        }

        else -> Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Files",
                color = IxColors.TextPrimary,
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.weight(1f),
            )
            if (menu) MenuButton(a.onMenu)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Storage
// ---------------------------------------------------------------------------------------------------------------

private val SEGMENTS = listOf(0.4f, 0.25f, 0.2f, 0.15f)

@Composable
private fun StorageRing(fraction: Float, segmented: Boolean) {
    val st = LocalHomeStyle.current
    val track = IxColors.Outline
    val colors = listOf(st.accent, Pastels.getValue(Category.Images), Pastels.getValue(Category.Videos), Pastels.getValue(Category.Apps))
    val shown = fraction.coerceIn(0.02f, 1f)
    Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            val arc = Size(size.width - stroke, size.height - stroke)
            drawArc(track, 0f, 360f, false, topLeft, arc, style = Stroke(stroke))
            if (segmented) {
                var start = -90f
                val total = 360f * shown
                SEGMENTS.forEachIndexed { i, part ->
                    val sweep = total * part
                    drawArc(colors[i], start, (sweep - 2f).coerceAtLeast(0.5f), false, topLeft, arc, style = Stroke(stroke))
                    start += sweep
                }
            } else {
                drawArc(st.accent, -90f, 360f * shown, false, topLeft, arc, style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
        Text("${(fraction * 100).roundToInt()}%", color = IxColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun StorageBlock(block: Block, data: HomeData, a: HomeActions) {
    val st = LocalHomeStyle.current
    val s = data.storage
    val used = formatFileSize(s.usedBytes)
    val total = formatStorage(s.totalBytes)
    val free = formatFileSize((s.totalBytes - s.usedBytes).coerceAtLeast(0L))
    val tap = if (block.opt("tap")) a.onStorage else null
    val freeLabel: @Composable () -> Unit = {
        if (block.opt("free")) Text("$free free", color = IxColors.TextSecondary, fontSize = 13.sp)
    }

    when (block.style) {
        "thin" -> Column(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(st.small))
                .then(if (tap != null) Modifier.clickable(role = Role.Button, onClick = tap) else Modifier),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(used, color = IxColors.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                Text(" of $total used", color = IxColors.TextSecondary, fontSize = 15.sp, modifier = Modifier.weight(1f))
                if (tap != null) PathIcon(Glyphs.ChevronRight, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 2f)
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(IxColors.Outline)) {
                Box(Modifier.fillMaxWidth(s.usedFraction.coerceAtLeast(0.03f)).height(6.dp).clip(CircleShape).background(st.accent))
            }
            freeLabel()
        }

        "bar" -> Card(if (tap != null) Modifier.clickable(role = Role.Button, onClick = tap) else Modifier) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("$free free", color = IxColors.TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text("$used of $total used", color = IxColors.TextSecondary, fontSize = 13.sp)
                    }
                    if (block.opt("clean")) AccentButton("Clean up", a.onCleaner)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    val parts = listOf(
                        0.15f to Pastels.getValue(Category.Images),
                        0.10f to Pastels.getValue(Category.Videos),
                        0.08f to Pastels.getValue(Category.Apps),
                        0.05f to Pastels.getValue(Category.Audio),
                    )
                    val usedShare = s.usedFraction.coerceIn(0.05f, 1f)
                    parts.forEach { (w, c) -> Box(Modifier.weight(w * usedShare + 0.001f).height(10.dp).background(c)) }
                    Box(Modifier.weight((1f - usedShare * 0.38f).coerceAtLeast(0.05f)).height(10.dp).background(IxColors.Outline))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    listOf("Images" to Category.Images, "Videos" to Category.Videos, "Apps" to Category.Apps).forEach { (n, c) ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(Pastels.getValue(c)))
                            Text(n, color = IxColors.TextSecondary, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        else -> {
            val peeking = block.style == "peek"
            Box(Modifier.padding(top = if (peeking) 30.dp else 0.dp)) {
                Card(if (tap != null) Modifier.clickable(role = Role.Button, onClick = tap) else Modifier) {
                    Row(
                        Modifier.padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                    ) {
                        StorageRing(s.usedFraction, segmented = block.style == "seg")
                        Column(Modifier.weight(1f)) {
                            Text(used, color = IxColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            Text("of $total used", color = IxColors.TextSecondary, fontSize = 14.sp)
                            freeLabel()
                            if (block.opt("clean")) {
                                Spacer(Modifier.height(10.dp))
                                AccentButton("Clean up", a.onCleaner)
                            }
                        }
                    }
                }
                if (peeking) {
                    BitView(54.dp, modifier = Modifier.align(Alignment.TopEnd).offset(x = (-48).dp, y = (-30).dp))
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun SearchBlock(block: Block, a: HomeActions) {
    val bit = block.style == "bit"
    SearchRow(
        externalQuery = a.query,
        onQueryChange = a.onQuery,
        onMenuClick = a.onMenu,
        onFiltersClick = if (block.opt("filter")) a.onFilters else null,
        filtersOpen = a.filtersOpen,
        cornerRadius = 24.dp,
        underline = block.style == "line",
        leading = if (bit) {
            { Box(Modifier.size(30.dp).clip(CircleShape).background(IxColors.Chip), contentAlignment = Alignment.BottomCenter) { BitView(26.dp) } }
        } else {
            null
        },
        showMenu = block.opt("menu"),
    )
    if (a.filtersOpen) {
        Spacer(Modifier.height(10.dp))
        a.filters()
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Folders
// ---------------------------------------------------------------------------------------------------------------

/** A Home folder ready to draw: what it says and does, and the color of its pastel look. */
private class FolderView(val entry: FolderEntry, val fill: Color)

/** Walks the Home folders in their saved order and hands each one to [content]. Call it inside a layout. */
@Composable
private fun FolderLoop(data: HomeData, a: HomeActions, content: @Composable (FolderView) -> Unit) {
    val items = orderedItems(data.customFolders, data.order)
    items.forEach { item ->
        key(item.key) {
            val entry = rememberFolderEntry(
                item, data.counts, data.scanning, data.folderStyles, data.refreshKey,
                a.onCategory, a.onCategoryLong, a.onCustom, a.onCustomLong,
            )
            val pastel = when (item) {
                is GridItem.Builtin -> Pastels.getValue(item.category)
                is GridItem.Custom -> CustomPastel
            }
            content(FolderView(entry, entry.tint ?: pastel))
        }
    }
}

/** The icon of a folder, in the icon look the person picked. */
@Composable
private fun GlyphBadge(v: FolderView, size: Dp, shape: Shape) {
    val st = LocalHomeStyle.current
    val inner = size * 0.55f
    when (st.icons) {
        IconStyle.Pastel -> Box(Modifier.size(size).clip(shape).background(v.fill), contentAlignment = Alignment.Center) {
            PathIcon(v.entry.glyph, tint = Ink, size = inner, strokeWidth = 2f)
        }

        IconStyle.Mono -> Box(Modifier.size(size), contentAlignment = Alignment.Center) {
            PathIcon(v.entry.glyph, tint = IxColors.TextSecondary, size = inner, strokeWidth = 2f)
        }

        IconStyle.Outline -> Box(
            Modifier.size(size).clip(shape).border(2.dp, st.accent, shape),
            contentAlignment = Alignment.Center,
        ) { PathIcon(v.entry.glyph, tint = st.accent, size = inner, strokeWidth = 2f) }
    }
}

@Composable
private fun FoldersBlock(block: Block, data: HomeData, a: HomeActions) {
    val st = LocalHomeStyle.current
    val counts = block.opt("count")
    val tile = RoundedCornerShape(st.card * 0.85f)
    val badge = RoundedCornerShape(st.small)

    if (block.opt("title")) SectionHeader("Folders", "New folder", a.onNewFolder)

    // The tiles that sit in a grid get their width from the space there is.
    @Composable
    fun Grid(columns: Int, gap: Dp, cell: @Composable (FolderView, Modifier) -> Unit) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            val width = (maxWidth - gap * (columns - 1)) / columns
            FlowRow(
                maxItemsInEachRow = columns,
                horizontalArrangement = Arrangement.spacedBy(gap),
                verticalArrangement = Arrangement.spacedBy(gap),
            ) {
                FolderLoop(data, a) { v ->
                    cell(
                        v,
                        Modifier
                            .width(width)
                            .alpha(if (v.entry.faded) 0.5f else 1f)
                            .combinedClickable(role = Role.Button, onClick = v.entry.onClick, onLongClick = v.entry.onLongClick),
                    )
                }
            }
        }
    }

    when (block.style) {
        "compact" -> Grid(3, 12.dp) { v, m ->
            Column(
                m.height(100.dp).clip(tile).background(IxColors.Field).padding(14.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                GlyphBadge(v, 40.dp, badge)
                Column {
                    Text(v.entry.title, color = IxColors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (counts) Text(v.entry.countLabel, color = IxColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        "tiles" -> Grid(2, 12.dp) { v, m ->
            Row(
                m.clip(tile).background(IxColors.Field).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                GlyphBadge(v, 40.dp, badge)
                Column(Modifier.weight(1f)) {
                    Text(v.entry.title, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (counts) Text(v.entry.countLabel, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        "big" -> Grid(2, 12.dp) { v, m ->
            Column(
                m.height(108.dp).clip(RoundedCornerShape(st.card * 1.15f)).background(v.fill).padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Box(Modifier.size(36.dp).clip(badge).background(Color.White.copy(alpha = 0.5f)), contentAlignment = Alignment.Center) {
                    PathIcon(v.entry.glyph, tint = Ink, size = 20.dp, strokeWidth = 2f)
                }
                Column {
                    Text(v.entry.title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (counts) Text(v.entry.countLabel, color = Ink.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        "open" -> Grid(3, 12.dp) { v, m ->
            Column(m.padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                GlyphBadge(v, 64.dp, CircleShape)
                Spacer(Modifier.height(6.dp))
                Text(v.entry.title, color = IxColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (counts) Text(v.entry.countLabel, color = IxColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            }
        }

        "list" -> Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            FolderLoop(data, a) { v ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .alpha(if (v.entry.faded) 0.5f else 1f)
                        .combinedClickable(role = Role.Button, onClick = v.entry.onClick, onLongClick = v.entry.onLongClick),
                ) {
                    Row(
                        Modifier.fillMaxWidth().height(54.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        PathIcon(v.entry.glyph, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.8f)
                        Text(v.entry.title, color = IxColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (counts) Text(v.entry.countLabel, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(IxColors.Outline.copy(alpha = 0.5f)))
                }
            }
        }

        "chips" -> FlowRow(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            FolderLoop(data, a) { v ->
                Row(
                    Modifier
                        .height(42.dp)
                        .alpha(if (v.entry.faded) 0.5f else 1f)
                        .clip(CircleShape)
                        .background(IxColors.Chip)
                        .combinedClickable(role = Role.Button, onClick = v.entry.onClick, onLongClick = v.entry.onLongClick)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    PathIcon(v.entry.glyph, tint = IxColors.TextPrimary, size = 18.dp, strokeWidth = 1.9f)
                    Text(v.entry.title, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                }
            }
            Row(
                Modifier
                    .height(42.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, IxColors.Outline, CircleShape)
                    .clickable(role = Role.Button, onClick = a.onNewFolder)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                PathIcon(Glyphs.Plus, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 2f)
                Text("New folder", color = IxColors.TextSecondary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
        }

        // Classic: the gray folders of the original Home.
        else -> BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            val width = (maxWidth - 10.dp * (COLUMNS - 1)) / COLUMNS
            FlowRow(
                maxItemsInEachRow = COLUMNS,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                orderedItems(data.customFolders, data.order).forEach { item ->
                    key(item.key) {
                        HomeTile(
                            item = item,
                            counts = data.counts,
                            scanning = data.scanning,
                            styles = data.folderStyles,
                            refreshKey = data.refreshKey,
                            enabled = true,
                            onCategoryClick = a.onCategory,
                            onCategoryLongClick = a.onCategoryLong,
                            onCustomClick = a.onCustom,
                            onCustomLongClick = a.onCustomLong,
                            modifier = Modifier.width(width),
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Favorites and Recent
// ---------------------------------------------------------------------------------------------------------------

private class FavoriteRow(val title: String, val subtitle: String, val glyph: List<String>, val onClick: () -> Unit)

@Composable
private fun favoriteRows(data: HomeData, a: HomeActions, limit: Int): List<FavoriteRow> {
    val context = LocalContext.current
    val folders = data.favoriteFolders.map { f ->
        FavoriteRow(f.name, itemsLabel(context, f.childCount), Glyphs.Folder) { a.onFolder(f) }
    }
    val files = data.favoriteFiles.map { f ->
        val name = if (f.extension.isEmpty()) f.name else "${f.name}.${f.extension}"
        FavoriteRow(name, formatFileSize(f.sizeBytes), Glyphs.Docs) { a.onFile(f) }
    }
    return (folders + files).take(limit)
}

@Composable
private fun FavoritesBlock(block: Block, data: HomeData, a: HomeActions) {
    val st = LocalHomeStyle.current
    val rows = favoriteRows(data, a, 4)
    val title = block.opt("title")
    val rowsContent: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth()) {
            rows.forEach { r ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable(role = Role.Button, onClick = r.onClick)
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(st.small)).background(IxColors.Chip), contentAlignment = Alignment.Center) {
                        PathIcon(r.glyph, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.8f)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(r.title, color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(r.subtitle, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                    PathIcon(Glyphs.Star, tint = st.accent, size = 20.dp, strokeWidth = 2f)
                }
            }
        }
    }

    when {
        block.style == "plain" && rows.isEmpty() -> Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text("Favorites", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("None yet. Press and hold a file to add one.", color = IxColors.TextSecondary, fontSize = 14.sp)
            }
            BitView(48.dp, BitPose.Sleepy)
        }

        block.style == "card" -> {
            if (title) SectionHeader("Favorites", if (rows.isEmpty()) null else "See all", a.onFavorites)
            Card {
                if (rows.isEmpty()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        BitView(56.dp, BitPose.Sleepy)
                        Column {
                            Text("No favorites yet", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("Press and hold a file or folder, then tap Favorite.", color = IxColors.TextSecondary, fontSize = 13.sp)
                        }
                    }
                } else {
                    Box(Modifier.padding(10.dp)) { rowsContent() }
                }
            }
        }

        else -> {
            if (title) SectionHeader("Favorites", if (rows.isEmpty()) null else "See all", a.onFavorites)
            if (rows.isEmpty()) {
                Text(
                    "No favorites yet. Press and hold a file or folder, then tap Favorite.",
                    color = IxColors.TextSecondary,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            } else {
                Box(Modifier.padding(horizontal = 16.dp)) { rowsContent() }
            }
        }
    }
}

@Composable
private fun RecentBlock(block: Block, data: HomeData, a: HomeActions) {
    val st = LocalHomeStyle.current
    if (block.style == "row") {
        SectionHeader("Recent")
        if (data.recent.isEmpty()) {
            Text("Nothing recent yet", color = IxColors.TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 20.dp))
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            ) {
                data.recent.take(10).forEach { file ->
                    key(file.path) {
                        FileTile(
                            file = file,
                            selection = data.selection,
                            favorite = file.path in data.favorites,
                            onOpen = { a.onFile(file) },
                            modifier = Modifier.width(106.dp),
                        )
                    }
                }
            }
        }
        return
    }
    // The peek bar. On the real Home it is the Recent sheet itself, so it is only drawn here for the previews.
    if (!data.preview) return
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(IxColors.Sheet)
            .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 16.dp),
    ) {
        Box(Modifier.align(Alignment.CenterHorizontally).width(36.dp).height(4.dp).clip(CircleShape).background(IxColors.Handle))
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Recent", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("  Nothing recent yet", color = IxColors.TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f))
            if (block.opt("bit") && st.bitShow) BitView(46.dp)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// Extras
// ---------------------------------------------------------------------------------------------------------------

@Composable
private fun ExtraBlock(block: Block, data: HomeData, a: HomeActions) {
    val st = LocalHomeStyle.current
    when (block.style) {
        "dup" -> Card {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(st.small)).background(Pastels.getValue(Category.Docs)), contentAlignment = Alignment.Center) {
                    PathIcon(Glyphs.Copy, tint = Ink, size = 22.dp, strokeWidth = 2f)
                }
                Column(Modifier.weight(1f)) {
                    Text("Duplicates", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Find copies of the same file", color = IxColors.TextSecondary, fontSize = 12.sp)
                }
                AccentButton("Review", a.onDuplicates, quiet = true)
            }
        }

        "act" -> Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            listOf(
                "Clean up" to a.onCleaner,
                "Duplicates" to a.onDuplicates,
                "Insights" to a.onInsights,
                "Apps" to a.onApps,
                "Trash" to a.onTrash,
            ).forEachIndexed { i, (label, onClick) ->
                Box(
                    Modifier
                        .height(42.dp)
                        .clip(CircleShape)
                        .background(if (i == 0) st.accent else IxColors.Chip)
                        .clickable(role = Role.Button, onClick = onClick)
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, color = if (i == 0) Ink else IxColors.TextPrimary, fontSize = 15.sp, fontWeight = if (i == 0) FontWeight.ExtraBold else FontWeight.Medium, maxLines = 1)
                }
            }
        }

        "private" -> Card(Modifier.clickable(role = Role.Button, onClick = a.onPrivate)) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(st.small)).background(IxColors.Chip), contentAlignment = Alignment.Center) {
                    PathIcon(if (data.privateUnlocked) Glyphs.Unlock else Glyphs.Lock, tint = IxColors.TextPrimary, size = 22.dp, strokeWidth = 1.9f)
                }
                Column(Modifier.weight(1f)) {
                    Text("Private", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(if (data.privateUnlocked) "Unlocked" else "Locked, opens with your fingerprint or screen lock", color = IxColors.TextSecondary, fontSize = 12.sp)
                }
                PathIcon(Glyphs.ChevronRight, tint = IxColors.TextSecondary, size = 18.dp, strokeWidth = 2f)
            }
        }

        else -> Box(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(st.card))
                .background(st.accent.copy(alpha = 0.14f)),
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BitView(54.dp)
                Column(Modifier.weight(1f)) {
                    Text("Free up space", color = IxColors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("Old installers, empty files and big leftovers", color = IxColors.TextSecondary, fontSize = 12.sp)
                }
                AccentButton("Clean", a.onCleaner)
            }
        }
    }
}
