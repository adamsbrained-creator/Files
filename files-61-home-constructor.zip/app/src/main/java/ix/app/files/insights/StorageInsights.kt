package ix.app.files.insights

import ix.app.files.data.FileItem

/** How much one folder holds. */
class FolderSize(val path: String, val bytes: Long, val files: Int)

/** A folder that got bigger since the last snapshot. */
class Growth(val path: String, val deltaBytes: Long, val totalBytes: Long)

/** How long ago files were last changed. */
enum class AgeBand { UnderMonth, Months1To6, Months6To12, OverYear }

class AgeStat(val band: AgeBand, val bytes: Long, val files: Int)

/** Folder sizes at one moment, kept to see later what grew. */
class StorageSnapshot(val takenMillis: Long, val folderBytes: Map<String, Long>) {

    fun encode(): String {
        val sb = StringBuilder("IXSNAP1\n").append(takenMillis).append('\n')
        for ((path, bytes) in folderBytes) sb.append(bytes).append('\t').append(path).append('\n')
        return sb.toString()
    }

    companion object {
        fun decode(text: String): StorageSnapshot? {
            val lines = text.lineSequence().iterator()
            if (!lines.hasNext() || lines.next() != "IXSNAP1" || !lines.hasNext()) return null
            val taken = lines.next().toLongOrNull() ?: return null
            val map = HashMap<String, Long>()
            while (lines.hasNext()) {
                val line = lines.next()
                val tab = line.indexOf('\t')
                if (tab <= 0) continue
                val bytes = line.substring(0, tab).toLongOrNull() ?: continue
                map[line.substring(tab + 1)] = bytes
            }
            return StorageSnapshot(taken, map)
        }
    }
}

/** Adds up a scan: where the space went, how old it is, and what grew. */
object StorageInsights {

    const val DAY_MILLIS = 24L * 60 * 60 * 1000

    /** The folders below the root that hold [path], as written in [rootPath]: ["Download", "old"]. */
    internal fun foldersOf(path: String, rootPath: String): List<String> {
        val root = rootPath.trimEnd('/')
        if (!path.startsWith("$root/")) return emptyList()
        val parts = path.substring(root.length + 1).split('/')
        return parts.dropLast(1)
    }

    /** The folders at the top of storage by size, biggest first. Files lying loose at the top are one entry, the root. */
    fun folderSizes(files: List<FileItem>, rootPath: String): List<FolderSize> {
        val root = rootPath.trimEnd('/')
        val bytes = HashMap<String, Long>()
        val counts = HashMap<String, Int>()
        for (file in files) {
            val first = foldersOf(file.path, root).firstOrNull()
            val key = if (first == null) root else "$root/$first"
            bytes[key] = (bytes[key] ?: 0L) + file.sizeBytes
            counts[key] = (counts[key] ?: 0) + 1
        }
        return bytes.entries.map { FolderSize(it.key, it.value, counts.getValue(it.key)) }
            .sortedByDescending { it.bytes }
    }

    /** Sizes of the folders one and two levels below the root, to compare with a later snapshot. */
    fun snapshot(files: List<FileItem>, rootPath: String, now: Long): StorageSnapshot {
        val root = rootPath.trimEnd('/')
        val map = HashMap<String, Long>()
        for (file in files) {
            val dirs = foldersOf(file.path, root)
            if (dirs.isEmpty()) continue
            val first = "$root/${dirs[0]}"
            map[first] = (map[first] ?: 0L) + file.sizeBytes
            if (dirs.size >= 2) {
                val second = "$first/${dirs[1]}"
                map[second] = (map[second] ?: 0L) + file.sizeBytes
            }
        }
        return StorageSnapshot(now, map)
    }

    /**
     * Folders that grew by at least [minBytes] since [old], biggest growth first. A folder whose growth is nearly
     * all in one subfolder is left out, so the subfolder (where the growth really is) is named instead.
     */
    fun growth(old: StorageSnapshot?, now: StorageSnapshot, minBytes: Long): List<Growth> {
        if (old == null) return emptyList()
        val grown = HashMap<String, Growth>()
        for ((path, bytes) in now.folderBytes) {
            val delta = bytes - (old.folderBytes[path] ?: 0L)
            if (delta >= minBytes) grown[path] = Growth(path, delta, bytes)
        }
        return grown.values
            .filter { parent ->
                grown.values.none { child ->
                    child.path.substringBeforeLast('/') == parent.path && child.deltaBytes >= parent.deltaBytes * 0.8
                }
            }
            .sortedByDescending { it.deltaBytes }
    }

    /** Space by how long files have gone unchanged. Only bands that hold something are returned. */
    fun ageBands(files: List<FileItem>, now: Long): List<AgeStat> {
        val bytes = LongArray(AgeBand.entries.size)
        val counts = IntArray(AgeBand.entries.size)
        for (file in files) {
            val days = (now - file.modifiedMillis) / DAY_MILLIS
            val band = when {
                days < 30 -> AgeBand.UnderMonth
                days < 180 -> AgeBand.Months1To6
                days < 365 -> AgeBand.Months6To12
                else -> AgeBand.OverYear
            }
            bytes[band.ordinal] += file.sizeBytes
            counts[band.ordinal]++
        }
        return AgeBand.entries.filter { counts[it.ordinal] > 0 }.map { AgeStat(it, bytes[it.ordinal], counts[it.ordinal]) }
    }
}
