package ix.app.files.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.StorageInfo
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize

/**
 * The short menu behind the sliders button. It slides in from the right edge, next to the button, and holds
 * only what is used often: the Home and folder looks, five tools, and a way to the full settings page.
 */
@Composable
fun SideMenu(
    storage: StorageInfo,
    freeform: Boolean,
    grid: Boolean,
    timeline: Boolean,
    onFreeformChange: (Boolean) -> Unit,
    onFolderLayout: (grid: Boolean, timeline: Boolean) -> Unit,
    onStorage: () -> Unit,
    onDuplicates: () -> Unit,
    onCleaner: () -> Unit,
    onInsights: () -> Unit,
    onApps: () -> Unit,
    onTrash: () -> Unit,
    onAllSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    // The panel slides in when the menu opens and slides out again before whatever was tapped happens.
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    /** Slides the panel away, then runs [action]. */
    fun closeThen(action: () -> Unit) {
        if (!visible.targetState) return
        pending = action
        visible.targetState = false
    }

    // Once the panel has finished leaving, do what was asked.
    LaunchedEffect(visible.currentState, visible.isIdle) {
        if (visible.isIdle && !visible.currentState) {
            pending?.let {
                pending = null
                it()
            }
        }
    }

    BackHandler { closeThen(onDismiss) }

    val scrim by animateFloatAsState(if (visible.targetState) 0.6f else 0f, label = "scrim")

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = scrim))
            .pointerInput(Unit) { detectTapGestures { closeThen(onDismiss) } },
    ) {
        AnimatedVisibility(
            visibleState = visible,
            modifier = Modifier.align(Alignment.CenterEnd),
            enter = slideInHorizontally { it } + fadeIn(),
            exit = slideOutHorizontally { it } + fadeOut(),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .width(300.dp)
                    .clip(RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp))
                    .background(IxColors.Sheet)
                    // A tap on the panel itself must not close the menu.
                    .pointerInput(Unit) { detectTapGestures { } }
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 20.dp),
            ) {
                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            color = IxColors.TextPrimary,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Row(
                            Modifier.padding(top = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(6.dp)
                                    .clip(CircleShape)
                                    .background(IxColors.Chip),
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(storage.usedFraction)
                                        .height(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFF6A2B)),
                                )
                            }
                            Text(
                                text = formatFileSize(storage.usedBytes) + " / " + formatFileSize(storage.totalBytes),
                                color = IxColors.TextSecondary,
                                fontSize = 12.sp,
                            )
                        }
                    }

                    Section(stringResource(R.string.side_quick_view)) {
                        Segmented {
                            Pick(stringResource(R.string.menu_home_grid), !freeform, Modifier.weight(1f)) { onFreeformChange(false) }
                            Pick(stringResource(R.string.menu_home_freeform), freeform, Modifier.weight(1f)) { onFreeformChange(true) }
                        }
                        Segmented {
                            Pick(stringResource(R.string.menu_list), !grid && !timeline, Modifier.weight(1f)) { onFolderLayout(false, false) }
                            Pick(stringResource(R.string.menu_grid), grid && !timeline, Modifier.weight(1f)) { onFolderLayout(true, false) }
                            Pick(stringResource(R.string.menu_timeline), timeline, Modifier.weight(1f)) { onFolderLayout(grid, true) }
                        }
                    }

                    Section(stringResource(R.string.side_tools)) {
                        ToolRow(Glyphs.Pie, stringResource(R.string.menu_storage), { closeThen(onStorage) })
                        ToolRow(Glyphs.Copy, stringResource(R.string.menu_duplicates), { closeThen(onDuplicates) })
                        ToolRow(Glyphs.Sparkle, stringResource(R.string.menu_cleaner), { closeThen(onCleaner) })
                        ToolRow(Glyphs.Trend, stringResource(R.string.menu_insights), { closeThen(onInsights) })
                        ToolRow(Glyphs.Apps, stringResource(R.string.menu_apps), { closeThen(onApps) })
                        ToolRow(Glyphs.Trash, stringResource(R.string.menu_trash), { closeThen(onTrash) })
                    }
                }

                Row(
                    Modifier
                        .padding(top = 14.dp)
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(CircleShape)
                        .background(IxColors.TextPrimary)
                        .clickable(role = Role.Button) { closeThen(onAllSettings) },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Text(
                        text = stringResource(R.string.side_all_settings),
                        color = IxColors.Background,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    PathIcon(
                        Glyphs.ChevronRight,
                        tint = IxColors.Background,
                        size = 16.dp,
                        strokeWidth = 2.2f,
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title.uppercase(),
            color = IxColors.TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.2.sp,
            modifier = Modifier.padding(start = 4.dp),
        )
        content()
    }
}

@Composable
private fun Segmented(content: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(IxColors.Field)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) { content() }
}

@Composable
private fun Pick(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) IxColors.Button else Color.Transparent)
            .clickable(role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) IxColors.TextPrimary else IxColors.TextSecondary,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
private fun ToolRow(icon: List<String>, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(IxColors.Field)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PathIcon(icon, tint = IxColors.TextPrimary, size = 20.dp, strokeWidth = 1.8f)
        Text(
            text = label,
            color = IxColors.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        PathIcon(Glyphs.ChevronRight, tint = IxColors.TextSecondary, size = 16.dp, strokeWidth = 2.2f)
    }
}
