package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileKind
import ix.app.files.insights.RuleAction
import ix.app.files.insights.RuleText
import ix.app.files.insights.SortRule
import ix.app.files.ui.theme.IxColors

/** The kinds a rule can be limited to, in the order they are offered. */
private val ruleKinds = listOf(
    FileKind.Image to R.string.insights_kind_image,
    FileKind.Video to R.string.insights_kind_video,
    FileKind.Audio to R.string.insights_kind_audio,
    FileKind.Document to R.string.insights_kind_document,
    FileKind.App to R.string.insights_kind_app,
    FileKind.Other to R.string.insights_kind_other,
)

/**
 * Makes or changes one sorting rule: where to look, which files, how old, and what to suggest doing with them.
 * Saving is only possible while the rule is valid (it has a name, and a move has a destination inside storage).
 */
@Composable
fun RuleEditor(
    rule: SortRule,
    /** False for a rule being made, true for one that is already saved (it can then be deleted). */
    existing: Boolean,
    onSave: (SortRule) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember(rule.id) { mutableStateOf(rule.name) }
    var from by remember(rule.id) { mutableStateOf(rule.fromFolder) }
    var kinds by remember(rule.id) { mutableStateOf(rule.kinds) }
    var extensions by remember(rule.id) { mutableStateOf(rule.extensions.joinToString(", ")) }
    var contains by remember(rule.id) { mutableStateOf(rule.nameContains) }
    var days by remember(rule.id) { mutableStateOf(if (rule.olderThanDays > 0) rule.olderThanDays.toString() else "") }
    var action by remember(rule.id) { mutableStateOf(rule.action) }
    var dest by remember(rule.id) { mutableStateOf(rule.destFolder) }

    val candidate = SortRule(
        id = rule.id,
        name = name.trim(),
        fromFolder = from.trim(),
        kinds = kinds,
        extensions = RuleText.extensions(extensions),
        nameContains = contains.trim(),
        olderThanDays = days.toIntOrNull()?.coerceIn(0, 3650) ?: 0,
        action = action,
        destFolder = dest.trim(),
        enabled = rule.enabled,
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(stringResource(if (existing) R.string.insights_rule_edit else R.string.insights_rule_new)) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                RuleField(R.string.insights_rule_name, name) { name = it }
                RuleField(R.string.insights_rule_from, from) { from = it }
                Text(stringResource(R.string.insights_rule_kinds), color = IxColors.TextSecondary, fontSize = 12.sp)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for ((kind, label) in ruleKinds) {
                        RuleChip(stringResource(label), kind in kinds) {
                            kinds = if (kind in kinds) kinds - kind else kinds + kind
                        }
                    }
                }
                RuleField(R.string.insights_rule_ext, extensions) { extensions = it }
                RuleField(R.string.insights_rule_contains, contains) { contains = it }
                RuleField(R.string.insights_rule_days, days, number = true) { days = it.filter { c -> c.isDigit() }.take(4) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RuleChip(stringResource(R.string.insights_rule_action_move), action == RuleAction.Move) { action = RuleAction.Move }
                    RuleChip(stringResource(R.string.insights_rule_action_trash), action == RuleAction.Trash) { action = RuleAction.Trash }
                }
                if (action == RuleAction.Move) {
                    RuleField(R.string.insights_rule_dest, dest) { dest = it }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(candidate) }, enabled = candidate.valid) {
                Text(
                    stringResource(R.string.text_save),
                    color = if (candidate.valid) IxColors.TextPrimary else IxColors.TextSecondary,
                )
            }
        },
        dismissButton = {
            Row {
                if (existing) {
                    TextButton(onClick = { onDelete(rule.id) }) {
                        Text(stringResource(R.string.action_delete), color = IxColors.Danger)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            }
        },
    )
}

@Composable
private fun RuleField(label: Int, value: String, number: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        label = { Text(stringResource(label), fontSize = 12.sp) },
        keyboardOptions = if (number) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = IxColors.TextPrimary,
            unfocusedTextColor = IxColors.TextPrimary,
            cursorColor = IxColors.TextPrimary,
            focusedBorderColor = IxColors.TextSecondary,
            unfocusedBorderColor = IxColors.Outline,
            focusedLabelColor = IxColors.TextSecondary,
            unfocusedLabelColor = IxColors.TextSecondary,
        ),
    )
}

@Composable
private fun RuleChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(32.dp)
            .clip(CircleShape)
            .background(if (selected) IxColors.Accent else IxColors.Button)
            .clickable(role = Role.Checkbox, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) IxColors.Background else IxColors.TextPrimary,
            fontSize = 13.sp,
            maxLines = 1,
        )
    }
}
