package ix.app.files.ui.home

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.zIndex
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.data.CustomFolder
import ix.app.files.data.FolderStyle
import ix.app.files.data.orderKey
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.FolderIconChoices
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal val Category.titleRes: Int
    get() = when (this) {
        Category.Downloads -> R.string.category_downloads
        Category.Images -> R.string.category_images
        Category.Videos -> R.string.category_videos
        Category.Audio -> R.string.category_audio
        Category.Docs -> R.string.category_docs
        Category.Apps -> R.string.category_apps
    }

internal val Category.glyph: List<String>
    get() = when (this) {
        Category.Downloads -> Glyphs.Downloads
        Category.Images -> Glyphs.Images
        Category.Videos -> Glyphs.Videos
        Category.Audio -> Glyphs.Audio
        Category.Docs -> Glyphs.Docs
        Category.Apps -> Glyphs.Apps
    }

/** The icon the user picked, or [fallback] when they picked none. */
internal fun glyphFor(style: FolderStyle?, fallback: List<String>): List<String> =
    style?.icon?.let { key -> FolderIconChoices.firstOrNull { it.key == key }?.glyph } ?: fallback

/** The icon to draw for a built-in folder: the user's pick, or the folder's own. */
internal fun Category.glyphFor(style: FolderStyle?): List<String> = glyphFor(style, glyph)

/** The name to show for a folder: the user's own, or the built-in one. */
@Composable
internal fun Category.displayName(style: FolderStyle?): String = style?.name ?: stringResource(titleRes)

/** What one tile in the grid stands for. [key] is what the saved order uses. */
internal sealed interface GridItem {
    val key: String

    data class Builtin(val category: Category) : GridItem {
        override val key: String = category.orderKey()
    }

    data class Custom(val folder: CustomFolder) : GridItem {
        override val key: String = folder.orderKey()
    }
}

/** The tiles in the order the user saved. Tiles the order does not mention go last, in their usual order. */
internal fun orderedItems(customFolders: List<CustomFolder>, order: List<String>): List<GridItem> {
    val all = Category.entries.map<Category, GridItem> { GridItem.Builtin(it) } + customFolders.map { GridItem.Custom(it) }
    val byKey = all.associateBy { it.key }
    val first = order.mapNotNull { byKey[it] }.distinctBy { it.key }
    val placed = first.map { it.key }.toSet()
    return first + all.filter { it.key !in placed }
}

internal const val COLUMNS = 3
private const val LOADING = -1
private const val MISSING = -2
private val CELL_MIN_HEIGHT = 124.dp
private val GAP_X = 10.dp
private val GAP_Y = 16.dp

/**
 * The Home folders, three per row, sitting directly on the background: the six built-in ones, then any the
 * user added, then a "New folder" tile. Tap opens a folder, long press edits it. While [arranging], the
 * tiles can be dragged into a new order and nothing opens.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategoryGrid(
    counts: Map<Category, Int>,
    scanning: Boolean,
    styles: Map<Category, FolderStyle>,
    customFolders: List<CustomFolder>,
    /** Changes when the contents of a custom folder may have changed, so its count is read again. */
    refreshKey: Any?,
    order: List<String>,
    arranging: Boolean,
    onOrderChange: (List<String>) -> Unit,
    onArrangeDone: () -> Unit,
    onCategoryClick: (Category) -> Unit,
    onCategoryLongClick: (Category) -> Unit,
    onCustomClick: (CustomFolder) -> Unit,
    onCustomLongClick: (CustomFolder) -> Unit,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current
    val savedItems = orderedItems(customFolders, order)
    val savedKeys = savedItems.map { it.key }

    // While a tile is dragged, [working] holds the order being tried. After the drop, [pending] keeps the new
    // order on screen until the saved order catches up, so the tiles do not jump back for a frame.
    var working by remember { mutableStateOf(savedKeys) }
    var pending by remember { mutableStateOf<List<String>?>(null) }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOrigin by remember { mutableStateOf(Offset.Zero) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var cellSize by remember { mutableStateOf(IntSize.Zero) }

    LaunchedEffect(savedKeys) { pending = null }

    val shownKeys = if (dragKey != null) working else pending ?: savedKeys
    val itemsByKey = savedItems.associateBy { it.key }
    val shown = shownKeys.mapNotNull { itemsByKey[it] }

    val currentSavedKeys by rememberUpdatedState(savedKeys)
    val currentShownKeys by rememberUpdatedState(shownKeys)
    val currentOnOrderChange by rememberUpdatedState(onOrderChange)

    val gapXPx = with(density) { GAP_X.toPx() }
    val gapYPx = with(density) { GAP_Y.toPx() }

    /** Where slot [index] sits inside the grid, in pixels. */
    fun slotPosition(index: Int): Offset = Offset(
        (index % COLUMNS) * (cellSize.width + gapXPx),
        (index / COLUMNS) * (cellSize.height + gapYPx),
    )

    fun startDrag(key: String) {
        val keys = currentShownKeys
        working = keys
        dragKey = key
        dragOrigin = slotPosition(keys.indexOf(key).coerceAtLeast(0))
        dragOffset = Offset.Zero
    }

    fun dragBy(delta: Offset) {
        val key = dragKey ?: return
        dragOffset += delta
        val center = dragOrigin + dragOffset + Offset(cellSize.width / 2f, cellSize.height / 2f)
        val col = (center.x / (cellSize.width + gapXPx)).toInt().coerceIn(0, COLUMNS - 1)
        val row = (center.y / (cellSize.height + gapYPx)).toInt().coerceAtLeast(0)
        val target = (row * COLUMNS + col).coerceIn(0, working.lastIndex)
        if (working.indexOf(key) != target) {
            working = working.toMutableList().apply {
                remove(key)
                add(target, key)
            }
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    fun endDrag() {
        if (dragKey == null) return
        val result = working
        dragKey = null
        dragOffset = Offset.Zero
        if (result != currentSavedKeys) {
            pending = result
            currentOnOrderChange(result)
        }
    }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        if (arranging) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.folder_arrange_hint),
                    color = IxColors.TextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = onArrangeDone) {
                    Text(stringResource(R.string.folder_arrange_done), color = IxColors.TextPrimary)
                }
            }
        }

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val cellWidth = (maxWidth - GAP_X * (COLUMNS - 1)) / COLUMNS
            FlowRow(
                maxItemsInEachRow = COLUMNS,
                horizontalArrangement = Arrangement.spacedBy(GAP_X),
                verticalArrangement = Arrangement.spacedBy(GAP_Y),
            ) {
                shown.forEach { item ->
                    key(item.key) {
                        val dragging = dragKey == item.key
                        val cellModifier = Modifier
                            .width(cellWidth)
                            .onSizeChanged { cellSize = it }
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer {
                                if (dragging) {
                                    // The tile sits in its new slot; this carries it back under the finger.
                                    val slot = slotPosition(working.indexOf(item.key).coerceAtLeast(0))
                                    translationX = dragOrigin.x + dragOffset.x - slot.x
                                    translationY = dragOrigin.y + dragOffset.y - slot.y
                                    scaleX = 1.06f
                                    scaleY = 1.06f
                                }
                            }
                            .then(
                                if (arranging) {
                                    Modifier.pointerInput(item.key) {
                                        detectDragGestures(
                                            onDragStart = { startDrag(item.key) },
                                            onDragEnd = { endDrag() },
                                            onDragCancel = { endDrag() },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                dragBy(amount)
                                            },
                                        )
                                    }
                                } else {
                                    Modifier
                                },
                            )

                        HomeTile(
                            item = item,
                            counts = counts,
                            scanning = scanning,
                            styles = styles,
                            refreshKey = refreshKey,
                            enabled = !arranging,
                            onCategoryClick = onCategoryClick,
                            onCategoryLongClick = onCategoryLongClick,
                            onCustomClick = onCustomClick,
                            onCustomLongClick = onCustomLongClick,
                            modifier = cellModifier,
                        )
                    }
                }

                // The "New folder" tile always comes last and is not part of the order.
                if (!arranging) {
                    FolderCell(
                        title = stringResource(R.string.new_folder),
                        subtitle = "",
                        glyph = Glyphs.Plus,
                        tint = null,
                        faded = true,
                        enabled = true,
                        onClick = onAddClick,
                        onLongClick = null,
                        modifier = Modifier.width(cellWidth),
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

/** What one Home tile shows and does. Worked out once, so every look of the Home folders can draw it. */
internal class FolderEntry(
    val title: String,
    val subtitle: String,
    /** Just the count, without the size, for the small looks. */
    val countLabel: String,
    val glyph: List<String>,
    /** The color the person picked for this folder, or null for the default. */
    val tint: Color?,
    val faded: Boolean,
    val onClick: () -> Unit,
    val onLongClick: () -> Unit,
)

/** The data behind one Home tile, a built-in or an added folder. */
@Composable
internal fun rememberFolderEntry(
    item: GridItem,
    counts: Map<Category, Int>,
    scanning: Boolean,
    styles: Map<Category, FolderStyle>,
    refreshKey: Any?,
    onCategoryClick: (Category) -> Unit,
    onCategoryLongClick: (Category) -> Unit,
    onCustomClick: (CustomFolder) -> Unit,
    onCustomLongClick: (CustomFolder) -> Unit,
): FolderEntry {
    val context = LocalContext.current
    when (item) {
        is GridItem.Builtin -> {
            val category = item.category
            val style = styles[category]
            val count = counts[category] ?: 0
            val label = if (scanning && count == 0) stringResource(R.string.scanning) else itemsLabel(context, count)
            return FolderEntry(
                title = category.displayName(style),
                subtitle = label,
                countLabel = label,
                glyph = category.glyphFor(style),
                tint = style?.color?.let { Color(it) },
                faded = false,
                onClick = { onCategoryClick(category) },
                onLongClick = { onCategoryLongClick(category) },
            )
        }

        is GridItem.Custom -> {
            val folder = item.folder
            val count by produceState(initialValue = LOADING, folder.path, refreshKey) {
                value = withContext(Dispatchers.IO) {
                    val dir = File(folder.path)
                    if (!dir.isDirectory) MISSING else dir.list()?.count { !it.startsWith(".") } ?: 0
                }
            }
            val missing = count == MISSING
            // The total size is worked out after the count shows, and stops counting in very large folders.
            val size by produceState<FolderSize?>(null, folder.path, refreshKey) {
                value = withContext(Dispatchers.IO) { sizeOfFolder(File(folder.path)) }
            }
            val countText = when {
                missing -> stringResource(R.string.folder_missing)
                count == LOADING -> ""
                else -> itemsLabel(context, count)
            }
            return FolderEntry(
                title = folder.style.name ?: File(folder.path).name,
                subtitle = if (missing || count == LOADING) countText else countText + (size?.let { " \u00b7 " + it.label() } ?: ""),
                countLabel = countText,
                glyph = glyphFor(folder.style, Glyphs.Folder),
                tint = folder.style.color?.let { Color(it) },
                faded = missing,
                // A folder that is gone has nothing to open, so a tap offers to remove the tile.
                onClick = { if (missing) onCustomLongClick(folder) else onCustomClick(folder) },
                onLongClick = { onCustomLongClick(folder) },
            )
        }
    }
}

/** One Home tile, a built-in or an added folder, with its name, count and look. Used by the grid and the canvas. */
@Composable
internal fun HomeTile(
    item: GridItem,
    counts: Map<Category, Int>,
    scanning: Boolean,
    styles: Map<Category, FolderStyle>,
    refreshKey: Any?,
    enabled: Boolean,
    onCategoryClick: (Category) -> Unit,
    onCategoryLongClick: (Category) -> Unit,
    onCustomClick: (CustomFolder) -> Unit,
    onCustomLongClick: (CustomFolder) -> Unit,
    modifier: Modifier = Modifier,
) {
    val entry = rememberFolderEntry(
        item, counts, scanning, styles, refreshKey,
        onCategoryClick, onCategoryLongClick, onCustomClick, onCustomLongClick,
    )
    FolderCell(
        title = entry.title,
        subtitle = entry.subtitle,
        glyph = entry.glyph,
        tint = entry.tint,
        enabled = enabled,
        faded = entry.faded,
        onClick = entry.onClick,
        onLongClick = entry.onLongClick,
        modifier = modifier,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderCell(
    title: String,
    subtitle: String,
    glyph: List<String>,
    tint: Color?,
    enabled: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    faded: Boolean = false,
) {
    val haptics = LocalHapticFeedback.current
    Column(
        modifier
            .heightIn(min = CELL_MIN_HEIGHT)
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                enabled = enabled,
                role = Role.Button,
                onClick = onClick,
                onLongClick = onLongClick?.let { longClick ->
                    {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        longClick()
                    }
                },
            )
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FolderIcon(
            glyph = glyph,
            modifier = Modifier
                .size(width = 84.dp, height = 70.dp)
                .alpha(if (faded) 0.5f else 1f),
            tint = tint,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = title,
            color = IxColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (subtitle.isNotEmpty()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** "42 items", "1,284 items", "1 item". */
fun itemsLabel(context: Context, count: Int): String =
    context.resources.getQuantityString(R.plurals.items_count, count, NumberFormat.getIntegerInstance().format(count))

/** The total size of a folder's files; [partial] means the walk stopped early, so the real size is larger. */
internal class FolderSize(val bytes: Long, val partial: Boolean) {
    fun label(): String = (if (partial) "\u2265 " else "") + formatFileSize(bytes)
}

private const val SIZE_WALK_LIMIT = 20_000

/** Adds up the files under [dir], looking at no more than [SIZE_WALK_LIMIT] of them. Null if it is not a folder. */
internal fun sizeOfFolder(dir: File): FolderSize? {
    if (!dir.isDirectory) return null
    var total = 0L
    var seen = 0
    for (file in dir.walkTopDown()) {
        if (file.isFile) {
            total += file.length()
            seen++
            if (seen >= SIZE_WALK_LIMIT) return FolderSize(total, partial = true)
        }
    }
    return FolderSize(total, partial = false)
}
