package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import ix.app.files.R
import ix.app.files.data.StorageAccess
import ix.app.files.ui.components.Bit
import ix.app.files.ui.components.BitPose
import ix.app.files.ui.theme.Figtree
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

// The welcome pages keep their own dark look in both themes, like the first screens of many apps.
// Colors, sizes and copy are from the Round 1 greeting screens mockup.
private val Background = Color(0xFF0C0C0E)
private val Halo = Color(0xFF17231C)
private val Muted = Color(0xFFB4B4BD)
private val HaloLabel = Color(0xFF9FB0A6)
private val Accent = Color(0xFFFF6A2B)
private val OnAccent = Color(0xFF0C0C0E)
private val DotOff = Color(0xFF3A3A42)
private val ChipBackground = Color(0xFF1C1C21)
private val CardBackground = Color(0xFF151518)

private const val PageCount = 3
private const val LastPage = PageCount - 1

/** The Skip row: 14 above the 44 tall button. Every page starts below it, even the one with no Skip. */
private val SkipRowHeight = 58.dp

/** Room the dots and buttons take at the bottom of a page, so its text never slides under them. */
private val ControlsHeight = 8.dp + 18.dp + 60.dp + 34.dp
private val ControlsHeightWithLater = ControlsHeight + 18.dp + 48.dp

/**
 * Three pages shown on the first start: Bit says hello, what the app is for, then a quick word about file access.
 * [onFinish] runs on Skip, on Not now, and once file access is on. Allow access starts the system's own flow.
 */
@Composable
fun WelcomeScreen(onFinish: () -> Unit) {
    val pager = rememberPagerState(pageCount = { PageCount })
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val page = pager.currentPage
    val last = page == LastPage
    val finish by rememberUpdatedState(onFinish)

    // Android 10 and older answer in place; the answer, either way, ends the welcome.
    val requestAccess = rememberAccessRequester(onResult = onFinish)

    // Android 11 and up send the user to a settings page. Coming back with the switch on ends the welcome;
    // coming back without it leaves the page here, so they can try again or tap Not now.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        if (StorageAccess.hasAccess(context)) finish()
    }

    BackHandler(enabled = page > 0) {
        scope.launch { pager.animateScrollToPage(page - 1) }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Background)) {
        // The mockup is 844 tall. Shorter phones get a smaller picture instead of a squeezed page.
        val fit = ((maxHeight - 400.dp) / 444.dp).coerceIn(0.6f, 1f)

        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { index ->
            when (index) {
                0 -> HelloPage(fit)
                1 -> FilesPage(fit)
                else -> AccessPage(fit)
            }
        }

        if (!last) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(top = 14.dp, end = 12.dp)
                    .height(44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .clickable(role = Role.Button, onClick = onFinish)
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(R.string.welcome_skip),
                    color = Muted,
                    fontFamily = Figtree,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 28.dp, end = 28.dp, bottom = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Dots(count = PageCount, current = page)
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Accent)
                    .clickable(role = Role.Button) {
                        if (last) requestAccess() else scope.launch { pager.animateScrollToPage(page + 1) }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(if (last) R.string.welcome_access_allow else R.string.welcome_next),
                    color = OnAccent,
                    fontFamily = Figtree,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
            }
            AnimatedVisibility(
                visible = last,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Box(
                    Modifier
                        .padding(top = 18.dp)
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable(role = Role.Button, onClick = onFinish),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(R.string.welcome_access_later),
                        color = Muted,
                        fontFamily = Figtree,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

/** Page dots. The current one stretches into a pill. They only repeat what the button row already says. */
@Composable
private fun Dots(count: Int, current: Int) {
    Row(
        Modifier.clearAndSetSemantics { },
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (index in 0 until count) {
            val active = index == current
            val width by animateDpAsState(if (active) 22.dp else 8.dp, label = "welcomeDot")
            Box(
                Modifier
                    .height(8.dp)
                    .width(width)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (active) Accent else DotOff),
            )
        }
    }
}

/** 1. Bit says hello. */
@Composable
private fun HelloPage(fit: Float) {
    PageFrame(controlsHeight = ControlsHeight) {
        Spacer(Modifier.height(SkipRowHeight + 36.dp * fit))
        Box(Modifier.fitted(fit).size(300.dp)) {
            Box(Modifier.offset(x = 20.dp, y = 20.dp).size(260.dp).background(Halo, CircleShape))
            Bit(
                pose = BitPose.Hello,
                description = stringResource(R.string.welcome_bit_description),
                modifier = Modifier.offset(x = 70.dp, y = 90.dp).size(width = 160.dp, height = 140.dp),
            )
            Chip(
                label = stringResource(R.string.welcome_tile_photos),
                dot = Color(0xFF4C8DFF),
                modifier = Modifier.align(Alignment.TopStart).offset(x = (-6).dp, y = 40.dp),
            )
            Chip(
                label = stringResource(R.string.welcome_tile_docs),
                dot = Color(0xFFF5B83D),
                modifier = Modifier.align(Alignment.TopEnd).offset(x = 10.dp, y = 110.dp),
            )
            Chip(
                label = stringResource(R.string.welcome_tile_private),
                dot = Color(0xFF8B6CFF),
                modifier = Modifier.align(Alignment.BottomStart).offset(x = 20.dp, y = (-14).dp),
            )
        }
        Column(
            Modifier.padding(start = 28.dp, end = 28.dp, top = 24.dp * fit),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = stringResource(R.string.welcome_to),
                color = HaloLabel,
                fontFamily = Figtree,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = stringResource(R.string.app_name),
                color = Color.White,
                fontFamily = Figtree,
                fontSize = 60.sp,
                lineHeight = 63.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-1.5).sp,
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = stringResource(R.string.welcome_tagline),
                color = Muted,
                fontFamily = Figtree,
                fontSize = 17.sp,
                lineHeight = 24.65.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.widthIn(max = 270.dp),
            )
        }
    }
}

/** 2. Bit holding a PDF, a DOC and a JPG. */
@Composable
private fun FilesPage(fit: Float) {
    PageFrame(controlsHeight = ControlsHeight) {
        Spacer(Modifier.height(SkipRowHeight + 40.dp * fit))
        Box(Modifier.fitted(fit).size(width = 300.dp, height = 280.dp), contentAlignment = Alignment.Center) {
            // Centered in the 300 x 280 area, which puts it 30 from the left and 20 from the top.
            Box(Modifier.size(240.dp).background(Halo, CircleShape))
            Bit(
                pose = BitPose.Files,
                description = stringResource(R.string.welcome_bit_files_description),
                modifier = Modifier.size(width = 280.dp, height = 266.dp),
            )
        }
        Column(
            Modifier.padding(start = 28.dp, end = 28.dp, top = 30.dp * fit),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            PageTitle(stringResource(R.string.welcome_title_two))
            Spacer(Modifier.height(14.dp))
            PageBody(stringResource(R.string.welcome_body_two), maxWidth = 300.dp)
        }
    }
}

/** 3. Bit with a padlock, and what the access is for. */
@Composable
private fun AccessPage(fit: Float) {
    PageFrame(controlsHeight = ControlsHeightWithLater) {
        Spacer(Modifier.height(SkipRowHeight))
        Box(
            Modifier
                .fitted(fit)
                .size(width = 220.dp, height = 190.dp)
                // The halo is an ellipse here, not a circle.
                .drawBehind { drawOval(Halo) },
        ) {
            Bit(
                pose = BitPose.Lock,
                description = stringResource(R.string.welcome_bit_lock_description),
                modifier = Modifier.offset(x = 30.dp, y = 40.dp).size(width = 160.dp, height = 140.dp),
            )
        }
        Column(
            Modifier.padding(start = 28.dp, end = 28.dp, top = 28.dp * fit),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            PageTitle(stringResource(R.string.welcome_access_title))
            Spacer(Modifier.height(14.dp))
            PageBody(stringResource(R.string.welcome_access_body), maxWidth = 300.dp)
        }
        Column(
            Modifier
                .padding(start = 28.dp, end = 28.dp, top = 30.dp * fit)
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(CardBackground)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Promise(
                title = stringResource(R.string.welcome_access_point_one_title),
                body = stringResource(R.string.welcome_access_point_one_body),
            )
            Promise(
                title = stringResource(R.string.welcome_access_point_two_title),
                body = stringResource(R.string.welcome_access_point_two_body),
            )
        }
    }
}

/**
 * Common frame of a page: below the status bar, scrollable in case a very short or very large-text screen
 * cannot fit it, and with room left at the bottom for the dots and buttons that float above the pager.
 */
@Composable
private fun PageFrame(controlsHeight: Dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(bottom = controlsHeight + 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

@Composable
private fun PageTitle(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontFamily = Figtree,
        fontSize = 32.sp,
        lineHeight = 35.2.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = (-0.5).sp,
        textAlign = TextAlign.Center,
    )
}

@Composable
private fun PageBody(text: String, maxWidth: Dp) {
    Text(
        text = text,
        color = Muted,
        fontFamily = Figtree,
        fontSize = 17.sp,
        lineHeight = 24.65.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.widthIn(max = maxWidth),
    )
}

/** A pill with a colored dot, floating around Bit on the first page. */
@Composable
private fun Chip(label: String, dot: Color, modifier: Modifier = Modifier) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(ChipBackground)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(dot))
        Text(
            text = label,
            color = Color.White,
            fontFamily = Figtree,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

/** One line of the access card: an orange dot, a short title and what it means. */
@Composable
private fun Promise(title: String, body: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 7.dp).size(10.dp).clip(CircleShape).background(Accent))
        Column {
            Text(
                text = title,
                color = Color.White,
                fontFamily = Figtree,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = body,
                color = Muted,
                fontFamily = Figtree,
                fontSize = 15.sp,
                lineHeight = 21.sp,
            )
        }
    }
}

/**
 * Shrinks this and everything in it by [factor], and takes the smaller space in the layout too.
 * The content must have a fixed size of its own.
 */
private fun Modifier.fitted(factor: Float): Modifier =
    if (factor >= 0.999f) {
        this
    } else {
        layout { measurable, constraints ->
            val placeable = measurable.measure(constraints)
            layout((placeable.width * factor).roundToInt(), (placeable.height * factor).roundToInt()) {
                placeable.placeWithLayer(0, 0) {
                    scaleX = factor
                    scaleY = factor
                    transformOrigin = TransformOrigin(0f, 0f)
                }
            }
        }
    }
