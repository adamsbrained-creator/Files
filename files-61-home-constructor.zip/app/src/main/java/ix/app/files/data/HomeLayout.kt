package ix.app.files.data

import android.content.Context
import androidx.compose.runtime.Immutable

/** The kinds of block a Home can be built from. */
enum class BlockType(val key: String, val label: String) {
    Header("header", "Header"),
    Storage("storage", "Storage"),
    Search("search", "Search"),
    Folders("folders", "Folders"),
    Favorites("favorites", "Favorites"),
    Recent("recent", "Recent"),
    Extra("extra", "Extras"),
    ;

    companion object {
        fun of(key: String): BlockType? = entries.firstOrNull { it.key == key }
    }
}

/** How the folder icons look. */
enum class IconStyle(val label: String) { Pastel("Pastel"), Mono("Mono"), Outline("Outline") }

/** The gap between blocks, in dp. */
enum class Spacing(val label: String, val dp: Int) { Compact("Compact", 8), Cozy("Cozy", 16), Roomy("Roomy", 26) }

/** One way a block can look. [key] is what gets saved. */
class StyleInfo(val key: String, val label: String)

/** One on/off setting of a block. */
class OptionInfo(val key: String, val label: String, val default: Boolean)

/** A group of block types in the "Add a block" sheet. */
class BlockGroup(val label: String, val types: List<BlockType>)

/** Everything the constructor knows about the blocks: their styles and their options. */
object HomeCatalog {

    val styles: Map<BlockType, List<StyleInfo>> = mapOf(
        BlockType.Header to listOf(
            StyleInfo("classic", "Classic"),
            StyleInfo("title", "Title"),
            StyleInfo("greeting", "Greeting"),
            StyleInfo("big", "Big number"),
            StyleInfo("tidy", "Centered Bit"),
        ),
        BlockType.Storage to listOf(
            StyleInfo("ring", "Ring card"),
            StyleInfo("seg", "Segmented"),
            StyleInfo("bar", "Free-space bar"),
            StyleInfo("thin", "Thin line"),
            StyleInfo("peek", "Bit peeking"),
        ),
        BlockType.Search to listOf(
            StyleInfo("pill", "Search pill"),
            StyleInfo("line", "Underline"),
            StyleInfo("bit", "Bit search"),
        ),
        BlockType.Folders to listOf(
            StyleInfo("classic", "Classic"),
            StyleInfo("compact", "Compact tiles"),
            StyleInfo("tiles", "Tiles"),
            StyleInfo("big", "Big cards"),
            StyleInfo("open", "Open icons"),
            StyleInfo("list", "List"),
            StyleInfo("chips", "Chips"),
        ),
        BlockType.Favorites to listOf(
            StyleInfo("card", "Card"),
            StyleInfo("plain", "Plain"),
            StyleInfo("list", "File list"),
        ),
        BlockType.Recent to listOf(
            StyleInfo("peek", "Peek bar"),
            StyleInfo("row", "Recent row"),
        ),
        BlockType.Extra to listOf(
            StyleInfo("sug", "Clean up suggestion"),
            StyleInfo("dup", "Duplicates"),
            StyleInfo("act", "Quick actions"),
            StyleInfo("private", "Private folder"),
        ),
    )

    val options: Map<BlockType, List<OptionInfo>> = mapOf(
        BlockType.Header to listOf(OptionInfo("menu", "Menu button", false)),
        BlockType.Storage to listOf(
            OptionInfo("clean", "Clean up button", true),
            OptionInfo("free", "Show free-space label", false),
            OptionInfo("tap", "Open storage on tap", true),
        ),
        BlockType.Search to listOf(
            OptionInfo("filter", "Filter button", true),
            OptionInfo("menu", "Menu button", true),
        ),
        BlockType.Folders to listOf(
            OptionInfo("title", "Section title", true),
            OptionInfo("count", "Item counts", true),
        ),
        BlockType.Favorites to listOf(OptionInfo("title", "Section title", true)),
        BlockType.Recent to listOf(OptionInfo("bit", "Bit on the peek bar", false)),
        BlockType.Extra to emptyList(),
    )

    val groups: List<BlockGroup> = listOf(
        BlockGroup("Header", listOf(BlockType.Header, BlockType.Search)),
        BlockGroup("Storage", listOf(BlockType.Storage)),
        BlockGroup("Folders", listOf(BlockType.Folders)),
        BlockGroup("Extras", listOf(BlockType.Favorites, BlockType.Recent, BlockType.Extra)),
    )

    fun stylesOf(type: BlockType): List<StyleInfo> = styles.getValue(type)

    fun styleLabel(type: BlockType, key: String): String =
        stylesOf(type).firstOrNull { it.key == key }?.label ?: key

    fun defaults(type: BlockType): Map<String, Boolean> =
        options.getValue(type).associate { it.key to it.default }
}

/** One block of the Home. [opts] holds only the options that were changed from their default. */
@Immutable
data class Block(
    val id: Int,
    val type: BlockType,
    val style: String,
    val hidden: Boolean = false,
    val opts: Map<String, Boolean> = emptyMap(),
) {
    /** The value of one on/off option, falling back to its default. */
    fun opt(key: String): Boolean =
        opts[key] ?: HomeCatalog.options.getValue(type).firstOrNull { it.key == key }?.default ?: false

    fun withOpt(key: String, on: Boolean): Block = copy(opts = opts + (key to on))

    val title: String
        get() = if (type == BlockType.Extra) HomeCatalog.styleLabel(type, style) else type.label

    val styleLabel: String get() = HomeCatalog.styleLabel(type, style)
}

/** The whole Home: its blocks, in order, and the look that applies to all of them. */
@Immutable
data class HomeLayout(
    val name: String,
    val blocks: List<Block>,
    /** ARGB of the accent. */
    val accent: Int = DEFAULT_ACCENT,
    val bitShow: Boolean = true,
    /** ARGB of Bit's body. */
    val bitBody: Int = DEFAULT_BIT_BODY,
    /** 0 is sharp corners, 1 is very round. */
    val round: Float = 0.7f,
    val icons: IconStyle = IconStyle.Pastel,
    val spacing: Spacing = Spacing.Cozy,
) {
    val visibleBlocks: List<Block> get() = blocks.filter { !it.hidden }

    /** True when the Recent sheet (the peek bar) is part of this Home. */
    val hasPeekSheet: Boolean
        get() = visibleBlocks.any { it.type == BlockType.Recent && it.style == "peek" }

    fun nextId(): Int = (blocks.maxOfOrNull { it.id } ?: 0) + 1

    fun withBlock(block: Block): HomeLayout = copy(blocks = blocks.map { if (it.id == block.id) block else it })

    /** Adds a new block with default options after the block with id [after], or at the end. */
    fun adding(type: BlockType, style: String, after: Int?): Pair<HomeLayout, Block> {
        val block = Block(nextId(), type, style)
        val at = blocks.indexOfFirst { it.id == after }.let { if (it < 0) blocks.size else it + 1 }
        return copy(blocks = blocks.toMutableList().apply { add(at, block) }) to block
    }

    fun duplicating(id: Int): Pair<HomeLayout, Block?> {
        val source = blocks.firstOrNull { it.id == id } ?: return this to null
        val copy = source.copy(id = nextId())
        val at = blocks.indexOf(source) + 1
        return copy(blocks = blocks.toMutableList().apply { add(at, copy) }) to copy
    }

    fun removing(id: Int): HomeLayout = copy(blocks = blocks.filter { it.id != id })

    fun moving(from: Int, to: Int): HomeLayout {
        if (from !in blocks.indices || to !in blocks.indices || from == to) return this
        return copy(blocks = blocks.toMutableList().apply { add(to, removeAt(from)) })
    }

    companion object {
        const val DEFAULT_ACCENT: Int = 0xFFFF6A2B.toInt()
        const val DEFAULT_BIT_BODY: Int = 0xFFE4E4E8.toInt()
    }
}

/** A ready-made Home to start from. */
class HomePreset(val key: String, val name: String, val description: String, val blocks: List<PresetBlock>)

/** One block of a preset: its type, style and the options that differ from the defaults. */
class PresetBlock(val type: BlockType, val style: String, val opts: Map<String, Boolean> = emptyMap())

object HomePresets {

    private fun b(type: BlockType, style: String, vararg opts: Pair<String, Boolean>) =
        PresetBlock(type, style, opts.toMap())

    private val H = BlockType.Header
    private val S = BlockType.Storage
    private val Q = BlockType.Search
    private val F = BlockType.Folders
    private val V = BlockType.Favorites
    private val R = BlockType.Recent
    private val X = BlockType.Extra

    val all: List<HomePreset> = listOf(
        HomePreset(
            "classic", "Classic", "The Home you know",
            listOf(b(H, "classic"), b(Q, "pill", "menu" to true), b(F, "classic", "title" to false), b(V, "plain"), b(X, "private"), b(R, "peek")),
        ),
        HomePreset(
            "hero", "Hero", "Storage first, calm tiles",
            listOf(b(H, "title"), b(S, "ring"), b(Q, "pill"), b(F, "compact"), b(V, "card"), b(R, "peek")),
        ),
        HomePreset(
            "quiet", "Quiet", "Plain list, almost no chrome",
            listOf(b(H, "title", "menu" to true), b(S, "thin"), b(Q, "line", "filter" to false, "menu" to false), b(F, "list", "title" to false), b(V, "plain"), b(R, "peek")),
        ),
        HomePreset(
            "greeting", "Greeting", "Bit says hello",
            listOf(b(H, "greeting", "menu" to true), b(Q, "pill", "filter" to false, "menu" to false), b(F, "open", "title" to false), b(V, "plain"), b(R, "peek")),
        ),
        HomePreset(
            "search", "Search first", "Search is the top",
            listOf(b(Q, "bit", "filter" to false), b(S, "ring"), b(F, "list"), b(V, "plain"), b(R, "peek")),
        ),
        HomePreset(
            "chips", "Chips", "Compact folders",
            listOf(b(H, "title", "menu" to true), b(S, "thin"), b(Q, "pill", "filter" to false, "menu" to false), b(F, "chips", "title" to false), b(V, "plain"), b(R, "peek")),
        ),
        HomePreset(
            "big", "Big number", "Free space as the title",
            listOf(b(H, "big", "menu" to true), b(S, "thin"), b(Q, "line", "filter" to false, "menu" to false), b(F, "chips", "title" to false), b(V, "plain"), b(R, "peek")),
        ),
        HomePreset(
            "seg", "Segmented", "Ring split by kind",
            listOf(b(H, "title"), b(S, "seg"), b(Q, "pill"), b(F, "compact"), b(V, "card"), b(R, "peek")),
        ),
        HomePreset(
            "free", "Free space", "Bar with a legend",
            listOf(b(H, "title"), b(S, "bar"), b(Q, "pill"), b(F, "tiles"), b(V, "card"), b(R, "peek")),
        ),
        HomePreset(
            "peek", "Bit peeking", "Open icons",
            listOf(b(H, "title"), b(S, "peek"), b(Q, "pill"), b(F, "open"), b(V, "card"), b(R, "peek")),
        ),
        HomePreset(
            "pastel", "Pastel", "Big colour cards",
            listOf(b(H, "title"), b(S, "thin"), b(Q, "pill"), b(F, "big"), b(V, "list"), b(R, "row")),
        ),
        HomePreset(
            "rows", "Rows", "Tiles and a recent row",
            listOf(b(H, "title"), b(S, "thin"), b(Q, "pill"), b(F, "tiles"), b(V, "list"), b(R, "row")),
        ),
        HomePreset(
            "clean", "Cleaner", "Suggestion up top",
            listOf(b(H, "title"), b(S, "thin", "free" to true), b(X, "sug"), b(Q, "pill"), b(F, "compact"), b(V, "card"), b(R, "peek", "bit" to true)),
        ),
        HomePreset(
            "tidy", "Tidy", "Centered Bit",
            listOf(b(H, "tidy"), b(Q, "pill", "filter" to false, "menu" to false), b(F, "open", "title" to false), b(X, "private"), b(R, "peek")),
        ),
    )

    fun find(key: String): HomePreset = all.firstOrNull { it.key == key } ?: all.first { it.key == "hero" }

    /** A layout from the preset [key]. The look (accent, Bit, corners, icons, spacing) of [look] is kept. */
    fun build(key: String, look: HomeLayout? = null): HomeLayout {
        val preset = find(key)
        val blocks = preset.blocks.mapIndexed { i, p -> Block(i + 1, p.type, p.style, false, p.opts) }
        return (look ?: HomeLayout(preset.name, emptyList())).copy(name = preset.name, blocks = blocks)
    }
}

/**
 * Saves a [HomeLayout] as plain text, one line per setting. It is written by hand, not with a JSON library, so the
 * format can be tested on a computer without a phone.
 */
object HomeLayoutCodec {

    private const val VERSION = "v1"

    fun encode(layout: HomeLayout): String = buildString {
        appendLine(VERSION)
        appendLine("name=" + layout.name.replace('\n', ' '))
        appendLine("accent=${layout.accent}")
        appendLine("bit=${if (layout.bitShow) 1 else 0}")
        appendLine("body=${layout.bitBody}")
        appendLine("round=${layout.round}")
        appendLine("icons=${layout.icons.name}")
        appendLine("spacing=${layout.spacing.name}")
        for (block in layout.blocks) {
            val opts = block.opts.entries.joinToString(",") { "${it.key}:${if (it.value) 1 else 0}" }
            appendLine("b=${block.id}|${block.type.key}|${block.style}|${if (block.hidden) 1 else 0}|$opts")
        }
    }

    /** The layout in [text], or null when the text is not one this app wrote. */
    fun decode(text: String): HomeLayout? {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.firstOrNull() != VERSION) return null
        var layout = HomeLayout(name = "Custom", blocks = emptyList())
        val blocks = ArrayList<Block>()
        for (line in lines.drop(1)) {
            val at = line.indexOf('=')
            if (at < 0) continue
            val key = line.substring(0, at)
            val value = line.substring(at + 1)
            when (key) {
                "name" -> layout = layout.copy(name = value)
                "accent" -> value.toIntOrNull()?.let { layout = layout.copy(accent = it) }
                "bit" -> layout = layout.copy(bitShow = value == "1")
                "body" -> value.toIntOrNull()?.let { layout = layout.copy(bitBody = it) }
                "round" -> value.toFloatOrNull()?.let { layout = layout.copy(round = it.coerceIn(0f, 1f)) }
                "icons" -> IconStyle.entries.firstOrNull { it.name == value }?.let { layout = layout.copy(icons = it) }
                "spacing" -> Spacing.entries.firstOrNull { it.name == value }?.let { layout = layout.copy(spacing = it) }
                "b" -> parseBlock(value)?.let { blocks += it }
            }
        }
        // Two blocks must never share an id, or editing one would edit both.
        val unique = blocks.distinctBy { it.id }
        return layout.copy(blocks = unique)
    }

    private fun parseBlock(value: String): Block? {
        val parts = value.split('|')
        if (parts.size < 4) return null
        val id = parts[0].toIntOrNull() ?: return null
        val type = BlockType.of(parts[1]) ?: return null
        val style = parts[2]
        // A style this version does not know falls back to the first one, so the block still shows.
        val known = HomeCatalog.stylesOf(type).any { it.key == style }
        val opts = HashMap<String, Boolean>()
        parts.getOrNull(4)?.split(',')?.filter { it.isNotEmpty() }?.forEach { pair ->
            val kv = pair.split(':')
            if (kv.size == 2) opts[kv[0]] = kv[1] == "1"
        }
        return Block(id, type, if (known) style else HomeCatalog.stylesOf(type).first().key, parts[3] == "1", opts)
    }
}

/** Remembers the Home the person built. No saved layout means the classic Home, exactly as before. */
class HomeLayoutStore(context: Context) {

    private val prefs = context.getSharedPreferences("home_layout", Context.MODE_PRIVATE)

    fun load(): HomeLayout? = prefs.getString(KEY, null)?.let { HomeLayoutCodec.decode(it) }

    fun save(layout: HomeLayout) {
        prefs.edit().putString(KEY, HomeLayoutCodec.encode(layout)).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "layout"
    }
}
