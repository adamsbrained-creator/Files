package ix.app.files.insights

import kotlin.math.pow

/** How many times something was opened, and when last. */
class Use(val count: Int, val lastMillis: Long)

/**
 * What the app has seen you do with your files, kept on the phone only: which files and folders you open,
 * which kinds of file you delete. Nothing in it leaves the device, and nothing from Private is ever recorded.
 * It is used to rank suggestions, to sort by "Most used", and to offer your busiest folders for Home.
 *
 * Immutable: every change gives a new [Habits], so it is safe to read from any thread.
 */
class Habits(
    val files: Map<String, Use> = emptyMap(),
    val folders: Map<String, Use> = emptyMap(),
    /** How often each extension was deleted, e.g. "apk" to 7. */
    val deletedExtensions: Map<String, Int> = emptyMap(),
    /** When the first thing was recorded. Zero while nothing has been. */
    val sinceMillis: Long = 0L,
) {
    val isEmpty: Boolean get() = files.isEmpty() && folders.isEmpty() && deletedExtensions.isEmpty()

    fun openedFile(path: String, now: Long): Habits =
        if (!recordable(path)) this else Habits(bump(files, path, now, MAX_FILES), folders, deletedExtensions, since(now))

    fun openedFolder(path: String, now: Long): Habits =
        if (!recordable(path)) this else Habits(files, bump(folders, path, now, MAX_FOLDERS), deletedExtensions, since(now))

    /** Things were deleted: their extensions are counted, and they are forgotten (a folder takes what is in it along). */
    fun deleted(paths: List<String>, now: Long): Habits {
        if (paths.isEmpty()) return this
        val ext = HashMap(deletedExtensions)
        for (path in paths) {
            val e = extensionOf(path)
            if (e.isNotEmpty()) ext[e] = (ext[e] ?: 0) + 1
        }
        if (ext.size > MAX_EXTENSIONS) {
            val keep = ext.entries.sortedByDescending { it.value }.take(MAX_EXTENSIONS)
            ext.clear()
            for (entry in keep) ext[entry.key] = entry.value
        }
        val gone = paths.map { it.trimEnd('/') }
        fun survives(path: String) = gone.none { path == it || path.startsWith("$it/") }
        return Habits(
            files.filterKeys { survives(it) },
            folders.filterKeys { survives(it) },
            ext,
            since(now),
        )
    }

    /** Things moved: what was known about them follows them to the new place. */
    fun moved(pairs: List<Pair<String, String>>): Habits {
        if (pairs.isEmpty() || (files.isEmpty() && folders.isEmpty())) return this
        fun remap(map: Map<String, Use>): Map<String, Use> {
            val out = HashMap<String, Use>(map.size)
            for ((path, use) in map) {
                var target = path
                for ((from, to) in pairs) {
                    val f = from.trimEnd('/')
                    if (path == f) {
                        target = to
                        break
                    }
                    if (path.startsWith("$f/")) {
                        target = to.trimEnd('/') + path.substring(f.length)
                        break
                    }
                }
                val existing = out[target]
                out[target] = if (existing == null) use else Use(existing.count + use.count, maxOf(existing.lastMillis, use.lastMillis))
            }
            return out
        }
        return Habits(remap(files), remap(folders), deletedExtensions, sinceMillis)
    }

    /** Opens per path, files and folders together, for sorting by "Most used". */
    fun useCounts(): Map<String, Int> {
        val out = HashMap<String, Int>(files.size + folders.size)
        for ((path, use) in files) out[path] = use.count
        for ((path, use) in folders) out[path] = use.count
        return out
    }

    fun topFiles(limit: Int, now: Long): List<Pair<String, Use>> = rank(files, limit, now)

    fun topFolders(limit: Int, now: Long): List<Pair<String, Use>> = rank(folders, limit, now)

    private fun since(now: Long): Long = if (sinceMillis == 0L) now else sinceMillis

    // ---- saving ----

    fun encode(): String {
        val sb = StringBuilder(HEADER).append('\n')
        sb.append("since\t").append(sinceMillis).append('\n')
        for ((path, use) in files) sb.append("f\t").append(use.count).append('\t').append(use.lastMillis).append('\t').append(path).append('\n')
        for ((path, use) in folders) sb.append("d\t").append(use.count).append('\t').append(use.lastMillis).append('\t').append(path).append('\n')
        for ((ext, count) in deletedExtensions) sb.append("x\t").append(count).append('\t').append(ext).append('\n')
        return sb.toString()
    }

    companion object {
        private const val HEADER = "IXHABITS1"
        const val MAX_FILES = 500
        const val MAX_FOLDERS = 200
        const val MAX_EXTENSIONS = 60
        private const val DAY = 86_400_000.0

        /** Reads what [encode] wrote. Anything unreadable is left out instead of failing. */
        fun decode(text: String): Habits {
            val lines = text.lineSequence().iterator()
            if (!lines.hasNext() || lines.next() != HEADER) return Habits()
            val files = HashMap<String, Use>()
            val folders = HashMap<String, Use>()
            val extensions = HashMap<String, Int>()
            var since = 0L
            while (lines.hasNext()) {
                val parts = lines.next().split('\t')
                when (parts.firstOrNull()) {
                    "since" -> since = parts.getOrNull(1)?.toLongOrNull() ?: 0L
                    "f", "d" -> {
                        val count = parts.getOrNull(1)?.toIntOrNull()
                        val last = parts.getOrNull(2)?.toLongOrNull()
                        val path = parts.drop(3).joinToString("\t")
                        if (count != null && last != null && count > 0 && path.isNotEmpty()) {
                            (if (parts[0] == "f") files else folders)[path] = Use(count, last)
                        }
                    }
                    "x" -> {
                        val count = parts.getOrNull(1)?.toIntOrNull()
                        val ext = parts.getOrNull(2).orEmpty()
                        if (count != null && count > 0 && ext.isNotEmpty()) extensions[ext] = count
                    }
                }
            }
            return Habits(files, folders, extensions, since)
        }

        /** Newer and more frequent opens count more: a count halves for every two months that pass. */
        fun score(use: Use, now: Long): Double {
            val ageDays = ((now - use.lastMillis).coerceAtLeast(0L)) / DAY
            return use.count * 0.5.pow(ageDays / 60.0)
        }

        private fun recordable(path: String): Boolean =
            path.isNotEmpty() && '\t' !in path && '\n' !in path

        private fun rank(map: Map<String, Use>, limit: Int, now: Long): List<Pair<String, Use>> =
            map.entries.sortedByDescending { score(it.value, now) }.take(limit).map { it.key to it.value }

        private fun bump(map: Map<String, Use>, path: String, now: Long, limit: Int): Map<String, Use> {
            val next = HashMap(map)
            next[path] = Use((map[path]?.count ?: 0) + 1, now)
            if (next.size > limit) {
                val keep = next.entries.sortedByDescending { score(it.value, now) }.take(limit - limit / 10)
                next.clear()
                for (entry in keep) next[entry.key] = entry.value
            }
            return next
        }

        fun extensionOf(path: String): String {
            val name = path.substringAfterLast('/')
            val dot = name.lastIndexOf('.')
            if (dot <= 0 || dot >= name.length - 1) return ""
            val ext = name.substring(dot + 1).lowercase()
            return if (ext.length <= 8) ext else ""
        }
    }
}
