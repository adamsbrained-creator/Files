package ix.app.files.insights

import ix.app.files.data.FileItem
import ix.app.files.data.FileKind

enum class RuleAction { Move, Trash }

/**
 * "Files like this, in this folder, go there." A rule never runs by itself: it is turned into a suggestion,
 * and nothing moves or goes to the Trash until the person confirms. Folders are written from the top of storage
 * ("Download", "Pictures/Screenshots"); an empty [fromFolder] means everywhere.
 */
data class SortRule(
    val id: String,
    val name: String,
    val fromFolder: String,
    /** Empty means any kind. */
    val kinds: Set<FileKind>,
    /** Lowercase, without dots. Empty means any. */
    val extensions: Set<String>,
    /** The name (with its extension) has to contain this, ignoring case. Empty means any. */
    val nameContains: String,
    /** Only files not changed for this many days. Zero means any age. */
    val olderThanDays: Int,
    val action: RuleAction,
    /** Where [RuleAction.Move] puts files, from the top of storage. */
    val destFolder: String,
    val enabled: Boolean = true,
) {
    /** A rule that can run: it has a name, and a clean destination when it moves. */
    val valid: Boolean
        get() = name.isNotBlank() &&
            (fromFolder.isEmpty() || RuleText.cleanFolder(fromFolder) != null) &&
            (action == RuleAction.Trash || RuleText.cleanFolder(destFolder).let { it != null && it.isNotEmpty() })

    fun matches(file: FileItem, rootPath: String, now: Long): Boolean {
        val root = rootPath.trimEnd('/')
        val from = RuleText.cleanFolder(fromFolder).orEmpty()
        val base = if (from.isEmpty()) "$root/" else "$root/$from/"
        if (!file.path.startsWith(base)) return false
        if (action == RuleAction.Move) {
            val dest = RuleText.cleanFolder(destFolder) ?: return false
            if (dest.isNotEmpty() && file.path.startsWith("$root/$dest/")) return false
        }
        if (kinds.isNotEmpty() && file.kind !in kinds) return false
        if (extensions.isNotEmpty() && file.extension.lowercase() !in extensions) return false
        if (nameContains.isNotBlank()) {
            val full = if (file.extension.isEmpty()) file.name else file.name + "." + file.extension
            if (!full.contains(nameContains.trim(), ignoreCase = true)) return false
        }
        // A file changed in the last day may still be being written.
        val age = now - file.modifiedMillis
        if (age < StorageInsights.DAY_MILLIS) return false
        if (olderThanDays > 0 && age < olderThanDays * StorageInsights.DAY_MILLIS) return false
        return true
    }

    /** The full path files go to, or null for a rule that does not move or has no clean destination. */
    fun destPath(rootPath: String): String? {
        if (action != RuleAction.Move) return null
        val dest = RuleText.cleanFolder(destFolder)?.takeIf { it.isNotEmpty() } ?: return null
        return rootPath.trimEnd('/') + "/" + dest
    }
}

/** Cleaning up what a person types, and saving rules as text. */
object RuleText {

    /**
     * A folder as typed, made into "A/B" with no slashes at the ends, or null when it points outside storage
     * (".." in it). Empty stays empty. A leading "/storage/emulated/0/" or "sdcard/" is accepted and dropped.
     */
    fun cleanFolder(text: String): String? {
        var t = text.trim().replace('\\', '/')
        for (prefix in listOf("/storage/emulated/0", "/sdcard", "sdcard")) {
            if (t == prefix || t.startsWith("$prefix/")) {
                t = t.removePrefix(prefix)
                break
            }
        }
        val parts = t.split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.any { it == ".." }) return null
        return parts.joinToString("/")
    }

    /** "jpg, .PNG; gif" becomes {"jpg", "png", "gif"}. */
    fun extensions(text: String): Set<String> =
        text.split(',', ';', ' ').map { it.trim().trimStart('.').lowercase() }.filter { it.isNotEmpty() }.toSet()

    private fun flat(s: String): String = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')

    fun encode(rules: List<SortRule>): String {
        val sb = StringBuilder("IXRULES1\n")
        for (r in rules) {
            sb.append(flat(r.id)).append('\t')
                .append(flat(r.name)).append('\t')
                .append(flat(r.fromFolder)).append('\t')
                .append(r.kinds.joinToString(",") { it.name }).append('\t')
                .append(r.extensions.joinToString(",")).append('\t')
                .append(flat(r.nameContains)).append('\t')
                .append(r.olderThanDays).append('\t')
                .append(r.action.name).append('\t')
                .append(flat(r.destFolder)).append('\t')
                .append(if (r.enabled) "1" else "0").append('\n')
        }
        return sb.toString()
    }

    fun decode(text: String): List<SortRule> {
        val lines = text.lineSequence().iterator()
        if (!lines.hasNext() || lines.next() != "IXRULES1") return emptyList()
        val out = ArrayList<SortRule>()
        while (lines.hasNext()) {
            val p = lines.next().split('\t')
            if (p.size < 10 || p[0].isEmpty()) continue
            val action = RuleAction.entries.firstOrNull { it.name == p[7] } ?: continue
            out.add(
                SortRule(
                    id = p[0],
                    name = p[1],
                    fromFolder = p[2],
                    kinds = p[3].split(',').mapNotNull { n -> FileKind.entries.firstOrNull { it.name == n } }.toSet(),
                    extensions = p[4].split(',').filter { it.isNotEmpty() }.toSet(),
                    nameContains = p[5],
                    olderThanDays = p[6].toIntOrNull() ?: 0,
                    action = action,
                    destFolder = p[8],
                    enabled = p[9] == "1",
                ),
            )
        }
        return out
    }
}

/** Rules that are ready to add with one tap. They are ordinary rules the person can change afterwards. */
object RulePresets {
    private val installers = setOf("apk", "xapk", "apks", "apkm")

    val all: List<SortRule> = listOf(
        SortRule("preset-photos", "Photos from Download to Pictures", "Download", setOf(FileKind.Image), emptySet(), "", 3, RuleAction.Move, "Pictures"),
        SortRule("preset-videos", "Videos from Download to Movies", "Download", setOf(FileKind.Video), emptySet(), "", 3, RuleAction.Move, "Movies"),
        SortRule("preset-music", "Music from Download to Music", "Download", setOf(FileKind.Audio), emptySet(), "", 3, RuleAction.Move, "Music"),
        SortRule("preset-docs", "Documents from Download to Documents", "Download", setOf(FileKind.Document), emptySet(), "", 3, RuleAction.Move, "Documents"),
        SortRule("preset-installers", "Old installers to Trash", "", emptySet(), installers, "", 7, RuleAction.Trash, ""),
        SortRule("preset-screenshots", "Old screenshots to Trash", "Pictures/Screenshots", setOf(FileKind.Image), emptySet(), "", 60, RuleAction.Trash, ""),
    )
}
