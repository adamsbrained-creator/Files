package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeLayoutTest {

    private fun hero() = HomePresets.build("hero")

    @Test
    fun everyPresetUsesKnownStylesAndHasUniqueIds() {
        for (preset in HomePresets.all) {
            val layout = HomePresets.build(preset.key)
            assertEquals(preset.blocks.size, layout.blocks.size)
            assertEquals(layout.blocks.size, layout.blocks.map { it.id }.toSet().size)
            for (block in layout.blocks) {
                assertTrue(
                    "${preset.key}: ${block.type} has no style '${block.style}'",
                    HomeCatalog.stylesOf(block.type).any { it.key == block.style },
                )
                // Every option a preset sets must exist on that block type.
                val known = HomeCatalog.options.getValue(block.type).map { it.key }.toSet()
                assertTrue("${preset.key}: unknown option in ${block.opts.keys}", known.containsAll(block.opts.keys))
            }
        }
    }

    @Test
    fun everyPresetHasAKnownKey() {
        assertEquals(HomePresets.all.size, HomePresets.all.map { it.key }.toSet().size)
        assertEquals("hero", HomePresets.find("does-not-exist").key)
    }

    @Test
    fun optionsFallBackToTheirDefaults() {
        val storage = Block(1, BlockType.Storage, "ring")
        assertTrue(storage.opt("clean"))
        assertFalse(storage.opt("free"))
        assertFalse(storage.withOpt("clean", false).opt("clean"))
        assertFalse(storage.opt("no-such-option"))
    }

    @Test
    fun codecRoundTripsALayout() {
        val layout = HomePresets.build("pastel").copy(
            accent = 0xFF4D8DFF.toInt(),
            bitShow = false,
            bitBody = 0xFF2A2A30.toInt(),
            round = 0.25f,
            icons = IconStyle.Outline,
            spacing = Spacing.Roomy,
        )
        val hidden = layout.blocks[1].copy(hidden = true).withOpt("clean", false)
        val edited = layout.withBlock(hidden)

        assertEquals(edited, HomeLayoutCodec.decode(HomeLayoutCodec.encode(edited)))
    }

    @Test
    fun codecRejectsTextThatIsNotALayout() {
        assertNull(HomeLayoutCodec.decode(""))
        assertNull(HomeLayoutCodec.decode("hello"))
        assertNull(HomeLayoutCodec.decode("v9\nname=x"))
    }

    @Test
    fun codecSkipsBrokenLinesAndFixesUnknownStyles() {
        val text = """
            v1
            name=Mine
            round=7
            b=1|header|title|0|
            b=oops
            b=2|folders|from-the-future|0|count:0
            b=3|spaceship|x|0|
            b=1|storage|ring|0|
        """.trimIndent()
        val layout = HomeLayoutCodec.decode(text)!!
        // The broken line, the unknown type and the repeated id are dropped.
        assertEquals(listOf(1, 2), layout.blocks.map { it.id })
        // An unknown style becomes the first style of its type, and its options stay.
        assertEquals(HomeCatalog.stylesOf(BlockType.Folders).first().key, layout.blocks[1].style)
        assertFalse(layout.blocks[1].opt("count"))
        // Out-of-range roundness is pulled back in.
        assertEquals(1f, layout.round, 0f)
    }

    @Test
    fun addingPutsTheBlockAfterTheSelectedOne() {
        val layout = hero()
        val after = layout.blocks[1].id
        val (next, added) = layout.adding(BlockType.Extra, "dup", after)
        assertEquals(layout.blocks.size + 1, next.blocks.size)
        assertEquals(added.id, next.blocks[2].id)
        assertEquals(next.blocks.size, next.blocks.map { it.id }.toSet().size)

        val (atEnd, last) = layout.adding(BlockType.Extra, "act", null)
        assertEquals(last.id, atEnd.blocks.last().id)
    }

    @Test
    fun duplicatingGivesTheCopyItsOwnIdAndTheSameLook() {
        val layout = hero()
        val source = layout.blocks[2].withOpt("filter", false)
        val withEdit = layout.withBlock(source)
        val (next, copy) = withEdit.duplicating(source.id)
        assertNotEquals(source.id, copy!!.id)
        assertEquals(source.style, copy.style)
        assertEquals(source.opts, copy.opts)
        assertEquals(source.id, next.blocks[2].id)
        assertEquals(copy.id, next.blocks[3].id)
    }

    @Test
    fun movingAndRemovingKeepTheOtherBlocksInOrder() {
        val layout = hero()
        val ids = layout.blocks.map { it.id }
        assertEquals(listOf(ids[1], ids[0]) + ids.drop(2), layout.moving(0, 1).blocks.map { it.id })
        assertEquals(layout, layout.moving(0, 0))
        assertEquals(layout, layout.moving(0, 99))
        assertEquals(ids.drop(1), layout.removing(ids[0]).blocks.map { it.id })
    }

    @Test
    fun theRecentSheetOnlyCountsWhileItsPeekBlockIsVisible() {
        val layout = hero()
        assertTrue(layout.hasPeekSheet)
        val peek = layout.blocks.first { it.type == BlockType.Recent }
        assertFalse(layout.withBlock(peek.copy(hidden = true)).hasPeekSheet)
        assertFalse(layout.withBlock(peek.copy(style = "row")).hasPeekSheet)
        assertFalse(layout.removing(peek.id).hasPeekSheet)
    }

    @Test
    fun startingFromAPresetKeepsTheChosenLook() {
        val look = hero().copy(accent = 0xFF2DBE82.toInt(), icons = IconStyle.Mono, round = 0.1f)
        val built = HomePresets.build("quiet", look)
        assertEquals("Quiet", built.name)
        assertEquals(look.accent, built.accent)
        assertEquals(IconStyle.Mono, built.icons)
        assertEquals(0.1f, built.round, 0f)
    }
}
