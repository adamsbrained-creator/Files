package ix.app.files.data

import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** The Keystore is not there in a plain unit test, so a software key stands in for it. */
private class SoftwareWrapper : KeyWrapper {
    private val master = SecretKeySpec(ByteArray(32) { it.toByte() }, "AES")

    override fun wrap(key: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, master, GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(key)
    }

    override fun unwrap(blob: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, master, GCMParameterSpec(128, blob, 0, 12))
        return cipher.doFinal(blob, 12, blob.size - 12)
    }
}

class VaultTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private lateinit var vaultDir: File

    @Before
    fun setUp() {
        vaultDir = tmp.newFolder("private")
        Vault.configure(vaultDir)
        Vault.useKeyWrapper(SoftwareWrapper())
    }

    @After
    fun tearDown() {
        Vault.configure(null)
        Vault.useKeyWrapper(null)
    }

    private fun sample(size: Int): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }

    private fun lockedCopy(content: ByteArray, name: String = "f.bin"): File {
        val file = File(vaultDir, name)
        Vault.openWrite(file).use { it.write(content) }
        return file
    }

    private fun unlocked(file: File): ByteArray = Vault.openRead(file).use { it.readBytes() }

    @Test
    fun roundTrip_forSizesAroundThePieceBoundary() {
        val sizes = listOf(0, 1, 100, Vault.CHUNK - 1, Vault.CHUNK, Vault.CHUNK + 1, 3 * Vault.CHUNK, 200_000)
        for (size in sizes) {
            val content = sample(size)
            val file = lockedCopy(content)
            assertArrayEquals("size $size", content, unlocked(file))
            assertEquals("display size for $size", size.toLong(), Vault.displaySize(file, file.length()))
        }
    }

    @Test
    fun storedBytes_doNotContainThePlainContent() {
        val content = ByteArray(5_000) { 'A'.code.toByte() }
        val file = lockedCopy(content)
        assertTrue(Vault.isEncrypted(file))
        val stored = file.readBytes()
        assertFalse(String(stored, Charsets.ISO_8859_1).contains("AAAAAAAAAAAAAAAA"))
    }

    @Test
    fun aChangedByte_isNoticed() {
        val file = lockedCopy(sample(150_000))
        val stored = file.readBytes()
        stored[Vault.HEADER + 500] = (stored[Vault.HEADER + 500].toInt() xor 1).toByte()
        file.writeBytes(stored)
        try {
            unlocked(file)
            fail("A damaged file must not open")
        } catch (e: IOException) {
            // expected
        }
    }

    @Test
    fun aFileCutAtAPieceBoundary_isNoticed() {
        val file = lockedCopy(sample(3 * Vault.CHUNK))
        val stored = file.readBytes()
        // Drop the last piece. What is left is whole pieces, but the last one is no longer marked as last.
        file.writeBytes(stored.copyOf(stored.size - (Vault.CHUNK + 16)))
        try {
            unlocked(file)
            fail("A cut-off file must not open")
        } catch (e: IOException) {
            // expected
        }
    }

    @Test
    fun filesWithoutTheHeader_areReadAsTheyAre() {
        val plain = File(vaultDir, "old.txt")
        plain.writeText("from before encryption")
        assertFalse(Vault.isEncrypted(plain))
        assertEquals("from before encryption", unlocked(plain).toString(Charsets.UTF_8))
        assertEquals(plain.length(), Vault.displaySize(plain, plain.length()))
    }

    @Test
    fun lockExisting_locksPlainFilesOnceAndKeepsTheirContent() {
        val folder = File(vaultDir, "sub").also { it.mkdir() }
        val old = File(folder, "old.txt")
        old.writeText("hello")
        old.setLastModified(1_600_000_000_000L)
        Vault.lockExisting(vaultDir)
        assertTrue(Vault.isEncrypted(old) || old.length() < Vault.HEADER + 16L)
        assertEquals("hello", unlocked(old).toString(Charsets.UTF_8))
        assertEquals(1_600_000_000_000L, old.lastModified())
        val sizeAfterFirst = old.length()
        Vault.lockExisting(vaultDir)
        assertEquals(sizeAfterFirst, old.length())
        assertFalse(File(folder, "old.txt.ixtmp").exists())
    }

    @Test
    fun pasteIntoPrivate_locks_andPasteOutUnlocks() {
        val outside = tmp.newFolder("outside")
        val source = outside.write("photo.jpg", sample(100_000))
        val original = source.readBytes()

        val into = FileOps.paste(vaultDir, listOf(source.path), move = true)
        assertEquals(1, into.done.size)
        assertFalse(source.exists())
        val inside = File(into.done.single().second)
        assertTrue(Vault.isEncrypted(inside))
        assertFalse(original.contentEquals(inside.readBytes()))
        assertEquals(original.size.toLong(), Vault.displaySize(inside, inside.length()))

        val out = tmp.newFolder("out")
        val back = FileOps.paste(out, listOf(inside.path), move = true)
        assertEquals(1, back.done.size)
        assertArrayEquals(original, File(back.done.single().second).readBytes())
        assertFalse(inside.exists())
    }

    @Test
    fun copyInsidePrivate_staysLockedAndStillOpens() {
        val content = sample(70_000)
        val file = lockedCopy(content, "a.bin")
        val sub = File(vaultDir, "sub").also { it.mkdir() }
        val result = FileOps.paste(sub, listOf(file.path), move = false)
        val copy = File(result.done.single().second)
        assertTrue(Vault.isEncrypted(copy))
        assertArrayEquals(content, unlocked(copy))
    }

    @Test
    fun foldersGoInAndOutWithEverythingInThem() {
        val outside = tmp.newFolder("outside")
        val folder = File(outside, "trip").also { it.mkdir() }
        folder.write("a.txt", "one".toByteArray())
        File(folder, "deep").mkdir()
        File(folder, "deep/b.txt").writeText("two")

        val into = FileOps.paste(vaultDir, listOf(folder.path), move = true)
        val inside = File(into.done.single().second)
        assertEquals("two", unlocked(File(inside, "deep/b.txt")).toString(Charsets.UTF_8))

        val restored = FileOps.relocate(listOf(inside.path to folder.path))
        assertEquals(1, restored.size)
        assertEquals("one", File(folder, "a.txt").readText())
        assertEquals("two", File(folder, "deep/b.txt").readText())
    }
}
