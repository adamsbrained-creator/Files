package ix.app.files.ui.home

import android.app.Application
import android.media.MediaScannerConnection
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.data.Clip
import ix.app.files.data.DuplicateFinder
import ix.app.files.data.DuplicateGroup
import ix.app.files.data.FavoritesStore
import ix.app.files.data.FileOps
import ix.app.files.data.FileItem
import ix.app.files.data.FileScanner
import ix.app.files.data.FileKind
import ix.app.files.data.FolderItem
import ix.app.files.data.FolderLister
import ix.app.files.data.HomeTab
import ix.app.files.data.JobControl
import ix.app.files.data.KindSize
import ix.app.files.data.Listing
import ix.app.files.data.ScanData
import ix.app.files.data.SearchEngine
import ix.app.files.data.SearchResults
import ix.app.files.data.SettingsStore
import ix.app.files.data.SheetAnchor
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.data.StorageAccess
import ix.app.files.data.StorageReport
import ix.app.files.data.ThemeMode
import ix.app.files.data.Thumbnails
import ix.app.files.data.UndoKind
import ix.app.files.data.UndoNotice
import ix.app.files.data.Vault
import ix.app.files.data.ZipBrowser
import ix.app.files.data.sortedBySpec
import ix.app.files.data.sortedFoldersBySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

data class HomeState(
    val tab: HomeTab = HomeTab.All,
    val sort: SortSpec = SortSpec(),
    /** True for the grid of tiles, false for the list. Applies to folders, categories, search and Favorites. */
    val grid: Boolean = false,
    val showHidden: Boolean = false,
    val sheet: SheetAnchor = SheetAnchor.Hidden,
    val hasAccess: Boolean = false,
    val scanning: Boolean = false,
    val scan: ScanData = ScanData.Empty,
    val counts: Map<Category, Int> = emptyMap(),
    val recent: List<FileItem> = emptyList(),
    val openCategory: Category? = null,
    val openFiles: List<FileItem> = emptyList(),

    /** True while the Storage screen is open. [report] is filled in a moment later. */
    val reportOpen: Boolean = false,
    val report: StorageReport? = null,

    /** What is typed in the search field. Anything but blank means search results replace the tabs. */
    val query: String = "",
    val results: SearchResults = SearchResults.Empty,

    /** True after the user proved it is them. Private locks again by itself, see [onForegrounded]. */
    val privateUnlocked: Boolean = false,
    /** How many items sit in the Private folder. Only known while it is unlocked. */
    val privateCount: Int = 0,

    /** Items waiting to be pasted into a folder of the browser. Null when nothing is being copied or moved. */
    val clip: Clip? = null,
    /** True while a copy, move or delete runs. The screen shows a blocking "Working…" card. */
    val busy: Boolean = false,
    /** What the Working card says: Copying…, Moving…, and so on. */
    val busyLabel: Int = R.string.busy_working,
    /** How far the running job is, from 0 to 1. Null while that is not known. */
    val busyProgress: Float? = null,
    /** True when the Working card offers a Cancel button. */
    val busyCancellable: Boolean = false,

    /** Paths of the files and folders ticked in selection mode. Empty means not selecting. */
    val selected: Set<String> = emptySet(),

    /** Paths of every favorite, saved on the device. */
    val favorites: Set<String> = emptySet(),
    /** The favorites that still exist, ready to show on the Favorites tab. */
    val favoriteFolders: List<FolderItem> = emptyList(),
    val favoriteFiles: List<FileItem> = emptyList(),

    /** The folder the browser shows, or null while the browser is closed. */
    val browserPath: String? = null,
    val browserLoading: Boolean = false,
    val browserFailed: Boolean = false,
    val browserFolders: List<FolderItem> = emptyList(),
    val browserFiles: List<FileItem> = emptyList(),

    /** The zip being looked into, or null while that screen is closed. [zipInner] is the folder inside it. */
    val zipPath: String? = null,
    val zipInner: String = "",
    val zipLoading: Boolean = false,
    val zipFailed: Boolean = false,
    val zipFolders: List<FolderItem> = emptyList(),
    val zipFiles: List<FileItem> = emptyList(),

    /** True while the Duplicates screen is open. [dupGroups] fills in once the search finishes. */
    val dupOpen: Boolean = false,
    val dupLoading: Boolean = false,
    val dupGroups: List<DuplicateGroup> = emptyList(),

    /** The Undo bar at the bottom. Null when there is nothing to take back. */
    val undo: UndoNotice? = null,
)

/** What Undo needs to put things back. */
private class PendingUndo(
    val kind: UndoKind,
    /** For every item: where it was, and where it is now. */
    val pairs: List<Pair<String, String>>,
    /** The trash folder of a delete. It is emptied for good once the Undo bar goes away. */
    val trash: File?,
    /** Favorites that went with a delete, so Undo can star them again. */
    val lostFavorites: List<String>,
)

/** What a delete did, handed from the worker thread back to the view model. */
private class Trashed(
    val batch: File,
    val pairs: List<Pair<String, String>>,
    val removed: List<String>,
    val cancelled: Boolean,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val scanner = FileScanner()
    private val favoritesStore = FavoritesStore(application)
    private val settingsStore = SettingsStore(application)
    private var scanJob: Job? = null
    private var sortJob: Job? = null
    private var favoritesJob: Job? = null
    private var browserJob: Job? = null
    private var browserSortJob: Job? = null
    private var searchJob: Job? = null
    private var reportJob: Job? = null
    private var zipJob: Job? = null
    private var dupJob: Job? = null
    private var tickerJob: Job? = null
    private var activeJob: JobControl? = null
    private var lastScanAt = 0L
    private var scanGeneration = 0
    private var leftAt = 0L

    /** Private lives inside the app's own storage. Other apps and the gallery can not see it. */
    private val privateDir = File(application.filesDir, "private")
    val privateRootPath: String = privateDir.absolutePath

    /**
     * Deleted files wait here until the Undo bar goes away. It sits in the app's own folder on the same storage
     * as the files, so putting a file in it is an instant rename rather than a copy.
     */
    private val trashDir = File(application.getExternalFilesDir(null) ?: application.filesDir, ".trash")
    /** Unlocked copies of Private files, made for opening and sharing. Wiped when Private locks. */
    private val viewDir = File(application.cacheDir, "private-view")

    private var pendingUndo: PendingUndo? = null
    private var undoTimer: Job? = null

    /** Files taken out of a zip for opening live here. Emptied whenever a zip is opened or closed. */
    private val zipPreviewDir = File(application.cacheDir, "zip-preview")

    /** Every line of the zip being looked into, kept so walking between its folders needs no disk read. */
    @Volatile
    private var zipIndex: List<ZipBrowser.Entry> = emptyList()

    /** The unsorted contents of the folder in the browser, kept so a new sort needs no disk read. */
    @Volatile
    private var browserListing: Listing? = null

    private val _state = MutableStateFlow(
        settingsStore.load().let { settings ->
            HomeState(
                hasAccess = StorageAccess.hasAccess(application),
                favorites = favoritesStore.load(),
                sort = settings.sort,
                grid = settings.grid,
                showHidden = settings.showHidden,
            )
        },
    )
    val state: StateFlow<HomeState> = _state.asStateFlow()

    /**
     * True while something from Private is on screen. The activity then blocks screenshots and hides the
     * window in the Recent apps screen, so private files never show up there.
     */
    val secureScreen: StateFlow<Boolean> = _state
        .map { s ->
            s.privateUnlocked && (
                s.tab == HomeTab.Private ||
                    s.browserPath?.let { isPrivatePath(it) } == true ||
                    s.zipPath?.let { isPrivatePath(it) } == true
                )
        }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _themeMode = MutableStateFlow(settingsStore.load().theme)

    /** Kept apart from [state] so the activity can follow it without redrawing for every scan update. */
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    /** Light, dark, or follow the phone. Remembered. */
    fun setThemeMode(mode: ThemeMode) {
        settingsStore.saveTheme(mode)
        _themeMode.value = mode
    }

    private val _events = MutableSharedFlow<Int>(extraBufferCapacity = 4)

    /** One-off messages for the user, as string resource ids. The screen shows them as toasts. */
    val events: SharedFlow<Int> = _events.asSharedFlow()

    init {
        Vault.configure(privateDir)
        // Anything still in the trash is from a run that ended before its Undo bar did.
        viewModelScope.launch(Dispatchers.IO) {
            trashDir.deleteRecursively()
            viewDir.deleteRecursively()
        }
        if (_state.value.hasAccess) {
            startScan()
            resolveFavorites()
        }
    }

    /** Call when the app comes back to the front, and after the user answers the permission prompt. */
    fun refreshAccess() {
        val granted = StorageAccess.hasAccess(getApplication())
        _state.update { it.copy(hasAccess = granted) }
        if (!granted) return
        val neverScanned = lastScanAt == 0L
        val stale = SystemClock.elapsedRealtime() - lastScanAt > RESCAN_AFTER_MS
        if (scanJob?.isActive != true && (neverScanned || stale)) startScan()
        // Files may have changed while the app was in the background.
        resolveFavorites()
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    fun selectTab(tab: HomeTab) {
        _state.update { it.copy(tab = tab, selected = emptySet()) }
    }

    fun setSheet(anchor: SheetAnchor) {
        _state.update { it.copy(sheet = anchor) }
    }

    fun selectSort(field: SortField) {
        _state.update {
            val spec = it.sort.select(field)
            it.copy(sort = spec, recent = it.scan.recent.sortedBySpec(spec))
        }
        settingsStore.saveSort(_state.value.sort)
        sortOpenFiles()
        resortBrowser()
    }

    /** List or grid. Remembered. */
    fun setGrid(grid: Boolean) {
        settingsStore.saveGrid(grid)
        _state.update { it.copy(grid = grid) }
    }

    /** Shows or hides files and folders whose names start with a dot, in the folder browser. */
    fun setShowHidden(show: Boolean) {
        settingsStore.saveShowHidden(show)
        _state.update { it.copy(showHidden = show) }
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    // ---- Home folders (Downloads, Images, ...) ----

    fun openCategory(category: Category) {
        _state.update { it.copy(openCategory = category, openFiles = emptyList(), selected = emptySet()) }
        sortOpenFiles()
    }

    fun closeCategory() {
        sortJob?.cancel()
        _state.update { it.copy(openCategory = null, openFiles = emptyList(), selected = emptySet()) }
    }

    // ---- Selection and actions ----

    /** Ticks or unticks one item. The first tick starts selection mode, the last untick ends it. */
    fun toggleSelect(path: String) {
        _state.update {
            val now = it.selected
            it.copy(selected = if (path in now) now - path else now + path)
        }
    }

    fun clearSelection() {
        _state.update { if (it.selected.isEmpty()) it else it.copy(selected = emptySet()) }
    }

    /** If everything selected is already a favorite, removes them all. Otherwise adds them all. */
    fun toggleFavoriteSelected() {
        val chosen = _state.value.selected.filter { !isPrivatePath(it) }.toSet()
        if (chosen.isEmpty()) {
            clearSelection()
            return
        }
        val current = _state.value.favorites
        val next = if (chosen.all { it in current }) current - chosen else current + chosen
        favoritesStore.save(next)
        _state.update { it.copy(favorites = next, selected = emptySet()) }
        resolveFavorites()
    }

    /** Renames the one selected item. [newName] is the full new name, extension included. */
    fun renameSelected(newName: String) {
        val path = _state.value.selected.singleOrNull() ?: return
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/') || name == "." || name == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val old = File(path)
        val target = File(old.parentFile, name)
        if (target.path == old.path) {
            clearSelection()
            return
        }
        viewModelScope.launch {
            val renamed = withContext(Dispatchers.IO) {
                val ok = !target.exists() && old.renameTo(target)
                if (ok) MediaScannerConnection.scanFile(getApplication(), arrayOf(old.path, target.path), null, null)
                ok
            }
            if (!renamed) {
                _events.tryEmit(R.string.rename_failed)
                return@launch
            }
            val favorites = _state.value.favorites
            val nextFavorites = if (old.path in favorites) favorites - old.path + target.path else favorites
            if (nextFavorites != favorites) favoritesStore.save(nextFavorites)
            _state.update { it.copy(favorites = nextFavorites, selected = emptySet()) }
            reloadAfterChange()
            startScan()
        }
    }

    /**
     * Shows the Working card for a job that reports progress and can be stopped, and returns the object the
     * job reports to. Call [endJob] when it is over.
     */
    private fun beginJob(label: Int, cancellable: Boolean = true): JobControl {
        val job = JobControl()
        activeJob = job
        tickerJob?.cancel()
        _state.update { it.copy(busy = true, busyLabel = label, busyProgress = null, busyCancellable = cancellable) }
        tickerJob = viewModelScope.launch {
            while (true) {
                delay(200)
                val total = job.totalBytes
                // Whole percents only, so the screen is not redrawn for nothing.
                val percent = if (total > 0L) ((job.done * 100L) / total).toInt().coerceIn(0, 100) else -1
                val progress = if (percent >= 0) percent / 100f else null
                if (_state.value.busyProgress != progress) _state.update { it.copy(busyProgress = progress) }
            }
        }
        return job
    }

    /** Hides the Working card again. */
    private fun endJob() {
        tickerJob?.cancel()
        tickerJob = null
        activeJob = null
        _state.update {
            it.copy(busy = false, busyLabel = R.string.busy_working, busyProgress = null, busyCancellable = false)
        }
    }

    /** The Cancel button of the Working card. The job stops at its next small step. */
    fun cancelBusyJob() {
        activeJob?.cancel()
    }

    /**
     * Deletes everything selected. Folders go with all that is inside them. The screen asks first.
     * What is outside Private goes to the trash first, so the Undo bar can bring it back.
     */
    fun deleteSelected() {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_deleting)
        val favoritesBefore = _state.value.favorites
        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                val keep = paths.filter { !isPrivatePath(it) }
                val batch = File(trashDir, System.nanoTime().toString())
                var pairs: List<Pair<String, String>> = emptyList()
                var cancelled = false
                if (keep.isNotEmpty() && batch.mkdirs()) {
                    try {
                        File(trashDir, ".nomedia").createNewFile()
                    } catch (e: IOException) {
                        // Only keeps the gallery out of the trash. Nothing breaks without it.
                    }
                    val result = FileOps.paste(batch, keep, move = true, control = job)
                    pairs = result.done
                    cancelled = result.cancelled
                }
                if (!cancelled) {
                    // Whatever could not go to the trash (and everything in Private) is deleted outright.
                    val trashed = pairs.map { it.first }.toHashSet()
                    for (path in paths) {
                        if (path in trashed) continue
                        val file = File(path)
                        if (file.isDirectory) file.deleteRecursively() else file.delete()
                    }
                }
                MediaScannerConnection.scanFile(getApplication(), paths.toTypedArray(), null, null)
                if (pairs.isEmpty()) batch.deleteRecursively()
                Trashed(batch, pairs, paths.filter { !File(it).exists() }, cancelled)
            }
            if (outcome.cancelled) {
                _events.tryEmit(R.string.job_cancelled)
            } else if (outcome.removed.size < paths.size) {
                _events.tryEmit(R.string.delete_failed)
            }
            if (outcome.pairs.isNotEmpty()) {
                val lost = favoritesBefore.filter { fav ->
                    outcome.removed.any { gone -> fav == gone || fav.startsWith("$gone/") }
                }
                offerUndo(PendingUndo(UndoKind.Delete, outcome.pairs, outcome.batch, lost))
            }
            applyRemoved(outcome.removed)
        }
    }

    // ---- Undo ----

    /** Puts the Undo bar up for the action that just finished. A bar that was still up is settled first. */
    private fun offerUndo(pending: PendingUndo) {
        finishUndo()
        pendingUndo = pending
        _state.update { it.copy(undo = UndoNotice(pending.kind, pending.pairs.size)) }
        undoTimer = viewModelScope.launch {
            delay(UNDO_MS)
            finishUndo()
        }
    }

    /** The Undo bar was dismissed or ran out: what waits in the trash is deleted for good. */
    fun finishUndo() {
        undoTimer?.cancel()
        undoTimer = null
        val pending = pendingUndo ?: return
        pendingUndo = null
        _state.update { it.copy(undo = null) }
        val trash = pending.trash
        if (trash != null) viewModelScope.launch(Dispatchers.IO) { trash.deleteRecursively() }
    }

    /** The Undo button: puts the last delete, move or copy back the way it was. */
    fun undoLast() {
        val pending = pendingUndo ?: return
        pendingUndo = null
        undoTimer?.cancel()
        undoTimer = null
        _state.update { it.copy(undo = null) }
        val job = beginJob(R.string.busy_restoring, cancellable = false)
        viewModelScope.launch {
            val restored = withContext(Dispatchers.IO) {
                val back: List<Pair<String, String>> = if (pending.kind == UndoKind.Copy) {
                    // The copies are new files that this app made, so taking them away loses nothing.
                    for (pair in pending.pairs) {
                        val copy = File(pair.second)
                        if (copy.isDirectory) copy.deleteRecursively() else copy.delete()
                    }
                    emptyList()
                } else {
                    FileOps.relocate(pending.pairs.map { pair -> pair.second to pair.first }, job)
                }
                val touched = ArrayList<String>()
                touched.addAll(FileOps.filesUnder(back.map { it.second }))
                touched.addAll(pending.pairs.map { it.second })
                MediaScannerConnection.scanFile(getApplication(), touched.toTypedArray(), null, null)
                back
            }
            if (pending.kind != UndoKind.Copy && restored.size < pending.pairs.size) {
                _events.tryEmit(R.string.undo_failed)
            }
            val trash = pending.trash
            if (trash != null) viewModelScope.launch(Dispatchers.IO) { trash.deleteRecursively() }

            if (pending.kind == UndoKind.Copy) {
                applyRemoved(pending.pairs.map { it.second })
                return@launch
            }
            var favorites = _state.value.favorites
            if (pending.kind == UndoKind.Delete) {
                favorites = favorites + pending.lostFavorites.filter { File(it).exists() }
            } else {
                // A moved favorite goes back with the move.
                for ((from, actual) in restored) {
                    favorites = favorites.map { FileOps.remap(it, from, actual) ?: it }.toSet()
                }
            }
            if (favorites != _state.value.favorites) favoritesStore.save(favorites)
            endJob()
            _state.update { it.copy(favorites = favorites) }
            reloadAfterChange()
            refreshPrivateCount()
            startScan()
        }
    }

    /**
     * Drops items that are gone from the lists and from Favorites right away, instead of scanning
     * everything again, and ends the "Working…" card.
     */
    private suspend fun applyRemoved(removed: List<String>) {
        val pruned = withContext(Dispatchers.Default) { withoutPaths(_state.value.scan, removed) }
        val favorites = _state.value.favorites
        val kept = favorites.filterNot { fav ->
            removed.any { gone -> fav == gone || fav.startsWith("$gone/") }
        }.toSet()
        if (kept.size != favorites.size) favoritesStore.save(kept)
        val removedExact = removed.toHashSet()
        val removedPrefixes = removed.map { "$it/" }
        val isGone: (String) -> Boolean = { p -> p in removedExact || removedPrefixes.any { prefix -> p.startsWith(prefix) } }
        _state.update {
            it.copy(
                scan = pruned,
                counts = pruned.byCategory.mapValues { entry -> entry.value.size },
                recent = pruned.recent.sortedBySpec(it.sort),
                favorites = kept,
                // A group with only one file left is no longer a duplicate, so it drops out.
                dupGroups = it.dupGroups.mapNotNull { group ->
                    val left = group.files.filterNot { file -> isGone(file.path) }
                    if (left.size >= 2) DuplicateGroup(group.size, left) else null
                },
            )
        }
        endJob()
        sortOpenFiles()
        reloadAfterChange()
        if (_state.value.reportOpen) computeReport()
    }

    /** Copy or Move was tapped: remember the selection and let the user pick a folder in the browser. */
    fun startClip(move: Boolean) {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(clip = Clip(paths, move), selected = emptySet()) }
        // Copying out of Private starts at the top of storage, since that is where things go.
        val current = _state.value.browserPath
        if (current == null || isPrivatePath(current)) openStorage()
    }

    fun cancelClip() {
        _state.update { it.copy(clip = null) }
    }

    /** Pastes the waiting items into the folder the browser is showing. */
    fun pasteHere() {
        val clip = _state.value.clip ?: return
        val dest = _state.value.browserPath ?: return
        val job = beginJob(if (clip.move) R.string.busy_moving else R.string.busy_copying)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                val outcome = FileOps.paste(File(dest), clip.paths, clip.move, job)
                val touched = ArrayList<String>()
                touched.addAll(FileOps.filesUnder(outcome.done.map { it.second } + outcome.leftover))
                if (clip.move) touched.addAll(clip.paths)
                if (touched.isNotEmpty()) {
                    MediaScannerConnection.scanFile(getApplication(), touched.toTypedArray(), null, null)
                }
                outcome
            }
            if (result.cancelled) _events.tryEmit(R.string.job_cancelled)
            if (result.skipped > 0) _events.tryEmit(R.string.paste_skipped)
            if (result.failed > 0) _events.tryEmit(R.string.paste_failed)
            if (result.leftover.isNotEmpty()) _events.tryEmit(R.string.paste_original_stays)

            // A moved favorite stays a favorite at its new place.
            var favorites = _state.value.favorites
            if (clip.move) {
                for ((from, to) in result.done) {
                    favorites = favorites.map { FileOps.remap(it, from, to) ?: it }.toSet()
                }
                if (favorites != _state.value.favorites) favoritesStore.save(favorites)
            }
            endJob()
            _state.update { it.copy(clip = null, favorites = favorites) }
            if (result.done.isNotEmpty()) {
                offerUndo(PendingUndo(if (clip.move) UndoKind.Move else UndoKind.Copy, result.done, null, emptyList()))
            }
            reloadAfterChange()
            if (result.done.isNotEmpty() || result.leftover.isNotEmpty()) startScan()
        }
    }

    /** Creates a folder inside the folder the browser is showing. */
    fun createFolder(name: String) {
        val dir = _state.value.browserPath ?: return
        val clean = name.trim()
        if (clean.isEmpty() || clean.contains('/') || clean == "." || clean == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val target = File(dir, clean)
        viewModelScope.launch {
            val created = withContext(Dispatchers.IO) { !target.exists() && target.mkdir() }
            if (created) loadBrowser(dir) else _events.tryEmit(R.string.folder_failed)
        }
    }

    // ---- Zip ----

    /** Packs the selection into one zip file, next to the first selected item. */
    fun compressSelected() {
        // Zipping reads the files as they are stored, which for Private is locked, so Private is left out.
        val paths = _state.value.selected.filter { !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_compressing)
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val sources = paths.map { File(it) }.filter { it.exists() }
                val first = sources.firstOrNull() ?: return@withContext false
                val folder = first.parentFile ?: return@withContext false
                val baseName = if (sources.size == 1) first.nameWithoutExtension.ifEmpty { first.name } else "Archive"
                val target = FileOps.uniqueTarget(folder, "$baseName.zip")
                val made = FileOps.zip(sources, target, job)
                if (made) MediaScannerConnection.scanFile(getApplication(), arrayOf(target.path), null, null)
                made
            }
            _events.tryEmit(
                when {
                    ok -> R.string.compress_done
                    job.cancelled -> R.string.job_cancelled
                    else -> R.string.compress_failed
                },
            )
            endJob()
            reloadAfterChange()
            if (ok) startScan()
        }
    }

    /** Unpacks each selected zip into a new folder named after it, next to it. */
    fun extractSelected() = extractPaths(_state.value.selected.toList())

    /** Same, for zips named directly, such as the one tapped in a list. Other files are skipped. */
    fun extractPaths(requested: List<String>) {
        val paths = requested.filter { it.endsWith(".zip", ignoreCase = true) && !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_extracting)
        viewModelScope.launch {
            val failed = withContext(Dispatchers.IO) {
                var count = 0
                job.totalBytes = paths.sumOf { File(it).length() }
                for (path in paths) {
                    if (job.cancelled) break
                    val zip = File(path)
                    val folder = zip.parentFile
                    if (folder == null || !zip.isFile) {
                        count++
                        continue
                    }
                    val dest = FileOps.uniqueTarget(folder, zip.nameWithoutExtension.ifEmpty { "Extracted" })
                    val unpacked = FileOps.unzip(zip, dest, job)
                    if (!unpacked) {
                        // Do not leave half an extracted folder behind, whether it was cancelled or failed.
                        dest.deleteRecursively()
                        if (job.cancelled) break
                        count++
                        continue
                    }
                    val made = FileOps.filesUnder(listOf(dest.path))
                    if (made.isNotEmpty()) MediaScannerConnection.scanFile(getApplication(), made.toTypedArray(), null, null)
                }
                count
            }
            _events.tryEmit(
                when {
                    job.cancelled -> R.string.job_cancelled
                    failed > 0 -> R.string.extract_failed
                    else -> R.string.extract_done
                },
            )
            endJob()
            reloadAfterChange()
            startScan()
        }
    }

    // ---- Duplicates ----

    /** Opens the Duplicates screen and searches the last scan for identical files. */
    fun openDuplicates() {
        dupJob?.cancel()
        val files = _state.value.scan.files
        _state.update { it.copy(dupOpen = true, dupLoading = true, dupGroups = emptyList(), selected = emptySet()) }
        dupJob = viewModelScope.launch(Dispatchers.IO) {
            val groups = DuplicateFinder.find(files, active = { isActive })
            _state.update { if (it.dupOpen) it.copy(dupLoading = false, dupGroups = groups) else it }
        }
    }

    fun closeDuplicates() {
        dupJob?.cancel()
        _state.update { it.copy(dupOpen = false, dupLoading = false, dupGroups = emptyList(), selected = emptySet()) }
    }

    /** Ticks every copy except the oldest of each group, so one tap on Delete clears the extras. */
    fun selectDuplicateExtras() {
        val extras = _state.value.dupGroups.flatMap { group -> group.files.drop(1).map { it.path } }.toSet()
        _state.update { it.copy(selected = extras) }
    }

    // ---- Looking inside a zip ----

    /** Opens the zip's table of contents. Nothing is unpacked. */
    fun openZip(path: String) {
        zipJob?.cancel()
        zipIndex = emptyList()
        _state.update {
            it.copy(
                selected = emptySet(),
                zipPath = path,
                zipInner = "",
                zipLoading = true,
                zipFailed = false,
                zipFolders = emptyList(),
                zipFiles = emptyList(),
            )
        }
        zipJob = viewModelScope.launch(Dispatchers.IO) {
            zipPreviewDir.deleteRecursively()
            val entries = ZipBrowser.read(File(path))
            if (entries == null) {
                _state.update { if (it.zipPath == path) it.copy(zipLoading = false, zipFailed = true) else it }
            } else {
                zipIndex = entries
                val contents = ZipBrowser.contents(entries, "")
                _state.update {
                    if (it.zipPath == path) {
                        it.copy(zipLoading = false, zipFolders = contents.folders, zipFiles = contents.files)
                    } else {
                        it
                    }
                }
            }
        }
    }

    /** Walks into a folder of the open zip. [inner] is its path inside the zip. */
    fun openZipFolder(inner: String) {
        val path = _state.value.zipPath ?: return
        zipJob?.cancel()
        zipJob = viewModelScope.launch(Dispatchers.Default) {
            val contents = ZipBrowser.contents(zipIndex, inner)
            _state.update {
                if (it.zipPath == path) {
                    it.copy(zipInner = inner, zipFolders = contents.folders, zipFiles = contents.files)
                } else {
                    it
                }
            }
        }
    }

    /** One folder up inside the zip. From the top of the zip it closes the screen. */
    fun zipUp() {
        val inner = _state.value.zipInner
        if (inner.isEmpty()) closeZip() else openZipFolder(inner.substringBeforeLast('/', ""))
    }

    fun closeZip() {
        zipJob?.cancel()
        zipIndex = emptyList()
        _state.update {
            it.copy(
                zipPath = null,
                zipInner = "",
                zipLoading = false,
                zipFailed = false,
                zipFolders = emptyList(),
                zipFiles = emptyList(),
            )
        }
        viewModelScope.launch(Dispatchers.IO) { zipPreviewDir.deleteRecursively() }
    }

    /** The Extract button of the zip screen: closes it and unpacks the whole zip next to itself. */
    fun extractOpenZip() {
        val path = _state.value.zipPath ?: return
        closeZip()
        extractPaths(listOf(path))
    }

    /** Unpacks just the one file at [inner] into temporary space, then calls [onReady] with where it is. */
    fun previewZipEntry(inner: String, onReady: (String) -> Unit) {
        val zipPath = _state.value.zipPath ?: return
        val entry = zipIndex.firstOrNull { it.path == inner && !it.isDirectory } ?: return
        _state.update { it.copy(busy = true) }
        viewModelScope.launch {
            val out = withContext(Dispatchers.IO) {
                ZipBrowser.extractEntry(File(zipPath), entry, File(zipPreviewDir, System.nanoTime().toString()))
            }
            _state.update { it.copy(busy = false) }
            if (out == null) {
                _events.tryEmit(R.string.zip_entry_failed)
            } else {
                onReady(out.absolutePath)
            }
        }
    }

    // ---- Storage ----

    fun openReport() {
        _state.update { it.copy(reportOpen = true, report = null, selected = emptySet()) }
        computeReport()
    }

    fun closeReport() {
        reportJob?.cancel()
        _state.update { it.copy(reportOpen = false, report = null, selected = emptySet()) }
    }

    /** Adds up the scan by kind of file and picks the biggest files. Runs again when the scan changes. */
    private fun computeReport() {
        val files = _state.value.scan.files
        reportJob?.cancel()
        reportJob = viewModelScope.launch(Dispatchers.Default) {
            val bytes = LongArray(FileKind.entries.size)
            val counts = IntArray(FileKind.entries.size)
            var total = 0L
            for (file in files) {
                bytes[file.kind.ordinal] += file.sizeBytes
                counts[file.kind.ordinal]++
                total += file.sizeBytes
            }
            val byKind = FileKind.entries
                .map { KindSize(it, bytes[it.ordinal], counts[it.ordinal]) }
                .filter { it.count > 0 }
                .sortedByDescending { it.bytes }
            val largest = files.sortedByDescending { it.sizeBytes }.take(LARGEST_COUNT)
            val report = StorageReport(byKind = byKind, filesBytes = total, largest = largest)
            _state.update { if (it.reportOpen) it.copy(report = report) else it }
        }
    }

    // ---- Search ----

    /** Called on every keystroke. A blank query ends the search and brings the tabs back. */
    fun search(query: String) {
        _state.update {
            it.copy(
                query = query,
                // The Recent sheet has no place next to search results.
                sheet = if (query.isNotBlank()) SheetAnchor.Hidden else it.sheet,
                selected = if (it.query == query) it.selected else emptySet(),
            )
        }
        runSearch()
    }

    private fun runSearch() {
        val needle = _state.value.query.trim()
        searchJob?.cancel()
        if (needle.isEmpty()) {
            _state.update { it.copy(results = SearchResults.Empty) }
            return
        }
        val index = _state.value.scan
        searchJob = viewModelScope.launch(Dispatchers.Default) {
            // Wait a moment so fast typing does not search for every letter.
            delay(SEARCH_DEBOUNCE_MS)
            val found = SearchEngine.search(index, needle)
            _state.update { if (it.query.trim() == needle) it.copy(results = found) else it }
        }
    }

    /** Selects everything in [paths], or clears the selection if it is all selected already. */
    fun selectAll(paths: List<String>) {
        _state.update {
            if (it.selected.containsAll(paths)) it.copy(selected = emptySet()) else it.copy(selected = it.selected + paths)
        }
    }

    // ---- Private ----

    /**
     * Calls [onReady] with paths another app can read. Files outside Private are passed on as they are. Files in
     * Private are unlocked into a temporary folder first, which is wiped when Private locks.
     */
    fun withReadableCopies(paths: List<String>, onReady: (List<String>) -> Unit) {
        if (paths.none { isPrivatePath(it) }) {
            onReady(paths)
            return
        }
        val job = beginJob(R.string.busy_unlocking, cancellable = false)
        viewModelScope.launch {
            val readable = withContext(Dispatchers.IO) {
                val dir = File(viewDir, System.nanoTime().toString())
                dir.mkdirs()
                job.totalBytes = paths.filter { isPrivatePath(it) }.sumOf { File(it).length() }
                val result = ArrayList<String>()
                for (path in paths) {
                    val source = File(path)
                    if (!isPrivatePath(path)) {
                        result.add(path)
                    } else if (source.isFile) {
                        val copy = FileOps.uniqueTarget(dir, source.name)
                        try {
                            FileOps.copyFileTo(source, copy, job)
                            result.add(copy.path)
                        } catch (e: Exception) {
                            copy.delete()
                        }
                    }
                }
                result
            }
            endJob()
            if (readable.isEmpty()) {
                _events.tryEmit(R.string.unlock_file_failed)
            } else {
                onReady(readable)
            }
        }
    }

    fun isPrivatePath(path: String): Boolean = path == privateRootPath || path.startsWith("$privateRootPath/")

    /** The top folder the browser stops at: Private for Private paths, shared storage for the rest. */
    fun rootOf(path: String): String =
        if (isPrivatePath(path)) privateRootPath else StorageAccess.root().absolutePath

    fun unlockPrivate() {
        _state.update { it.copy(privateUnlocked = true) }
        refreshPrivateCount()
        // Creates the key on the first unlock, and locks files that were put here before encryption existed.
        viewModelScope.launch(Dispatchers.IO) {
            try {
                Vault.prepare()
                Vault.lockExisting(privateDir)
            } catch (e: Exception) {
                // Reading and writing report their own errors if the key is not usable.
            }
        }
    }

    /** Locks Private and closes anything that shows it. */
    fun lockPrivate() {
        val s = _state.value
        if (!s.privateUnlocked) return
        val browsingPrivate = s.browserPath?.let { isPrivatePath(it) } == true
        val clipHasPrivate = s.clip?.paths?.any { isPrivatePath(it) } == true
        val selectionHasPrivate = s.selected.any { isPrivatePath(it) }
        _state.update {
            it.copy(
                privateUnlocked = false,
                privateCount = 0,
                clip = if (clipHasPrivate) null else it.clip,
                selected = if (selectionHasPrivate) emptySet() else it.selected,
            )
        }
        if (browsingPrivate) closeBrowser()
        if (s.zipPath?.let { isPrivatePath(it) } == true) closeZip()
        Thumbnails.clear()
        viewModelScope.launch(Dispatchers.IO) { viewDir.deleteRecursively() }
    }

    fun openPrivate() {
        privateDir.mkdirs()
        openFolder(privateRootPath)
    }

    /** The app left the screen. Remember when, so Private can lock if the user stays away a while. */
    fun onBackgrounded() {
        leftAt = SystemClock.elapsedRealtime()
    }

    fun onForegrounded() {
        if (leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > PRIVATE_RELOCK_MS) lockPrivate()
    }

    /** Moves the selected items into Private. They disappear from everywhere else. */
    fun moveSelectedToPrivate() {
        if (!_state.value.privateUnlocked) return
        val paths = _state.value.selected.filter { !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_moving)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                privateDir.mkdirs()
                val outcome = FileOps.paste(privateDir, paths, move = true, control = job)
                MediaScannerConnection.scanFile(getApplication(), paths.toTypedArray(), null, null)
                outcome
            }
            if (result.cancelled) _events.tryEmit(R.string.job_cancelled)
            if (result.failed > 0) _events.tryEmit(R.string.paste_failed)
            if (result.leftover.isNotEmpty()) _events.tryEmit(R.string.paste_original_stays)
            if (result.done.isNotEmpty()) offerUndo(PendingUndo(UndoKind.Move, result.done, null, emptyList()))
            applyRemoved(result.done.map { it.first })
        }
    }

    private fun refreshPrivateCount() {
        if (!_state.value.privateUnlocked) return
        viewModelScope.launch(Dispatchers.IO) {
            val count = privateDir.list()?.size ?: 0
            _state.update { it.copy(privateCount = count) }
        }
    }

    private fun withoutPaths(data: ScanData, removed: List<String>): ScanData {
        val exact = removed.toHashSet()
        val prefixes = removed.map { "$it/" }
        fun gone(file: FileItem): Boolean = file.path in exact || prefixes.any { file.path.startsWith(it) }
        fun goneFolder(folder: FolderItem): Boolean =
            folder.path in exact || prefixes.any { folder.path.startsWith(it) }
        return ScanData(
            byCategory = data.byCategory.mapValues { entry -> entry.value.filterNot { gone(it) } },
            recent = data.recent.filterNot { gone(it) },
            files = data.files.filterNot { gone(it) },
            folders = data.folders.filterNot { goneFolder(it) },
        )
    }

    private fun reloadAfterChange() {
        resolveFavorites()
        refreshPrivateCount()
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    // ---- Favorites ----

    /** Looks up the saved paths on disk. Ones that no longer exist are simply not shown. */
    private fun resolveFavorites() {
        val paths = _state.value.favorites
        favoritesJob?.cancel()
        favoritesJob = viewModelScope.launch(Dispatchers.IO) {
            val folders = ArrayList<FolderItem>()
            val files = ArrayList<FileItem>()
            for (path in paths) {
                if (isPrivatePath(path)) continue
                val folder = FolderLister.folderAt(path)
                if (folder != null) {
                    folders.add(folder)
                } else {
                    val file = FolderLister.fileAt(path)
                    if (file != null) files.add(file)
                }
            }
            val sortedFolders = folders.sortedBy { it.name.lowercase() }
            val sortedFiles = files.sortedBy { it.name.lowercase() }
            _state.update { it.copy(favoriteFolders = sortedFolders, favoriteFiles = sortedFiles) }
        }
    }

    // ---- Folder browser ----

    /** Opens the root of shared storage. */
    fun openStorage() {
        openFolder(StorageAccess.root().absolutePath)
    }

    fun openFolder(path: String) {
        browserListing = null
        _state.update {
            it.copy(
                selected = emptySet(),
                browserPath = path,
                browserLoading = true,
                browserFailed = false,
                browserFolders = emptyList(),
                browserFiles = emptyList(),
            )
        }
        loadBrowser(path)
    }

    /** Goes one folder up. From the top of storage it closes the browser. */
    fun browserUp() {
        val path = _state.value.browserPath ?: return
        val root = rootOf(path)
        val parent = File(path).parent
        if (path == root || parent == null || !parent.startsWith(root)) {
            closeBrowser()
        } else {
            openFolder(parent)
        }
    }

    fun closeBrowser() {
        browserJob?.cancel()
        browserSortJob?.cancel()
        browserListing = null
        _state.update {
            it.copy(
                clip = null,
                selected = emptySet(),
                browserPath = null,
                browserLoading = false,
                browserFailed = false,
                browserFolders = emptyList(),
                browserFiles = emptyList(),
            )
        }
    }

    private fun loadBrowser(path: String) {
        browserJob?.cancel()
        browserJob = viewModelScope.launch(Dispatchers.IO) {
            val listing = FolderLister.list(File(path), _state.value.showHidden)
            val spec = _state.value.sort
            val folders = listing.folders.sortedFoldersBySpec(spec)
            val files = listing.files.sortedBySpec(spec)
            _state.update {
                if (it.browserPath == path) {
                    browserListing = listing
                    it.copy(
                        browserLoading = false,
                        browserFailed = listing.failed,
                        browserFolders = folders,
                        browserFiles = files,
                    )
                } else {
                    it
                }
            }
        }
    }

    /** The sort changed: reorder what is already loaded. */
    private fun resortBrowser() {
        val path = _state.value.browserPath ?: return
        val listing = browserListing ?: return
        val spec = _state.value.sort
        browserSortJob?.cancel()
        browserSortJob = viewModelScope.launch(Dispatchers.Default) {
            val folders = listing.folders.sortedFoldersBySpec(spec)
            val files = listing.files.sortedBySpec(spec)
            _state.update {
                if (it.browserPath == path) it.copy(browserFolders = folders, browserFiles = files) else it
            }
        }
    }

    // ---- Scanning ----

    private fun startScan() {
        scanJob?.cancel()
        // The scan that was just cancelled finishes later than this line. Only the newest one may say "done".
        val generation = ++scanGeneration
        scanJob = viewModelScope.launch {
            _state.update { it.copy(scanning = true) }
            try {
                // The first scan shows progress as it goes. Later scans only replace the numbers
                // when they are complete, so counts never drop back while a rescan is running.
                val progressive = lastScanAt == 0L
                var latest: ScanData? = null
                scanner.scan(StorageAccess.root()) { data ->
                    if (progressive) applyScan(data) else latest = data
                }
                latest?.let { applyScan(it) }
                lastScanAt = SystemClock.elapsedRealtime()
            } finally {
                if (generation == scanGeneration) _state.update { it.copy(scanning = false) }
            }
        }
    }

    /** Called from the scanner's thread. Cheap on purpose: only the small recent list is sorted here. */
    private fun applyScan(data: ScanData) {
        _state.update {
            it.copy(
                scan = data,
                counts = data.byCategory.mapValues { entry -> entry.value.size },
                recent = data.recent.sortedBySpec(it.sort),
            )
        }
        sortOpenFiles()
        if (_state.value.query.isNotBlank()) runSearch()
        if (_state.value.reportOpen) computeReport()
    }

    /** Sorting a folder with tens of thousands of files happens off the main thread. */
    private fun sortOpenFiles() {
        val current = _state.value
        val category = current.openCategory ?: return
        val source = current.scan.byCategory[category].orEmpty()
        val spec = current.sort
        sortJob?.cancel()
        sortJob = viewModelScope.launch(Dispatchers.Default) {
            val sorted = source.sortedBySpec(spec)
            _state.update { if (it.openCategory == category) it.copy(openFiles = sorted) else it }
        }
    }

    private companion object {
        const val RESCAN_AFTER_MS = 60_000L
        const val SEARCH_DEBOUNCE_MS = 120L
        const val LARGEST_COUNT = 40
        const val PRIVATE_RELOCK_MS = 60_000L

        /** How long the Undo bar stays up. */
        const val UNDO_MS = 8_000L
    }
}
