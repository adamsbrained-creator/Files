package ix.app.files.data

import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.attribute.BasicFileAttributes

/** Reads one folder at a time for the browser. Call it off the main thread. */
object FolderLister {

    /**
     * Everything in [dir]. Hidden entries (names starting with a dot) are left out
     * unless [showHidden] is true.
     */
    fun list(dir: File, showHidden: Boolean = false): Listing {
        val folders = ArrayList<FolderItem>()
        val files = ArrayList<FileItem>()
        try {
            Files.newDirectoryStream(dir.toPath()).use { stream ->
                for (entry in stream) {
                    val name = entry.fileName?.toString() ?: continue
                    if (!showHidden && name.startsWith(".")) continue
                    val attrs = try {
                        Files.readAttributes(entry, BasicFileAttributes::class.java)
                    } catch (e: IOException) {
                        continue
                    }
                    if (attrs.isDirectory) {
                        folders.add(folderItemOf(entry, name, attrs, showHidden))
                    } else if (attrs.isRegularFile) {
                        files.add(fileItemOf(entry, name, attrs))
                    }
                }
            }
        } catch (e: Exception) {
            return Listing(emptyList(), emptyList(), failed = true)
        }
        return Listing(folders, files, failed = false)
    }

    /** A saved path turned back into a folder, or null if it is gone or is not a folder. */
    fun folderAt(path: String): FolderItem? = try {
        val p = File(path).toPath()
        val attrs = Files.readAttributes(p, BasicFileAttributes::class.java)
        if (attrs.isDirectory) folderItemOf(p, p.fileName?.toString() ?: path, attrs) else null
    } catch (e: Exception) {
        null
    }

    /** A saved path turned back into a file, or null if it is gone or is not a file. */
    fun fileAt(path: String): FileItem? = try {
        val p = File(path).toPath()
        val attrs = Files.readAttributes(p, BasicFileAttributes::class.java)
        if (attrs.isRegularFile) fileItemOf(p, p.fileName?.toString() ?: path, attrs) else null
    } catch (e: Exception) {
        null
    }

    private fun folderItemOf(path: Path, name: String, attrs: BasicFileAttributes, showHidden: Boolean = false) = FolderItem(
        path = path.toString(),
        name = name,
        childCount = countChildren(path, showHidden),
        modifiedMillis = attrs.lastModifiedTime().toMillis(),
    )

    private fun fileItemOf(path: Path, fileName: String, attrs: BasicFileAttributes): FileItem {
        val dot = fileName.lastIndexOf('.')
        val name = if (dot > 0) fileName.substring(0, dot) else fileName
        val extension = if (dot > 0 && dot < fileName.length - 1) fileName.substring(dot + 1).lowercase() else ""
        return FileItem(
            path = path.toString(),
            name = name,
            extension = extension,
            sizeBytes = Vault.displaySize(path.toFile(), attrs.size()),
            modifiedMillis = attrs.lastModifiedTime().toMillis(),
            kind = FileKinds.kindOf(extension),
        )
    }

    private fun countChildren(dir: Path, showHidden: Boolean): Int = try {
        Files.newDirectoryStream(dir).use { stream ->
            stream.count { entry -> showHidden || entry.fileName?.toString()?.startsWith(".") == false }
        }
    } catch (e: Exception) {
        0
    }
}
