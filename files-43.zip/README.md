# ix.app.files

A fast, minimal Android file manager. Kotlin, Jetpack Compose, Material 3.

Design reference: the Home mockup (dark, gray folders, bottom "Recent" sheet).
Behavior reference: [Material Files](https://github.com/zhanghai/materialfiles). It is GPL-3.0 and is
only a reference for how a file manager should behave. No code is copied from it.

## Status: Step 43 (Freeform Home canvas)

| Done | Next |
| --- | --- |
| Freeform Home: drag the folders anywhere on the canvas, press and hold an empty spot for New folder, New file and Import. Menu, Home: Grid or Freeform | |
| Welcome pages on the first start: Welcome, then Everything in one place (Next, Skip, Get started). Phones that already gave file access skip them | |
| Home layout from the mockup | |
| Real folder counts and Recent files (background scan) | |
| Folder browser: any folder, path bar, sort, new folder | |
| Favorites, saved on the device | |
| Previews: pictures, video frames, song covers, app icons, first page of PDFs | |
| Selection: copy, move, share, delete, favorite, rename, details, select all | |
| Private folder behind fingerprint, face or screen lock, with every file encrypted and every name hidden | |
| Search across every file and folder by name or extension | |
| Menu: layout, theme (system, light, dark), show hidden files, storage, duplicates, clean up | |
| Zip: compress, extract, look inside without extracting | |
| Archives open on a tap: zip, 7z, rar, tar, tar.gz, tar.bz2, tar.xz and single .gz, .bz2, .xz files; unpack from the press-and-hold menu | |
| Clean up screen: installers, temporary and empty files, empty folders, big files untouched for months | |
| Search filters: type, size and date, alone or together with text | |
| Picture viewer: swipe through a folder, pinch and double-tap zoom, Share, Open with, Delete (Private pictures too) | |
| Folder browser remembers where each folder was scrolled to, and pulls down to refresh | |
| Find in text: highlighted hits, next and previous, count. In the editor it also replaces one hit or all of them | |
| Text reader and editor: line numbers, wrap, text size, edit and save (UTF-8, up to 512 KB), Private files stay locked | |
| Duplicate finder with Select extras | |
| Batch rename: numbering, find and replace, add text, with a live preview and no overwrites | |
| Checksums: MD5, SHA-1 and SHA-256 of a file (Private files too), tap to copy | |
| Trash: deleted items wait 30 days (or 7, or not at all), restore, delete forever or empty | |
| Apps: installed apps with size, search and sort, open, info, uninstall, back up the apk (split apks too) | |
| Progress bar and Cancel for copy, move, zip and extract | |
| Undo for delete, move and copy (a few seconds, one level) | |
| Safer move, copies keep their date, extract checks free space | |
| Duplicates confirmed by comparing whole files | |
| Private hidden from screenshots and the Recent apps screen | |
| Unit tests for file operations, search, sorting, zip and duplicates | |
| Storage screen: usage by kind of file, largest files you can delete | |
| Home folders: press and hold to rename, change color and icon; add your own folders with the New folder tile | |
| Private key tied to the unlock: the key opens only right after a fingerprint or the screen lock, and leaves memory when Private locks. Older Private files move to it on the first unlock | |
| Add to Home: select one folder, More, Add to Home (or Remove from Home). It gets a tile you can rename, color and arrange | |
| A Home folder that was deleted or moved shows dimmed as "Folder not found"; tap it to remove the tile | |
| Saved searches: keep a search with its filters under a name (up to 20), run it again from the Saved chip, delete it | |
| Arrange: drag the Home folders, built-in and added, into your own order (press and hold, then Arrange) | |
| Cast: show videos, songs and pictures on a TV, Xbox or PC on the same Wi-Fi (DLNA / UPnP). Select files, More, Cast to device; or Cast in the picture viewer. A remote at the bottom has play, pause, seek, next, previous and volume, and keeps going with the screen off | |

**Private** is a folder inside the app's own storage, so other apps and the gallery can not see it.
It opens with the phone's fingerprint, face or screen lock, and locks again after the app has been
away for a minute. Every file in it is encrypted: each file gets its own random AES-256 key, sealed
with a master key that lives in the Android Keystore and never leaves the phone's secure hardware.
The content is stored in 64 KB pieces with AES-GCM, so a changed or cut-off file is noticed.
Names of files and folders are encrypted too (stored as "~" and scrambled text, with the key kept beside the folder and sealed by the same Keystore key). What is not hidden: sizes (roughly), dates and how many items a folder holds. Someone who copies the
files off the phone, even with root access, gets unreadable content. The file keys are sealed by one root key. The root key is kept in a file next to Private, sealed by a Keystore key
that only works for a minute after a strong fingerprint or the screen lock (a weak face unlock does not count).
While Private is unlocked the root key sits in memory; locking Private wipes it, so code running inside the app
on an unlocked phone can not open Private files without the user unlocking again. **If the phone's screen lock is
removed or reset to none, Android deletes that Keystore key and the files in Private can no longer be opened.**
Changing from one PIN or pattern to another is fine, and so is adding a fingerprint. Files made by earlier versions
are moved to the new key on the first unlock (only the small sealed key in each file's header changes, in place),
and the old key is removed once every file has moved. Opening or sharing a file makes a temporary readable copy that is wiped when
Private locks. Files in Private are deleted if the app is uninstalled or its data is cleared.

The app asks for **All files access** on Android 11 and up (a settings page), or the normal storage
permission on Android 8 to 10.

**Casting** uses network permissions, but only for the home network: the app looks for DLNA / UPnP media renderers
(an Xbox, a smart TV, Kodi, Windows Media Player) with SSDP, and starts a small web server on the phone that only
serves the files you picked, behind a random address that changes every time. The TV downloads the file from the
phone, so seeking works (HTTP Range) and nothing goes through the internet. Files in Private are never cast.
A foreground service (the "Casting" notification, with Stop) keeps the phone serving the file while the screen is off.
Two options in the Cast sheet help stubborn devices: "Check formats first" (skip files the device says it can not
play) and "Plain stream" (no DLNA headers). "Copy log" in the same sheet copies what happened, for bug reports.
Not every device plays every format: an Xbox handles mp4 (H.264) best, mkv and avi depend on the model.

## Tests

Plain JVM tests live in `app/src/test`. Run them with `./gradlew :app:testDebugUnitTest`. The GitHub workflow runs them
before building the APK and uploads the report as `unit-test-report`.

## Build locally

Needs JDK 17 and the Android SDK (API 35).

```
./gradlew :app:assembleRelease
```

The APK lands in `app/build/outputs/apk/release/`.

## Build on GitHub

1. Create a repo and push this folder to `main`.
2. Open the **Actions** tab. **Release APK** runs on its own for every push.
   You can also start it with **Run workflow**.
3. When it finishes, open the run and download:
   - `ix.app.files-release-apk` is the installable APK.
   - `r8-mapping` is the R8 mapping file. Keep it to decode crash traces.
4. To publish a GitHub Release with the APK attached, push a tag: `git tag v0.1.0 && git push --tags`.

Without any secrets the APK is signed with the **debug key**. It installs fine and is good for testing.
Debug-signed and own-key-signed builds can't be installed over each other, so uninstall first if you switch.

### Sign with your own key (optional)

Create a keystore once:

```
keytool -genkeypair -v -keystore release.jks -alias ixfiles -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks > release.jks.b64        # on macOS: base64 -i release.jks
```

Then add four repository secrets (Settings > Secrets and variables > Actions):

| Secret | Value |
| --- | --- |
| `IX_KEYSTORE_BASE64` | contents of `release.jks.b64` |
| `IX_KEYSTORE_PASSWORD` | the store password |
| `IX_KEY_ALIAS` | `ixfiles` (or your alias) |
| `IX_KEY_PASSWORD` | the key password |

Keep `release.jks` somewhere safe and never commit it. Losing it means you can't update installed copies.

## Project layout

```
app/src/main/java/ix/app/files/
  MainActivity.kt
  data/        models, scanner, search, folder lister, file operations, favorites and settings stores, thumbnails, storage info
  ui/theme/    colors and theme
  ui/components/  PathIcon (stroked SVG icons), FolderIcon, FileIcon
  cast/        DLNA / UPnP casting: discovery (SSDP), SOAP, file server with Range, engine, hub and foreground service
  ui/cast/     the Cast to sheet and the remote bar
  ui/home/     HomeScreen, header, tabs, category grid, recent sheet, folder browser, favorites, selection bars, name dialog, unlock, list/grid view, menu, storage screen, view model
  util/        size formatting, opening and sharing files
  (tests)      app/src/test/java/ix/app/files/data and .../cast
```

Icons are drawn from the same SVG paths as the mockup, so there are no icon libraries or image files.
