package ix.app.files.data

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class TrashStoreTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private val trash get() = File(tmp.root, "trash").also { it.mkdirs() }

    /** A batch as a delete makes it: items renamed in, note beside them. */
    private fun batch(name: String, at: Long, vararg items: Pair<String, ByteArray>): File {
        val batch = File(trash, name).also { it.mkdirs() }
        val pairs = items.map { (original, bytes) ->
            val stored = File(batch, File(original).name).also { it.writeBytes(bytes) }
            original to stored.path
        }
        TrashStore.record(batch, pairs, at)
        return batch
    }

    @Test
    fun listsItemsNewestFirstWithOriginsAndSizes() {
        batch("t1", 1_000L, "/sdcard/Download/a.txt" to ByteArray(10))
        batch("t2", 2_000L, "/sdcard/DCIM/b.jpg" to ByteArray(20), "/sdcard/DCIM/c.jpg" to ByteArray(5))
        val items = TrashStore.list(listOf(trash))
        assertEquals(listOf("b.jpg", "c.jpg", "a.txt"), items.map { it.name })
        assertEquals("/sdcard/DCIM/b.jpg", items[0].originalPath)
        assertEquals(2_000L, items[0].deletedAt)
        assertEquals(20L, items[0].bytes)
        assertFalse(items[0].isDirectory)
    }

    @Test
    fun foldersAreSizedAndListedAsFolders() {
        val batch = File(trash, "t1").also { it.mkdirs() }
        val folder = File(batch, "pics").also { it.mkdirs() }
        folder.write("one", ByteArray(7))
        File(folder, "deep").also { it.mkdirs() }.write("two", ByteArray(3))
        TrashStore.record(batch, listOf("/sdcard/pics" to folder.path), 5L)
        val item = TrashStore.list(listOf(trash)).single()
        assertTrue(item.isDirectory)
        assertEquals(10L, item.bytes)
    }

    @Test
    fun namesWithTabsAndNewlinesSurvive() {
        val weird = "/sdcard/we\tird\nname\\x.txt"
        val batch = File(trash, "t1").also { it.mkdirs() }
        val stored = File(batch, "x.txt").also { it.writeBytes(byteArrayOf(1)) }
        TrashStore.record(batch, listOf(weird to stored.path), 9L)
        assertEquals(weird, TrashStore.list(listOf(trash)).single().originalPath)
    }

    @Test
    fun withoutANoteItemsAreStillListedWithNoOrigin() {
        val batch = File(trash, "t1").also { it.mkdirs() }
        batch.write("lost.txt", byteArrayOf(1, 2))
        val item = TrashStore.list(listOf(trash)).single()
        assertEquals("lost.txt", item.name)
        assertNull(item.originalPath)
        val fallback = File(tmp.root, "Restored")
        assertEquals(File(fallback, "lost.txt").path, TrashStore.restorePairs(listOf(item), fallback).single().second)
    }

    @Test
    fun releaseStrikesItemsAndRemovesAnEmptyBatch() {
        val b = batch("t1", 1L, "/s/a.txt" to ByteArray(1), "/s/b.txt" to ByteArray(1))
        val first = TrashStore.list(listOf(trash)).first { it.name == "a.txt" }
        File(first.storedPath).delete()
        TrashStore.release(b, listOf(first.storedPath))
        val left = TrashStore.list(listOf(trash)).single()
        assertEquals("b.txt", left.name)
        assertEquals("/s/b.txt", left.originalPath)
        assertEquals(1L, left.deletedAt)
        File(left.storedPath).delete()
        TrashStore.release(b, listOf(left.storedPath))
        assertFalse(b.exists())
    }

    @Test
    fun deleteRemovesFilesAndFolders() {
        val b = batch("t1", 1L, "/s/a.txt" to ByteArray(4))
        val folder = File(b, "dir").also { it.mkdirs() }
        folder.write("x", ByteArray(1))
        val items = TrashStore.list(listOf(trash))
        assertEquals(2, items.size)
        assertEquals(2, TrashStore.delete(items))
        assertFalse(b.exists())
        assertTrue(TrashStore.list(listOf(trash)).isEmpty())
    }

    @Test
    fun deleteStoppedByCancelLeavesTheRest() {
        batch("t1", 1L, "/s/a.txt" to ByteArray(1), "/s/b.txt" to ByteArray(1))
        val control = JobControl().also { it.cancel() }
        var stopped = false
        try {
            TrashStore.delete(TrashStore.list(listOf(trash)), control)
        } catch (e: JobStopped) {
            stopped = true
        }
        assertTrue(stopped)
        assertEquals(2, TrashStore.list(listOf(trash)).size)
    }

    @Test
    fun purgeKeepsRecentBatchesAndDropsOldOnes() {
        val day = 24L * 60 * 60 * 1000
        val old = batch("old", 1_000L, "/s/old.txt" to ByteArray(1))
        val fresh = batch("fresh", 40 * day, "/s/fresh.txt" to ByteArray(1))
        val removed = TrashStore.purgeOlderThan(listOf(trash), 30 * day, 45 * day)
        assertEquals(1, removed)
        assertFalse(old.exists())
        assertTrue(fresh.exists())
    }

    @Test
    fun purgeWithZeroAgeDropsEverything() {
        batch("a", 5L, "/s/a.txt" to ByteArray(1))
        batch("b", 6L, "/s/b.txt" to ByteArray(1))
        assertEquals(2, TrashStore.purgeOlderThan(listOf(trash), 0L, 10L))
        assertTrue(TrashStore.list(listOf(trash)).isEmpty())
    }

    @Test
    fun clearEmptiesEverythingButTheMarker() {
        batch("a", 5L, "/s/a.txt" to ByteArray(1))
        File(trash, ".nomedia").createNewFile()
        TrashStore.clear(listOf(trash))
        assertEquals(listOf(".nomedia"), trash.list()!!.toList())
    }

    @Test
    fun missingDirsAreFine() {
        assertTrue(TrashStore.list(listOf(File(tmp.root, "nope"))).isEmpty())
        assertEquals(0, TrashStore.purgeOlderThan(listOf(File(tmp.root, "nope")), 0L, 1L))
    }

    @Test
    fun restoreThroughRelocateBringsItemsBack() {
        val home = File(tmp.root, "docs").also { it.mkdirs() }
        val original = File(home, "a.txt")
        val b = batch("t1", 1L, original.path to byteArrayOf(5))
        val item = TrashStore.list(listOf(trash)).single()
        // The original folder is gone; relocate makes it again.
        home.deleteRecursively()
        val done = FileOps.relocate(TrashStore.restorePairs(listOf(item), File(tmp.root, "Restored")))
        assertEquals(1, done.size)
        assertEquals(5, original.readBytes()[0].toInt())
        TrashStore.release(b, done.map { it.first })
        assertFalse(b.exists())
    }
}
