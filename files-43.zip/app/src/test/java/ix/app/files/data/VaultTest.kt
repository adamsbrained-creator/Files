package ix.app.files.data

import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** The Keystore is not there in a plain unit test, so a software key stands in for it. */
private class SoftwareWrapper : KeyWrapper {
    private val master = SecretKeySpec(ByteArray(32) { it.toByte() }, "AES")

    override fun wrap(key: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, master, GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(key)
    }

    override fun unwrap(blob: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, master, GCMParameterSpec(128, blob, 0, 12))
        return cipher.doFinal(blob, 12, blob.size - 12)
    }
}

class VaultTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private lateinit var vaultDir: File

    @Before
    fun setUp() {
        vaultDir = tmp.newFolder("private")
        Vault.configure(vaultDir)
        Vault.useKeyWrapper(SoftwareWrapper())
    }

    @After
    fun tearDown() {
        Vault.configure(null)
        Vault.useKeyWrapper(null)
    }

    private fun sample(size: Int): ByteArray = ByteArray(size).also { SecureRandom().nextBytes(it) }

    private fun lockedCopy(content: ByteArray, name: String = "f.bin"): File {
        val file = File(vaultDir, name)
        Vault.openWrite(file).use { it.write(content) }
        return file
    }

    private fun unlocked(file: File): ByteArray = Vault.openRead(file).use { it.readBytes() }

    @Test
    fun roundTrip_forSizesAroundThePieceBoundary() {
        val sizes = listOf(0, 1, 100, Vault.CHUNK - 1, Vault.CHUNK, Vault.CHUNK + 1, 3 * Vault.CHUNK, 200_000)
        for (size in sizes) {
            val content = sample(size)
            val file = lockedCopy(content)
            assertArrayEquals("size $size", content, unlocked(file))
            assertEquals("display size for $size", size.toLong(), Vault.displaySize(file, file.length()))
        }
    }

    @Test
    fun storedBytes_doNotContainThePlainContent() {
        val content = ByteArray(5_000) { 'A'.code.toByte() }
        val file = lockedCopy(content)
        assertTrue(Vault.isEncrypted(file))
        val stored = file.readBytes()
        assertFalse(String(stored, Charsets.ISO_8859_1).contains("AAAAAAAAAAAAAAAA"))
    }

    @Test
    fun aChangedByte_isNoticed() {
        val file = lockedCopy(sample(150_000))
        val stored = file.readBytes()
        stored[Vault.HEADER + 500] = (stored[Vault.HEADER + 500].toInt() xor 1).toByte()
        file.writeBytes(stored)
        try {
            unlocked(file)
            fail("A damaged file must not open")
        } catch (e: IOException) {
            // expected
        }
    }

    @Test
    fun aFileCutAtAPieceBoundary_isNoticed() {
        val file = lockedCopy(sample(3 * Vault.CHUNK))
        val stored = file.readBytes()
        // Drop the last piece. What is left is whole pieces, but the last one is no longer marked as last.
        file.writeBytes(stored.copyOf(stored.size - (Vault.CHUNK + 16)))
        try {
            unlocked(file)
            fail("A cut-off file must not open")
        } catch (e: IOException) {
            // expected
        }
    }

    @Test
    fun filesWithoutTheHeader_areReadAsTheyAre() {
        val plain = File(vaultDir, "old.txt")
        plain.writeText("from before encryption")
        assertFalse(Vault.isEncrypted(plain))
        assertEquals("from before encryption", unlocked(plain).toString(Charsets.UTF_8))
        assertEquals(plain.length(), Vault.displaySize(plain, plain.length()))
    }

    @Test
    fun lockExisting_locksPlainFilesOnceAndKeepsTheirContent() {
        val old = File(vaultDir, "old.txt")
        old.writeText("hello")
        old.setLastModified(1_600_000_000_000L)
        Vault.lockExisting(vaultDir)

        // The name is hidden too now, so the file is found by looking in the folder.
        val stored = vaultDir.listFiles()!!.single()
        assertTrue(Vault.isEncrypted(stored))
        assertEquals("old.txt", VaultNames.plainName(stored))
        assertEquals("hello", unlocked(stored).toString(Charsets.UTF_8))
        assertEquals(1_600_000_000_000L, stored.lastModified())
        val sizeAfterFirst = stored.length()
        Vault.lockExisting(vaultDir)
        assertEquals(sizeAfterFirst, vaultDir.listFiles()!!.single().length())
        assertEquals(1, vaultDir.list()!!.size)
    }

    @Test
    fun lockExisting_leavesAFileThatIsBeingWrittenRightNow() {
        // A new file in Private has only its header on disk for a moment, which looks like a plain file.
        val fresh = File(vaultDir, "fresh.bin")
        fresh.writeBytes(ByteArray(10) { 7 })
        val before = fresh.readBytes()
        Vault.lockExisting(vaultDir)
        assertArrayEquals(before, fresh.readBytes())
        // Once it is old enough it is locked like any other.
        Vault.lockExisting(vaultDir, minAgeMillis = 5_000L, now = System.currentTimeMillis() + 60_000L)
        // Its name is hidden by then as well, so it is found by looking in the folder.
        val stored = vaultDir.listFiles()!!.single()
        assertTrue(Vault.isEncrypted(stored))
        assertEquals(10, unlocked(stored).size)
    }

    @Test
    fun lockExisting_removesOnlyStaleLeftovers() {
        val stale = File(vaultDir, "a.txt.ixtmp").also { it.writeText("x"); it.setLastModified(1_600_000_000_000L) }
        val fresh = File(vaultDir, "b.txt.ixtmp").also { it.writeText("y") }
        Vault.lockExisting(vaultDir)
        assertFalse(stale.exists())
        assertTrue(fresh.exists())
    }

    @Test
    fun pasteIntoPrivate_locks_andPasteOutUnlocks() {
        val outside = tmp.newFolder("outside")
        val source = outside.write("photo.jpg", sample(100_000))
        val original = source.readBytes()

        val into = FileOps.paste(vaultDir, listOf(source.path), move = true)
        assertEquals(1, into.done.size)
        assertFalse(source.exists())
        val inside = File(into.done.single().second)
        assertTrue(Vault.isEncrypted(inside))
        assertFalse(original.contentEquals(inside.readBytes()))
        assertEquals(original.size.toLong(), Vault.displaySize(inside, inside.length()))

        val out = tmp.newFolder("out")
        val back = FileOps.paste(out, listOf(inside.path), move = true)
        assertEquals(1, back.done.size)
        assertArrayEquals(original, File(back.done.single().second).readBytes())
        assertFalse(inside.exists())
    }

    @Test
    fun copyInsidePrivate_staysLockedAndStillOpens() {
        val content = sample(70_000)
        val file = lockedCopy(content, "a.bin")
        val sub = File(vaultDir, "sub").also { it.mkdir() }
        val result = FileOps.paste(sub, listOf(file.path), move = false)
        val copy = File(result.done.single().second)
        assertTrue(Vault.isEncrypted(copy))
        assertArrayEquals(content, unlocked(copy))
    }

    @Test
    fun foldersGoInAndOutWithEverythingInThem() {
        val outside = tmp.newFolder("outside")
        val folder = File(outside, "trip").also { it.mkdir() }
        folder.write("a.txt", "one".toByteArray())
        File(folder, "deep").mkdir()
        File(folder, "deep/b.txt").writeText("two")

        val into = FileOps.paste(vaultDir, listOf(folder.path), move = true)
        val inside = File(into.done.single().second)
        val deep = inside.listFiles()!!.first { VaultNames.plainName(it) == "deep" }
        assertEquals("two", unlocked(deep.listFiles()!!.single()).toString(Charsets.UTF_8))

        val restored = FileOps.relocate(listOf(inside.path to folder.path))
        assertEquals(1, restored.size)
        assertEquals("one", File(folder, "a.txt").readText())
        assertEquals("two", File(folder, "deep/b.txt").readText())
    }

    // ---- Hidden names ----

    @Test
    fun names_roundTrip_andAreHidden() {
        val names = listOf("a.txt", "Holiday photos 2024", "Ünïcødé – 日本語.pdf", "x".repeat(100) + ".jpg")
        for (name in names) {
            val stored = VaultNames.encode(name)
            assertTrue(stored.startsWith("~"))
            assertFalse(stored.contains(name.take(5)))
            assertEquals(name, VaultNames.decode(stored))
            assertEquals("same name, same text", stored, VaultNames.encode(name))
        }
        assertFalse(VaultNames.encode("a.txt") == VaultNames.encode("b.txt"))
    }

    @Test
    fun namesFromBeforeHiding_areShownAsTheyAre() {
        assertEquals(null, VaultNames.decodeOrNull("photo.jpg"))
        assertEquals("photo.jpg", VaultNames.decode("photo.jpg"))
        assertEquals("~not valid at all", VaultNames.decode("~not valid at all"))
    }

    @Test
    fun aTooLongName_isCutButKeepsItsExtension() {
        val fitted = VaultNames.fit("y".repeat(400) + ".mp4")
        assertTrue(fitted.endsWith(".mp4"))
        assertTrue(VaultNames.encode(fitted).length <= 255)
    }

    @Test
    fun pasteIntoPrivate_hidesTheName_andListingShowsTheRealOne() {
        val outside = tmp.newFolder("outside")
        val first = outside.write("secret plans.txt", "one".toByteArray())

        val result = FileOps.paste(vaultDir, listOf(first.path), move = true)
        val inside = File(result.done.single().second)
        assertFalse(inside.name.contains("secret"))
        assertEquals("secret plans.txt", VaultNames.plainName(inside))

        val listing = FolderLister.list(vaultDir)
        val item = listing.files.single()
        assertEquals("secret plans", item.name)
        assertEquals("txt", item.extension)
        assertEquals(inside.path, item.path)
        assertEquals(3L, item.sizeBytes)
    }

    @Test
    fun twoFilesWithTheSameName_getANumber() {
        val outside = tmp.newFolder("outside")
        val one = outside.write("a.txt", "1".toByteArray())
        FileOps.paste(vaultDir, listOf(one.path), move = false)
        val second = FileOps.paste(vaultDir, listOf(one.path), move = false)
        assertEquals("a (1).txt", VaultNames.plainName(File(second.done.single().second)))
        assertEquals(2, vaultDir.list()!!.size)
    }

    @Test
    fun foldersKeepTheirRealNamesGoingOut_andHideThemGoingIn() {
        val outside = tmp.newFolder("outside")
        val folder = File(outside, "Trip").also { it.mkdir() }
        File(folder, "notes.txt").writeText("hi")

        val into = FileOps.paste(vaultDir, listOf(folder.path), move = true)
        val inside = File(into.done.single().second)
        assertFalse(inside.name.contains("Trip"))
        val child = inside.listFiles()!!.single()
        assertFalse(child.name.contains("notes"))
        assertEquals("notes.txt", VaultNames.plainName(child))

        val out = tmp.newFolder("out")
        val back = FileOps.paste(out, listOf(inside.path), move = true)
        val restored = File(back.done.single().second)
        assertEquals("Trip", restored.name)
        assertEquals("hi", File(restored, "notes.txt").readText())
    }

    @Test
    fun lockExisting_alsoHidesOldNames_once() {
        val folder = File(vaultDir, "Old folder").also { it.mkdir() }
        val oldFile = File(folder, "old.txt")
        oldFile.writeText("hello")
        // Things written in the last few seconds are left alone, so these have to look old.
        oldFile.setLastModified(1_600_000_000_000L)
        folder.setLastModified(1_600_000_000_000L)
        Vault.lockExisting(vaultDir)

        val top = vaultDir.list()!!.single()
        assertFalse(top.contains("Old"))
        assertEquals("Old folder", VaultNames.decode(top))
        val nested = File(vaultDir, top).listFiles()!!.single()
        assertEquals("old.txt", VaultNames.plainName(nested))
        assertEquals("hello", unlocked(nested).toString(Charsets.UTF_8))

        Vault.lockExisting(vaultDir)
        assertEquals(top, vaultDir.list()!!.single())
    }

    @Test
    fun displayPath_swapsHiddenNamesForRealOnes() {
        val folder = File(vaultDir, VaultNames.encode("Taxes")).also { it.mkdir() }
        assertEquals(vaultDir.absolutePath + "/Taxes", VaultNames.displayPath(folder.absolutePath))
        assertEquals("/somewhere/else", VaultNames.displayPath("/somewhere/else"))
    }
}
