package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.Random

class DuplicateFinderTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun item(file: File, modified: Long = 0L) =
        fileItem(file.path, size = file.length(), modified = modified)

    private fun randomBytes(size: Int, seed: Long) = ByteArray(size).also { Random(seed).nextBytes(it) }

    @Test
    fun identicalBigFiles_formOneGroupOldestFirst() {
        val data = randomBytes(1_000_000, 1)
        val older = File(tmp.root, "a.bin").also { it.writeBytes(data) }
        val newer = File(tmp.root, "b.bin").also { it.writeBytes(data) }
        val groups = DuplicateFinder.find(listOf(item(newer, 20), item(older, 10)), minBytes = 1_000)
        assertEquals(1, groups.size)
        assertEquals(older.path, groups[0].files[0].path)
        assertEquals(1_000_000L, groups[0].extraBytes)
    }

    @Test
    fun filesThatDifferBetweenTheSamples_areNotDuplicates() {
        val a = randomBytes(1_000_000, 2)
        val b = a.copyOf()
        // Offset 150,000 is outside the first 64 KB, the middle 64 KB and the last 64 KB.
        b[150_000] = (b[150_000] + 1).toByte()
        val fa = File(tmp.root, "a.bin").also { it.writeBytes(a) }
        val fb = File(tmp.root, "b.bin").also { it.writeBytes(b) }
        val groups = DuplicateFinder.find(listOf(item(fa), item(fb)), minBytes = 1_000)
        assertTrue(groups.isEmpty())
    }

    @Test
    fun smallFilesBelowTheMinimumAreIgnored() {
        val data = randomBytes(500, 3)
        val fa = File(tmp.root, "a.bin").also { it.writeBytes(data) }
        val fb = File(tmp.root, "b.bin").also { it.writeBytes(data) }
        assertTrue(DuplicateFinder.find(listOf(item(fa), item(fb))).isEmpty())
    }

    @Test
    fun stoppedSearchReturnsNothing() {
        val data = randomBytes(1_000_000, 4)
        val fa = File(tmp.root, "a.bin").also { it.writeBytes(data) }
        val fb = File(tmp.root, "b.bin").also { it.writeBytes(data) }
        val groups = DuplicateFinder.find(listOf(item(fa), item(fb)), minBytes = 1_000, active = { false })
        assertTrue(groups.isEmpty())
    }
}
