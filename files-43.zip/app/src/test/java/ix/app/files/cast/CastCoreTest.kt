package ix.app.files.cast

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class CastCoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    // ---- SOAP --------------------------------------------------------------------------------

    @Test
    fun soapParse_readsLeafElementsWithoutPrefixes() {
        val xml = """<?xml version="1.0"?>
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body>
            <u:GetPositionInfoResponse xmlns:u="urn:schemas-upnp-org:service:AVTransport:1">
              <Track>1</Track><TrackDuration>0:03:05</TrackDuration><RelTime>0:00:12.500</RelTime>
              <TrackURI>http://192.168.1.5:4000/abc/m/1.mp4</TrackURI>
            </u:GetPositionInfoResponse></s:Body></s:Envelope>"""
        val m = Soap.parse(xml)
        assertEquals("0:03:05", m["TrackDuration"])
        assertEquals("0:00:12.500", m["RelTime"])
        assertEquals("http://192.168.1.5:4000/abc/m/1.mp4", m["TrackURI"])
        assertFalse(m.containsKey("GetPositionInfoResponse"))
    }

    @Test
    fun soapParse_keepsWhatItReadFromBrokenXml_andIgnoresBlank() {
        val m = Soap.parse("<a><CurrentVolume>42</CurrentVolume><b>")
        assertEquals("42", m["CurrentVolume"])
        assertTrue(Soap.parse("").isEmpty())
        assertTrue(Soap.parse("not xml at all").isEmpty())
    }

    @Test
    fun soapParse_readsUpnpErrors() {
        val xml = "<s:Envelope xmlns:s=\"x\"><s:Body><s:Fault><detail><UPnPError><errorCode>714</errorCode>" +
            "<errorDescription>Illegal MIME-type</errorDescription></UPnPError></detail></s:Fault></s:Body></s:Envelope>"
        val m = Soap.parse(xml)
        assertEquals("714", m["errorCode"])
        assertEquals("Illegal MIME-type", m["errorDescription"])
    }

    @Test
    fun soapParse_doesNotFetchExternalEntities() {
        val evil = "<?xml version=\"1.0\"?><!DOCTYPE a [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><a><b>&x;</b></a>"
        val m = Soap.parse(evil)
        assertFalse(m["b"].orEmpty().contains("root:"))
    }

    @Test
    fun times_roundTrip() {
        assertEquals(185_250L, Soap.parseTime("0:03:05.250"))
        assertEquals(3_600_000L, Soap.parseTime("1:00:00"))
        assertNull(Soap.parseTime("NOT_IMPLEMENTED"))
        assertNull(Soap.parseTime(""))
        assertEquals("0:03:05", Soap.formatTime(185_250))
        assertEquals("2:00:00.007", Soap.formatTime(7_200_007, withMillis = true))
        assertEquals("0:00:00", Soap.formatTime(-5))
    }

    @Test
    fun clockLabel_formatsShortAndLongTimes() {
        assertEquals("0:00", clockLabel(-1))
        assertEquals("0:09", clockLabel(9_999))
        assertEquals("3:05", clockLabel(185_000))
        assertEquals("1:02:03", clockLabel(3_723_000))
    }

    @Test
    fun escape_handlesXmlCharacters() {
        assertEquals("a &amp; b &lt;c&gt; &quot;d&quot; &apos;e&apos;", Soap.escape("a & b <c> \"d\" 'e'"))
    }

    // ---- device description ------------------------------------------------------------------

    private val xboxXml = """<?xml version="1.0"?>
        <root xmlns="urn:schemas-upnp-org:device-1-0"><URLBase>http://192.168.1.20:2869/</URLBase>
        <device><deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType>
          <friendlyName>Living room Xbox</friendlyName><manufacturer>Microsoft</manufacturer>
          <modelName>Xbox One</modelName><UDN>uuid:1234</UDN>
          <serviceList>
            <service><serviceType>urn:schemas-upnp-org:service:RenderingControl:1</serviceType><controlURL>/rc</controlURL></service>
            <service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><controlURL>/avt</controlURL></service>
            <service><serviceType>urn:schemas-upnp-org:service:ConnectionManager:1</serviceType><controlURL>/cm</controlURL></service>
          </serviceList></device></root>"""

    @Test
    fun description_findsEndpointsAndKind() {
        val d = UpnpDescription.parse(xboxXml, "http://192.168.1.20:2869/desc.xml")
        assertNotNull(d)
        d!!
        assertEquals("Living room Xbox", d.name)
        assertEquals("uuid:1234", d.udn)
        assertEquals("192.168.1.20", d.host)
        assertEquals("http://192.168.1.20:2869/avt", d.avtUrl)
        assertEquals("http://192.168.1.20:2869/rc", d.rcUrl)
        assertEquals("http://192.168.1.20:2869/cm", d.cmUrl)
        assertEquals(DeviceKind.TV, d.kind)
    }

    @Test
    fun description_ignoresDevicesWithoutAvTransport() {
        val xml = """<root><device><friendlyName>Router</friendlyName><UDN>uuid:r</UDN><serviceList>
            <service><serviceType>urn:schemas-upnp-org:service:WANIPConnection:1</serviceType><controlURL>/w</controlURL></service>
            </serviceList></device></root>"""
        assertNull(UpnpDescription.parse(xml, "http://192.168.1.1/d.xml"))
    }

    @Test
    fun description_usesTheEmbeddedRendererOfAMediaServerBundle() {
        val xml = """<root><device><friendlyName>Windows PC</friendlyName><UDN>uuid:root</UDN>
          <deviceList><device><friendlyName>PC Renderer</friendlyName><modelName>WMP</modelName><UDN>uuid:inner</UDN>
          <serviceList><service><serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><controlURL>/avt</controlURL></service>
          <service><serviceType>urn:schemas-upnp-org:service:RenderingControl:1</serviceType><controlURL>/rc</controlURL></service></serviceList>
          </device></deviceList></device></root>"""
        val d = UpnpDescription.parse(xml, "http://10.0.0.7:5000/d.xml")!!
        assertEquals("uuid:inner", d.udn)
        assertEquals("PC Renderer", d.name)
        assertEquals("http://10.0.0.7:5000/rc", d.rcUrl)
    }

    @Test
    fun ssdpHeaders_areLowercased() {
        val h = Ssdp.headers("HTTP/1.1 200 OK\r\nLOCATION: http://x/d.xml\r\nST: urn:a\r\n\r\n")
        assertEquals("http://x/d.xml", h["location"])
    }

    // ---- file kinds, formats, DIDL -----------------------------------------------------------

    @Test
    fun media_knowsWhatCanBeCast() {
        assertEquals(CastKind.Video, CastMedia.kindOf("MKV"))
        assertEquals(CastKind.Audio, CastMedia.kindOf("flac"))
        assertEquals(CastKind.Image, CastMedia.kindOf("jpg"))
        assertNull(CastMedia.kindOf("pdf"))
        assertEquals("video/x-matroska", CastMedia.mimeOf("mkv"))
        val f = tmp.newFile("Holiday 2024.MP4").also { it.writeBytes(ByteArray(10)) }
        val item = CastMedia.itemFor(f, 5_000)!!
        assertEquals("Holiday 2024", item.title)
        assertEquals("mp4", item.ext)
        assertEquals(10L, item.size)
        assertEquals(5_000L, item.durationMs)
        assertNull(CastMedia.itemFor(tmp.newFile("notes.txt")))
        assertNull(CastMedia.itemFor(tmp.newFolder("clips.mp4")))
        assertFalse(CastMedia.canCast(tmp.newFolder("x")))
    }

    @Test
    fun formatSupport_matchesAliasesAndWildcards() {
        val sink = listOf(
            "http-get:*:video/mp4:DLNA.ORG_PN=AVC_MP4_MP_SD_AAC_MULT5",
            "http-get:*:video/x-ms-wmv:*",
            "rtsp-rtp-udp:*:audio/mpeg:*",
        )
        assertTrue(FormatSupport.supports(sink, "video/mp4"))
        assertTrue(FormatSupport.supports(sink, "video/x-ms-wmv"))
        assertFalse(FormatSupport.supports(sink, "video/x-matroska"))
        assertFalse("only http-get counts", FormatSupport.supports(sink, "audio/mpeg"))
        assertTrue(FormatSupport.supports(listOf("http-get:*:video/x-mkv:*"), "video/x-matroska"))
        assertTrue(FormatSupport.supports(listOf("http-get:*:*:*"), "video/x-flv"))
        assertTrue(FormatSupport.supports(listOf("http-get:*:image/jpeg:DLNA.ORG_PN=JPEG_LRG"), "image/jpeg"))
    }

    private fun item(kind: CastKind, mime: String, ext: String, title: String = "T", size: Long = 100, dur: Long = 0) =
        CastItem("/x/$title.$ext", title, kind, mime, ext, size, dur)

    @Test
    fun didl_describesAVideo() {
        val xml = Didl.build(item(CastKind.Video, "video/mp4", "mp4", "A & B", 1234, 65_000), 7, "http://1.2.3.4:5/t/m/7.mp4", false)
        assertTrue(xml.contains("<dc:title>A &amp; B</dc:title>"))
        assertTrue(xml.contains("object.item.videoItem"))
        assertTrue(xml.contains("protocolInfo=\"http-get:*:video/mp4:DLNA.ORG_OP=01;"))
        assertTrue(xml.contains("duration=\"0:01:05.000\""))
        assertTrue(xml.contains("size=\"1234\""))
        assertTrue(xml.contains(">http://1.2.3.4:5/t/m/7.mp4</res>"))
        // and it must itself be well-formed
        assertEquals("A & B", Soap.parse(xml)["title"])
    }

    @Test
    fun didl_pictureSongAndPlainVariants() {
        val pic = Didl.build(item(CastKind.Image, "image/jpeg", "jpg"), 1, "http://h/1.jpg", false)
        assertTrue(pic.contains("object.item.imageItem.photo"))
        assertTrue(pic.contains("DLNA.ORG_OP=00"))
        assertFalse(pic.contains("duration="))
        val mp3 = Didl.build(item(CastKind.Audio, "audio/mpeg", "mp3"), 2, "http://h/2.mp3", false)
        assertTrue(mp3.contains("object.item.audioItem.musicTrack"))
        assertTrue(mp3.contains("DLNA.ORG_PN=MP3;"))
        val plain = Didl.build(item(CastKind.Video, "video/mp4", "mp4"), 3, "http://h/3.mp4", true)
        assertTrue(plain.contains("protocolInfo=\"http-get:*:video/mp4:*\""))
    }

    // ---- Range -------------------------------------------------------------------------------

    @Test
    fun range_resolvesTheCommonForms() {
        fun r(h: String?, size: Long = 1000) = RangeHeader.resolve(h, size)
        r(null)!!.let { assertEquals(0L, it.start); assertEquals(999L, it.end); assertFalse(it.partial) }
        r("bytes=0-")!!.let { assertEquals(0L, it.start); assertEquals(999L, it.end); assertTrue(it.partial) }
        r("bytes=100-199")!!.let { assertEquals(100L, it.start); assertEquals(199L, it.end); assertEquals(100L, it.length) }
        r("bytes=900-5000")!!.let { assertEquals(999L, it.end) }
        r("bytes=-100")!!.let { assertEquals(900L, it.start); assertEquals(999L, it.end) }
        r("bytes=-5000")!!.let { assertEquals(0L, it.start) }
        r("bytes=0-99, 200-299")!!.let { assertEquals(99L, it.end) }
        r("garbage")!!.let { assertFalse(it.partial) }
    }

    @Test
    fun range_rejectsTheImpossible() {
        assertNull(RangeHeader.resolve("bytes=1000-", 1000))
        assertNull(RangeHeader.resolve("bytes=500-100", 1000))
        assertNull(RangeHeader.resolve("bytes=-0", 1000))
        assertNull(RangeHeader.resolve("bytes=0-10", 0))
    }
}
