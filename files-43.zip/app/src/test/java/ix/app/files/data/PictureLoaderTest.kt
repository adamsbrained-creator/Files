package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PictureLoaderTest {

    @Test
    fun smallPicturesAreNotShrunk() {
        assertEquals(1, PictureLoader.sampleSizeFor(800, 600, 2000))
        assertEquals(1, PictureLoader.sampleSizeFor(2000, 1000, 2000))
    }

    @Test
    fun bigPicturesShrinkByPowersOfTwo_butStayAtLeastTheWantedSize() {
        // 8000 / 2 = 4000 >= 2400, 8000 / 4 = 2000 < 2400, so shrink by 2.
        assertEquals(2, PictureLoader.sampleSizeFor(8000, 6000, 2400))
        assertEquals(4, PictureLoader.sampleSizeFor(10000, 5000, 2400))
        // Portrait counts by its longer side.
        assertEquals(2, PictureLoader.sampleSizeFor(6000, 8000, 2400))
    }

    @Test
    fun unknownSizesAreLeftAlone() {
        assertEquals(1, PictureLoader.sampleSizeFor(0, 0, 2000))
        assertEquals(1, PictureLoader.sampleSizeFor(4000, 3000, 0))
    }

    @Test
    fun svgIsNotViewable_otherPicturesAre() {
        assertTrue(PictureLoader.viewable(fileItem("/s/a.jpg")))
        assertTrue(PictureLoader.viewable(fileItem("/s/a.png")))
        assertFalse(PictureLoader.viewable(fileItem("/s/a.svg")))
        assertFalse(PictureLoader.viewable(fileItem("/s/a.mp4")))
    }
}
