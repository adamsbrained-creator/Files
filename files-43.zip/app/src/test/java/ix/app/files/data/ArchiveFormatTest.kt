package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ArchiveFormatTest {

    @Test
    fun endingsAreRecognised_ignoringCase() {
        assertEquals(ArchiveFormat.Zip, ArchiveFormat.of("photos.zip"))
        assertEquals(ArchiveFormat.Zip, ArchiveFormat.of("PHOTOS.ZIP"))
        assertEquals(ArchiveFormat.SevenZ, ArchiveFormat.of("a.7z"))
        assertEquals(ArchiveFormat.Rar, ArchiveFormat.of("a.rar"))
        assertEquals(ArchiveFormat.Tar, ArchiveFormat.of("a.tar"))
        assertEquals(ArchiveFormat.TarGz, ArchiveFormat.of("a.tgz"))
        assertEquals(ArchiveFormat.TarBz2, ArchiveFormat.of("a.tbz2"))
        assertEquals(ArchiveFormat.TarXz, ArchiveFormat.of("a.txz"))
    }

    @Test
    fun longestEndingWins() {
        assertEquals(ArchiveFormat.TarGz, ArchiveFormat.of("backup.tar.gz"))
        assertEquals(ArchiveFormat.TarBz2, ArchiveFormat.of("backup.tar.bz2"))
        assertEquals(ArchiveFormat.TarXz, ArchiveFormat.of("backup.TAR.XZ"))
        assertEquals(ArchiveFormat.Gz, ArchiveFormat.of("notes.txt.gz"))
    }

    @Test
    fun otherNamesAreNotArchives() {
        assertNull(ArchiveFormat.of("photo.jpg"))
        assertNull(ArchiveFormat.of("zip"))
        // A hidden file that is only an ending is not an archive.
        assertNull(ArchiveFormat.of(".zip"))
        assertNull(ArchiveFormat.of("archive.zipx"))
        assertNull(ArchiveFormat.of("movie.apk"))
    }

    @Test
    fun baseNameDropsTheWholeEnding() {
        assertEquals("photos", ArchiveFormat.baseName("photos.zip"))
        assertEquals("backup", ArchiveFormat.baseName("backup.tar.gz"))
        assertEquals("notes.txt", ArchiveFormat.baseName("notes.txt.gz"))
        assertEquals("plain.txt", ArchiveFormat.baseName("plain.txt"))
    }

    @Test
    fun singleFileFormats() {
        assertTrue(ArchiveFormat.Gz.isSingleFile)
        assertTrue(ArchiveFormat.Xz.isSingleFile)
        assertFalse(ArchiveFormat.TarGz.isSingleFile)
        assertFalse(ArchiveFormat.SevenZ.isSingleFile)
    }
}
