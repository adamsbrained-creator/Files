package ix.app.files.data

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZMethod
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.OutputStream
import java.util.Date

class ArchiveReadersTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val hello = "hello archive".toByteArray()
    private val big = ByteArray(300_000) { (it % 251).toByte() }

    /** A name ending in "/" is a folder. */
    private fun makeTar(target: File, entries: List<Pair<String, ByteArray?>>, wrap: (OutputStream) -> OutputStream = { it }) {
        TarArchiveOutputStream(wrap(target.outputStream().buffered())).use { tar ->
            for ((name, data) in entries) {
                val entry = TarArchiveEntry(name)
                entry.modTime = Date(1_700_000_000_000L)
                if (data != null) entry.size = data.size.toLong()
                tar.putArchiveEntry(entry)
                if (data != null) tar.write(data)
                tar.closeArchiveEntry()
            }
            tar.finish()
        }
    }

    private fun make7z(target: File, entries: List<Pair<String, ByteArray?>>, method: SevenZMethod = SevenZMethod.DEFLATE) {
        SevenZOutputFile(target).use { out ->
            out.setContentCompression(method)
            for ((name, data) in entries) {
                val entry = SevenZArchiveEntry()
                entry.name = name
                entry.isDirectory = data == null
                entry.hasLastModifiedDate = true
                entry.lastModifiedDate = Date(1_700_000_000_000L)
                if (data != null) entry.size = data.size.toLong()
                out.putArchiveEntry(entry)
                if (data != null) out.write(data)
                out.closeArchiveEntry()
            }
            out.finish()
        }
    }

    private val sample = listOf<Pair<String, ByteArray?>>(
        "docs/" to null,
        "docs/a.txt" to hello,
        "b.bin" to big,
    )

    private fun checkListing(entries: List<ZipBrowser.Entry>?) {
        assertNotNull(entries)
        val byPath = entries!!.associateBy { it.path }
        assertEquals(setOf("docs", "docs/a.txt", "b.bin"), byPath.keys)
        assertTrue(byPath.getValue("docs").isDirectory)
        assertFalse(byPath.getValue("b.bin").isDirectory)
        assertEquals(big.size.toLong(), byPath.getValue("b.bin").size)
        assertEquals(1_700_000_000_000L, byPath.getValue("docs/a.txt").modifiedMillis)
    }

    @Test
    fun tar_listsEntries() {
        val file = File(tmp.root, "a.tar")
        makeTar(file, sample)
        checkListing(ZipBrowser.read(file))
    }

    @Test
    fun tarGz_listsEntries() {
        val file = File(tmp.root, "a.tar.gz")
        makeTar(file, sample) { GzipCompressorOutputStream(it) }
        checkListing(ZipBrowser.read(file))
    }

    @Test
    fun tgzAndTarBz2_listEntries() {
        val tgz = File(tmp.root, "a.tgz")
        makeTar(tgz, sample) { GzipCompressorOutputStream(it) }
        checkListing(ZipBrowser.read(tgz))
        val bz = File(tmp.root, "a.tar.bz2")
        makeTar(bz, sample) { BZip2CompressorOutputStream(it) }
        checkListing(ZipBrowser.read(bz))
    }

    @Test
    fun sevenZ_listsEntries_andOpensOneFile() {
        val file = File(tmp.root, "a.7z")
        make7z(file, sample)
        val entries = ZipBrowser.read(file)
        checkListing(entries)
        val entry = entries!!.first { it.path == "docs/a.txt" }
        val out = ZipBrowser.extractEntry(file, entry, File(tmp.root, "preview"))
        assertNotNull(out)
        assertEquals("a.txt", out!!.name)
        assertArrayEquals(hello, out.readBytes())
    }

    @Test
    fun tarGz_opensOneFileFromTheMiddle() {
        val file = File(tmp.root, "a.tar.gz")
        makeTar(file, sample) { GzipCompressorOutputStream(it) }
        val entry = ZipBrowser.read(file)!!.first { it.path == "b.bin" }
        val out = ZipBrowser.extractEntry(file, entry, File(tmp.root, "preview"))
        assertArrayEquals(big, out!!.readBytes())
    }

    @Test
    fun singlePackedFile_hasOneEntryNamedWithoutTheEnding() {
        val file = File(tmp.root, "notes.txt.gz")
        GzipCompressorOutputStream(file.outputStream()).use { it.write(hello) }
        val entries = ZipBrowser.read(file)!!
        assertEquals(listOf("notes.txt"), entries.map { it.path })
        val dest = File(tmp.root, "out")
        assertTrue(ArchiveReaders.extractAll(ArchiveFormat.Gz, file, dest))
        assertArrayEquals(hello, File(dest, "notes.txt").readBytes())
    }

    @Test
    fun extractAll_tarGz_writesFilesAndFolders_andKeepsDates() {
        val file = File(tmp.root, "a.tar.gz")
        makeTar(file, sample) { GzipCompressorOutputStream(it) }
        val dest = File(tmp.root, "out")
        assertTrue(FileOps.unpack(file, dest))
        assertTrue(File(dest, "docs").isDirectory)
        assertArrayEquals(hello, File(dest, "docs/a.txt").readBytes())
        assertArrayEquals(big, File(dest, "b.bin").readBytes())
        assertEquals(1_700_000_000_000L, File(dest, "b.bin").lastModified())
    }

    @Test
    fun extractAll_sevenZ_writesFilesAndFolders() {
        val file = File(tmp.root, "a.7z")
        make7z(file, sample)
        val dest = File(tmp.root, "out")
        val control = JobControl()
        assertTrue(FileOps.unpack(file, dest, control))
        assertArrayEquals(hello, File(dest, "docs/a.txt").readBytes())
        assertArrayEquals(big, File(dest, "b.bin").readBytes())
        // Progress was counted, and never went past the archive's own size.
        assertTrue(control.done > 0L)
        assertTrue(control.done <= file.length())
    }

    @Test
    fun extractAll_skipsNamesThatClimbOut() {
        val file = File(tmp.root, "evil.tar")
        makeTar(file, listOf("../evil.txt" to hello, "ok.txt" to hello))
        val dest = File(tmp.root, "out")
        assertTrue(ArchiveReaders.extractAll(ArchiveFormat.Tar, file, dest))
        assertFalse(File(tmp.root, "evil.txt").exists())
        assertTrue(File(dest, "ok.txt").exists())
        // And the listing does not show it either.
        assertEquals(listOf("ok.txt"), ZipBrowser.read(file)!!.map { it.path })
    }

    @Test
    fun damagedOrWronglyNamedFiles_cannotBeRead() {
        val junk = ByteArray(2_000) { (it * 31).toByte() }
        for (name in listOf("bad.7z", "bad.tar.gz", "bad.tar.bz2", "bad.gz")) {
            val file = File(tmp.root, name)
            file.writeBytes(junk)
            assertNull(name, ZipBrowser.read(file))
            assertFalse(name, ArchiveReaders.extractAll(ArchiveFormat.of(name)!!, file, File(tmp.root, "out-$name")))
        }
    }

    @Test
    fun extractAll_stopsWhenCancelled() {
        val file = File(tmp.root, "a.tar.gz")
        makeTar(file, sample) { GzipCompressorOutputStream(it) }
        val control = JobControl().also { it.cancel() }
        assertFalse(ArchiveReaders.extractAll(ArchiveFormat.TarGz, file, File(tmp.root, "out"), control))
    }

    @Test
    fun linksInATarHoldNoData_andAreLeftOut() {
        val file = File(tmp.root, "links.tar")
        TarArchiveOutputStream(file.outputStream().buffered()).use { tar ->
            val link = TarArchiveEntry("shortcut", TarArchiveEntry.LF_SYMLINK)
            link.linkName = "/etc/passwd"
            tar.putArchiveEntry(link)
            tar.closeArchiveEntry()
            val real = TarArchiveEntry("real.txt")
            real.size = hello.size.toLong()
            tar.putArchiveEntry(real)
            tar.write(hello)
            tar.closeArchiveEntry()
            tar.finish()
        }
        assertEquals(listOf("real.txt"), ZipBrowser.read(file)!!.map { it.path })
    }
}
