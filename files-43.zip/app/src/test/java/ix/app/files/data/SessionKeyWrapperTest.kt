package ix.app.files.data

import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** A software stand-in for the Keystore key that guards the root key. [unlocked] plays the phone's unlock. */
private class FakeSealer : RootSealer {
    var unlocked = true
    private val key = SecretKeySpec(ByteArray(32) { (it * 3).toByte() }, "AES")

    override fun seal(secret: ByteArray): ByteArray {
        if (!unlocked) throw IOException("Unlock Private first")
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(secret)
    }

    override fun open(blob: ByteArray): ByteArray {
        if (!unlocked) throw IOException("Unlock Private first")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12))
        return cipher.doFinal(blob, 12, blob.size - 12)
    }
}

/** The old key, which opened for anyone. */
private class FakeLegacy : LegacyKey {
    var retired = false
    private val key = SecretKeySpec(ByteArray(32) { (it + 100).toByte() }, "AES")

    override fun wrap(key: ByteArray): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, this.key, GCMParameterSpec(128, iv))
        return iv + cipher.doFinal(key)
    }

    override fun unwrap(blob: ByteArray): ByteArray {
        if (retired) throw IOException("The old key is gone")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12))
        return cipher.doFinal(blob, 12, blob.size - 12)
    }

    override fun retire() {
        retired = true
    }
}

class SessionKeyWrapperTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private lateinit var dir: File
    private lateinit var rootFile: File
    private val sealer = FakeSealer()

    @Before
    fun setUp() {
        dir = tmp.newFolder("private")
        rootFile = File(tmp.root, "private-root.key")
        Vault.configure(dir)
    }

    @After
    fun tearDown() {
        Vault.configure(null)
        Vault.useKeyWrapper(null)
    }

    private fun fileKey(): ByteArray = ByteArray(32).also { SecureRandom().nextBytes(it) }

    @Test
    fun wrapAndUnwrap_roundTripWhileAllowed() {
        val wrapper = SessionKeyWrapper(rootFile, sealer, null)
        wrapper.allow()
        val key = fileKey()
        val blob = wrapper.wrap(key)
        assertEquals(Vault.WRAPPED_SIZE, blob.size)
        assertArrayEquals(key, wrapper.unwrap(blob))
    }

    @Test
    fun nothingWorksUntilAllowed_andNotAfterLock() {
        val wrapper = SessionKeyWrapper(rootFile, sealer, null)
        try {
            wrapper.wrap(fileKey())
            fail("should be locked")
        } catch (expected: IOException) {
        }
        wrapper.allow()
        val blob = wrapper.wrap(fileKey())
        wrapper.lock()
        try {
            wrapper.unwrap(blob)
            fail("should be locked again")
        } catch (expected: IOException) {
        }
    }

    @Test
    fun afterLock_theRootKeyIsNotNeededUntilUsedAgain_andOpensOnlyWithThePhoneUnlock() {
        val wrapper = SessionKeyWrapper(rootFile, sealer, null)
        wrapper.allow()
        val key = fileKey()
        val blob = wrapper.wrap(key)
        wrapper.lock()

        // The phone is locked: the root key can not be opened, so the file key stays closed.
        sealer.unlocked = false
        wrapper.allow()
        try {
            wrapper.unwrap(blob)
            fail("the root key must stay closed without the phone's unlock")
        } catch (expected: IOException) {
        }

        sealer.unlocked = true
        assertArrayEquals(key, wrapper.unwrap(blob))
    }

    @Test
    fun rootKeyIsKeptSealed_andSurvivesANewWrapper() {
        val first = SessionKeyWrapper(rootFile, sealer, null)
        first.allow()
        val key = fileKey()
        val blob = first.wrap(key)
        assertTrue(rootFile.exists())
        assertArrayEquals(byteArrayOf(0x49, 0x58, 0x52, 0x31), rootFile.readBytes().copyOfRange(0, 4))

        val second = SessionKeyWrapper(rootFile, sealer, null)
        second.allow()
        assertArrayEquals(key, second.unwrap(blob))
    }

    @Test
    fun aFileFromTheOldKey_stillOpens_andUpgradeMovesItToTheNewKey() {
        val legacy = FakeLegacy()
        val wrapper = SessionKeyWrapper(rootFile, sealer, legacy)
        wrapper.allow()
        val key = fileKey()
        val old = legacy.wrap(key)

        assertArrayEquals(key, wrapper.unwrap(old))

        val upgraded = wrapper.upgrade(old)
        assertTrue(upgraded != null)
        assertNotEquals(old.toList(), upgraded!!.toList())
        // Already moved: nothing more to do.
        assertEquals(null, wrapper.upgrade(upgraded))

        // After the old key is gone the moved key still opens, the old blob does not.
        wrapper.retireLegacy()
        assertFalse(wrapper.hasLegacy)
        assertArrayEquals(key, wrapper.unwrap(upgraded))
        try {
            wrapper.unwrap(old)
            fail("the old blob needs the old key")
        } catch (expected: Exception) {
        }
    }

    @Test
    fun vault_upgradesFilesInPlace_andKeepsTheirContent() {
        val legacy = FakeLegacy()
        val content = ByteArray(150_000).also { SecureRandom().nextBytes(it) }
        val file = File(dir, "photo.bin")

        // A file made by the old version: its key is sealed by the old key.
        Vault.useKeyWrapper(legacy)
        Vault.openWrite(file).use { it.write(content) }
        val before = file.readBytes()

        val wrapper = SessionKeyWrapper(rootFile, sealer, legacy)
        Vault.useKeyWrapper(wrapper)
        wrapper.allow()
        Vault.upgradeLegacyKeys(dir)

        val after = file.readBytes()
        assertEquals(before.size, after.size)
        // Only the sealed key in the header changed.
        assertArrayEquals(before.copyOfRange(0, 4), after.copyOfRange(0, 4))
        assertFalse(before.copyOfRange(4, Vault.HEADER).contentEquals(after.copyOfRange(4, Vault.HEADER)))
        assertArrayEquals(before.copyOfRange(Vault.HEADER, before.size), after.copyOfRange(Vault.HEADER, after.size))
        assertTrue(legacy.retired)
        assertArrayEquals(content, Vault.openRead(file).use { it.readBytes() })

        // Running it again changes nothing.
        Vault.upgradeLegacyKeys(dir)
        assertArrayEquals(after, file.readBytes())
    }

    @Test
    fun vault_keepsTheOldKey_ifAFileCouldNotBeMoved() {
        val legacy = FakeLegacy()
        val wrapper = SessionKeyWrapper(rootFile, sealer, legacy)
        Vault.useKeyWrapper(legacy)
        val good = File(dir, "good.bin")
        Vault.openWrite(good).use { it.write(ByteArray(1000)) }
        // A file whose sealed key matches neither key.
        val broken = File(dir, "broken.bin")
        Vault.openWrite(broken).use { it.write(ByteArray(1000)) }
        val bytes = broken.readBytes()
        for (i in 4 until Vault.HEADER) bytes[i] = (bytes[i].toInt() xor 0x5A).toByte()
        broken.writeBytes(bytes)

        Vault.useKeyWrapper(wrapper)
        wrapper.allow()
        Vault.upgradeLegacyKeys(dir)

        assertFalse("the old key must stay while a file still needs it", legacy.retired)
        assertTrue(wrapper.hasLegacy)
        // The good file moved anyway.
        assertEquals(1000L, Vault.openRead(good).use { it.readBytes() }.size.toLong())
    }
}
