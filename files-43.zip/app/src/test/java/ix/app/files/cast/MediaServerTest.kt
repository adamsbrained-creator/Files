package ix.app.files.cast

import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.net.HttpURLConnection
import java.net.URL

class MediaServerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val server = MediaServer()
    private val bytes = ByteArray(300_000) { (it * 7 % 251).toByte() }
    private lateinit var url: String

    @Before
    fun setUp() {
        server.start()
        val f = tmp.newFile("movie.mkv").also { it.writeBytes(bytes) }
        val item = CastMedia.itemFor(f)!!
        url = server.urlFor(item, "127.0.0.1").second
    }

    @After
    fun tearDown() = server.stop()

    private fun get(u: String, method: String = "GET", range: String? = null): HttpURLConnection =
        (URL(u).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            range?.let { setRequestProperty("Range", it) }
            connectTimeout = 3000
            readTimeout = 3000
        }

    @Test
    fun urlCarriesTheTokenAndExtension() {
        assertTrue(url.startsWith("http://127.0.0.1:${server.port}/${server.token}/m/"))
        assertTrue(url.endsWith(".mkv"))
        // asking again for the same file gives the same address
        val again = server.urlFor(CastMedia.itemFor(java.io.File(tmp.root, "movie.mkv"))!!, "127.0.0.1").second
        assertEquals(url, again)
    }

    @Test
    fun servesTheWholeFile_withDlnaHeaders() {
        val c = get(url)
        assertEquals(200, c.responseCode)
        assertEquals("video/x-matroska", c.contentType)
        assertEquals("bytes", c.getHeaderField("Accept-Ranges"))
        assertEquals("Streaming", c.getHeaderField("transferMode.dlna.org"))
        assertNotNull(c.getHeaderField("contentFeatures.dlna.org"))
        assertArrayEquals(bytes, c.inputStream.readBytes())
    }

    @Test
    fun servesARange_forSeeking() {
        val c = get(url, range = "bytes=1000-1999")
        assertEquals(206, c.responseCode)
        assertEquals("bytes 1000-1999/${bytes.size}", c.getHeaderField("Content-Range"))
        assertArrayEquals(bytes.copyOfRange(1000, 2000), c.inputStream.readBytes())
    }

    @Test
    fun servesTheTail_andOpenEndedRanges() {
        val tail = get(url, range = "bytes=-500")
        assertEquals(206, tail.responseCode)
        assertArrayEquals(bytes.copyOfRange(bytes.size - 500, bytes.size), tail.inputStream.readBytes())
        val open = get(url, range = "bytes=299000-")
        assertArrayEquals(bytes.copyOfRange(299000, bytes.size), open.inputStream.readBytes())
    }

    @Test
    fun headSendsHeadersOnly() {
        val c = get(url, "HEAD")
        assertEquals(200, c.responseCode)
        assertEquals(bytes.size.toLong(), c.contentLengthLong)
        assertEquals(0, c.inputStream.readBytes().size)
    }

    @Test
    fun badRange_is416() {
        assertEquals(416, get(url, range = "bytes=999999-").responseCode)
    }

    @Test
    fun wrongTokenUnknownIdAndOtherMethods_areRefused() {
        val base = "http://127.0.0.1:${server.port}"
        assertEquals(404, get("$base/wrongtoken/m/1.mkv").responseCode)
        assertEquals(404, get("$base/${server.token}/m/99.mkv").responseCode)
        assertEquals(404, get("$base/${server.token}/../etc/passwd").responseCode)
        assertEquals(405, get(url, "DELETE").responseCode)
    }

    @Test
    fun plainMode_leavesOutDlnaHeaders() {
        server.plain = true
        val c = get(url)
        assertEquals(200, c.responseCode)
        assertNull(c.getHeaderField("contentFeatures.dlna.org"))
        c.inputStream.readBytes()
    }

    @Test
    fun aFileThatDisappeared_is404() {
        java.io.File(tmp.root, "movie.mkv").delete()
        assertEquals(404, get(url).responseCode)
    }

    @Test
    fun stoppingTheServerClosesThePort() {
        server.stop()
        assertEquals(0, server.port)
        val failed = runCatching { get(url).responseCode }.isFailure
        assertTrue(failed)
    }
}
