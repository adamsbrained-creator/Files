package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class RenameIntoTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun filesAndFoldersMoveInByRename_andCanBePutBack() {
        val file = tmp.root.write("a.bin", byteArrayOf(1, 2, 3))
        val folder = File(tmp.root, "dir").also { it.mkdirs() }
        folder.write("x.txt", byteArrayOf(9))
        val batch = File(tmp.root, "trash/1").also { it.mkdirs() }

        val done = FileOps.renameInto(batch, listOf(file.path, folder.path))
        assertEquals(2, done.size)
        assertFalse(file.exists())
        assertFalse(folder.exists())
        assertTrue(File(batch, "a.bin").exists())
        assertTrue(File(batch, "dir/x.txt").exists())

        val back = FileOps.relocate(done.map { it.second to it.first })
        assertEquals(2, back.size)
        assertTrue(file.exists())
        assertTrue(File(folder, "x.txt").exists())
    }

    @Test
    fun sameNamesGetNumbers_andMissingPathsAreSkipped() {
        val a = File(tmp.root, "one").also { it.mkdirs() }.write("same.txt", byteArrayOf(1))
        val b = File(tmp.root, "two").also { it.mkdirs() }.write("same.txt", byteArrayOf(2))
        val batch = File(tmp.root, "trash").also { it.mkdirs() }
        val done = FileOps.renameInto(batch, listOf(a.path, b.path, File(tmp.root, "gone").path))
        assertEquals(2, done.size)
        assertEquals(setOf("same.txt", "same (1).txt"), batch.list()!!.toSet())
    }

    @Test(expected = JobStopped::class)
    fun cancelStopsBeforeTheNextItem() {
        val a = tmp.root.write("a.txt", byteArrayOf(1))
        val batch = File(tmp.root, "trash").also { it.mkdirs() }
        val control = JobControl().also { it.cancel() }
        FileOps.renameInto(batch, listOf(a.path), control)
    }
}
