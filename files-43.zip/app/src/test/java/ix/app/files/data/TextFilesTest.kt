package ix.app.files.data

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class TextFilesTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun namesTheReaderOpensByItself() {
        assertTrue(TextFiles.isTextName("notes.TXT"))
        assertTrue(TextFiles.isTextName("config.json"))
        assertTrue(TextFiles.isTextName(".gitignore"))
        assertTrue(TextFiles.isTextName("README"))
        assertFalse(TextFiles.isTextName("photo.jpg"))
        assertFalse(TextFiles.isTextName("archive.zip"))
        assertFalse(TextFiles.isTextName("holiday"))
    }

    @Test
    fun viewable_usesExtensionOrKnownBareNames() {
        assertTrue(TextFiles.viewable(fileItem("/a/b.md")))
        assertFalse(TextFiles.viewable(fileItem("/a/b.mp4")))
    }

    @Test
    fun decode_plainUtf8() {
        val d = TextFiles.decode("héllo\nworld".toByteArray())
        assertEquals("héllo\nworld", d.text)
        assertFalse(d.crlf)
        assertFalse(d.bom)
        assertTrue(d.editable)
    }

    @Test
    fun decode_keepsTrackOfWindowsLineEndingsAndBom_andEncodeWritesThemBack() {
        val original = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + "a\r\nb\r\n".toByteArray()
        val d = TextFiles.decode(original)
        assertEquals("a\nb\n", d.text)
        assertTrue(d.crlf)
        assertTrue(d.bom)
        assertArrayEquals(original, TextFiles.encode(d.text, d.crlf, d.bom))
    }

    @Test
    fun encode_doesNotDoubleUpPastedWindowsLineEndings() {
        val bytes = TextFiles.encode("a\r\nb\nc", crlf = true, bom = false)
        assertEquals("a\r\nb\r\nc", String(bytes))
    }

    @Test
    fun decode_nonUtf8IsShownButNotEditable() {
        val d = TextFiles.decode(byteArrayOf(0x63, 0x61, 0x66, 0xE9.toByte()))
        assertEquals("caf\u00e9", d.text)
        assertFalse(d.editable)
    }

    @Test
    fun decode_utf16IsReadOnly() {
        val d = TextFiles.decode("hi".toByteArray(Charsets.UTF_16))
        assertEquals("hi", d.text)
        assertFalse(d.editable)
        assertFalse(TextFiles.looksBinary("hi".toByteArray(Charsets.UTF_16)))
    }

    @Test
    fun looksBinary_onZeroBytes() {
        assertTrue(TextFiles.looksBinary(byteArrayOf(1, 2, 0, 4)))
        assertFalse(TextFiles.looksBinary("plain".toByteArray()))
    }

    @Test
    fun load_reportsTooLargeBinaryAndOk() {
        val ok = File(tmp.root, "a.txt").also { it.writeText("one\ntwo") }
        val loaded = TextFiles.load(ok)
        assertEquals("one\ntwo", loaded.decoded!!.text)
        val bin = File(tmp.root, "b.txt").also { it.writeBytes(byteArrayOf(0, 1, 2)) }
        assertEquals(TextProblem.Binary, TextFiles.load(bin).problem)
        val missing = File(tmp.root, "missing.txt")
        assertEquals(TextProblem.Unreadable, TextFiles.load(missing).problem)
    }

    @Test
    fun save_replacesTheFile_andLeavesNoTempBehind() {
        val file = File(tmp.root, "a.txt").also { it.writeText("old") }
        assertTrue(TextFiles.save(file, "new\ntext", crlf = false, bom = false))
        assertEquals("new\ntext", file.readText())
        assertEquals(listOf("a.txt"), tmp.root.list()!!.toList())
    }

    @Test
    fun save_toAFolderThatIsGoneFails() {
        val file = File(File(tmp.root, "gone"), "a.txt")
        assertFalse(TextFiles.save(file, "x", crlf = false, bom = false))
    }

    @Test
    fun lineCount_ignoresAFinalNewLine() {
        assertEquals(0, TextFiles.lineCount(""))
        assertEquals(1, TextFiles.lineCount("a"))
        assertEquals(1, TextFiles.lineCount("a\n"))
        assertEquals(3, TextFiles.lineCount("a\nb\nc"))
    }

    @Test
    fun rows_numberLines_andCutVeryLongOnes() {
        val rows = TextFiles.rows("a\n\nccc\n")
        assertEquals(listOf(1, 2, 3), rows.map { it.number })
        assertEquals(listOf("a", "", "ccc"), rows.map { it.text })
        val long = "x".repeat(TextFiles.ROW_CHARS * 2 + 5)
        val cut = TextFiles.rows(long + "\nnext")
        assertEquals(listOf(1, 0, 0, 2), cut.map { it.number })
        assertEquals(long, cut.take(3).joinToString("") { it.text })
        assertEquals("next", cut.last().text)
    }

    @Test
    fun rows_ofEmptyAndSingleNewLine() {
        assertEquals(1, TextFiles.rows("").size)
        assertEquals(1, TextFiles.rows("\n").size)
    }

    @Test
    fun findAll_ignoresCase_andListsEveryHitInOrder() {
        val rows = TextFiles.rows("Hello world\nno match\nHELLO hello")
        val hits = TextFiles.findAll(rows, "hello")
        assertEquals(listOf(0, 2, 2), hits.map { it.row })
        assertEquals(listOf(0, 0, 6), hits.map { it.start })
        assertEquals(listOf(5, 5, 11), hits.map { it.end })
    }

    @Test
    fun findAll_hitsDoNotOverlap_andEmptyQueryFindsNothing() {
        val rows = TextFiles.rows("aaaa")
        assertEquals(2, TextFiles.findAll(rows, "aa").size)
        assertTrue(TextFiles.findAll(rows, "").isEmpty())
        assertTrue(TextFiles.findAll(rows, "b").isEmpty())
    }

    @Test
    fun findAll_stopsAtTheLimit() {
        val rows = TextFiles.rows("x ".repeat(50))
        assertEquals(10, TextFiles.findAll(rows, "x", limit = 10).size)
    }

    @Test
    fun findOffsets_listsStartsIgnoringCase() {
        assertEquals(listOf(0, 4, 9), TextFiles.findOffsets("Cat cat? CAT", "cat"))
        assertTrue(TextFiles.findOffsets("abc", "").isEmpty())
        assertEquals(2, TextFiles.findOffsets("aaaa", "aa").size)
        assertEquals(3, TextFiles.findOffsets("x x x x x", "x", limit = 3).size)
    }

    @Test
    fun replaceAll_swapsEveryHit_andCountsThem() {
        val done = TextFiles.replaceAll("Cat cat? CAT", "cat", "dog")
        assertEquals("dog dog? dog", done.text)
        assertEquals(3, done.count)
    }

    @Test
    fun replaceAll_canShrinkGrowOrDelete_andLeavesNoHitAlone() {
        assertEquals("a-b-c", TextFiles.replaceAll("a b c", " ", "-").text)
        assertEquals("abc", TextFiles.replaceAll("a b c", " ", "").text)
        assertEquals("xx xx", TextFiles.replaceAll("x x", "x", "xx").text)
        val none = TextFiles.replaceAll("hello", "z", "y")
        assertEquals("hello", none.text)
        assertEquals(0, none.count)
        assertEquals(0, TextFiles.replaceAll("hello", "", "y").count)
    }
}
