package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ZipBrowserTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun makeZip(vararg names: String): File {
        val zip = File(tmp.root, "t.zip")
        ZipOutputStream(zip.outputStream()).use { out ->
            for (name in names) {
                out.putNextEntry(ZipEntry(name))
                if (!name.endsWith("/")) out.write(name.toByteArray())
                out.closeEntry()
            }
        }
        return zip
    }

    @Test
    fun topLevelShowsFoldersAndFiles_evenWithoutFolderLines() {
        val entries = ZipBrowser.read(makeZip("readme.txt", "docs/a.txt", "docs/deep/b.txt"))!!
        val top = ZipBrowser.contents(entries, "")
        assertEquals(listOf("docs"), top.folders.map { it.name })
        assertEquals(listOf("readme"), top.files.map { it.name })
        assertEquals(2, top.folders[0].childCount)
        val inside = ZipBrowser.contents(entries, "docs")
        assertEquals(listOf("deep"), inside.folders.map { it.name })
        assertEquals(listOf("a"), inside.files.map { it.name })
    }

    @Test
    fun namesThatClimbOutAreHidden() {
        val entries = ZipBrowser.read(makeZip("../evil.txt", "ok.txt"))!!
        assertEquals(listOf("ok"), ZipBrowser.contents(entries, "").files.map { it.name })
    }

    @Test
    fun notAZipReadsAsNull() {
        val bad = File(tmp.root, "bad.zip").also { it.writeText("not a zip") }
        assertNull(ZipBrowser.read(bad))
    }

    @Test
    fun extractEntryWritesOnlyTheOneFile() {
        val zip = makeZip("a/b/c.txt", "other.txt")
        val entries = ZipBrowser.read(zip)!!
        val entry = entries.first { it.path == "a/b/c.txt" }
        val dest = File(tmp.root, "out")
        val out = ZipBrowser.extractEntry(zip, entry, dest)
        assertNotNull(out)
        assertEquals("c.txt", out!!.name)
        assertEquals("a/b/c.txt", out.readText())
        assertFalse(File(dest, "other.txt").exists())
    }
}
