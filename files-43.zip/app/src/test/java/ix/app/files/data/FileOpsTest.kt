package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class FileOpsTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun uniqueTarget_addsNumberBeforeExtension() {
        val dir = tmp.newFolder()
        File(dir, "photo.jpg").writeText("a")
        File(dir, "photo (1).jpg").writeText("b")
        assertEquals("photo (2).jpg", FileOps.uniqueTarget(dir, "photo.jpg").name)
        assertEquals("fresh.txt", FileOps.uniqueTarget(dir, "fresh.txt").name)
    }

    @Test
    fun uniqueTarget_worksForFoldersAndDotFiles() {
        val dir = tmp.newFolder()
        File(dir, "Docs").mkdir()
        File(dir, ".nomedia").writeText("")
        assertEquals("Docs (1)", FileOps.uniqueTarget(dir, "Docs").name)
        assertEquals(".nomedia (1)", FileOps.uniqueTarget(dir, ".nomedia").name)
    }

    @Test
    fun remap_followsAMovedFolder() {
        assertEquals("/b/x", FileOps.remap("/a/x", "/a/x", "/b/x"))
        assertEquals("/b/x/y.txt", FileOps.remap("/a/x/y.txt", "/a/x", "/b/x"))
        assertNull(FileOps.remap("/a/xy", "/a/x", "/b/x"))
    }

    @Test
    fun copy_keepsDateAndLeavesOriginal() {
        val src = tmp.newFolder()
        val dest = tmp.newFolder()
        val file = src.write("a.txt", "hello".toByteArray())
        file.setLastModified(1_600_000_000_000L)
        val result = FileOps.paste(dest, listOf(file.path), move = false)
        assertEquals(1, result.done.size)
        assertTrue(file.exists())
        val copy = File(dest, "a.txt")
        assertEquals("hello", copy.readText())
        assertEquals(1_600_000_000_000L, copy.lastModified())
    }

    @Test
    fun copy_intoSameFolderGetsANewName() {
        val dir = tmp.newFolder()
        val file = dir.write("a.txt", "x".toByteArray())
        val result = FileOps.paste(dir, listOf(file.path), move = false)
        assertEquals(1, result.done.size)
        assertTrue(File(dir, "a (1).txt").exists())
    }

    @Test
    fun move_ontoItsOwnFolderIsSkipped_andFolderCanNotGoIntoItself() {
        val dir = tmp.newFolder()
        val file = dir.write("a.txt", "x".toByteArray())
        val sub = File(dir, "sub").also { it.mkdir() }
        val skippedSame = FileOps.paste(dir, listOf(file.path), move = true)
        assertEquals(1, skippedSame.skipped)
        val skippedInto = FileOps.paste(sub, listOf(sub.path), move = true)
        assertEquals(1, skippedInto.skipped)
    }

    @Test
    fun move_putsFileInNewPlace() {
        val a = tmp.newFolder()
        val b = tmp.newFolder()
        val file = a.write("a.txt", "x".toByteArray())
        val result = FileOps.paste(b, listOf(file.path), move = true)
        assertEquals(1, result.done.size)
        assertFalse(file.exists())
        assertTrue(File(b, "a.txt").exists())
    }

    @Test
    fun cancelledCopy_leavesNoHalfCopy() {
        val a = tmp.newFolder()
        val b = tmp.newFolder()
        val file = a.write("big.bin", ByteArray(2 * 1024 * 1024))
        val control = JobControl().also { it.cancel() }
        val result = FileOps.paste(b, listOf(file.path), move = false, control = control)
        assertTrue(result.cancelled)
        assertEquals(0, b.listFiles()?.size ?: 0)
    }

    @Test
    fun zipThenUnzip_roundTrips() {
        val src = tmp.newFolder("src")
        val folder = File(src, "docs").also { it.mkdir() }
        File(folder, "one.txt").writeText("1")
        File(folder, "two.txt").writeText("22")
        val zip = File(tmp.root, "out.zip")
        assertTrue(FileOps.zip(listOf(folder), zip))
        val dest = File(tmp.root, "unpacked")
        assertTrue(FileOps.unzip(zip, dest))
        assertEquals("1", File(dest, "docs/one.txt").readText())
        assertEquals("22", File(dest, "docs/two.txt").readText())
    }

    @Test
    fun unzip_skipsEntriesThatClimbOut() {
        val zip = File(tmp.root, "evil.zip")
        ZipOutputStream(zip.outputStream()).use { out ->
            out.putNextEntry(ZipEntry("../escaped.txt"))
            out.write("no".toByteArray())
            out.closeEntry()
            out.putNextEntry(ZipEntry("fine.txt"))
            out.write("yes".toByteArray())
            out.closeEntry()
        }
        val dest = File(tmp.newFolder(), "x")
        assertTrue(FileOps.unzip(zip, dest))
        assertEquals("yes", File(dest, "fine.txt").readText())
        assertFalse(File(dest.parentFile, "escaped.txt").exists())
    }

    @Test
    fun sizeOf_addsUpAFolder() {
        val dir = tmp.newFolder()
        dir.write("a", ByteArray(10))
        File(dir, "sub").mkdir()
        File(dir, "sub/b").writeBytes(ByteArray(5))
        assertEquals(15L, FileOps.sizeOf(dir))
    }
}
