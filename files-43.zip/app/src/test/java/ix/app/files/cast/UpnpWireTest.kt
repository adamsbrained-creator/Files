package ix.app.files.cast

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList

/** The real SOAP client talking to a small stand-in for a TV, over loopback. */
class UpnpWireTest {

    private class Seen(val soapAction: String?, val contentType: String?, val body: String)

    private val seen = CopyOnWriteArrayList<Seen>()
    private lateinit var http: HttpServer
    private var respond: (String) -> Pair<Int, String> = { 200 to "<s:Envelope xmlns:s=\"x\"><s:Body/></s:Envelope>" }

    private val plainLan = object : Lan {
        override fun open(url: String): HttpURLConnection = URL(url).openConnection() as HttpURLConnection
        override fun bind(socket: DatagramSocket) {}
        override fun localIpFor(host: String): String? = "127.0.0.1"
    }

    private fun device(): CastDevice {
        val base = "http://127.0.0.1:${http.address.port}"
        return CastDevice(
            "uuid:t", "Test TV", "Model", DeviceKind.TV, "127.0.0.1", "$base/d.xml",
            "$base/avt", "urn:schemas-upnp-org:service:AVTransport:1",
            "$base/rc", "urn:schemas-upnp-org:service:RenderingControl:1",
            "$base/cm", "urn:schemas-upnp-org:service:ConnectionManager:1",
        )
    }

    @Before
    fun setUp() {
        http = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        http.createContext("/") { ex: HttpExchange ->
            val body = ex.requestBody.readBytes().toString(Charsets.UTF_8)
            seen += Seen(ex.requestHeaders.getFirst("SOAPACTION"), ex.requestHeaders.getFirst("Content-Type"), body)
            val (code, text) = respond(body)
            val bytes = text.toByteArray()
            ex.sendResponseHeaders(code, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
        http.start()
    }

    @After
    fun tearDown() = http.stop(0)

    private fun envelope(inner: String) =
        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body>$inner</s:Body></s:Envelope>"

    @Test
    fun setUri_sendsTheActionHeader_andAnEscapedDidlThatSurvivesTheRoundTrip() {
        val item = CastItem("/x/A & B.mp4", "A & B <1>", CastKind.Video, "video/mp4", "mp4", 99, 61_000)
        val url = "http://192.168.1.2:5000/tok/m/1.mp4"
        val didl = Didl.build(item, 1, url, false)
        UpnpRenderer(plainLan, device()).setUri(url, didl)

        val r = seen.single()
        assertEquals("\"urn:schemas-upnp-org:service:AVTransport:1#SetAVTransportURI\"", r.soapAction)
        assertTrue(r.contentType!!.startsWith("text/xml"))
        val parsed = Soap.parse(r.body)
        assertEquals(url, parsed["CurrentURI"])
        assertEquals("0", parsed["InstanceID"])
        // The device unescapes the metadata once and gets exactly the DIDL we built.
        assertEquals(didl, parsed["CurrentURIMetaData"])
        assertNotNull(Soap.parse(parsed["CurrentURIMetaData"]!!)["title"])
        assertEquals("A & B <1>", Soap.parse(parsed["CurrentURIMetaData"]!!)["title"])
    }

    @Test
    fun playPauseStopSeek_useTheRightActionsAndArguments() {
        val r = UpnpRenderer(plainLan, device())
        r.play(); r.pause(); r.stop(); r.seek(3_725_000)
        val actions = seen.map { it.soapAction!!.substringAfter('#').trim('"') }
        assertEquals(listOf("Play", "Pause", "Stop", "Seek"), actions)
        assertEquals("1", Soap.parse(seen[0].body)["Speed"])
        val seek = Soap.parse(seen[3].body)
        assertEquals("REL_TIME", seek["Unit"])
        assertEquals("1:02:05", seek["Target"])
    }

    @Test
    fun seek_fallsBackToAbsoluteTime_whenRelativeIsRefused() {
        respond = { body ->
            if (body.contains("REL_TIME")) 500 to envelope("<s:Fault><detail><UPnPError><errorCode>710</errorCode></UPnPError></detail></s:Fault>")
            else 200 to envelope("")
        }
        UpnpRenderer(plainLan, device()).seek(5_000)
        assertEquals(2, seen.size)
        assertEquals("ABS_TIME", Soap.parse(seen[1].body)["Unit"])
    }

    @Test
    fun transportAndPosition_areParsed() {
        respond = { body ->
            when {
                body.contains("GetTransportInfo") -> 200 to envelope("<u:GetTransportInfoResponse xmlns:u=\"urn:x\"><CurrentTransportState>PLAYING</CurrentTransportState></u:GetTransportInfoResponse>")
                else -> 200 to envelope("<u:GetPositionInfoResponse xmlns:u=\"urn:x\"><TrackDuration>1:30:00</TrackDuration><RelTime>0:10:05</RelTime><TrackURI>http://h/t/m/3.mkv</TrackURI></u:GetPositionInfoResponse>")
            }
        }
        val r = UpnpRenderer(plainLan, device())
        assertEquals("PLAYING", r.transportState())
        val p = r.positionInfo()
        assertEquals(605_000L, p.relMs)
        assertEquals(5_400_000L, p.durMs)
        assertEquals("http://h/t/m/3.mkv", p.trackUri)
    }

    @Test
    fun upnpErrors_carryTheirCode() {
        respond = { 500 to envelope("<s:Fault><detail><UPnPError><errorCode>714</errorCode><errorDescription>Illegal MIME-type</errorDescription></UPnPError></detail></s:Fault>") }
        val e = runCatching { UpnpRenderer(plainLan, device()).setUri("http://x/y.mkv", "<DIDL-Lite/>") }.exceptionOrNull()
        assertTrue(e is UpnpException)
        assertEquals(714, (e as UpnpException).code)
        assertTrue(e.message!!.contains("Illegal MIME-type"))
    }

    @Test
    fun volume_andFormats_useTheirOwnServices() {
        respond = { body ->
            when {
                body.contains("GetVolume") -> 200 to envelope("<CurrentVolume>37</CurrentVolume>")
                body.contains("GetProtocolInfo") -> 200 to envelope("<Sink>http-get:*:video/mp4:*,http-get:*:audio/mpeg:*</Sink>")
                else -> 200 to envelope("")
            }
        }
        val r = UpnpRenderer(plainLan, device())
        assertEquals(37, r.getVolume())
        r.setVolume(150)
        assertEquals(listOf("video/mp4:*", "audio/mpeg:*").size, r.sinkFormats().size)
        val set = seen.first { it.body.contains("SetVolume") }
        assertEquals("100", Soap.parse(set.body)["DesiredVolume"])
        assertEquals("Master", Soap.parse(set.body)["Channel"])
        assertTrue(set.soapAction!!.contains("RenderingControl:1#SetVolume"))
    }

    @Test
    fun deviceWithoutRenderingControl_hasNoVolume() {
        val d = device().copy(rcUrl = null, rcType = null)
        val r = UpnpRenderer(plainLan, d)
        assertEquals(null, r.getVolume())
        r.setVolume(10)
        assertTrue(seen.isEmpty())
    }

    @Test
    fun descriptionIsFetchedOverHttp() {
        respond = {
            200 to "<root><device><friendlyName>Den TV</friendlyName><UDN>uuid:d</UDN><serviceList><service>" +
                "<serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType><controlURL>/avt</controlURL>" +
                "</service></serviceList></device></root>"
        }
        val d = UpnpDescription.fetch(plainLan, "http://127.0.0.1:${http.address.port}/d.xml")
        assertEquals("Den TV", d!!.name)
        assertEquals("http://127.0.0.1:${http.address.port}/avt", d.avtUrl)
    }
}
