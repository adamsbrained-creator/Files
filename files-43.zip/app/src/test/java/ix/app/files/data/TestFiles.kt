package ix.app.files.data

import java.io.File

/** Small helpers shared by the tests. */
internal fun fileItem(
    path: String,
    name: String = path.substringAfterLast('/').substringBeforeLast('.'),
    extension: String = path.substringAfterLast('.', ""),
    size: Long = 1_000L,
    modified: Long = 0L,
    kind: FileKind = FileKinds.kindOf(extension),
) = FileItem(path, name, extension, size, modified, kind)

internal fun File.write(name: String, bytes: ByteArray): File = File(this, name).also { it.writeBytes(bytes) }
