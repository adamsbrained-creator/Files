package ix.app.files.data

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** The xz library is a separate download, and 7z uses it by default, so these cover the common real-world case. */
class ArchiveXzTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val hello = "hello xz".toByteArray()

    @Test
    fun tarXz_listsAndUnpacks() {
        val file = File(tmp.root, "a.tar.xz")
        TarArchiveOutputStream(XZCompressorOutputStream(file.outputStream().buffered())).use { tar ->
            val entry = TarArchiveEntry("x/hello.txt")
            entry.size = hello.size.toLong()
            tar.putArchiveEntry(entry)
            tar.write(hello)
            tar.closeArchiveEntry()
            tar.finish()
        }
        assertEquals(listOf("x/hello.txt"), ZipBrowser.read(file)!!.filter { !it.isDirectory }.map { it.path })
        val dest = File(tmp.root, "out")
        assertTrue(FileOps.unpack(file, dest))
        assertArrayEquals(hello, File(dest, "x/hello.txt").readBytes())
    }

    @Test
    fun sevenZ_withTheDefaultLzma2_unpacks() {
        val file = File(tmp.root, "a.7z")
        SevenZOutputFile(file).use { out ->
            val entry = SevenZArchiveEntry()
            entry.name = "hello.txt"
            entry.size = hello.size.toLong()
            out.putArchiveEntry(entry)
            out.write(hello)
            out.closeArchiveEntry()
            out.finish()
        }
        val dest = File(tmp.root, "out")
        assertTrue(FileOps.unpack(file, dest))
        assertArrayEquals(hello, File(dest, "hello.txt").readBytes())
    }
}
