package ix.app.files.data

import java.io.File
import java.io.ByteArrayInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class BatchRenameTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun file(name: String) = tmp.root.write(name, byteArrayOf(1))

    @Test
    fun numberingKeepsExtensionsAndCountsNaturally() {
        val files = listOf("img10.jpg", "img2.jpg", "img1.png").map { file(it) }
        val rows = BatchRename.preview(files, RenameRule.Numbering("Trip ", 1, 3))
        assertEquals(listOf("img1.png", "img2.jpg", "img10.jpg"), rows.map { it.oldName })
        assertEquals(listOf("Trip 001.png", "Trip 002.jpg", "Trip 003.jpg"), rows.map { it.newName })
        assertTrue(rows.all { it.ready })
    }

    @Test
    fun foldersHaveNoExtension() {
        val dir = File(tmp.root, "v1.2").also { it.mkdirs() }
        val rows = BatchRename.preview(listOf(dir), RenameRule.Affix("", "-old"))
        assertEquals("v1.2-old", rows[0].newName)
    }

    @Test
    fun replaceWorksOnTheNamePartOnly() {
        val rows = BatchRename.preview(
            listOf(file("my.txt.txt"), file("other.doc")),
            RenameRule.Replace("TXT", "md", true),
        ).associateBy { it.oldName }
        assertEquals("my.md.txt", rows.getValue("my.txt.txt").newName)
        assertFalse(rows.getValue("other.doc").changed)
        assertFalse(rows.getValue("other.doc").ready)
    }

    @Test
    fun emptyFindChangesNothing() {
        val rows = BatchRename.preview(listOf(file("a.txt")), RenameRule.Replace("", "x", false))
        assertFalse(rows[0].changed)
    }

    @Test
    fun affixKeepsExtensions() {
        val rows = BatchRename.preview(listOf(file("a.tar.gz"), file(".nomedia")), RenameRule.Affix("x_", "_y"))
            .associate { it.oldName to it.newName }
        assertEquals("x_a_y.tar.gz", rows["a.tar.gz"])
        assertEquals("x_.nomedia_y", rows[".nomedia"])
    }

    @Test
    fun sameNewNameInOneFolderClashes() {
        // "a" is dropped from both: ab.txt -> b.txt and ba.txt -> b.txt.
        val rows = BatchRename.preview(listOf(file("ab.txt"), file("ba.txt")), RenameRule.Replace("a", "", false))
        assertTrue(rows.all { it.problem == RenameProblem.Clash })
    }

    @Test
    fun clashIsCaseBlind() {
        val rows = BatchRename.preview(listOf(file("aB.txt"), file("ba.txt")), RenameRule.Replace("a", "", false))
        assertTrue(rows.all { it.problem == RenameProblem.Clash })
    }

    @Test
    fun sameNameInDifferentFoldersIsFine() {
        val sub = File(tmp.root, "sub").also { it.mkdirs() }
        val rows = BatchRename.preview(
            listOf(file("ab.txt"), sub.write("ba.txt", byteArrayOf(1))),
            RenameRule.Replace("a", "", false),
        )
        assertTrue(rows.all { it.ready })
    }

    @Test
    fun takenNameIsFlaggedUnlessTheOwnerMovesAway() {
        // Another item of the batch keeps the name: a clash. A file outside the batch has it: taken.
        val clash = BatchRename.preview(listOf(file("c.txt"), file("d.txt")), RenameRule.Replace("c", "d", false))
        assertEquals(RenameProblem.Clash, clash.first { it.oldName == "c.txt" }.problem)
        file("f.txt")
        val taken = BatchRename.preview(listOf(file("e.txt")), RenameRule.Replace("e", "f", false))
        assertEquals(RenameProblem.Exists, taken[0].problem)
        // 1.txt -> 2.txt is fine while 2.txt itself is renamed (to 3.txt).
        val dir = File(tmp.root, "chain").also { it.mkdirs() }
        val rows = BatchRename.preview(
            listOf(dir.write("1.txt", byteArrayOf(1)), dir.write("2.txt", byteArrayOf(1))),
            RenameRule.Numbering("", 2, 1),
        )
        assertTrue(rows.all { it.ready })
    }

    @Test
    fun badNamesAreRefused() {
        val rows = BatchRename.preview(listOf(file("a.txt")), RenameRule.Replace("a", "x/y", false))
        assertEquals(RenameProblem.Invalid, rows[0].problem)
        val empty = BatchRename.preview(listOf(File(tmp.root, "z").also { it.mkdirs() }), RenameRule.Replace("z", "", false))
        assertEquals(RenameProblem.Invalid, empty[0].problem)
        val long = BatchRename.preview(listOf(file("b.txt")), RenameRule.Affix("x".repeat(300), ""))
        assertEquals(RenameProblem.TooLong, long[0].problem)
    }

    @Test
    fun shiftingNamesGoThroughWithoutOverwriting() {
        val dir = File(tmp.root, "shift").also { it.mkdirs() }
        val files = listOf(
            dir.write("1.txt", byteArrayOf(1)),
            dir.write("2.txt", byteArrayOf(2)),
            dir.write("3.txt", byteArrayOf(3)),
        )
        // 1->2, 2->3, 3->4
        val rows = BatchRename.preview(files, RenameRule.Numbering("", 2, 1))
        assertTrue(rows.all { it.ready })
        val result = BatchRename.apply(rows)
        assertEquals(0, result.failed)
        assertEquals(3, result.moved.size)
        assertEquals(setOf("2.txt", "3.txt", "4.txt"), dir.list()!!.toSet())
        assertEquals(1, File(dir, "2.txt").readBytes()[0].toInt())
        assertEquals(2, File(dir, "3.txt").readBytes()[0].toInt())
        assertEquals(3, File(dir, "4.txt").readBytes()[0].toInt())
    }

    @Test
    fun swapWorks() {
        val dir = File(tmp.root, "swap").also { it.mkdirs() }
        val a = dir.write("a.txt", byteArrayOf(1))
        val b = dir.write("b.txt", byteArrayOf(2))
        // Built by hand: preview would call it a clash only if two items shared a target.
        val rows = listOf(
            RenameRow(a, "a.txt", "b.txt", false, null),
            RenameRow(b, "b.txt", "a.txt", false, null),
        )
        val result = BatchRename.apply(rows)
        assertEquals(0, result.failed)
        assertEquals(2, File(dir, "a.txt").readBytes()[0].toInt())
        assertEquals(1, File(dir, "b.txt").readBytes()[0].toInt())
        assertEquals(setOf("a.txt", "b.txt"), dir.list()!!.toSet())
    }

    @Test
    fun existingTargetIsNeverOverwritten() {
        val dir = File(tmp.root, "keep").also { it.mkdirs() }
        val a = dir.write("a.txt", byteArrayOf(1))
        dir.write("b.txt", byteArrayOf(9))
        val rows = listOf(RenameRow(a, "a.txt", "b.txt", false, null))
        val result = BatchRename.apply(rows)
        assertEquals(1, result.failed)
        assertEquals(9, File(dir, "b.txt").readBytes()[0].toInt())
        assertTrue(File(dir, "a.txt").exists())
    }

    @Test
    fun failedSecondStepPutsTheItemBack() {
        val dir = File(tmp.root, "undo").also { it.mkdirs() }
        val a = dir.write("a.txt", byteArrayOf(1))
        val b = dir.write("b.txt", byteArrayOf(2))
        val rows = listOf(
            RenameRow(a, "a.txt", "b.txt", false, null),
            RenameRow(b, "b.txt", "a.txt", false, null),
        )
        var failedOnce = false
        val result = BatchRename.apply(rows, rename = { from, to ->
            if (!failedOnce && from.name.startsWith(".ixrename") && to.name == "b.txt") {
                failedOnce = true
                false
            } else {
                from.renameTo(to)
            }
        })
        // Nothing is lost: both files are back under their own names with their own content.
        assertEquals(2, result.failed)
        assertEquals(0, result.moved.size)
        assertEquals(setOf("a.txt", "b.txt"), dir.list()!!.toSet())
        assertEquals(1, File(dir, "a.txt").readBytes()[0].toInt())
        assertEquals(2, File(dir, "b.txt").readBytes()[0].toInt())
    }

    @Test
    fun cancelledBeforeStartTouchesNothing() {
        val dir = File(tmp.root, "stop").also { it.mkdirs() }
        val a = dir.write("a.txt", byteArrayOf(1))
        val control = JobControl().also { it.cancel() }
        val result = BatchRename.apply(listOf(RenameRow(a, "a.txt", "z.txt", false, null)), control)
        assertEquals(0, result.moved.size)
        assertTrue(File(dir, "a.txt").exists())
    }

    @Test
    fun naturalOrder() {
        val sorted = listOf("a10", "a2", "A1", "a02b", "b").sortedWith { x, y -> BatchRename.compareNatural(x, y) }
        assertEquals(listOf("A1", "a2", "a02b", "a10", "b"), sorted)
    }

    @Test
    fun checksumsMatchKnownValues() {
        val file = file("abc.txt").also { it.writeBytes("abc".toByteArray()) }
        val sums = Checksums.of(file, open = { ByteArrayInputStream(it.readBytes()) })
        assertEquals("900150983cd24fb0d6963f7d28e17f72", sums.md5)
        assertEquals("a9993e364706816aba3e25717850c26c9cd0d89d", sums.sha1)
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", sums.sha256)
    }

    @Test
    fun checksumOfEmptyFileAndCancel() {
        val empty = file("empty.bin").also { it.writeBytes(ByteArray(0)) }
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", Checksums.of(empty, open = { ByteArrayInputStream(it.readBytes()) }).md5)
        val control = JobControl().also { it.cancel() }
        var stopped = false
        try {
            Checksums.of(empty, control, open = { ByteArrayInputStream(it.readBytes()) })
        } catch (e: JobStopped) {
            stopped = true
        }
        assertTrue(stopped)
    }
}
