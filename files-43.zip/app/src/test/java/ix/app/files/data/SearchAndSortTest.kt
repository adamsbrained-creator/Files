package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import ix.app.files.util.formatFileSize
import java.util.Locale

class SearchAndSortTest {

    private val scan = ScanData(
        byCategory = emptyMap(),
        recent = emptyList(),
        files = listOf(
            fileItem("/s/holiday.jpg", modified = 5),
            fileItem("/s/my holiday notes.txt", modified = 9),
            fileItem("/s/report.pdf", modified = 1),
            fileItem("/s/Holiday2.png", modified = 7),
        ),
    )

    @Test
    fun namesThatStartWithTheTextComeFirst_newestFirst() {
        val found = SearchEngine.search(scan, "holiday").files.map { it.path }
        assertEquals(listOf("/s/Holiday2.png", "/s/holiday.jpg", "/s/my holiday notes.txt"), found)
    }

    @Test
    fun extensionAndWholeNameMatch() {
        assertEquals(listOf("/s/report.pdf"), SearchEngine.search(scan, "pdf").files.map { it.path })
        assertEquals(listOf("/s/report.pdf"), SearchEngine.search(scan, "report.pdf").files.map { it.path })
    }

    private val day = 24L * 60 * 60 * 1000

    private val filterScan = ScanData(
        byCategory = emptyMap(),
        recent = emptyList(),
        files = listOf(
            fileItem("/s/new.jpg", size = 500_000, modified = 100 * day),
            fileItem("/s/old.jpg", size = 500_000, modified = 10 * day),
            fileItem("/s/big.mp4", size = 200L * 1024 * 1024, modified = 99 * day),
            fileItem("/s/mid.pdf", size = 5L * 1024 * 1024, modified = 80 * day),
        ),
    )

    @Test
    fun filterAloneIsASearch_andBlankWithNoFilterIsNot() {
        val kind = SearchFilter(kind = FileKind.Image)
        val found = SearchEngine.search(filterScan, "", kind, now = 100 * day).files.map { it.path }
        assertEquals(listOf("/s/new.jpg", "/s/old.jpg"), found)
        assertEquals(0, SearchEngine.search(filterScan, "", SearchFilter.None, now = 100 * day).total)
    }

    @Test
    fun sizeAndDateBandsNarrowTheResults() {
        val big = SearchFilter(size = SizeBand.Large)
        assertEquals(listOf("/s/big.mp4"), SearchEngine.search(filterScan, "", big, now = 100 * day).files.map { it.path })
        val week = SearchFilter(date = DateBand.Week)
        assertEquals(listOf("/s/new.jpg", "/s/big.mp4"), SearchEngine.search(filterScan, "", week, now = 100 * day).files.map { it.path })
        val mid = SearchFilter(size = SizeBand.Medium, date = DateBand.Month)
        assertEquals(listOf("/s/mid.pdf"), SearchEngine.search(filterScan, "", mid, now = 100 * day).files.map { it.path })
    }

    @Test
    fun filtersCombineWithText() {
        val images = SearchFilter(kind = FileKind.Image)
        assertEquals(listOf("/s/old.jpg"), SearchEngine.search(filterScan, "old", images, now = 100 * day).files.map { it.path })
        assertEquals(0, SearchEngine.search(filterScan, "big", images, now = 100 * day).total)
    }

    @Test
    fun foldersStayOnlyWhenNoKindOrSizeIsSet() {
        val folder = FolderItem("/s/x", "x", 0, 90 * day)
        assertTrue(SearchFilter(date = DateBand.Month).matches(folder, 100 * day))
        assertFalse(SearchFilter(date = DateBand.Week).matches(folder, 100 * day))
        assertFalse(SearchFilter(kind = FileKind.Image).matches(folder, 100 * day))
        assertFalse(SearchFilter(size = SizeBand.Small).matches(folder, 100 * day))
    }

    @Test
    fun blankSearchFindsNothing() {
        assertEquals(0, SearchEngine.search(scan, "   ").total)
    }

    @Test
    fun sortSpec_flipsOnSameFieldAndUsesDefaultsOnNewField() {
        val start = SortSpec(SortField.Modified, ascending = false)
        assertEquals(true, start.select(SortField.Modified).ascending)
        val name = start.select(SortField.Name)
        assertEquals(SortField.Name, name.field)
        assertEquals(true, name.ascending)
    }

    @Test
    fun filesSortByNameIgnoringCase_andBySizeDescending() {
        val files = listOf(
            fileItem("/a/b.txt", size = 5),
            fileItem("/a/A.txt", size = 50),
            fileItem("/a/c.txt", size = 1),
        )
        assertEquals(
            listOf("A", "b", "c"),
            files.sortedBySpec(SortSpec(SortField.Name, ascending = true)).map { it.name },
        )
        assertEquals(
            listOf(50L, 5L, 1L),
            files.sortedBySpec(SortSpec(SortField.Size, ascending = false)).map { it.sizeBytes },
        )
    }

    @Test
    fun fileSizesUseDecimalUnits() {
        assertEquals("820 KB", formatFileSize(820_000, Locale.US))
        assertEquals("1.1 MB", formatFileSize(1_100_000, Locale.US))
        assertEquals("148 MB", formatFileSize(148_000_000, Locale.US))
        assertEquals("0 B", formatFileSize(-5, Locale.US))
    }
}
