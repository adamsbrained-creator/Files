package ix.app.files.data

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class AppsTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private fun app(
        label: String,
        pkg: String = "com.example.${label.lowercase().replace(' ', '.')}",
        bytes: Long = 1,
        updated: Long = 0,
        system: Boolean = false,
        paths: List<String> = emptyList(),
        version: String = "1.0",
    ) = AppEntry(pkg, label, version, paths, bytes, 0L, updated, system)

    @Test
    fun viewHidesSystemAppsUnlessAsked() {
        val apps = listOf(app("Maps"), app("Phone", system = true))
        assertEquals(listOf("Maps"), AppsEngine.view(apps, AppSort.Name, false, "").map { it.label })
        assertEquals(listOf("Maps", "Phone"), AppsEngine.view(apps, AppSort.Name, true, "").map { it.label })
    }

    @Test
    fun viewSortsByNameSizeAndUpdate() {
        val apps = listOf(
            app("beta", bytes = 5, updated = 30),
            app("Alpha", bytes = 50, updated = 10),
            app("gamma", bytes = 20, updated = 20),
        )
        assertEquals(listOf("Alpha", "beta", "gamma"), AppsEngine.view(apps, AppSort.Name, false, "").map { it.label })
        assertEquals(listOf("Alpha", "gamma", "beta"), AppsEngine.view(apps, AppSort.Size, false, "").map { it.label })
        assertEquals(listOf("beta", "gamma", "Alpha"), AppsEngine.view(apps, AppSort.Updated, false, "").map { it.label })
    }

    @Test
    fun viewSearchesNameAndPackage() {
        val apps = listOf(app("Maps", pkg = "com.google.maps"), app("Notes", pkg = "org.notes"))
        assertEquals(listOf("Maps"), AppsEngine.view(apps, AppSort.Name, false, " MAP ").map { it.label })
        assertEquals(listOf("Notes"), AppsEngine.view(apps, AppSort.Name, false, "org.").map { it.label })
        assertTrue(AppsEngine.view(apps, AppSort.Name, false, "zzz").isEmpty())
    }

    @Test
    fun safeNameCleansUp() {
        assertEquals("a b c", AppBackup.safeName("a/b:c"))
        assertEquals("app", AppBackup.safeName("///"))
        assertEquals("app", AppBackup.safeName("..."))
        assertEquals(120, AppBackup.safeName("x".repeat(500)).length)
        assertEquals("My App 2.0", AppBackup.safeName("  My   App\t2.0 "))
    }

    @Test
    fun singleApkBecomesOneFile() {
        val apk = tmp.root.write("base.apk", byteArrayOf(1, 2, 3))
        val dest = File(tmp.root, "backups")
        val made = AppBackup.backup(app("My App", paths = listOf(apk.path), version = "2.1"), dest)!!
        assertEquals("My App 2.1.apk", made.name)
        assertEquals(listOf<Byte>(1, 2, 3), made.readBytes().toList())
        // A second backup of the same version gets a number.
        val again = AppBackup.backup(app("My App", paths = listOf(apk.path), version = "2.1"), dest)!!
        assertEquals("My App 2.1 (1).apk", again.name)
        assertTrue(apk.exists())
    }

    @Test
    fun splitApksBecomeAFolder() {
        val dir = File(tmp.root, "src").also { it.mkdirs() }
        val base = dir.write("base.apk", byteArrayOf(1))
        val split = dir.write("split_config.en.apk", byteArrayOf(2))
        val dest = File(tmp.root, "backups")
        val made = AppBackup.backup(app("Big", paths = listOf(base.path, split.path)), dest)!!
        assertTrue(made.isDirectory)
        assertEquals(setOf("base.apk", "split_config.en.apk"), made.list()!!.toSet())
    }

    @Test
    fun missingApkFailsAndLeavesNothing() {
        val dest = File(tmp.root, "backups")
        assertNull(AppBackup.backup(app("Gone", paths = listOf(File(tmp.root, "no.apk").path)), dest))
        assertNull(AppBackup.backup(app("Empty"), dest))
        assertTrue(dest.list().isNullOrEmpty())
    }

    @Test
    fun oneMissingPieceFailsTheWholeApp() {
        val base = tmp.root.write("base.apk", byteArrayOf(1))
        val dest = File(tmp.root, "backups")
        val result = AppBackup.backup(app("Half", paths = listOf(base.path, File(tmp.root, "split.apk").path)), dest)
        assertNull(result)
        assertTrue(dest.list().isNullOrEmpty())
    }

    @Test
    fun cancelCleansUp() {
        val dir = File(tmp.root, "src").also { it.mkdirs() }
        val a = dir.write("base.apk", ByteArray(10))
        val b = dir.write("split.apk", ByteArray(10))
        val dest = File(tmp.root, "backups")
        val control = JobControl().also { it.cancel() }
        var stopped = false
        try {
            AppBackup.backup(app("Stop", paths = listOf(a.path, b.path)), dest, control)
        } catch (e: JobStopped) {
            stopped = true
        }
        assertTrue(stopped)
        assertFalse(dest.listFiles()!!.any { it.exists() })
    }

    @Test
    fun progressCountsBytes() {
        val apk = tmp.root.write("base.apk", ByteArray(1000))
        val control = JobControl()
        AppBackup.backup(app("P", paths = listOf(apk.path)), File(tmp.root, "b"), control)
        assertEquals(1000L, control.done)
    }
}
