package ix.app.files.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** Undo is a paste into the trash followed by a relocate back, so these two are tested together. */
class UndoRelocateTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun deleteThenUndo_bringsTheFileBack() {
        val home = tmp.newFolder()
        val trash = tmp.newFolder()
        val file = home.write("a.txt", "keep me".toByteArray())

        val trashed = FileOps.paste(trash, listOf(file.path), move = true)
        assertFalse(file.exists())

        val restored = FileOps.relocate(trashed.done.map { it.second to it.first })
        assertEquals(1, restored.size)
        assertEquals("keep me", file.readText())
    }

    @Test
    fun undo_recreatesAFolderThatIsGone() {
        val root = tmp.newFolder()
        val folder = File(root, "photos").also { it.mkdir() }
        folder.write("x.jpg", ByteArray(3))
        val trash = tmp.newFolder()
        val trashed = FileOps.paste(trash, listOf(folder.path), move = true)
        folder.parentFile?.deleteRecursively()

        val restored = FileOps.relocate(trashed.done.map { it.second to it.first })
        assertEquals(1, restored.size)
        assertTrue(File(root, "photos/x.jpg").exists())
    }

    @Test
    fun undo_usesAFreeNameWhenTheOldOneIsTaken() {
        val home = tmp.newFolder()
        val trash = tmp.newFolder()
        val file = home.write("a.txt", "old".toByteArray())
        val trashed = FileOps.paste(trash, listOf(file.path), move = true)
        home.write("a.txt", "new".toByteArray())

        val restored = FileOps.relocate(trashed.done.map { it.second to it.first })
        assertEquals("new", File(home, "a.txt").readText())
        assertEquals("old", File(home, "a (1).txt").readText())
        assertEquals(File(home, "a (1).txt").absolutePath, restored.single().second)
    }

    @Test
    fun relocate_skipsItemsThatAreNoLongerThere() {
        val home = tmp.newFolder()
        val restored = FileOps.relocate(listOf(File(home, "ghost").path to File(home, "back").path))
        assertTrue(restored.isEmpty())
    }
}
