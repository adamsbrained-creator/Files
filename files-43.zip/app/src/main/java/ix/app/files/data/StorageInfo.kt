package ix.app.files.data

import android.os.Environment
import android.os.StatFs

/** Used and total space of the device's main storage, shown in the header pill. */
data class StorageInfo(val usedBytes: Long, val totalBytes: Long) {

    val usedFraction: Float
        get() = if (totalBytes > 0) (usedBytes.toDouble() / totalBytes).toFloat().coerceIn(0f, 1f) else 0f

    companion object {
        fun read(): StorageInfo = try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.totalBytes
            StorageInfo(usedBytes = total - stat.availableBytes, totalBytes = total)
        } catch (e: Exception) {
            StorageInfo(0L, 0L)
        }
    }
}
