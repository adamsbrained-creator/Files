package ix.app.files.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** Launcher icons of installed apps, drawn off the main thread (three at a time) and kept in a memory cache. */
private object AppIcons {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 16).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount / 1024
    }
    private val gate = Semaphore(3)

    private fun key(packageName: String, updatedAt: Long, px: Int) = "$packageName|$updatedAt|$px"

    fun peek(packageName: String, updatedAt: Long, px: Int): Bitmap? = cache.get(key(packageName, updatedAt, px))

    suspend fun load(context: Context, packageName: String, updatedAt: Long, px: Int): Bitmap? {
        val k = key(packageName, updatedAt, px)
        cache.get(k)?.let { return it }
        val bitmap = gate.withPermit {
            withContext(Dispatchers.IO) {
                try {
                    val icon = context.packageManager.getApplicationIcon(packageName)
                    val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                    icon.setBounds(0, 0, px, px)
                    icon.draw(Canvas(out))
                    out
                } catch (e: Exception) {
                    null
                } catch (e: OutOfMemoryError) {
                    null
                }
            }
        }
        if (bitmap != null) cache.put(k, bitmap)
        return bitmap
    }
}

/** The launcher icon of the installed app [packageName]. Blank while it loads, and if it can not be read. */
@Composable
fun AppIcon(packageName: String, updatedAt: Long, size: Dp, modifier: Modifier = Modifier) {
    val px = with(LocalDensity.current) { size.roundToPx() }
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(AppIcons.peek(packageName, updatedAt, px), packageName, updatedAt, px) {
        if (value == null) value = AppIcons.load(context, packageName, updatedAt, px)
    }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        val ready = bitmap
        if (ready != null) {
            val image = remember(ready) { ready.asImageBitmap() }
            Image(bitmap = image, contentDescription = null, modifier = Modifier.fillMaxSize())
        }
    }
}
