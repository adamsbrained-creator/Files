package ix.app.files.data

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Access to shared storage.
 * Android 11 and up needs "All files access" (granted in system settings).
 * Android 8 to 10 uses the normal storage permission.
 */
object StorageAccess {

    fun hasAccess(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    /** The folder that holds Download, DCIM, Pictures and so on. */
    @Suppress("DEPRECATION")
    fun root(): File = Environment.getExternalStorageDirectory()

    /** Opens this app's "All files access" page in system settings (Android 11+). */
    fun settingsIntent(context: Context): Intent =
        Intent(
            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        )
}
