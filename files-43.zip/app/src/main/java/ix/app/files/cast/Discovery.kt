package ix.app.files.cast

import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

/** SSDP: shout "who is a media renderer?" at the whole network and collect the answers. */
object Ssdp {
    private const val GROUP = "239.255.255.250"
    private const val PORT = 1900
    private val targets = listOf(
        "urn:schemas-upnp-org:service:AVTransport:1",
        "urn:schemas-upnp-org:device:MediaRenderer:1",
    )

    /** Blocking. Calls [onLocation] once per distinct device description URL. */
    fun search(lan: Lan, listenMs: Int, keepGoing: () -> Boolean, onLocation: (String) -> Unit) {
        val socket = DatagramSocket()
        try {
            lan.bind(socket)
            socket.soTimeout = 400
            val group = InetAddress.getByName(GROUP)
            val end = System.nanoTime() + listenMs * 1_000_000L
            var nextSend = 0L
            var sendFailures = 0
            val buf = ByteArray(4096)
            val seen = HashSet<String>()
            while (keepGoing() && System.nanoTime() < end) {
                val now = System.nanoTime()
                if (now >= nextSend) {
                    for (st in targets) {
                        val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: $GROUP:$PORT\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n" +
                            "ST: $st\r\nUSER-AGENT: ${Soap.USER_AGENT}\r\n\r\n").toByteArray()
                        try {
                            socket.send(DatagramPacket(msg, msg.size, group, PORT))
                        } catch (e: Exception) {
                            if (sendFailures++ == 0) CastLog.log("SSDP send failed: $e")
                        }
                    }
                    nextSend = now + 1_300_000_000L
                }
                try {
                    val p = DatagramPacket(buf, buf.size)
                    socket.receive(p)
                    val location = headers(String(p.data, 0, p.length, Charsets.UTF_8))["location"]
                    if (location != null && seen.add(location)) onLocation(location)
                } catch (e: SocketTimeoutException) {
                    // nothing yet, loop again
                }
            }
        } finally {
            socket.close()
        }
    }

    fun headers(text: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (line in text.split("\r\n").drop(1)) {
            val i = line.indexOf(':')
            if (i > 0) out[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        return out
    }
}

/** Reads a device's description XML and pulls out its name and the addresses of its control endpoints. */
object UpnpDescription {

    fun fetch(lan: Lan, location: String): CastDevice? {
        val c = lan.open(location)
        val text = try {
            c.connectTimeout = 3000
            c.readTimeout = 4000
            c.setRequestProperty("User-Agent", Soap.USER_AGENT)
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
        return parse(text, location)
    }

    private class Dev { var name = ""; var maker = ""; var model = ""; var udn = "" }
    private class Svc(val type: String, val control: String, val owner: Dev?)

    fun parse(xml: String, location: String): CastDevice? {
        val stack = ArrayList<Dev>()
        val services = ArrayList<Svc>()
        var root: Dev? = null
        var urlBase: String? = null

        Soap.sax(xml, object : DefaultHandler() {
            private var svcType = ""
            private var svcControl = ""
            private val text = StringBuilder()

            override fun startElement(uri: String?, localName: String?, qName: String, attrs: Attributes?) {
                text.setLength(0)
                when (Soap.local(qName)) {
                    "device" -> { val d = Dev(); stack.add(d); if (root == null) root = d }
                    "service" -> { svcType = ""; svcControl = "" }
                }
            }

            override fun characters(ch: CharArray, start: Int, length: Int) {
                text.append(ch, start, length)
            }

            override fun endElement(uri: String?, localName: String?, qName: String) {
                val t = text.toString().trim()
                when (Soap.local(qName)) {
                    "friendlyName" -> stack.lastOrNull()?.name = t
                    "manufacturer" -> stack.lastOrNull()?.maker = t
                    "modelName" -> stack.lastOrNull()?.model = t
                    "UDN" -> stack.lastOrNull()?.udn = t
                    "URLBase" -> urlBase = t
                    "serviceType" -> svcType = t
                    "controlURL" -> svcControl = t
                    "service" -> services.add(Svc(svcType, svcControl, stack.lastOrNull()))
                    "device" -> stack.removeLastOrNull()
                }
                text.setLength(0)
            }
        })

        val avt = services.firstOrNull { it.type.contains("AVTransport", ignoreCase = true) && it.control.isNotBlank() }
            ?: return null   // not a media renderer
        val owner = avt.owner ?: root
        fun sibling(name: String) = services.firstOrNull {
            it.type.contains(name, ignoreCase = true) && it.control.isNotBlank() && it.owner === avt.owner
        } ?: services.firstOrNull { it.type.contains(name, ignoreCase = true) && it.control.isNotBlank() }

        val base = urlBase?.takeIf { it.isNotBlank() } ?: location
        fun abs(u: String) = runCatching { URL(URL(base), u).toString() }.getOrDefault(u)

        val host = runCatching { URL(location).host }.getOrDefault("")
        val rc = sibling("RenderingControl")
        val cm = sibling("ConnectionManager")
        val name = owner?.name?.ifBlank { null } ?: root?.name?.ifBlank { null } ?: host
        val model = owner?.model?.ifBlank { null } ?: owner?.maker?.ifBlank { null } ?: "Media renderer"
        val udn = owner?.udn?.ifBlank { null } ?: root?.udn?.ifBlank { null } ?: location

        return CastDevice(
            udn = udn,
            name = name,
            model = model,
            kind = kindOf("$name $model ${owner?.maker.orEmpty()}"),
            host = host,
            location = location,
            avtUrl = abs(avt.control),
            avtType = avt.type,
            rcUrl = rc?.let { abs(it.control) },
            rcType = rc?.type,
            cmUrl = cm?.let { abs(it.control) },
            cmType = cm?.type,
        )
    }

    private val tvWords = Regex("\\b(tv|xbox|bravia|webos|roku|chromecast|television)\\b")
    private val pcWords = Regex("\\b(kodi|pc|windows|vlc|foobar2000|desktop|laptop|mpc|jriver|linux|mac)\\b")

    fun kindOf(text: String): DeviceKind {
        val s = text.lowercase()
        return when {
            tvWords.containsMatchIn(s) -> DeviceKind.TV
            pcWords.containsMatchIn(s) -> DeviceKind.PC
            else -> DeviceKind.SPEAKER
        }
    }
}
