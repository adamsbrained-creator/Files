package ix.app.files.ui.home

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import ix.app.files.R
import ix.app.files.ui.theme.IxColors

/**
 * Asks for a name. Used for Rename and New folder.
 * The part before the last dot starts highlighted, so typing replaces the name and keeps the extension.
 */
@Composable
fun NameDialog(
    title: String,
    initialName: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val dot = initialName.lastIndexOf('.')
    val baseLength = if (dot > 0) dot else initialName.length
    var value by remember { mutableStateOf(TextFieldValue(initialName, TextRange(0, baseLength))) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (e: Exception) {
            // The field was not ready yet. The user can still tap it.
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focus),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = IxColors.TextPrimary,
                    unfocusedTextColor = IxColors.TextPrimary,
                    cursorColor = IxColors.TextPrimary,
                    focusedBorderColor = IxColors.TextSecondary,
                    unfocusedBorderColor = IxColors.Outline,
                ),
            )
        },
        confirmButton = {
            TextButton(
                enabled = value.text.isNotBlank(),
                onClick = { onConfirm(value.text) },
            ) { Text(confirmLabel, color = IxColors.TextPrimary) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
            }
        },
    )
}
