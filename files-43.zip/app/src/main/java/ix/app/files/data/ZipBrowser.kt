package ix.app.files.data

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

/** Reads the table of contents of a zip (or 7z, rar, tar and the like) so it can be browsed without unpacking it. Call off the main thread. */
object ZipBrowser {

    /** One line of the zip. [path] has no leading or trailing slash, [rawName] is the name as stored. */
    class Entry(
        val path: String,
        val rawName: String,
        val isDirectory: Boolean,
        val size: Long,
        val modifiedMillis: Long,
    )

    /** What one folder inside the zip holds. Paths are the inner paths, such as "docs/2024". */
    class Contents(val folders: List<FolderItem>, val files: List<FileItem>)

    /** Every entry of [zip], or null when the file can not be read as a zip. */
    fun read(zip: File): List<Entry>? {
        val format = ArchiveFormat.of(zip.name) ?: ArchiveFormat.Zip
        if (format != ArchiveFormat.Zip) return ArchiveReaders.read(format, zip)
        return try {
            ZipFile(zip).use { file ->
                val result = ArrayList<Entry>()
                val all = file.entries()
                while (all.hasMoreElements()) {
                    val entry = all.nextElement()
                    val path = entry.name.trim('/')
                    if (path.isEmpty()) continue
                    // Names that try to climb out of the zip are not shown (they are never unpacked either).
                    if (path.split('/').any { it == ".." }) continue
                    result.add(
                        Entry(
                            path = path,
                            rawName = entry.name,
                            isDirectory = entry.isDirectory,
                            size = entry.size.coerceAtLeast(0L),
                            modifiedMillis = entry.time.coerceAtLeast(0L),
                        ),
                    )
                }
                result
            }
        } catch (e: Exception) {
            null
        }
    }

    /** The folders and files directly inside [inner] ("" is the top of the zip), each sorted by name. */
    fun contents(entries: List<Entry>, inner: String): Contents {
        val prefix = if (inner.isEmpty()) "" else "$inner/"
        val folderChildren = LinkedHashMap<String, HashSet<String>>()
        val folderTimes = HashMap<String, Long>()
        val files = ArrayList<FileItem>()

        for (entry in entries) {
            if (!entry.path.startsWith(prefix)) continue
            val rest = entry.path.substring(prefix.length)
            if (rest.isEmpty()) continue
            val slash = rest.indexOf('/')
            if (slash < 0) {
                if (entry.isDirectory) {
                    folderChildren.getOrPut(rest) { HashSet() }
                    folderTimes[rest] = maxOf(folderTimes[rest] ?: 0L, entry.modifiedMillis)
                } else {
                    files.add(fileItemOf(entry, rest))
                }
            } else {
                // Something deeper: its first folder is a child here, even if the zip has no line for that folder.
                val first = rest.substring(0, slash)
                val below = rest.substring(slash + 1)
                folderChildren.getOrPut(first) { HashSet() }.add(below.substringBefore('/'))
                folderTimes[first] = maxOf(folderTimes[first] ?: 0L, entry.modifiedMillis)
            }
        }

        val folders = folderChildren.map { (name, children) ->
            FolderItem(
                path = prefix + name,
                name = name,
                childCount = children.size,
                modifiedMillis = folderTimes[name] ?: 0L,
            )
        }
        return Contents(
            folders = folders.sortedBy { it.name.lowercase() },
            files = files.sortedBy { it.name.lowercase() },
        )
    }

    /**
     * Unpacks the one [entry] into [destDir] and returns the new file, or null on failure.
     * Only the last part of the name is used, so nothing can land outside [destDir].
     */
    fun extractEntry(zip: File, entry: Entry, destDir: File): File? {
        val name = File(entry.path).name
        if (name.isEmpty() || name == "." || name == "..") return null
        val format = ArchiveFormat.of(zip.name) ?: ArchiveFormat.Zip
        if (format != ArchiveFormat.Zip) return ArchiveReaders.extractEntry(format, zip, entry, destDir)
        return try {
            ZipFile(zip).use { file ->
                val zipEntry = file.getEntry(entry.rawName)
                if (zipEntry == null) {
                    null
                } else {
                    destDir.mkdirs()
                    val out = File(destDir, name)
                    file.getInputStream(zipEntry).use { input ->
                        FileOutputStream(out).use { output -> input.copyTo(output) }
                    }
                    out
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fileItemOf(entry: Entry, fileName: String): FileItem {
        val dot = fileName.lastIndexOf('.')
        val name = if (dot > 0) fileName.substring(0, dot) else fileName
        val extension = if (dot > 0 && dot < fileName.length - 1) fileName.substring(dot + 1).lowercase() else ""
        return FileItem(
            path = entry.path,
            name = name,
            extension = extension,
            sizeBytes = entry.size,
            modifiedMillis = entry.modifiedMillis,
            // Other, so no preview is attempted for something that is not a real file on disk.
            kind = FileKind.Other,
        )
    }
}
