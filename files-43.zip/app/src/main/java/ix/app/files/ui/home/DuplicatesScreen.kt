package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.DuplicateGroup
import ix.app.files.data.FileItem
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat

/**
 * Files that exist more than once, one group after another, the biggest waste first.
 * "Select extras" ticks every copy except the oldest of each group; the usual selection bar then
 * offers Delete. Rows can also be ticked by hand.
 */
@Composable
fun DuplicatesScreen(
    groups: List<DuplicateGroup>,
    loading: Boolean,
    scanning: Boolean,
    rootPath: String,
    favorites: Set<String>,
    selection: Selection,
    onBack: () -> Unit,
    onSelectExtras: () -> Unit,
    onFileClick: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)
    val freeable = groups.sumOf { it.extraBytes }

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.dup_title),
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    Text(
                        text = if (loading || groups.isEmpty()) {
                            ""
                        } else {
                            context.getString(R.string.dup_summary, groups.size, formatFileSize(freeable))
                        },
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
                if (!loading && groups.isNotEmpty()) {
                    Box(
                        Modifier
                            .height(40.dp)
                            .clip(CircleShape)
                            .background(IxColors.Button)
                            .clickable(role = Role.Button, onClick = onSelectExtras)
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = stringResource(R.string.dup_select_extras),
                            color = IxColors.TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }

            if (scanning && !loading) {
                Text(
                    text = stringResource(R.string.dup_scanning_note),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }

            when {
                loading -> DuplicatesNote(stringResource(R.string.dup_loading))

                groups.isEmpty() -> DuplicatesNote(stringResource(R.string.dup_empty))

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = bottomInset + 96.dp),
                ) {
                    for (group in groups) {
                        item(key = "h:" + group.files.first().path) {
                            GroupHeader(group)
                        }
                        items(group.files, key = { "f:" + it.path }) { file ->
                            FileRow(
                                file = file,
                                selection = selection,
                                favorite = file.path in favorites,
                                onOpen = { onFileClick(file) },
                                hint = duplicateLocationOf(file.path, rootPath, rootLabel),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** "IMG_2041.jpg" on top, "3 copies · 4.2 MB each" under it. */
@Composable
private fun GroupHeader(group: DuplicateGroup) {
    val context = LocalContext.current
    val first = group.files.first()
    val fileName = if (first.extension.isEmpty()) first.name else first.name + "." + first.extension
    val copies = context.resources.getQuantityString(
        R.plurals.dup_copies,
        group.files.size,
        NumberFormat.getIntegerInstance().format(group.files.size),
    )
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 2.dp),
    ) {
        Text(
            text = fileName,
            color = IxColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = context.getString(R.string.dup_group_meta, copies, formatFileSize(group.size)),
            color = IxColors.Accent,
            fontSize = 12.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun DuplicatesNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}

/** The folder a file sits in, written from the top of storage: "DCIM/Camera". */
private fun duplicateLocationOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}
