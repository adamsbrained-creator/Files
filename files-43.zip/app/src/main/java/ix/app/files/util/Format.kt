package ix.app.files.util

import java.util.Locale

private val units = arrayOf("B", "KB", "MB", "GB", "TB")

/** "820 KB", "1.1 MB", "148 MB". Decimal units, same as the system uses. */
fun formatFileSize(bytes: Long, locale: Locale = Locale.getDefault()): String {
    var value = bytes.coerceAtLeast(0L).toDouble()
    var unit = 0
    while (value >= 1000 && unit < units.lastIndex) {
        value /= 1000
        unit++
    }
    val text = when {
        unit == 0 || value >= 100 -> String.format(locale, "%.0f", value)
        else -> String.format(locale, "%.1f", value)
    }
    return "$text ${units[unit]}"
}

/** Storage totals for the header pill: "153 GB", "2 TB", "1.5 TB". */
fun formatStorage(bytes: Long, locale: Locale = Locale.getDefault()): String =
    if (bytes >= 1_000_000_000_000L) {
        val tb = bytes / 1_000_000_000_000.0
        val text = if (tb % 1.0 == 0.0) String.format(locale, "%.0f", tb) else String.format(locale, "%.1f", tb)
        "$text TB"
    } else {
        String.format(locale, "%.0f GB", bytes / 1_000_000_000.0)
    }
