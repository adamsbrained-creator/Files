package ix.app.files.data

import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/** The fingerprints of one file, as lowercase hex. */
class Checksums(val md5: String, val sha1: String, val sha256: String) {

    companion object {
        private const val BUFFER = 256 * 1024

        /**
         * Reads [file] once and returns its MD5, SHA-1 and SHA-256. A Private file is unlocked on the way, so
         * the numbers are those of the real content. [control] is checked between chunks (it throws
         * [JobStopped] once cancelled) and gets the bytes read so far, for a progress bar. Call off the main thread.
         */
        fun of(
            file: File,
            control: JobControl? = null,
            open: (File) -> InputStream = { Vault.openRead(it) },
        ): Checksums {
            val md5 = MessageDigest.getInstance("MD5")
            val sha1 = MessageDigest.getInstance("SHA-1")
            val sha256 = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(BUFFER)
            open(file).use { input ->
                while (true) {
                    control?.check()
                    val n = input.read(buffer)
                    if (n < 0) break
                    md5.update(buffer, 0, n)
                    sha1.update(buffer, 0, n)
                    sha256.update(buffer, 0, n)
                    control?.add(n.toLong())
                }
            }
            return Checksums(hex(md5.digest()), hex(sha1.digest()), hex(sha256.digest()))
        }

        private fun hex(bytes: ByteArray): String {
            val out = StringBuilder(bytes.size * 2)
            for (b in bytes) {
                val v = b.toInt() and 0xff
                out.append("0123456789abcdef"[v shr 4]).append("0123456789abcdef"[v and 15])
            }
            return out.toString()
        }
    }
}
