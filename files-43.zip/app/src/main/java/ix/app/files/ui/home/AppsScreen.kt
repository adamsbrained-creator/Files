package ix.app.files.ui.home

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.AppEntry
import ix.app.files.data.AppSort
import ix.app.files.data.AppsEngine
import ix.app.files.ui.components.AppIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.text.NumberFormat

/**
 * Installed apps with the size of their apk files. Tap rows to tick them. Ticked apps can be backed up
 * (their apk files are copied to Download/App backups); a single app can also be opened, looked at in
 * the system's app info, or uninstalled by the system.
 */
@Composable
fun AppsScreen(
    apps: List<AppEntry>,
    loading: Boolean,
    onBack: () -> Unit,
    onBackup: (List<AppEntry>) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val number = NumberFormat.getIntegerInstance()
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(AppSort.Name) }
    var showSystem by remember { mutableStateOf(false) }
    // Ticks start again whenever the list is read anew, for instance after an app was uninstalled.
    var picked by remember(apps) { mutableStateOf(setOf<String>()) }
    var confirmUninstall by remember { mutableStateOf<AppEntry?>(null) }

    val shown = remember(apps, sort, showSystem, query) { AppsEngine.view(apps, sort, showSystem, query) }
    val chosen = shown.filter { it.packageName in picked }

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.apps_title),
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    Text(
                        text = if (loading || shown.isEmpty()) {
                            ""
                        } else {
                            context.getString(
                                R.string.file_meta,
                                context.resources.getQuantityString(
                                    R.plurals.apps_count,
                                    shown.size,
                                    number.format(shown.size),
                                ),
                                formatFileSize(shown.sumOf { it.bytes }),
                            )
                        },
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
            }

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.apps_search), fontSize = 14.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = IxColors.TextPrimary,
                    unfocusedTextColor = IxColors.TextPrimary,
                    cursorColor = IxColors.TextPrimary,
                    focusedBorderColor = IxColors.TextSecondary,
                    unfocusedBorderColor = IxColors.Outline,
                    focusedPlaceholderColor = IxColors.TextSecondary,
                    unfocusedPlaceholderColor = IxColors.TextSecondary,
                ),
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AppChip(R.string.apps_sort_name, sort == AppSort.Name) { sort = AppSort.Name }
                AppChip(R.string.apps_sort_size, sort == AppSort.Size) { sort = AppSort.Size }
                AppChip(R.string.apps_sort_updated, sort == AppSort.Updated) { sort = AppSort.Updated }
                AppChip(R.string.apps_show_system, showSystem) { showSystem = !showSystem }
            }

            when {
                loading -> AppsNote(stringResource(R.string.apps_loading))

                shown.isEmpty() -> AppsNote(stringResource(R.string.apps_empty))

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = bottomInset + 96.dp),
                ) {
                    items(shown, key = { it.packageName }) { app ->
                        AppRow(
                            app = app,
                            picked = app.packageName in picked,
                            onToggle = {
                                picked = if (app.packageName in picked) picked - app.packageName else picked + app.packageName
                            },
                        )
                    }
                }
            }
        }

        if (chosen.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = bottomInset + 16.dp)
                    .clip(CircleShape)
                    .background(IxColors.Sheet)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val single = chosen.singleOrNull()
                if (single == null) {
                    AppButton(
                        stringResource(if (chosen.size == shown.size) R.string.cleaner_deselect else R.string.cleaner_select),
                    ) {
                        picked = if (chosen.size == shown.size) emptySet() else shown.map { it.packageName }.toSet()
                    }
                } else {
                    AppButton(stringResource(R.string.apps_open)) { launchApp(context, single.packageName) }
                    AppButton(stringResource(R.string.apps_info)) { openAppInfo(context, single.packageName) }
                }
                AppButton(stringResource(R.string.apps_backup)) { onBackup(chosen) }
                if (single != null && !single.isSystem) {
                    AppButton(stringResource(R.string.apps_uninstall), danger = true) { confirmUninstall = single }
                }
            }
        }
    }

    val asking = confirmUninstall
    if (asking != null) {
        AlertDialog(
            onDismissRequest = { confirmUninstall = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.apps_uninstall)) },
            text = { Text(context.getString(R.string.apps_uninstall_ask, asking.label)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmUninstall = null
                    uninstallApp(context, asking.packageName)
                }) { Text(stringResource(R.string.apps_uninstall), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmUninstall = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

/** Icon, name, "version · size", "updated when", and a tick. */
@Composable
private fun AppRow(app: AppEntry, picked: Boolean, onToggle: () -> Unit) {
    val context = LocalContext.current
    val updated = modifiedLabel(app.updatedAt)
    val meta = context.getString(
        R.string.file_meta,
        app.versionName.ifEmpty { app.packageName },
        formatFileSize(app.bytes),
    )
    Row(
        Modifier
            .fillMaxWidth()
            .height(66.dp)
            .background(if (picked) IxColors.Chip else Color.Transparent)
            .clickable(role = Role.Button, onClick = onToggle)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        AppIcon(app.packageName, app.updatedAt, 40.dp)
        Column(Modifier.weight(1f)) {
            Text(
                text = app.label,
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = meta,
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp),
            )
            Text(
                text = context.getString(R.string.apps_updated, updated),
                color = IxColors.TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        SelectMark(picked)
    }
}

@Composable
private fun AppButton(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .height(36.dp)
            .clip(CircleShape)
            .background(IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (danger) IxColors.Danger else IxColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
        )
    }
}

@Composable
private fun AppChip(label: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(32.dp)
            .clip(CircleShape)
            .background(if (selected) IxColors.Accent else IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = stringResource(label),
            color = if (selected) IxColors.Background else IxColors.TextPrimary,
            fontSize = 13.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun AppsNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}

/** Starts the app, if it has something to start (many system services have not). */
private fun launchApp(context: Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
    }
}

/** The system's own page about the app: storage, permissions, force stop. */
private fun openAppInfo(context: Context, packageName: String) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
    }
}

/** Hands the uninstall to the system, which asks the person once more. */
private fun uninstallApp(context: Context, packageName: String) {
    val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName"))
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, R.string.apps_cannot_open, Toast.LENGTH_SHORT).show()
    }
}
