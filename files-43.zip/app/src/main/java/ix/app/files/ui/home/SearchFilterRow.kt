package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import ix.app.files.data.SAVED_SEARCH_NAME_MAX
import ix.app.files.data.SavedSearch
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.R
import ix.app.files.data.DateBand
import ix.app.files.data.FileKind
import ix.app.files.data.SearchFilter
import ix.app.files.data.SizeBand
import ix.app.files.ui.theme.IxColors

/** Which of the three chips has its list of choices open. */
private enum class FilterPick { None, Type, Size, Date, Saved, Save }

/**
 * Three chips under the search field: Type, Size and Date. A chip shows its name until a choice is made,
 * then the choice. Tapping one opens a short list of choices.
 */
@Composable
fun SearchFilterRow(
    filter: SearchFilter,
    onChange: (SearchFilter) -> Unit,
    saved: List<SavedSearch>,
    canSave: Boolean,
    onSave: (String) -> Unit,
    onApply: (SavedSearch) -> Unit,
    onDelete: (String) -> Unit,
    suggestedName: String,
    modifier: Modifier = Modifier,
) {
    var open by remember { mutableStateOf(FilterPick.None) }
    val typeLabel = filter.kind?.let { stringResource(kindLabel(it)) }
    val sizeLabel = if (filter.size == SizeBand.Any) null else stringResource(sizeLabel(filter.size))
    val dateLabel = if (filter.date == DateBand.Any) null else stringResource(dateLabel(filter.date))

    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (saved.isNotEmpty()) {
            FilterChip(stringResource(R.string.saved_searches), false) { open = FilterPick.Saved }
        }
        FilterChip(typeLabel ?: stringResource(R.string.filter_type), typeLabel != null) { open = FilterPick.Type }
        FilterChip(sizeLabel ?: stringResource(R.string.filter_size), sizeLabel != null) { open = FilterPick.Size }
        FilterChip(dateLabel ?: stringResource(R.string.filter_date), dateLabel != null) { open = FilterPick.Date }
        if (canSave) {
            FilterChip(stringResource(R.string.save_search), false) { open = FilterPick.Save }
        }
    }

    when (open) {
        FilterPick.Type -> {
            val kinds = listOf(
                FileKind.Image, FileKind.Video, FileKind.Audio, FileKind.Document, FileKind.App, FileKind.Other,
            )
            PickDialog(
                title = stringResource(R.string.filter_type),
                labels = listOf(stringResource(R.string.filter_any)) + kinds.map { stringResource(kindLabel(it)) },
                selected = if (filter.kind == null) 0 else kinds.indexOf(filter.kind) + 1,
                onPick = { index ->
                    onChange(filter.copy(kind = if (index == 0) null else kinds[index - 1]))
                    open = FilterPick.None
                },
                onDismiss = { open = FilterPick.None },
            )
        }

        FilterPick.Size -> {
            val bands = listOf(SizeBand.Any, SizeBand.Small, SizeBand.Medium, SizeBand.Large)
            PickDialog(
                title = stringResource(R.string.filter_size),
                labels = bands.map { stringResource(sizeLabel(it)) },
                selected = bands.indexOf(filter.size),
                onPick = { index ->
                    onChange(filter.copy(size = bands[index]))
                    open = FilterPick.None
                },
                onDismiss = { open = FilterPick.None },
            )
        }

        FilterPick.Date -> {
            val bands = listOf(DateBand.Any, DateBand.Day, DateBand.Week, DateBand.Month, DateBand.Year)
            PickDialog(
                title = stringResource(R.string.filter_date),
                labels = bands.map { stringResource(dateLabel(it)) },
                selected = bands.indexOf(filter.date),
                onPick = { index ->
                    onChange(filter.copy(date = bands[index]))
                    open = FilterPick.None
                },
                onDismiss = { open = FilterPick.None },
            )
        }

        FilterPick.Saved -> SavedSearchesDialog(
            saved = saved,
            onApply = {
                onApply(it)
                open = FilterPick.None
            },
            onDelete = onDelete,
            onDismiss = { open = FilterPick.None },
        )

        FilterPick.Save -> NameDialog(
            title = stringResource(R.string.save_search_title),
            initialName = suggestedName.take(SAVED_SEARCH_NAME_MAX),
            confirmLabel = stringResource(R.string.save_search_confirm),
            onConfirm = { name ->
                open = FilterPick.None
                onSave(name.take(SAVED_SEARCH_NAME_MAX))
            },
            onDismiss = { open = FilterPick.None },
        )

        FilterPick.None -> Unit
    }
}

private fun kindLabel(kind: FileKind): Int = when (kind) {
    FileKind.Image -> R.string.filter_kind_images
    FileKind.Video -> R.string.filter_kind_videos
    FileKind.Audio -> R.string.filter_kind_audio
    FileKind.Document -> R.string.filter_kind_documents
    FileKind.App -> R.string.filter_kind_apps
    FileKind.Other -> R.string.filter_kind_other
}

private fun sizeLabel(band: SizeBand): Int = when (band) {
    SizeBand.Any -> R.string.filter_any
    SizeBand.Small -> R.string.filter_size_small
    SizeBand.Medium -> R.string.filter_size_medium
    SizeBand.Large -> R.string.filter_size_large
}

private fun dateLabel(band: DateBand): Int = when (band) {
    DateBand.Any -> R.string.filter_any
    DateBand.Day -> R.string.filter_date_day
    DateBand.Week -> R.string.filter_date_week
    DateBand.Month -> R.string.filter_date_month
    DateBand.Year -> R.string.filter_date_year
}

@Composable
private fun FilterChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(34.dp)
            .clip(CircleShape)
            .background(if (active) IxColors.Button else IxColors.Field)
            .border(1.dp, if (active) IxColors.TextSecondary else IxColors.Outline, CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (active) IxColors.TextPrimary else IxColors.TextSecondary,
            fontSize = 13.sp,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}

/** The kept searches. Tap one to run it, tap the bin to forget it. */
@Composable
private fun SavedSearchesDialog(
    saved: List<SavedSearch>,
    onApply: (SavedSearch) -> Unit,
    onDelete: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    val deleteDescription = stringResource(R.string.saved_search_delete)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = stringResource(R.string.saved_searches),
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 6.dp),
            )
            if (saved.isEmpty()) {
                // The last one was just deleted.
                LaunchedEffect(Unit) { onDismiss() }
            }
            Column(
                Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                saved.forEach { item ->
                    val summary = summaryOf(item)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(IxColors.Field)
                            .clickable(role = Role.Button) { onApply(item) }
                            .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = item.name,
                                color = IxColors.TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (summary.isNotEmpty()) {
                                Text(
                                    text = summary,
                                    color = IxColors.TextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .clickable(role = Role.Button) { onDelete(item.id) }
                                .semantics { contentDescription = deleteDescription },
                            contentAlignment = Alignment.Center,
                        ) {
                            PathIcon(Glyphs.Trash, tint = IxColors.TextSecondary, size = 20.dp, strokeWidth = 1.8f)
                        }
                    }
                }
            }
        }
    }
}

/** "“report” · Documents · Last 7 days": what a saved search looks for, in one line. */
@Composable
private fun summaryOf(saved: SavedSearch): String {
    val parts = buildList {
        if (saved.query.isNotBlank()) add("“${saved.query}”")
        saved.filter.kind?.let { add(stringResource(kindLabel(it))) }
        if (saved.filter.size != SizeBand.Any) add(stringResource(sizeLabel(saved.filter.size)))
        if (saved.filter.date != DateBand.Any) add(stringResource(dateLabel(saved.filter.date)))
    }
    return parts.joinToString(" · ")
}

/** A short list of choices in the same card style as the menu. Tap one to pick it. */
@Composable
private fun PickDialog(
    title: String,
    labels: List<String>,
    selected: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = title,
                color = IxColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 6.dp),
            )
            labels.forEachIndexed { index, label ->
                val chosen = index == selected
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (chosen) IxColors.Button else IxColors.Field)
                        .clickable(role = Role.RadioButton) { onPick(index) }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Text(
                        text = label,
                        color = if (chosen) IxColors.TextPrimary else IxColors.TextSecondary,
                        fontSize = 15.sp,
                        fontWeight = if (chosen) FontWeight.SemiBold else FontWeight.Medium,
                    )
                }
            }
        }
    }
}
