package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.TrashItem
import ix.app.files.ui.components.FileIcon
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat

/** How long deleted things stay in the Trash, in days. Zero means they are removed as soon as Undo is gone. */
val TrashKeepChoices = listOf(0, 7, 30)

private const val DAY_MILLIS = 24L * 60 * 60 * 1000

/**
 * Everything that was deleted and is still waiting. Tap rows to tick them, then put them back or delete
 * them for good. "Empty" clears all. The chips under the title set how long things are kept.
 */
@Composable
fun TrashScreen(
    trashItems: List<TrashItem>,
    loading: Boolean,
    keepDays: Int,
    rootPath: String,
    onBack: () -> Unit,
    onRestore: (Set<String>) -> Unit,
    onDelete: (Set<String>) -> Unit,
    onEmpty: () -> Unit,
    onKeepDays: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val number = NumberFormat.getIntegerInstance()
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)

    // Ticks start again whenever the list is made anew, for instance after something was restored.
    var picked by remember(trashItems) { mutableStateOf(setOf<String>()) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pendingKeep by remember { mutableStateOf<Int?>(null) }

    val totalBytes = trashItems.sumOf { it.bytes }

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.trash_title),
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    Text(
                        text = if (loading || trashItems.isEmpty()) {
                            ""
                        } else {
                            context.getString(
                                R.string.file_meta,
                                context.resources.getQuantityString(
                                    R.plurals.trash_items,
                                    trashItems.size,
                                    number.format(trashItems.size),
                                ),
                                formatFileSize(totalBytes),
                            )
                        },
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
                if (trashItems.isNotEmpty()) {
                    TrashButton(stringResource(R.string.trash_empty)) { confirmEmpty = true }
                }
            }

            Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                Text(
                    text = stringResource(R.string.trash_keep_label),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                )
                Row(
                    Modifier.padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (days in TrashKeepChoices) {
                        KeepChip(
                            label = if (days == 0) {
                                stringResource(R.string.trash_keep_off)
                            } else {
                                context.resources.getQuantityString(R.plurals.trash_keep_days, days, days)
                            },
                            selected = days == keepDays,
                        ) {
                            if (days == keepDays) return@KeepChip
                            // Keeping for a shorter time removes what is already older: ask before that happens.
                            val now = System.currentTimeMillis()
                            val wouldGo = trashItems.any { now - it.deletedAt >= days * DAY_MILLIS }
                            if (wouldGo) pendingKeep = days else onKeepDays(days)
                        }
                    }
                }
            }

            when {
                loading -> TrashNote(stringResource(R.string.trash_loading))

                trashItems.isEmpty() -> TrashNote(stringResource(R.string.trash_empty_note))

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 8.dp, bottom = bottomInset + 96.dp),
                ) {
                    items(trashItems, key = { it.storedPath }) { item ->
                        TrashRow(
                            item = item,
                            picked = item.storedPath in picked,
                            from = trashFromLabel(item.originalPath, rootPath, rootLabel),
                            onToggle = {
                                picked = if (item.storedPath in picked) picked - item.storedPath else picked + item.storedPath
                            },
                        )
                    }
                }
            }
        }

        if (picked.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = bottomInset + 16.dp)
                    .clip(CircleShape)
                    .background(IxColors.Sheet)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TrashButton(
                    label = stringResource(
                        if (picked.size == trashItems.size) R.string.cleaner_deselect else R.string.cleaner_select,
                    ),
                ) {
                    picked = if (picked.size == trashItems.size) emptySet() else trashItems.map { it.storedPath }.toSet()
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TrashButton(stringResource(R.string.trash_restore)) { onRestore(picked) }
                    TrashButton(stringResource(R.string.trash_delete_forever), danger = true) { confirmDelete = true }
                }
            }
        }
    }

    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.trash_empty_title)) },
            text = { Text(stringResource(R.string.trash_empty_ask)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmEmpty = false
                    onEmpty()
                }) { Text(stringResource(R.string.trash_empty), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmEmpty = false }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.trash_delete_forever)) },
            text = {
                Text(
                    context.resources.getQuantityString(
                        R.plurals.trash_delete_ask,
                        picked.size,
                        number.format(picked.size),
                    ),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(picked)
                }) { Text(stringResource(R.string.trash_delete_forever), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }

    val shorter = pendingKeep
    if (shorter != null) {
        AlertDialog(
            onDismissRequest = { pendingKeep = null },
            containerColor = IxColors.Sheet,
            titleContentColor = IxColors.TextPrimary,
            textContentColor = IxColors.TextSecondary,
            title = { Text(stringResource(R.string.trash_keep_title)) },
            text = {
                Text(
                    if (shorter == 0) {
                        stringResource(R.string.trash_keep_ask_off)
                    } else {
                        context.resources.getQuantityString(R.plurals.trash_keep_ask, shorter, shorter)
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingKeep = null
                    onKeepDays(shorter)
                }) { Text(stringResource(R.string.trash_keep_confirm), color = IxColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { pendingKeep = null }) {
                    Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
                }
            },
        )
    }
}

/** One deleted item: icon, name, "size · deleted when", where it came from, and a tick. */
@Composable
private fun TrashRow(item: TrashItem, picked: Boolean, from: String?, onToggle: () -> Unit) {
    val context = LocalContext.current
    val deleted = modifiedLabel(item.deletedAt)
    val meta = context.getString(
        R.string.file_meta,
        formatFileSize(item.bytes),
        context.getString(R.string.trash_deleted, deleted),
    )
    Row(
        Modifier
            .fillMaxWidth()
            .height(66.dp)
            .background(if (picked) IxColors.Chip else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(role = Role.Button, onClick = onToggle)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.size(width = 36.dp, height = 36.dp), contentAlignment = Alignment.Center) {
            if (item.isDirectory) {
                FolderIcon(emptyList(), Modifier.size(width = 34.dp, height = 28.dp))
            } else {
                FileIcon(File(item.name).extension.lowercase())
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                text = item.name,
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = meta,
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp),
            )
            if (from != null) {
                Text(
                    text = context.getString(R.string.trash_from, from),
                    color = IxColors.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        SelectMark(picked)
    }
}

@Composable
private fun TrashButton(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier
            .height(36.dp)
            .clip(CircleShape)
            .background(IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (danger) IxColors.Danger else IxColors.TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
        )
    }
}

@Composable
private fun KeepChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(32.dp)
            .clip(CircleShape)
            .background(if (selected) IxColors.Accent else IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) IxColors.Background else IxColors.TextPrimary,
            fontSize = 13.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun TrashNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}

/** The folder an item was deleted from, written from the top of storage: "Download/old". Null if unknown. */
private fun trashFromLabel(originalPath: String?, rootPath: String, rootLabel: String): String? {
    val parent = originalPath?.let { File(it).parent } ?: return null
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}
