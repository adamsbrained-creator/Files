package ix.app.files.cast

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * The one place the screens and the cast engine meet: which devices exist, what is playing where, the options.
 * The screens and the foreground service run in the same process, so plain flows work.
 */
object CastHub {

    const val LOCAL_NETWORK_PERMISSION = "android.permission.ACCESS_LOCAL_NETWORK"

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var lan: AndroidLan
    private lateinit var engine: CastEngine
    private var ready = false

    private val scanScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val devices = MutableStateFlow<List<CastDevice>>(emptyList())
    val scanning = MutableStateFlow(false)
    val settings = MutableStateFlow(CastSettings())
    val localNetworkGranted = MutableStateFlow(true)
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)

    /** Short notes for a toast: "Lost connection to Xbox" and the like. */
    val messages: SharedFlow<String> = _messages

    /** What is playing where. */
    val state: StateFlow<CastState> get() = engine.state

    val active: Boolean get() = ready && engine.state.value.phase != CastPhase.IDLE

    private var wifiLock: WifiManager.WifiLock? = null

    @Synchronized
    fun init(context: Context) {
        if (ready) { refreshPermission(); return }
        app = context.applicationContext
        prefs = app.getSharedPreferences("ixfiles_cast", Context.MODE_PRIVATE)
        lan = AndroidLan(app)
        CastLog.sink = { message -> log(message) }
        settings.value = CastSettings(
            checkFormats = prefs.getBoolean("checkFormats", false),
            plainStream = prefs.getBoolean("plainStream", false),
            volumeStep = prefs.getInt("volumeStep", 5).coerceIn(1, 25),
        )

        // The engine does all its thinking on one thread, so its fields need no locks.
        val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "ixfiles-cast").apply { isDaemon = true } }
        val handler = CoroutineExceptionHandler { _, e -> log("cast engine error: $e") }
        engine = CastEngine(
            lan = lan,
            scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher() + handler),
            settings = { settings.value },
            post = { _messages.tryEmit(it) },
            hooks = object : CastHooks {
                override fun onSessionStarted() = sessionStarted()
                override fun onSessionEnded() = sessionEnded()
            },
            durationOf = { file -> probeDuration(file) },
        )
        ready = true
        refreshPermission()
    }

    // ---- permission --------------------------------------------------------------------------

    /**
     * Android 17 blocks all traffic to and from the home network until the person allows
     * "local network access". Older versions do not have that permission.
     */
    fun refreshPermission() {
        if (!ready) return
        localNetworkGranted.value = Build.VERSION.SDK_INT < 37 ||
            ContextCompat.checkSelfPermission(app, LOCAL_NETWORK_PERMISSION) == PackageManager.PERMISSION_GRANTED
    }

    // ---- discovery ---------------------------------------------------------------------------

    private var scanJob: Job? = null
    private val knownLocations = ConcurrentHashMap.newKeySet<String>()

    fun startScan(clear: Boolean = false) {
        if (!ready || !localNetworkGranted.value) return
        if (scanJob?.isActive == true) return
        if (clear) {
            knownLocations.clear()
            devices.value = listOfNotNull(state.value.device)
        }
        scanJob = scanScope.launch {
            scanning.value = true
            // Without this lock many phones drop the multicast answers of the devices to save battery.
            val lock = runCatching {
                app.getSystemService(WifiManager::class.java)
                    .createMulticastLock("ixfiles-ssdp").apply { setReferenceCounted(false); acquire() }
            }.getOrNull()
            val me = this.coroutineContext[Job]
            try {
                log("scan started")
                repeat(3) {
                    Ssdp.search(lan, 3500, { me?.isActive != false }) { location ->
                        if (knownLocations.add(location)) scanScope.launch { fetch(location) }
                    }
                }
            } catch (e: Exception) {
                log("scan failed: $e")
            } finally {
                runCatching { lock?.release() }
                scanning.value = false
                log("scan finished, ${devices.value.size} device(s)")
            }
        }
    }

    private fun fetch(location: String) {
        val d = try {
            UpnpDescription.fetch(lan, location)
        } catch (e: Exception) {
            log("couldn't read $location: $e")
            knownLocations.remove(location)
            null
        } ?: return
        log("found ${d.name} (${d.model}) at ${d.host}")
        devices.update { list -> (list.filterNot { it.udn == d.udn } + d).sortedBy { it.name.lowercase() } }
    }

    // ---- options -----------------------------------------------------------------------------

    fun updateSettings(change: (CastSettings) -> CastSettings) {
        val next = change(settings.value)
        settings.value = next
        if (!ready) return
        prefs.edit()
            .putBoolean("checkFormats", next.checkFormats)
            .putBoolean("plainStream", next.plainStream)
            .putInt("volumeStep", next.volumeStep)
            .apply()
    }

    // ---- commands from the screens -----------------------------------------------------------

    /** Shows these files on [device]. They are played in order; the one at [startIndex] first. */
    fun cast(device: CastDevice, items: List<CastItem>, startIndex: Int = 0) {
        if (!ready) return
        engine.start(device, items, startIndex)
    }

    fun togglePlay() { if (ready) engine.togglePlay() }
    fun seekTo(ms: Long) { if (ready) engine.seekTo(ms) }
    fun skipBy(ms: Long) { if (ready) engine.skipBy(ms) }
    fun next() { if (ready) engine.next() }
    fun previous() { if (ready) engine.previous() }
    fun stepVolume(direction: Int) { if (ready) engine.stepVolume(direction) }
    fun stop() { if (ready) engine.stop() }

    fun post(message: String) { _messages.tryEmit(message) }

    // ---- keeping the phone awake while casting -----------------------------------------------

    private fun sessionStarted() {
        // A foreground service keeps the app (and the file server inside it) alive with the screen off.
        runCatching { ContextCompat.startForegroundService(app, Intent(app, CastService::class.java)) }
            .onFailure { log("couldn't start the cast service: $it") }
        runCatching {
            @Suppress("DEPRECATION")
            val mode = WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = app.getSystemService(WifiManager::class.java)
                .createWifiLock(mode, "ixfiles-cast").apply { setReferenceCounted(false); acquire() }
        }
    }

    private fun sessionEnded() {
        runCatching { wifiLock?.let { if (it.isHeld) it.release() } }
        wifiLock = null
        runCatching { app.stopService(Intent(app, CastService::class.java)) }
    }

    private fun probeDuration(file: File): Long = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(file.path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            r.release()
        }
    }.getOrDefault(0L)

    // ---- debug log (so problems on a real TV can be copied out of the app) -------------------

    private val logLines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun log(message: String) {
        Log.d("IxFilesCast", message)
        synchronized(logLines) {
            logLines.addLast("${clock.format(Date())}  $message")
            while (logLines.size > 300) logLines.removeFirst()
        }
    }

    fun logText(): String = synchronized(logLines) { logLines.joinToString("\n") }
}
