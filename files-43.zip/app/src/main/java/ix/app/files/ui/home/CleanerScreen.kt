package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.CleanGroup
import ix.app.files.data.CleanKind
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import ix.app.files.util.formatFileSize
import java.io.File
import java.text.NumberFormat

/**
 * Things that are very likely safe to clear, one group after another: installers, temporary and empty
 * files, empty folders, and big files nobody touched for months. Nothing is ticked for you. "Select all"
 * ticks one group; the usual selection bar then offers Delete, which can be undone.
 */
@Composable
fun CleanerScreen(
    groups: List<CleanGroup>,
    loading: Boolean,
    scanning: Boolean,
    rootPath: String,
    favorites: Set<String>,
    selection: Selection,
    onBack: () -> Unit,
    onToggleGroup: (List<String>) -> Unit,
    onFileClick: (FileItem) -> Unit,
    onFolderClick: (FolderItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val rootLabel = stringResource(R.string.browser_root)
    val clearable = groups.sumOf { it.bytes }

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.cleaner_title),
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                    val summary = when {
                        loading || groups.isEmpty() -> ""
                        clearable > 0L -> context.getString(R.string.cleaner_summary, formatFileSize(clearable))
                        else -> context.getString(R.string.cleaner_summary_folders)
                    }
                    Text(
                        text = summary,
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
            }

            if (scanning && !loading) {
                Text(
                    text = stringResource(R.string.cleaner_scanning_note),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }

            when {
                loading -> CleanerNote(stringResource(R.string.cleaner_loading))

                groups.isEmpty() -> CleanerNote(stringResource(R.string.cleaner_empty))

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = bottomInset + 96.dp),
                ) {
                    for (group in groups) {
                        val groupPaths = group.paths
                        item(key = "h:" + group.kind.name) {
                            CleanerHeader(
                                group = group,
                                allSelected = groupPaths.all { it in selection.paths },
                                onToggle = { onToggleGroup(groupPaths) },
                            )
                        }
                        items(group.folders, key = { "d:" + it.path }) { folder ->
                            FolderRow(
                                folder = folder,
                                selection = selection,
                                favorite = folder.path in favorites,
                                onOpen = { onFolderClick(folder) },
                                hint = cleanerLocationOf(folder.path, rootPath, rootLabel),
                            )
                        }
                        items(group.files, key = { "f:" + it.path }) { file ->
                            FileRow(
                                file = file,
                                selection = selection,
                                favorite = file.path in favorites,
                                onOpen = { onFileClick(file) },
                                hint = cleanerLocationOf(file.path, rootPath, rootLabel),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** "Installers" with its explanation, "12 files · 340 MB" under it, and the Select all button. */
@Composable
private fun CleanerHeader(group: CleanGroup, allSelected: Boolean, onToggle: () -> Unit) {
    val context = LocalContext.current
    val number = NumberFormat.getIntegerInstance()
    val title = when (group.kind) {
        CleanKind.Installers -> R.string.cleaner_installers
        CleanKind.Leftovers -> R.string.cleaner_leftovers
        CleanKind.EmptyFolders -> R.string.cleaner_empty_folders
        CleanKind.LargeOld -> R.string.cleaner_large_old
    }
    val hint = when (group.kind) {
        CleanKind.Installers -> R.string.cleaner_installers_hint
        CleanKind.Leftovers -> R.string.cleaner_leftovers_hint
        CleanKind.EmptyFolders -> R.string.cleaner_empty_folders_hint
        CleanKind.LargeOld -> R.string.cleaner_large_old_hint
    }
    val meta = if (group.kind == CleanKind.EmptyFolders) {
        context.resources.getQuantityString(
            R.plurals.cleaner_folders,
            group.folders.size,
            number.format(group.folders.size),
        )
    } else {
        context.getString(
            R.string.file_meta,
            context.resources.getQuantityString(
                R.plurals.details_files,
                group.files.size,
                number.format(group.files.size),
            ),
            formatFileSize(group.bytes),
        )
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            Modifier
                .weight(1f)
                .padding(end = 12.dp),
        ) {
            Text(
                text = context.getString(title),
                color = IxColors.TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = meta,
                color = IxColors.Accent,
                fontSize = 12.sp,
                maxLines = 1,
                modifier = Modifier.padding(top = 1.dp),
            )
            Text(
                text = context.getString(hint),
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 3.dp),
            )
        }
        Box(
            Modifier
                .height(36.dp)
                .clip(CircleShape)
                .background(IxColors.Button)
                .clickable(role = Role.Button, onClick = onToggle)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(if (allSelected) R.string.cleaner_deselect else R.string.cleaner_select),
                color = IxColors.TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun CleanerNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}

/** The folder a thing sits in, written from the top of storage: "Download/old". */
private fun cleanerLocationOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}
