package ix.app.files.data

import android.content.Context
import android.content.pm.ApplicationInfo
import java.io.File

/** Reads the list of installed apps from the system. Call off the main thread: it can take a second or two. */
object AppsLoader {

    fun load(context: Context): List<AppEntry> {
        val manager = context.packageManager
        val packages = try {
            manager.getInstalledPackages(0)
        } catch (e: Exception) {
            return emptyList()
        }
        val apps = ArrayList<AppEntry>(packages.size)
        for (info in packages) {
            val app = info.applicationInfo ?: continue
            val paths = ArrayList<String>()
            app.sourceDir?.let { paths.add(it) }
            app.splitSourceDirs?.let { paths.addAll(it) }
            if (paths.isEmpty()) continue
            val label = try {
                manager.getApplicationLabel(app).toString()
            } catch (e: Exception) {
                info.packageName
            }
            apps.add(
                AppEntry(
                    packageName = info.packageName,
                    label = label.ifBlank { info.packageName },
                    versionName = info.versionName.orEmpty(),
                    apkPaths = paths,
                    bytes = paths.sumOf { File(it).length() },
                    installedAt = info.firstInstallTime,
                    updatedAt = info.lastUpdateTime,
                    isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                ),
            )
        }
        return apps
    }
}
