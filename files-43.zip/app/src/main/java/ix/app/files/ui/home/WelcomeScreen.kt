package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.Glyphs
import kotlinx.coroutines.launch

// The welcome pages keep their own dark look in both themes, like the first screens of many apps.
private val WelcomeBackground = Color(0xFF0C0C0E)
private val WelcomeText = Color.White
private val WelcomeMuted = Color(0xFFB4B4BD)
private val WelcomeAccent = Color(0xFFFF6A2B)
private val WelcomeOnAccent = Color(0xFF0C0C0E)
private val WelcomeDotOff = Color(0xFF3A3A42)

/**
 * Two pages shown on the first start: a welcome, then what the app is for.
 * [onFinish] runs on Get started and on Skip.
 */
@Composable
fun WelcomeScreen(onFinish: () -> Unit) {
    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == 1

    BackHandler(enabled = pager.currentPage > 0) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    Box(Modifier.fillMaxSize().background(WelcomeBackground)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            if (page == 0) WelcomePage() else EverythingPage()
        }

        if (!last) {
            Text(
                text = stringResource(R.string.welcome_skip),
                color = WelcomeMuted,
                fontSize = 16.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(8.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .clickable(role = Role.Button, onClick = onFinish)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                for (index in 0 until 2) {
                    val active = pager.currentPage == index
                    Box(
                        Modifier
                            .height(8.dp)
                            .width(if (active) 22.dp else 8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (active) WelcomeAccent else WelcomeDotOff),
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(WelcomeAccent)
                    .clickable(role = Role.Button) {
                        if (last) onFinish() else scope.launch { pager.animateScrollToPage(1) }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = stringResource(if (last) R.string.welcome_start else R.string.welcome_next),
                    color = WelcomeOnAccent,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun WelcomePage() {
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF16231B), WelcomeBackground), endY = 1500f))
            .statusBarsPadding()
            .padding(start = 28.dp, end = 28.dp, top = 96.dp, bottom = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = stringResource(R.string.welcome_to),
            color = Color(0xFF9FB0A6),
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = stringResource(R.string.app_name),
            color = WelcomeText,
            fontSize = 64.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.welcome_tagline),
            color = WelcomeMuted,
            fontSize = 17.sp,
            lineHeight = 24.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(260.dp),
        )
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            WelcomeTile(stringResource(R.string.welcome_tile_photos), Color(0xFF4C8DFF), -6f)
            WelcomeTile(stringResource(R.string.welcome_tile_docs), Color(0xFFF5B83D), 4f)
            WelcomeTile(stringResource(R.string.welcome_tile_private), Color(0xFF8B6CFF), -3f)
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun WelcomeTile(label: String, accent: Color, tilt: Float) {
    Box(
        Modifier
            .rotate(tilt)
            .size(width = 92.dp, height = 100.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White.copy(alpha = 0.09f)),
    ) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(accent))
        Text(
            text = label,
            color = WelcomeText,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
        )
    }
}

@Composable
private fun EverythingPage() {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(start = 28.dp, end = 28.dp, top = 80.dp, bottom = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(width = 280.dp, height = 270.dp)) {
            FolderIcon(
                glyph = Glyphs.Folder,
                modifier = Modifier.align(Alignment.BottomCenter).size(width = 250.dp, height = 208.dp),
                tint = Color(0xFF4A9FC0),
            )
            FileTag("PDF", Color(0xFFC9241F), -12f, 20.dp, 22.dp)
            FileTag("DOC", Color(0xFF1F6BFF), 10f, 160.dp, 4.dp)
            FileTag("JPG", Color(0xFFC25A10), 4f, 104.dp, 74.dp)
        }
        Spacer(Modifier.weight(1f))
        Text(
            text = stringResource(R.string.welcome_title_two),
            color = WelcomeText,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.welcome_body_two),
            color = WelcomeMuted,
            fontSize = 16.sp,
            lineHeight = 23.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(300.dp),
        )
    }
}

/** A small paper sheet with a colored label, floating above the folder. */
@Composable
private fun FileTag(label: String, labelColor: Color, tilt: Float, x: Dp, y: Dp) {
    Box(
        Modifier
            .offset(x = x, y = y)
            .rotate(tilt)
            .size(width = 64.dp, height = 78.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF1F1F4))
            .padding(8.dp),
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(labelColor)
                .padding(horizontal = 5.dp, vertical = 2.dp),
        )
    }
}
