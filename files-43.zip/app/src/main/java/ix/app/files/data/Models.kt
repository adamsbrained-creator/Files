package ix.app.files.data

import androidx.compose.runtime.Immutable

enum class FileKind { Document, Image, Video, Audio, App, Other }

/** A file as the UI needs it. [name] has no extension, [extension] has no dot and is lowercase. */
data class FileItem(
    val path: String,
    val name: String,
    val extension: String,
    val sizeBytes: Long,
    val modifiedMillis: Long,
    val kind: FileKind,
)

/** A folder in the browser or the Favorites list. [childCount] is how many visible items it holds. */
data class FolderItem(
    val path: String,
    val name: String,
    val childCount: Int,
    val modifiedMillis: Long,
)

/** What one folder contains. A plain class on purpose, so state updates compare it by identity. */
@Immutable
class Listing(
    val folders: List<FolderItem>,
    val files: List<FileItem>,
    val failed: Boolean,
)

/** What a search found. [total] can be bigger than the lists, which are capped. */
@Immutable
class SearchResults(val folders: List<FolderItem>, val files: List<FileItem>, val total: Int) {
    companion object {
        val Empty = SearchResults(emptyList(), emptyList(), 0)
    }
}

/** How much room one kind of file takes. */
@Immutable
class KindSize(val kind: FileKind, val bytes: Long, val count: Int)

/** What the Storage screen shows, worked out from the scan. */
@Immutable
class StorageReport(
    /** Biggest kind first. */
    val byKind: List<KindSize>,
    /** Sum of every file the scan found. */
    val filesBytes: Long,
    val largest: List<FileItem>,
)

/** Items waiting to be pasted. [move] is true for Move and false for Copy. */
@Immutable
class Clip(val paths: List<String>, val move: Boolean)

/** What the Undo bar can take back. */
enum class UndoKind { Delete, Move, Copy }

/** Shown on the Undo bar: what happened, and to how many items. */
class UndoNotice(val kind: UndoKind, val count: Int)

enum class Category { Downloads, Images, Videos, Audio, Docs, Apps }

enum class HomeTab { All, Favorites, Private }

/** Which look the app uses. System follows the phone's dark mode setting. */
enum class ThemeMode { System, Light, Dark }

/** The three resting places of the Recent sheet. It starts hidden and appears on a swipe up. */
enum class SheetAnchor { Hidden, Collapsed, Expanded }

/**
 * Everything one scan found. This is a plain class, not a data class, on purpose:
 * it can hold tens of thousands of files, and comparing two of them by identity keeps state updates cheap.
 */
@Immutable
class ScanData(
    val byCategory: Map<Category, List<FileItem>>,
    val recent: List<FileItem>,
    /** Every visible file found, of any type. This is what search looks through. */
    val files: List<FileItem> = emptyList(),
    /** Every visible folder found. [FolderItem.childCount] is not filled in here. */
    val folders: List<FolderItem> = emptyList(),
) {
    companion object {
        val Empty = ScanData(emptyMap(), emptyList())
    }
}

enum class SortField(val defaultAscending: Boolean) {
    Modified(false),
    Name(true),
    Size(false),
    Type(true),
}

data class SortSpec(val field: SortField = SortField.Modified, val ascending: Boolean = false) {
    /** Tapping the active field flips the direction. Tapping another field uses that field's default. */
    fun select(newField: SortField): SortSpec =
        if (newField == field) copy(ascending = !ascending) else SortSpec(newField, newField.defaultAscending)
}

fun List<FileItem>.sortedBySpec(spec: SortSpec): List<FileItem> {
    val comparator: Comparator<FileItem> = when (spec.field) {
        SortField.Modified -> compareBy<FileItem> { it.modifiedMillis }
        SortField.Name -> Comparator<FileItem> { a, b -> String.CASE_INSENSITIVE_ORDER.compare(a.name, b.name) }
        SortField.Size -> compareBy<FileItem> { it.sizeBytes }
        SortField.Type -> compareBy<FileItem> { it.kind.ordinal }.thenBy { it.extension }
    }
    return sortedWith(if (spec.ascending) comparator else comparator.reversed())
}

/**
 * Folders sort by date when the list is sorted by Modified, and by name otherwise.
 * (Size and Type mean nothing for a folder, so they fall back to A to Z.)
 */
fun List<FolderItem>.sortedFoldersBySpec(spec: SortSpec): List<FolderItem> =
    when (spec.field) {
        SortField.Modified ->
            if (spec.ascending) sortedBy { it.modifiedMillis } else sortedByDescending { it.modifiedMillis }
        SortField.Name ->
            sortedWith(
                if (spec.ascending) {
                    Comparator<FolderItem> { a, b -> String.CASE_INSENSITIVE_ORDER.compare(a.name, b.name) }
                } else {
                    Comparator<FolderItem> { a, b -> String.CASE_INSENSITIVE_ORDER.compare(b.name, a.name) }
                },
            )
        else -> sortedWith(Comparator<FolderItem> { a, b -> String.CASE_INSENSITIVE_ORDER.compare(a.name, b.name) })
    }
