package ix.app.files.data

import androidx.compose.runtime.Immutable
import java.io.File
import java.io.IOException

/** One installed app, with what the Apps screen shows about it. */
@Immutable
class AppEntry(
    val packageName: String,
    val label: String,
    val versionName: String,
    /** The apk files of the app: the base one first, then the split ones if it has any. */
    val apkPaths: List<String>,
    /** Size of those apk files. What the app stores while running is not counted. */
    val bytes: Long,
    val installedAt: Long,
    val updatedAt: Long,
    val isSystem: Boolean,
)

enum class AppSort { Name, Size, Updated }

/** Sorting and filtering the list of apps. Pure, so it can run on every key press. */
object AppsEngine {

    /**
     * The apps to show: system apps only when [showSystem] is on, and only those whose name or package
     * contains [query] (blank means all). Name sorts A to Z; size and update time sort biggest and newest first.
     */
    fun view(apps: List<AppEntry>, sort: AppSort, showSystem: Boolean, query: String): List<AppEntry> {
        val needle = query.trim().lowercase()
        val kept = apps.filter { app ->
            (showSystem || !app.isSystem) &&
                (needle.isEmpty() || app.label.lowercase().contains(needle) || app.packageName.lowercase().contains(needle))
        }
        return when (sort) {
            AppSort.Name -> kept.sortedWith(compareBy<AppEntry> { it.label.lowercase() }.thenBy { it.packageName })
            AppSort.Size -> kept.sortedWith(compareByDescending<AppEntry> { it.bytes }.thenBy { it.label.lowercase() })
            AppSort.Updated -> kept.sortedWith(compareByDescending<AppEntry> { it.updatedAt }.thenBy { it.label.lowercase() })
        }
    }
}

/** Copies the apk files of an app somewhere safe, so the app can be installed again later. */
object AppBackup {

    private const val MAX_NAME = 120

    /**
     * Copies [app] into [destDir]. An app with one apk becomes "Name 1.2.3.apk". An app that comes as several
     * pieces (split apks) becomes a folder "Name 1.2.3" holding every piece under its own name, because the
     * pieces only install together. A name that is taken gets a number. Returns what was made, or null when
     * the copy failed; nothing half-written is left behind. Throws [JobStopped] when [control] was cancelled,
     * after cleaning up.
     */
    fun backup(app: AppEntry, destDir: File, control: JobControl? = null): File? {
        val sources = app.apkPaths.map { File(it) }.filter { it.isFile }
        if (sources.isEmpty() || sources.size != app.apkPaths.size) return null
        if (!destDir.isDirectory && !destDir.mkdirs()) return null
        val stem = safeName("${app.label} ${app.versionName}".trim())
        return if (sources.size == 1) {
            val target = FileOps.uniqueTarget(destDir, "$stem.apk")
            if (copyOne(sources[0], target, control)) target else null
        } else {
            val folder = FileOps.uniqueTarget(destDir, stem)
            if (!folder.mkdirs()) return null
            var ok = true
            try {
                for (source in sources) {
                    if (!copyOne(source, File(folder, source.name), control)) {
                        ok = false
                        break
                    }
                }
            } catch (e: JobStopped) {
                folder.deleteRecursively()
                throw e
            }
            if (ok) folder else {
                folder.deleteRecursively()
                null
            }
        }
    }

    private fun copyOne(source: File, target: File, control: JobControl?): Boolean {
        return try {
            source.inputStream().use { input ->
                target.outputStream().use { output ->
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        control?.check()
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        control?.add(read.toLong())
                    }
                }
            }
            true
        } catch (e: JobStopped) {
            target.delete()
            throw e
        } catch (e: IOException) {
            target.delete()
            false
        } catch (e: SecurityException) {
            target.delete()
            false
        }
    }

    /** Makes [text] fit as a file name: no slashes or other characters file systems dislike, and not too long. */
    fun safeName(text: String): String {
        val cleaned = text
            .map { c -> if (c in "/\\:*?\"<>|" || c.isISOControl()) ' ' else c }
            .joinToString("")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('.')
            .take(MAX_NAME)
            .trim()
        return cleaned.ifEmpty { "app" }
    }
}
