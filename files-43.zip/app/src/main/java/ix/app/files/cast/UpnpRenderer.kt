package ix.app.files.cast

class PositionInfo(val relMs: Long?, val durMs: Long?, val trackUri: String)

/** The handful of things the engine asks of a device. A fake one stands in for it in the tests. */
interface Renderer {
    fun setUri(uri: String, didl: String)
    fun play()
    fun pause()
    fun stop()
    fun seek(ms: Long)
    fun transportState(): String
    fun positionInfo(): PositionInfo
    fun getVolume(): Int?
    fun setVolume(v: Int)

    /** The formats the device says it can play. Empty = unknown. */
    fun sinkFormats(): List<String>
}

/** The UPnP actions the app needs, for one device. All calls block: run them off the main thread. */
class UpnpRenderer(private val lan: Lan, val device: CastDevice) : Renderer {

    private fun avt(action: String, extra: List<Pair<String, String>> = emptyList()): Map<String, String> =
        Soap.call(lan, device.avtUrl, device.avtType, action, listOf("InstanceID" to "0") + extra)

    override fun setUri(uri: String, didl: String) {
        avt("SetAVTransportURI", listOf("CurrentURI" to uri, "CurrentURIMetaData" to didl))
    }

    override fun play() { avt("Play", listOf("Speed" to "1")) }
    override fun pause() { avt("Pause") }
    override fun stop() { avt("Stop") }

    override fun seek(ms: Long) {
        val target = Soap.formatTime(ms)
        try {
            avt("Seek", listOf("Unit" to "REL_TIME", "Target" to target))
        } catch (e: UpnpException) {
            avt("Seek", listOf("Unit" to "ABS_TIME", "Target" to target))
        }
    }

    override fun transportState(): String = avt("GetTransportInfo")["CurrentTransportState"].orEmpty()

    override fun positionInfo(): PositionInfo {
        val m = avt("GetPositionInfo")
        return PositionInfo(Soap.parseTime(m["RelTime"]), Soap.parseTime(m["TrackDuration"]), m["TrackURI"].orEmpty())
    }

    override fun getVolume(): Int? {
        val url = device.rcUrl ?: return null
        val type = device.rcType ?: return null
        return Soap.call(lan, url, type, "GetVolume", listOf("InstanceID" to "0", "Channel" to "Master"))["CurrentVolume"]
            ?.toIntOrNull()
    }

    override fun setVolume(v: Int) {
        val url = device.rcUrl ?: return
        val type = device.rcType ?: return
        Soap.call(
            lan, url, type, "SetVolume",
            listOf("InstanceID" to "0", "Channel" to "Master", "DesiredVolume" to v.coerceIn(0, 100).toString()),
        )
    }

    override fun sinkFormats(): List<String> {
        val url = device.cmUrl ?: return emptyList()
        val type = device.cmType ?: return emptyList()
        val sink = Soap.call(lan, url, type, "GetProtocolInfo")["Sink"].orEmpty()
        return sink.split(',').map { it.trim() }.filter { it.isNotEmpty() }
    }
}
