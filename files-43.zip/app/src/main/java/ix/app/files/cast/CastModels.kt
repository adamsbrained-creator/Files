package ix.app.files.cast

import java.io.File

enum class DeviceKind { TV, PC, SPEAKER }

/** One DLNA / UPnP "MediaRenderer" found on the network (an Xbox, Kodi, a smart TV, a Windows PC...). */
data class CastDevice(
    val udn: String,
    val name: String,
    val model: String,
    val kind: DeviceKind,
    val host: String,
    val location: String,
    val avtUrl: String,
    val avtType: String,
    val rcUrl: String?,
    val rcType: String?,
    val cmUrl: String?,
    val cmType: String?,
) {
    val subtitle: String get() = "$model · UPnP"
}

/** The two options in the Cast sheet. They apply to every device. */
data class CastSettings(
    /** Only send a file when the device's own list of supported formats mentions its type. */
    val checkFormats: Boolean = false,
    /** Plain stream: no DLNA headers and a wildcard description. Some devices play more files this way. */
    val plainStream: Boolean = false,
    /** How much one tap of the volume buttons changes the device's volume (0 to 100). */
    val volumeStep: Int = 5,
)

enum class CastPhase { IDLE, CONNECTING, CONNECTED }

enum class CastKind { Video, Audio, Image }

/** One file waiting to be shown on the device. [durationMs] is 0 when it is not known (pictures, odd files). */
data class CastItem(
    val path: String,
    val title: String,
    val kind: CastKind,
    val mime: String,
    val ext: String,
    val size: Long,
    val durationMs: Long,
)

/** What the UI shows: where things are playing right now. */
data class CastState(
    val phase: CastPhase = CastPhase.IDLE,
    val device: CastDevice? = null,
    val queue: List<CastItem> = emptyList(),
    val index: Int = 0,
    /** True while the device reports PLAYING. */
    val playing: Boolean = false,
    /** True while a new file is being handed over or the device is buffering it. */
    val loading: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    /** The device's volume from 0 to 100, or -1 when it can not tell. */
    val volume: Int = -1,
) {
    val current: CastItem? get() = queue.getOrNull(index)
    val hasNext: Boolean get() = index + 1 < queue.size
    val hasPrevious: Boolean get() = index > 0
}

/** Which files can be cast, and what to tell the device about them. */
object CastMedia {

    private val video = mapOf(
        "mp4" to "video/mp4",
        "m4v" to "video/mp4",
        "mkv" to "video/x-matroska",
        "webm" to "video/webm",
        "avi" to "video/x-msvideo",
        "mov" to "video/quicktime",
        "wmv" to "video/x-ms-wmv",
        "asf" to "video/x-ms-asf",
        "mpg" to "video/mpeg",
        "mpeg" to "video/mpeg",
        "ts" to "video/mp2t",
        "m2ts" to "video/mp2t",
        "3gp" to "video/3gpp",
        "flv" to "video/x-flv",
    )
    private val audio = mapOf(
        "mp3" to "audio/mpeg",
        "m4a" to "audio/mp4",
        "aac" to "audio/aac",
        "wav" to "audio/wav",
        "flac" to "audio/flac",
        "ogg" to "audio/ogg",
        "oga" to "audio/ogg",
        "opus" to "audio/ogg",
        "wma" to "audio/x-ms-wma",
    )
    private val image = mapOf(
        "jpg" to "image/jpeg",
        "jpeg" to "image/jpeg",
        "png" to "image/png",
        "gif" to "image/gif",
        "bmp" to "image/bmp",
        "webp" to "image/webp",
    )

    fun kindOf(ext: String): CastKind? = when (ext.lowercase()) {
        in video -> CastKind.Video
        in audio -> CastKind.Audio
        in image -> CastKind.Image
        else -> null
    }

    fun mimeOf(ext: String): String? {
        val e = ext.lowercase()
        return video[e] ?: audio[e] ?: image[e]
    }

    fun canCast(file: File): Boolean = file.isFile && kindOf(file.extension) != null

    /** Describes a file for casting, or null when it is not a video, song or picture a device could show. */
    fun itemFor(file: File, durationMs: Long = 0L): CastItem? {
        if (!file.isFile) return null
        val ext = file.extension.lowercase()
        val kind = kindOf(ext) ?: return null
        val mime = mimeOf(ext) ?: return null
        return CastItem(
            path = file.path,
            title = file.nameWithoutExtension.ifBlank { file.name },
            kind = kind,
            mime = mime,
            ext = ext,
            size = file.length(),
            durationMs = durationMs,
        )
    }
}

/** Does the device's list of supported formats (from GetProtocolInfo) cover this file's type? */
object FormatSupport {
    private val groups = listOf(
        setOf("audio/mpeg", "audio/mp3", "audio/mpeg3", "audio/x-mpeg"),
        setOf("audio/mp4", "audio/x-m4a", "audio/m4a", "audio/aac", "audio/aacp", "audio/mp4a-latm", "audio/3gpp"),
        setOf("audio/flac", "audio/x-flac"),
        setOf("audio/wav", "audio/x-wav", "audio/wave", "audio/vnd.wave", "audio/l16"),
        setOf("audio/ogg", "application/ogg", "audio/x-ogg", "audio/vorbis", "audio/opus"),
        setOf("audio/x-ms-wma", "audio/wma"),
        setOf("video/mp4", "video/x-m4v", "video/mpeg4", "video/m4v"),
        setOf("video/x-matroska", "video/matroska", "video/x-mkv", "video/mkv"),
        setOf("video/x-msvideo", "video/avi", "video/msvideo", "video/divx"),
        setOf("video/x-ms-wmv", "video/x-ms-asf", "video/wmv", "video/x-ms-wvx", "video/x-ms-asf-plugin"),
        setOf("video/mpeg", "video/mp2t", "video/vnd.dlna.mpeg-tts", "video/mpeg2", "video/x-mpeg"),
        setOf("video/quicktime"),
        setOf("video/webm"),
        setOf("video/3gpp", "video/3gp"),
        setOf("video/x-flv", "video/flv"),
        setOf("image/jpeg", "image/jpg", "image/pjpeg"),
        setOf("image/png", "image/x-png"),
        setOf("image/gif"),
        setOf("image/bmp", "image/x-ms-bmp"),
    )

    fun supports(sink: List<String>, mime: String): Boolean {
        val wanted = mime.lowercase().substringBefore(';').trim()
        val group = groups.firstOrNull { wanted in it } ?: setOf(wanted)
        for (entry in sink) {
            val f = entry.trim().split(':')   // protocol : network : contentFormat : additionalInfo
            if (f.size < 3 || !f[0].equals("http-get", ignoreCase = true)) continue
            val format = f[2].lowercase().substringBefore(';').trim()
            if (format == "*" || format == "*/*" || format in group) return true
        }
        return false
    }
}

/** The small XML description of a file that devices show on screen (title, kind of item) and use to pick a player. */
object Didl {
    private const val STREAM_FLAGS = "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
    private const val IMAGE_FLAGS = "DLNA.ORG_OP=00;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=00f00000000000000000000000000000"

    /** The 4th field of the protocolInfo, which is also what the server sends as contentFeatures.dlna.org. */
    fun features(item: CastItem): String = if (item.kind == CastKind.Image) IMAGE_FLAGS else STREAM_FLAGS

    fun upnpClass(kind: CastKind): String = when (kind) {
        CastKind.Video -> "object.item.videoItem"
        CastKind.Audio -> "object.item.audioItem.musicTrack"
        CastKind.Image -> "object.item.imageItem.photo"
    }

    fun build(item: CastItem, id: Int, url: String, plain: Boolean): String {
        val fourth = if (plain) "*" else {
            val pn = if (item.mime == "audio/mpeg") "DLNA.ORG_PN=MP3;" else ""
            "$pn${features(item)}"
        }
        val e = Soap::escape
        return buildString {
            append("<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" ")
            append("xmlns:dc=\"http://purl.org/dc/elements/1.1/\" ")
            append("xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" ")
            append("xmlns:dlna=\"urn:schemas-dlna-org:metadata-1-0/\">")
            append("<item id=\"$id\" parentID=\"0\" restricted=\"1\">")
            append("<dc:title>${e(item.title)}</dc:title>")
            append("<upnp:class>${upnpClass(item.kind)}</upnp:class>")
            append("<res protocolInfo=\"${e("http-get:*:${item.mime}:$fourth")}\"")
            if (item.durationMs > 0) append(" duration=\"${Soap.formatTime(item.durationMs, true)}\"")
            if (item.size > 0) append(" size=\"${item.size}\"")
            append(">${e(url)}</res>")
            append("</item></DIDL-Lite>")
        }
    }
}

/** "3:05" or "1:02:03", for the position and length shown on the remote. */
fun clockLabel(ms: Long): String {
    val total = (ms.coerceAtLeast(0L)) / 1000
    val h = total / 3600
    val m = (total / 60) % 60
    val sec = total % 60
    return if (h > 0) "%d:%02d:%02d".format(java.util.Locale.US, h, m, sec) else "%d:%02d".format(java.util.Locale.US, m, sec)
}
