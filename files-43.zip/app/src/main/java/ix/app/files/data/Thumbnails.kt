package ix.app.files.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.os.ParcelFileDescriptor
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Small square previews: pictures, a frame of a video, the cover art of a song, the icon of an app (apk)
 * and the first page of a PDF.
 * Decoding happens off the main thread, three at a time, and finished previews stay in a memory cache.
 */
object Thumbnails {

    private val cache = object : LruCache<String, Bitmap>(cacheSizeKb()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.allocationByteCount / 1024
    }
    private val failed: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val gate = Semaphore(3)

    /** Bigger pictures in Private get no preview, so unlocking one never needs much memory. */
    private const val PRIVATE_PICTURE_LIMIT = 16L * 1024 * 1024

    /** Needed to read app icons. Set once by [attach]. */
    @Volatile
    private var appContext: Context? = null

    /** Gives the previews what they need to read app icons. Safe to call again and again. */
    fun attach(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    /** True for files that can have a preview, so the list knows to ask for one. */
    fun supports(file: FileItem): Boolean = when (file.kind) {
        FileKind.Image, FileKind.Video, FileKind.Audio -> true
        FileKind.App -> file.extension == "apk"
        FileKind.Document -> file.extension == "pdf"
        FileKind.Other -> false
    }

    private fun cacheSizeKb(): Int = (Runtime.getRuntime().maxMemory() / 1024 / 12).toInt()

    private fun keyOf(file: FileItem, px: Int) = "${file.path}|${file.modifiedMillis}|$px"

    /** Forgets every preview, for example when Private locks. */
    fun clear() {
        cache.evictAll()
        failed.clear()
    }

    /** The preview if it is already in memory. Safe to call while composing. */
    fun peek(file: FileItem, px: Int): Bitmap? = cache.get(keyOf(file, px))

    /** True if this file was tried before and could not be decoded. */
    fun hasFailed(file: FileItem, px: Int): Boolean = keyOf(file, px) in failed

    /** Returns the preview, decoding it first if needed. Null means the file has no preview. */
    suspend fun load(file: FileItem, px: Int): Bitmap? {
        val key = keyOf(file, px)
        cache.get(key)?.let { return it }
        if (key in failed) return null
        val bitmap = gate.withPermit {
            currentCoroutineContext().ensureActive()
            withContext(Dispatchers.IO) { decode(file, px) }
        }
        if (bitmap != null) cache.put(key, bitmap) else failed.add(key)
        return bitmap
    }

    private fun decode(file: FileItem, px: Int): Bitmap? = try {
        when (file.kind) {
            FileKind.Image -> decodeImage(file, px)
            FileKind.Video -> decodeVideo(file.path, px)
            FileKind.Audio -> decodeCover(file.path, px)
            FileKind.App -> decodeApkIcon(file.path, px)
            FileKind.Document -> decodePdfPage(file.path, px)
            else -> null
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }

    private fun decodeImage(file: FileItem, px: Int): Bitmap? {
        // A picture in Private is locked, so it is unlocked into memory instead of read from the path.
        val stored = File(file.path)
        if (Vault.isPrivate(stored) && Vault.isEncrypted(stored)) {
            val bytes = Vault.readAll(stored, PRIVATE_PICTURE_LIMIT) ?: return null
            return decodePrivatePicture(bytes, px)
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // Let the decoder shrink the picture while reading, so a 12 MP photo never fills memory.
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val source = BitmapFactory.decodeFile(file.path, options) ?: return null

        val square = ThumbnailUtils.extractThumbnail(source, px, px)
        val degrees = if (file.extension == "jpg" || file.extension == "jpeg") exifDegrees(file.path) else 0
        if (degrees == 0) return square
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(square, 0, 0, square.width, square.height, matrix, true)
    }

    private fun decodeVideo(path: String, px: Int): Bitmap? {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(path)
            // A negative time asks for whichever frame the system thinks represents the video.
            val frame = retriever.getFrameAtTime(-1L) ?: return null
            return ThumbnailUtils.extractThumbnail(frame, px, px)
        } finally {
            retriever.release()
        }
    }

    private fun decodePrivatePicture(data: ByteArray, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val source = BitmapFactory.decodeByteArray(data, 0, data.size, options) ?: return null
        val square = ThumbnailUtils.extractThumbnail(source, px, px)
        val degrees = try {
            when (ExifInterface(ByteArrayInputStream(data)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0
        }
        if (degrees == 0) return square
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(square, 0, 0, square.width, square.height, matrix, true)
    }

    /** The picture stored inside a song file, if it has one. */
    private fun decodeCover(path: String, px: Int): Bitmap? {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(path)
            val art = retriever.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(art, 0, art.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val source = BitmapFactory.decodeByteArray(art, 0, art.size, options) ?: return null
            return ThumbnailUtils.extractThumbnail(source, px, px)
        } finally {
            retriever.release()
        }
    }

    /** The launcher icon of an apk, read from the file without installing it. */
    private fun decodeApkIcon(path: String, px: Int): Bitmap? {
        val context = appContext ?: return null
        val manager = context.packageManager
        val info = manager.getPackageArchiveInfo(path, 0) ?: return null
        val app = info.applicationInfo ?: return null
        // Without these two the system looks for the icon in an app that is not installed.
        app.sourceDir = path
        app.publicSourceDir = path
        val icon = app.loadIcon(manager)
        val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        icon.setBounds(0, 0, px, px)
        icon.draw(Canvas(bitmap))
        return bitmap
    }

    /** The top of the first page of a PDF, on white. */
    private fun decodePdfPage(path: String, px: Int): Bitmap? {
        val descriptor = ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val renderer = PdfRenderer(descriptor)
            try {
                if (renderer.pageCount == 0) return null
                val page = renderer.openPage(0)
                try {
                    val width = px * 2
                    val height = ((width.toLong() * page.height) / page.width.coerceAtLeast(1)).toInt().coerceAtLeast(1)
                    val full = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    full.eraseColor(Color.WHITE)
                    page.render(full, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val side = minOf(width, height)
                    val square = Bitmap.createBitmap(full, 0, 0, side, side)
                    return Bitmap.createScaledBitmap(square, px, px, true)
                } finally {
                    page.close()
                }
            } finally {
                renderer.close()
            }
        } finally {
            descriptor.close()
        }
    }

    private fun exifDegrees(path: String): Int = try {
        when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }
}
