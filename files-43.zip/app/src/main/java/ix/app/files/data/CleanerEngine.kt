package ix.app.files.data

import androidx.compose.runtime.Immutable
import java.io.File
import java.nio.file.Files

/** The kinds of leftovers the Cleaner looks for, in the order they are shown. */
enum class CleanKind { Installers, Leftovers, EmptyFolders, LargeOld }

/** One kind of leftover and what was found. Empty folders come as [folders], everything else as [files]. */
@Immutable
class CleanGroup(val kind: CleanKind, val files: List<FileItem>, val folders: List<FolderItem>) {
    val count: Int get() = files.size + folders.size
    val bytes: Long get() = files.sumOf { it.sizeBytes }
    val paths: List<String> get() = folders.map { it.path } + files.map { it.path }
}

/**
 * Finds things that are very likely safe to clear, from the list of files the last scan made.
 * Nothing is deleted here: the screen lists them and the usual delete (with Undo) does the work.
 *
 * Every file is listed in one group only, the first that fits, so no space is counted twice.
 */
object CleanerEngine {

    /** Files this big that nobody touched for [OLD_DAYS] days are offered for review. */
    const val LARGE_BYTES = 100L * 1024 * 1024
    const val OLD_DAYS = 90

    /** Half-written downloads and the like are left alone for a day, since they may still be in use. */
    const val SETTLE_MILLIS = 24L * 60 * 60 * 1000

    private const val DAY_MILLIS = 24L * 60 * 60 * 1000

    private val installerExtensions = setOf("apk", "xapk", "apks", "apkm")

    /** Extensions that mean "temporary", "backup" or "unfinished". */
    private val leftoverExtensions = setOf(
        "tmp", "temp", "bak", "old", "crdownload", "part", "partial", "download", "dmp", "swp", "log",
    )

    /** Folders at the top of storage that Android and apps expect to find, even when empty. */
    private val standardFolders = setOf(
        "alarms", "audiobooks", "dcim", "documents", "download", "downloads", "movies", "music",
        "notifications", "pictures", "podcasts", "recordings", "ringtones",
    )

    /**
     * Looks through [scan]. [rootPath] is the top of storage: its standard folders are never offered.
     * [active] is asked now and then; once it returns false the work stops and returns nothing.
     * Call off the main thread: empty folders are double-checked on disk.
     */
    fun find(
        scan: ScanData,
        rootPath: String,
        now: Long = System.currentTimeMillis(),
        active: () -> Boolean = { true },
    ): List<CleanGroup> {
        val installers = ArrayList<FileItem>()
        val leftovers = ArrayList<FileItem>()
        val large = ArrayList<FileItem>()
        for (file in scan.files) {
            when {
                isLeftover(file, now) -> leftovers.add(file)
                file.extension in installerExtensions -> installers.add(file)
                file.sizeBytes >= LARGE_BYTES && file.modifiedMillis < now - OLD_DAYS * DAY_MILLIS -> large.add(file)
            }
        }
        if (!active()) return emptyList()
        val empty = emptyFolders(scan, rootPath, now, active)
        if (!active()) return emptyList()

        val groups = ArrayList<CleanGroup>()
        if (installers.isNotEmpty()) {
            groups.add(CleanGroup(CleanKind.Installers, installers.sortedByDescending { it.sizeBytes }, emptyList()))
        }
        if (leftovers.isNotEmpty()) {
            groups.add(CleanGroup(CleanKind.Leftovers, leftovers.sortedByDescending { it.sizeBytes }, emptyList()))
        }
        if (empty.isNotEmpty()) {
            groups.add(CleanGroup(CleanKind.EmptyFolders, emptyList(), empty))
        }
        if (large.isNotEmpty()) {
            groups.add(CleanGroup(CleanKind.LargeOld, large.sortedByDescending { it.sizeBytes }, emptyList()))
        }
        return groups
    }

    /** Temporary, backup and unfinished files, and files with nothing in them, once they have settled. */
    private fun isLeftover(file: FileItem, now: Long): Boolean {
        if (file.modifiedMillis > now - SETTLE_MILLIS) return false
        if (file.sizeBytes == 0L) return true
        if (file.extension in leftoverExtensions) return true
        // Editors leave "notes.txt~" behind.
        return file.name.endsWith("~") || file.extension.endsWith("~")
    }

    /**
     * Folders with no file anywhere inside them, only the top one of a nest of empty folders.
     * The scan skips hidden names, so a folder that only looks empty is checked on disk before it is offered.
     */
    private fun emptyFolders(scan: ScanData, rootPath: String, now: Long, active: () -> Boolean): List<FolderItem> {
        // Every folder that has a file somewhere below it.
        val withFiles = HashSet<String>()
        for (file in scan.files) {
            var parent = File(file.path).parent
            while (parent != null && withFiles.add(parent)) {
                parent = File(parent).parent
            }
        }

        val candidates = scan.folders
            .filter { it.path !in withFiles && it.modifiedMillis <= now - SETTLE_MILLIS && !isStandard(it.path, rootPath) }
            .sortedBy { it.path.length }

        // Shortest paths first, so a folder inside an already chosen one is skipped.
        val chosen = HashSet<String>()
        val result = ArrayList<FolderItem>()
        for (folder in candidates) {
            if (!active()) return emptyList()
            var inside = false
            var parent = File(folder.path).parent
            while (parent != null) {
                if (parent in chosen) {
                    inside = true
                    break
                }
                parent = File(parent).parent
            }
            if (inside) continue
            if (!holdsNoFiles(File(folder.path))) continue
            chosen.add(folder.path)
            result.add(folder)
        }
        return result.sortedBy { it.path.lowercase() }
    }

    private fun isStandard(path: String, rootPath: String): Boolean {
        val parent = File(path).parent ?: return true
        return parent == rootPath && File(path).name.lowercase() in standardFolders
    }

    /** True when the folder and everything below it are folders only: no file, hidden or not, and no link. */
    internal fun holdsNoFiles(dir: File): Boolean {
        if (!dir.isDirectory || Files.isSymbolicLink(dir.toPath())) return false
        val children = dir.listFiles() ?: return false
        for (child in children) {
            if (Files.isSymbolicLink(child.toPath()) || !child.isDirectory) return false
            if (!holdsNoFiles(child)) return false
        }
        return true
    }
}
