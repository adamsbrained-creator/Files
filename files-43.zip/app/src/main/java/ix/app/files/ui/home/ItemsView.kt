package ix.app.files.ui.home

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import androidx.compose.foundation.lazy.grid.items as gridItems

/**
 * Folders first, then files, as a list of rows or a grid of tiles.
 * Every screen that lists things goes through here, so they all react to the layout setting.
 *
 * [hintOf] adds a short "where is this" line to list rows (used by search).
 * [footer] is one extra item after the last row or tile.
 *
 * [startIndex] and [startOffset] say where to begin scrolling, and [onScrolled] is told whenever the view moves,
 * so a screen can remember where each of its lists was left.
 */
@Composable
fun ItemsView(
    folders: List<FolderItem>,
    files: List<FileItem>,
    grid: Boolean,
    favorites: Set<String>,
    selection: Selection,
    onOpenFolder: (FolderItem) -> Unit,
    onOpenFile: (FileItem) -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
    hintOf: ((String) -> String)? = null,
    footer: (@Composable () -> Unit)? = null,
    startIndex: Int = 0,
    startOffset: Int = 0,
    onScrolled: ((index: Int, offset: Int) -> Unit)? = null,
) {
    if (grid) {
        val gridState = rememberLazyGridState(startIndex, startOffset)
        if (onScrolled != null) {
            LaunchedEffect(gridState) {
                snapshotFlow { gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset }
                    .collect { (index, offset) -> onScrolled(index, offset) }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 108.dp),
            state = gridState,
            modifier = modifier,
            contentPadding = PaddingValues(
                start = 12.dp,
                end = 12.dp,
                top = 4.dp,
                bottom = contentPadding.calculateBottomPadding(),
            ),
        ) {
            gridItems(folders, key = { "d:" + it.path }) { folder ->
                FolderTile(
                    folder,
                    selection = selection,
                    favorite = folder.path in favorites,
                    onOpen = { onOpenFolder(folder) },
                )
            }
            gridItems(files, key = { "f:" + it.path }) { file ->
                FileTile(
                    file,
                    selection = selection,
                    favorite = file.path in favorites,
                    onOpen = { onOpenFile(file) },
                )
            }
            if (footer != null) {
                item(key = "footer", span = { GridItemSpan(maxLineSpan) }) { footer() }
            }
        }
    } else {
        val listState = rememberLazyListState(startIndex, startOffset)
        if (onScrolled != null) {
            LaunchedEffect(listState) {
                snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
                    .collect { (index, offset) -> onScrolled(index, offset) }
            }
        }
        LazyColumn(modifier, state = listState, contentPadding = contentPadding) {
            items(folders, key = { "d:" + it.path }) { folder ->
                FolderRow(
                    folder,
                    selection = selection,
                    favorite = folder.path in favorites,
                    onOpen = { onOpenFolder(folder) },
                    hint = hintOf?.invoke(folder.path),
                )
            }
            items(files, key = { "f:" + it.path }) { file ->
                FileRow(
                    file,
                    selection = selection,
                    favorite = file.path in favorites,
                    onOpen = { onOpenFile(file) },
                    hint = hintOf?.invoke(file.path),
                )
            }
            if (footer != null) {
                item(key = "footer") { footer() }
            }
        }
    }
}
