package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.BatchRename
import ix.app.files.data.RenameProblem
import ix.app.files.data.RenameRow
import ix.app.files.data.RenameRule
import ix.app.files.ui.theme.IxColors
import java.io.File
import java.text.NumberFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class RenameMode { Numbering, Replace, Affix }

/**
 * Renames the selected items together: a name with numbers, a find-and-replace, or text added around
 * the names. A preview under the fields shows every new name before anything is touched, and items that
 * cannot be renamed (clashes, taken names) are marked and skipped.
 */
@Composable
fun BatchRenameDialog(
    files: List<File>,
    onConfirm: (RenameRule) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(RenameMode.Numbering) }
    var base by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("1") }
    var digits by remember { mutableStateOf("1") }
    var find by remember { mutableStateOf("") }
    var replaceWith by remember { mutableStateOf("") }
    var ignoreCase by remember { mutableStateOf(true) }
    var prefix by remember { mutableStateOf("") }
    var suffix by remember { mutableStateOf("") }

    val rule: RenameRule = when (mode) {
        RenameMode.Numbering -> RenameRule.Numbering(
            base = base,
            start = (start.toIntOrNull() ?: 1).coerceIn(0, 999_999),
            digits = (digits.toIntOrNull() ?: 1).coerceIn(1, 9),
        )

        RenameMode.Replace -> RenameRule.Replace(find = find, with = replaceWith, ignoreCase = ignoreCase)
        RenameMode.Affix -> RenameRule.Affix(prefix = prefix, suffix = suffix)
    }

    // The preview looks at the disk (is the new name taken?), so it is made off the main thread.
    val rows by produceState<List<RenameRow>>(emptyList(), files, rule) {
        value = withContext(Dispatchers.IO) { BatchRename.preview(files, rule) }
    }
    val ready = rows.count { it.ready }
    val skipped = rows.count { it.problem != null }
    val number = NumberFormat.getIntegerInstance()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(context.getString(R.string.batch_rename_title, number.format(files.size))) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip(R.string.batch_mode_number, mode == RenameMode.Numbering) { mode = RenameMode.Numbering }
                    ModeChip(R.string.batch_mode_replace, mode == RenameMode.Replace) { mode = RenameMode.Replace }
                    ModeChip(R.string.batch_mode_affix, mode == RenameMode.Affix) { mode = RenameMode.Affix }
                }
                when (mode) {
                    RenameMode.Numbering -> {
                        RenameField(stringResource(R.string.batch_field_base), base) { base = it }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.weight(1f)) {
                                RenameField(stringResource(R.string.batch_field_start), start, numbers = true) {
                                    start = it.filter { c -> c.isDigit() }.take(6)
                                }
                            }
                            Box(Modifier.weight(1f)) {
                                RenameField(stringResource(R.string.batch_field_digits), digits, numbers = true) {
                                    digits = it.filter { c -> c.isDigit() }.take(1)
                                }
                            }
                        }
                    }

                    RenameMode.Replace -> {
                        RenameField(stringResource(R.string.batch_field_find), find) { find = it }
                        RenameField(stringResource(R.string.batch_field_with), replaceWith) { replaceWith = it }
                        ModeChip(R.string.batch_ignore_case, ignoreCase) { ignoreCase = !ignoreCase }
                    }

                    RenameMode.Affix -> {
                        RenameField(stringResource(R.string.batch_field_prefix), prefix) { prefix = it }
                        RenameField(stringResource(R.string.batch_field_suffix), suffix) { suffix = it }
                    }
                }

                if (skipped > 0) {
                    Text(
                        text = context.getString(R.string.batch_skipped, number.format(skipped)),
                        color = IxColors.Danger,
                        fontSize = 12.sp,
                    )
                }
                LazyColumn(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp),
                ) {
                    items(rows, key = { it.file.path }) { row -> PreviewLine(row) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = ready > 0, onClick = { onConfirm(rule) }) {
                Text(
                    text = stringResource(R.string.rename_confirm),
                    color = if (ready > 0) IxColors.TextPrimary else IxColors.TextSecondary,
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = IxColors.TextPrimary)
            }
        },
    )
}

@Composable
private fun ModeChip(label: Int, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(34.dp)
            .clip(CircleShape)
            .background(if (selected) IxColors.Accent else IxColors.Button)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = stringResource(label),
            color = if (selected) IxColors.Background else IxColors.TextPrimary,
            fontSize = 13.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun RenameField(label: String, value: String, numbers: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        label = { Text(label, fontSize = 12.sp) },
        keyboardOptions = if (numbers) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = IxColors.TextPrimary,
            unfocusedTextColor = IxColors.TextPrimary,
            cursorColor = IxColors.TextPrimary,
            focusedBorderColor = IxColors.TextSecondary,
            unfocusedBorderColor = IxColors.Outline,
            focusedLabelColor = IxColors.TextSecondary,
            unfocusedLabelColor = IxColors.TextSecondary,
        ),
    )
}

/** "old name" over "new name". Items that stay as they are show one dimmed line; blocked ones say why. */
@Composable
private fun PreviewLine(row: RenameRow) {
    Column(Modifier.padding(vertical = 4.dp)) {
        if (!row.changed) {
            Text(text = row.oldName, color = IxColors.TextSecondary, fontSize = 13.sp, maxLines = 1)
        } else {
            Text(text = row.oldName, color = IxColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
            Text(
                text = row.newName,
                color = if (row.problem == null) IxColors.TextPrimary else IxColors.Danger,
                fontSize = 14.sp,
                maxLines = 1,
            )
            val reason = when (row.problem) {
                RenameProblem.Invalid -> R.string.batch_problem_invalid
                RenameProblem.TooLong -> R.string.batch_problem_long
                RenameProblem.Clash -> R.string.batch_problem_clash
                RenameProblem.Exists -> R.string.batch_problem_exists
                null -> 0
            }
            if (reason != 0) {
                Text(text = stringResource(reason), color = IxColors.Danger, fontSize = 11.sp)
            }
        }
    }
}
