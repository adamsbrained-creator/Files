package ix.app.files.ui.home

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.data.SearchResults
import ix.app.files.ui.theme.IxColors
import java.io.File
import java.text.NumberFormat

/** What the search found: folders first, then files. Each row says which folder it lives in. */
@Composable
fun SearchResultsList(
    results: SearchResults,
    scanning: Boolean,
    grid: Boolean,
    favorites: Set<String>,
    selection: Selection,
    rootPath: String,
    onFolderClick: (FolderItem) -> Unit,
    onFileClick: (FileItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shown = results.folders.size + results.files.size
    if (shown == 0) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Text(
                text = stringResource(if (scanning) R.string.scanning else R.string.search_empty),
                color = IxColors.TextSecondary,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 40.dp),
            )
        }
        return
    }

    val rootLabel = stringResource(R.string.browser_root)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    ItemsView(
        folders = results.folders,
        files = results.files,
        grid = grid,
        favorites = favorites,
        selection = selection,
        onOpenFolder = onFolderClick,
        onOpenFile = onFileClick,
        contentPadding = PaddingValues(bottom = bottomInset + 24.dp),
        // imePadding lifts the list above the keyboard so the last results can be reached while typing.
        modifier = modifier.fillMaxWidth().imePadding(),
        hintOf = { path -> locationOf(path, rootPath, rootLabel) },
        footer = if (results.total > shown) {
            {
                val number = NumberFormat.getIntegerInstance()
                Text(
                    text = stringResource(
                        R.string.search_more,
                        number.format(shown),
                        number.format(results.total),
                    ),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                )
            }
        } else {
            null
        },
    )
}

/** The folder a thing sits in, written from the top of storage: "DCIM/Camera". */
private fun locationOf(path: String, rootPath: String, rootLabel: String): String {
    val parent = File(path).parent ?: return rootLabel
    val relative = parent.removePrefix(rootPath).trim('/')
    return relative.ifEmpty { rootLabel }
}
