package ix.app.files.cast

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/** The part of a file a request asks for. [partial] is true when the answer is a 206. */
class ByteSpan(val start: Long, val end: Long, val partial: Boolean) {
    val length: Long get() = end - start + 1
}

/** Works out which bytes a "Range:" header asks for. Null means the range can not be satisfied (416). */
object RangeHeader {
    private val pattern = Regex("^\\s*bytes\\s*=\\s*(\\d*)\\s*-\\s*(\\d*)\\s*(,.*)?$", RegexOption.IGNORE_CASE)

    fun resolve(header: String?, size: Long): ByteSpan? {
        if (size <= 0) return if (header == null) ByteSpan(0, -1, false) else null
        val m = header?.let { pattern.find(it) } ?: return ByteSpan(0, size - 1, false)
        val a = m.groupValues[1]
        val b = m.groupValues[2]
        return when {
            a.isEmpty() && b.isEmpty() -> ByteSpan(0, size - 1, false)
            // "the last N bytes"
            a.isEmpty() -> {
                val n = b.toLongOrNull() ?: return null
                if (n <= 0) null else ByteSpan((size - n).coerceAtLeast(0), size - 1, true)
            }
            else -> {
                val start = a.toLongOrNull() ?: return null
                val end = if (b.isEmpty()) size - 1 else minOf(b.toLongOrNull() ?: return null, size - 1)
                if (start >= size || start > end) null else ByteSpan(start, end, true)
            }
        }
    }
}

/**
 * A tiny web server inside the app. The TV / Xbox / PC does not get the file pushed to it; it downloads it
 * from here (with Range support, so seeking works). Only files that were announced with [urlFor] can be
 * fetched, and every URL contains a random token that changes each time the server starts.
 */
class MediaServer {

    private class Served(val file: File, val mime: String, val features: String)

    private var serverSocket: ServerSocket? = null
    private var pool: ExecutorService? = null

    @Volatile
    var token = ""
        private set

    @Volatile
    var port = 0
        private set

    /** Plain stream: no DLNA headers. */
    @Volatile
    var plain = false

    private val served = ConcurrentHashMap<Int, Served>()
    private val ids = ConcurrentHashMap<String, Int>()

    @Synchronized
    fun start() {
        if (serverSocket != null) return
        val ss = ServerSocket(0, 50)
        serverSocket = ss
        port = ss.localPort
        token = UUID.randomUUID().toString().replace("-", "").take(16)
        val p = Executors.newCachedThreadPool()
        pool = p
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (e: IOException) { break }
                try { p.execute { serve(s) } } catch (e: RejectedExecutionException) { runCatching { s.close() }; break }
            }
        }, "ixfiles-media-server").apply { isDaemon = true }.start()
        CastLog.log("media server listening on port $port")
    }

    @Synchronized
    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        pool?.shutdownNow()
        pool = null
        port = 0
        served.clear()
        ids.clear()
    }

    val running: Boolean get() = serverSocket != null

    /** Announces a file and returns the address the device can fetch it from, plus the id it was given. */
    fun urlFor(item: CastItem, host: String): Pair<Int, String> {
        val id = ids.getOrPut(item.path) { ids.size + 1 }
        served[id] = Served(File(item.path), item.mime, Didl.features(item))
        return id to "http://$host:$port/$token/m/$id.${item.ext.ifBlank { "bin" }}"
    }

    // ---- serving -----------------------------------------------------------------------------

    private fun serve(s: Socket) {
        try {
            s.soTimeout = 30_000
            val input = BufferedInputStream(s.getInputStream())
            val requestLine = readLine(input) ?: return
            val h = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) h[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }
            val parts = requestLine.split(' ')
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val segs = parts[1].substringBefore('?').split('/').filter { it.isNotEmpty() }
            val out = BufferedOutputStream(s.getOutputStream(), 64 * 1024)

            if (method != "GET" && method != "HEAD") return status(out, 405, "Method Not Allowed")
            if (segs.size != 3 || segs[0] != token || segs[1] != "m") return status(out, 404, "Not Found")
            val id = segs[2].substringBeforeLast('.').toIntOrNull() ?: return status(out, 404, "Not Found")
            serveFile(out, id, method == "HEAD", h)
        } catch (e: IOException) {
            // the device closed the connection (it does that when seeking): normal
        } catch (e: Exception) {
            CastLog.log("media server error: $e")
        } finally {
            runCatching { s.close() }
        }
    }

    private fun serveFile(out: OutputStream, id: Int, head: Boolean, h: Map<String, String>) {
        val info = served[id] ?: return status(out, 404, "Not Found")
        val raf = try { RandomAccessFile(info.file, "r") } catch (e: IOException) { return status(out, 404, "Not Found") }
        raf.use { f ->
            val size = f.length()
            val span = RangeHeader.resolve(h["range"], size)
                ?: return header(out, 416, "Range Not Satisfiable", "Content-Range: bytes */$size", "Content-Length: 0")

            val lines = ArrayList<String>()
            lines += "Content-Type: ${info.mime}"
            lines += "Content-Length: ${span.length}"
            lines += "Accept-Ranges: bytes"
            if (span.partial) lines += "Content-Range: bytes ${span.start}-${span.end}/$size"
            if (!plain) {
                val image = info.mime.startsWith("image/")
                lines += "transferMode.dlna.org: ${if (image) "Interactive" else "Streaming"}"
                lines += "contentFeatures.dlna.org: ${info.features}"
            }
            header(out, if (span.partial) 206 else 200, if (span.partial) "Partial Content" else "OK", *lines.toTypedArray())
            if (head || span.length <= 0) { out.flush(); return }

            f.seek(span.start)
            val buf = ByteArray(128 * 1024)
            var remaining = span.length
            while (remaining > 0) {
                val n = f.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (n <= 0) break
                out.write(buf, 0, n)
                remaining -= n
            }
            out.flush()
        }
    }

    private fun status(out: OutputStream, code: Int, reason: String) {
        header(out, code, reason, "Content-Length: 0")
        out.flush()
    }

    private fun header(out: OutputStream, code: Int, reason: String, vararg lines: String) {
        val sb = StringBuilder("HTTP/1.1 $code $reason\r\n")
        for (l in lines) sb.append(l).append("\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
        out.flush()
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val c = input.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(c.toChar())
        }
        return sb.toString()
    }
}
