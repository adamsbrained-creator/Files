package ix.app.files.cast

import org.xml.sax.Attributes
import org.xml.sax.InputSource
import org.xml.sax.helpers.DefaultHandler
import java.io.StringReader
import java.net.DatagramSocket
import java.net.HttpURLConnection
import javax.xml.parsers.SAXParserFactory

/** What the cast code needs from the phone's network. The Android version pins everything to Wi-Fi. */
interface Lan {
    fun open(url: String): HttpURLConnection
    fun bind(socket: DatagramSocket)

    /** This phone's address on the same subnet as [host], i.e. the address the device can reach us on. */
    fun localIpFor(host: String): String?
}

/** A tiny log the Android side forwards to Logcat and to the in-app debug text. */
object CastLog {
    @Volatile
    var sink: (String) -> Unit = {}

    fun log(message: String) = sink(message)
}

class UpnpException(val code: Int?, message: String) : Exception(message)

/** Minimal UPnP "SOAP" client: one POST per action, answers come back as a flat name -> text map. */
object Soap {
    private const val UA = "Linux/Android UPnP/1.0 IxFiles/0.26"

    fun call(
        lan: Lan,
        url: String,
        serviceType: String,
        action: String,
        args: List<Pair<String, String>> = emptyList(),
        readTimeoutMs: Int = 6000,
    ): Map<String, String> {
        val body = buildString {
            append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
            append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ")
            append("s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>")
            append("<u:$action xmlns:u=\"$serviceType\">")
            for ((k, v) in args) append("<$k>").append(escape(v)).append("</$k>")
            append("</u:$action></s:Body></s:Envelope>")
        }.toByteArray(Charsets.UTF_8)

        val c = lan.open(url)
        try {
            c.connectTimeout = 3000
            c.readTimeout = readTimeoutMs
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            c.setRequestProperty("SOAPACTION", "\"$serviceType#$action\"")
            c.setRequestProperty("User-Agent", UA)
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }

            val code = c.responseCode
            if (code in 200..299) {
                return parse(c.inputStream.bufferedReader().use { it.readText() })
            }
            val err = runCatching { c.errorStream?.bufferedReader()?.use { it.readText() } }.getOrNull().orEmpty()
            val m = parse(err)
            throw UpnpException(
                m["errorCode"]?.toIntOrNull(),
                "$action failed: HTTP $code ${m["errorDescription"].orEmpty()}".trim(),
            )
        } finally {
            c.disconnect()
        }
    }

    const val USER_AGENT = UA

    /**
     * Runs a SAX parse that never fetches anything from outside and never fails the caller:
     * half-broken XML from a device just ends early and whatever was read stays.
     */
    internal fun sax(xml: String, handler: DefaultHandler) {
        if (xml.isBlank()) return
        try {
            val factory = SAXParserFactory.newInstance()
            runCatching { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { factory.setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
            val reader = factory.newSAXParser().xmlReader
            reader.contentHandler = handler
            reader.errorHandler = handler
            reader.entityResolver = org.xml.sax.EntityResolver { _, _ -> InputSource(StringReader("")) }
            reader.parse(InputSource(StringReader(xml)))
        } catch (e: Exception) {
            // Half-broken XML from a renderer: keep whatever we managed to read.
        }
    }

    /** The local name of an element, without any "u:" style prefix. */
    internal fun local(qName: String): String = qName.substringAfter(':')

    /** Every leaf element's text, by local name (no namespace prefix). */
    fun parse(xml: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        sax(xml, object : DefaultHandler() {
            private var current = ""
            private val text = StringBuilder()
            override fun startElement(uri: String?, localName: String?, qName: String, attrs: Attributes?) {
                current = local(qName)
                text.setLength(0)
            }

            override fun characters(ch: CharArray, start: Int, length: Int) {
                text.append(ch, start, length)
            }

            override fun endElement(uri: String?, localName: String?, qName: String) {
                val t = text.toString().trim()
                if (current.isNotEmpty() && t.isNotEmpty() && local(qName) == current) out[current] = t
                current = ""
                text.setLength(0)
            }
        })
        return out
    }

    fun escape(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    /** "0:03:05.250" or "0:03:05" -> milliseconds. NOT_IMPLEMENTED and friends -> null. */
    fun parseTime(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        val parts = s.trim().split(':')
        if (parts.size != 3) return null
        val h = parts[0].toLongOrNull() ?: return null
        val m = parts[1].toLongOrNull() ?: return null
        val sec = parts[2].toDoubleOrNull() ?: return null
        return ((h * 3600 + m * 60) * 1000 + (sec * 1000).toLong())
    }

    fun formatTime(ms: Long, withMillis: Boolean = false): String {
        val total = ms.coerceAtLeast(0)
        val h = total / 3_600_000
        val m = (total / 60_000) % 60
        val s = (total / 1000) % 60
        val base = "%d:%02d:%02d".format(java.util.Locale.US, h, m, s)
        return if (withMillis) base + ".%03d".format(java.util.Locale.US, total % 1000) else base
    }
}
