package ix.app.files.data

/**
 * The kinds of archive the app can look into and unpack. Zip is read by the system's own code, the rest by
 * small libraries. A format is told by the end of the file name.
 */
enum class ArchiveFormat(val suffixes: List<String>) {
    Zip(listOf(".zip")),
    SevenZ(listOf(".7z")),
    Rar(listOf(".rar")),
    Tar(listOf(".tar")),
    TarGz(listOf(".tar.gz", ".tgz")),
    TarBz2(listOf(".tar.bz2", ".tbz2", ".tbz")),
    TarXz(listOf(".tar.xz", ".txz")),
    Gz(listOf(".gz")),
    Bz2(listOf(".bz2")),
    Xz(listOf(".xz"));

    /** True for the formats that pack one single file, such as "notes.txt.gz". */
    val isSingleFile: Boolean get() = this == Gz || this == Bz2 || this == Xz

    companion object {
        /** The format [name] says it is, or null when it is not an archive this app knows. */
        fun of(name: String): ArchiveFormat? = match(name)?.first

        /** [name] without its archive ending: "photos.tar.gz" gives "photos". Other names are returned as they are. */
        fun baseName(name: String): String {
            val match = match(name) ?: return name
            return name.substring(0, name.length - match.second.length)
        }

        /** The format and the ending that matched. The longest ending wins, so "a.tar.gz" is not just a gz. */
        private fun match(name: String): Pair<ArchiveFormat, String>? {
            val lower = name.lowercase()
            var best: Pair<ArchiveFormat, String>? = null
            for (format in values()) {
                for (suffix in format.suffixes) {
                    if (lower.length > suffix.length && lower.endsWith(suffix)) {
                        val current = best
                        if (current == null || suffix.length > current.second.length) best = format to suffix
                    }
                }
            }
            return best
        }
    }
}
