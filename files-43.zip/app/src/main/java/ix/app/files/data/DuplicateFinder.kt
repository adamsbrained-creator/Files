package ix.app.files.data

import androidx.compose.runtime.Immutable
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/** Files that look identical. [files] is sorted oldest first, so the first one is the likely original. */
@Immutable
class DuplicateGroup(val size: Long, val files: List<FileItem>) {
    /** Space that deleting every copy but one would give back. */
    val extraBytes: Long get() = size * (files.size - 1)
}

/**
 * Finds files that are the same. It works in three cheap-to-slow steps, so most files are never read:
 *
 * 1. Only files with exactly the same size can match.
 * 2. Of those, files whose content matches in three samples (the start, the middle and the end).
 * 3. Of those, files whose whole content matches. This is what makes it safe to delete the extras:
 *    a pair that differs only somewhere between the samples is told apart here.
 *
 * Names do not matter, so a renamed copy is found too. Call off the main thread. [active] is asked
 * between chunks; once it returns false the search stops and returns nothing.
 */
object DuplicateFinder {

    /** Files smaller than this are ignored: they are not worth the time, and many tiny files look alike. */
    const val MIN_BYTES = 100_000L

    private const val SAMPLE = 64 * 1024

    /** Groups of two or more identical files among [files], the group that wastes the most space first. */
    fun find(
        files: List<FileItem>,
        minBytes: Long = MIN_BYTES,
        active: () -> Boolean = { true },
    ): List<DuplicateGroup> {
        // Only a size that shows up more than once can have a twin, so everything else is skipped unread.
        val bySize = HashMap<Long, MutableList<FileItem>>()
        for (file in files) {
            if (file.sizeBytes >= minBytes) {
                bySize.getOrPut(file.sizeBytes) { ArrayList() }.add(file)
            }
        }

        val groups = ArrayList<DuplicateGroup>()
        for ((size, sameSize) in bySize) {
            if (sameSize.size < 2) continue
            val byPrint = HashMap<String, MutableList<FileItem>>()
            for (file in sameSize) {
                if (!active()) return emptyList()
                val print = fingerprint(File(file.path), size) ?: continue
                byPrint.getOrPut(print) { ArrayList() }.add(file)
            }
            for (candidates in byPrint.values) {
                if (candidates.size < 2) continue
                // A small file was read whole already, so the samples were the whole content.
                val confirmed: Collection<List<FileItem>> = if (size <= SAMPLE * 3L) {
                    listOf(candidates)
                } else {
                    val byContent = HashMap<String, MutableList<FileItem>>()
                    for (file in candidates) {
                        if (!active()) return emptyList()
                        val whole = wholeHash(File(file.path), active) ?: continue
                        byContent.getOrPut(whole) { ArrayList() }.add(file)
                    }
                    byContent.values
                }
                for (twins in confirmed) {
                    if (twins.size >= 2) {
                        val oldestFirst = twins.sortedWith(compareBy<FileItem> { it.modifiedMillis }.thenBy { it.path })
                        groups.add(DuplicateGroup(size, oldestFirst))
                    }
                }
            }
        }
        return groups.sortedByDescending { it.extraBytes }
    }

    /** A code for the whole content of [file], or null if it can not be read or the search was stopped. */
    private fun wholeHash(file: File, active: () -> Boolean): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(256 * 1024)
            java.io.FileInputStream(file).use { input ->
                while (true) {
                    if (!active()) return null
                    val read = input.read(buffer)
                    if (read < 0) break
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { byte -> "%02x".format(byte) }
        } catch (e: Exception) {
            null
        }
    }

    /** A short code for what is inside [file], or null if it can not be read. Small files are read whole. */
    private fun fingerprint(file: File, size: Long): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-1")
            val whole = size <= SAMPLE * 3L
            val offsets = if (whole) {
                listOf(0L)
            } else {
                listOf(0L, size / 2 - SAMPLE / 2, size - SAMPLE)
            }
            RandomAccessFile(file, "r").use { raf ->
                val buffer = ByteArray(SAMPLE)
                for (offset in offsets) {
                    raf.seek(offset)
                    var remaining = if (whole) size else SAMPLE.toLong()
                    while (remaining > 0) {
                        val read = raf.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                        if (read < 0) break
                        digest.update(buffer, 0, read)
                        remaining -= read
                    }
                }
            }
            digest.digest().joinToString("") { byte -> "%02x".format(byte) }
        } catch (e: Exception) {
            null
        }
    }
}
