package ix.app.files.data

import androidx.compose.runtime.Immutable
import java.io.File
import java.io.IOException
import java.nio.file.Files

/** One thing waiting in the Trash. */
@Immutable
class TrashItem(
    /** The folder of the delete this item came with. All its items share [deletedAt]. */
    val batch: File,
    /** Where the item lies now, inside [batch]. */
    val storedPath: String,
    /** The name it had before it was deleted. */
    val name: String,
    /** Where it was, or null when the note about it is gone. */
    val originalPath: String?,
    val deletedAt: Long,
    val isDirectory: Boolean,
    val bytes: Long,
)

/**
 * The Trash on disk. A delete puts its items into one folder (a "batch") with a small note beside them
 * that says where each came from and when they were deleted. Everything here is plain file work, so it can
 * be tested without a phone. Call off the main thread.
 *
 * Note format, one file per batch: a first line "ixtrash 1 <millis>", then one line per item,
 * "<name in the batch><TAB><original path>". Tabs, line breaks and backslashes inside names are escaped.
 */
object TrashStore {

    /** The note inside a batch folder. It starts with a dot, so it is never taken for an item. */
    const val INFO = ".ixinfo"

    private const val HEADER = "ixtrash 1"

    /**
     * Writes the note for a batch. [pairs] is what a delete returned: for every item (where it was, where it
     * is now), the second path being inside [batch]. Failing to write it is not fatal: the items are then
     * listed without a known origin.
     */
    fun record(batch: File, pairs: List<Pair<String, String>>, deletedAt: Long): Boolean {
        val text = StringBuilder()
        text.append(HEADER).append(' ').append(deletedAt).append('\n')
        for ((original, stored) in pairs) {
            text.append(escape(File(stored).name)).append('\t').append(escape(original)).append('\n')
        }
        return try {
            File(batch, INFO).writeText(text.toString())
            true
        } catch (e: IOException) {
            false
        }
    }

    /**
     * Everything waiting in the batch folders under [dirs], newest delete first. Items that are gone from
     * disk are left out. Sizes are added up here, so this can take a moment for big folders.
     */
    fun list(dirs: List<File>): List<TrashItem> {
        val items = ArrayList<TrashItem>()
        for (dir in dirs) {
            val batches = dir.listFiles() ?: continue
            for (batch in batches) {
                if (!batch.isDirectory) continue
                val note = readNote(batch)
                val deletedAt = note.deletedAt ?: batch.lastModified()
                val children = batch.listFiles() ?: continue
                for (child in children) {
                    if (child.name == INFO) continue
                    val original = note.origins[child.name]
                    items.add(
                        TrashItem(
                            batch = batch,
                            storedPath = child.path,
                            name = original?.let { File(it).name }?.ifEmpty { null } ?: child.name,
                            originalPath = original,
                            deletedAt = deletedAt,
                            isDirectory = child.isDirectory,
                            bytes = sizeOf(child),
                        ),
                    )
                }
            }
        }
        return items.sortedWith(compareByDescending<TrashItem> { it.deletedAt }.thenBy { it.name.lowercase() })
    }

    /**
     * The (where it lies now, where it should go) pairs that put [items] back. An item with no known origin
     * goes into [fallbackDir]. Feed the result to [FileOps.relocate], which picks a free name when needed.
     */
    fun restorePairs(items: List<TrashItem>, fallbackDir: File): List<Pair<String, String>> =
        items.map { it.storedPath to (it.originalPath ?: File(fallbackDir, it.name).path) }

    /**
     * Forgets items that left their batch (restored, or deleted): they are struck from the note, and the
     * batch folder goes when nothing else is left in it.
     */
    fun release(batch: File, storedPaths: Collection<String>) {
        if (!batch.isDirectory) return
        val gone = storedPaths.map { File(it).name }.toHashSet()
        val note = readNote(batch)
        val left = (batch.listFiles() ?: emptyArray()).filter { it.name != INFO && it.name !in gone }
        if (left.isEmpty()) {
            batch.deleteRecursively()
            return
        }
        val pairs = left.mapNotNull { child -> note.origins[child.name]?.let { it to child.path } }
        record(batch, pairs, note.deletedAt ?: batch.lastModified())
    }

    /** Deletes [items] for good, and strikes them from their notes. Returns how many are gone. */
    fun delete(items: List<TrashItem>, control: JobControl? = null): Int {
        var removed = 0
        for (item in items) {
            control?.check()
            val file = File(item.storedPath)
            val ok = !file.exists() || (if (file.isDirectory) deleteTree(file) else file.delete())
            if (ok) removed += 1
        }
        for ((batch, group) in items.groupBy { it.batch }) {
            release(batch, group.filter { !File(it.storedPath).exists() }.map { it.storedPath })
        }
        return removed
    }

    /** Throws away every batch that is older than [maxAgeMillis]. Returns how many batches went. */
    fun purgeOlderThan(dirs: List<File>, maxAgeMillis: Long, now: Long): Int {
        var removed = 0
        for (dir in dirs) {
            for (batch in dir.listFiles() ?: continue) {
                if (!batch.isDirectory) continue
                val deletedAt = readNote(batch).deletedAt ?: batch.lastModified()
                if (now - deletedAt >= maxAgeMillis && batch.deleteRecursively()) removed += 1
            }
        }
        return removed
    }

    /** Empties the Trash: every batch goes. The marker that keeps the gallery out stays. */
    fun clear(dirs: List<File>) {
        for (dir in dirs) {
            for (child in dir.listFiles() ?: continue) {
                if (child.name == ".nomedia") continue
                if (child.isDirectory) child.deleteRecursively() else child.delete()
            }
        }
    }

    private class Note(val deletedAt: Long?, val origins: Map<String, String>)

    private fun readNote(batch: File): Note {
        val file = File(batch, INFO)
        if (!file.isFile) return Note(null, emptyMap())
        val lines = try {
            file.readLines()
        } catch (e: IOException) {
            return Note(null, emptyMap())
        }
        val head = lines.firstOrNull()?.split(' ')
        val deletedAt = if (head != null && head.size == 3 && head[0] + " " + head[1] == HEADER) head[2].toLongOrNull() else null
        val origins = HashMap<String, String>()
        for (line in lines.drop(1)) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            origins[unescape(line.substring(0, tab))] = unescape(line.substring(tab + 1))
        }
        return Note(deletedAt, origins)
    }

    private fun sizeOf(file: File): Long {
        if (!file.isDirectory) return file.length()
        var total = 0L
        for (f in file.walkTopDown()) {
            if (f.isFile && !Files.isSymbolicLink(f.toPath())) total += f.length()
        }
        return total
    }

    /** Deletes a folder without following links out of it. */
    private fun deleteTree(dir: File): Boolean = dir.deleteRecursively()

    private fun escape(text: String): String =
        text.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r")

    private fun unescape(text: String): String {
        if (!text.contains('\\')) return text
        val out = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '\\' && i + 1 < text.length) {
                when (text[i + 1]) {
                    't' -> out.append('\t')
                    'n' -> out.append('\n')
                    'r' -> out.append('\r')
                    else -> out.append(text[i + 1])
                }
                i += 2
            } else {
                out.append(c)
                i++
            }
        }
        return out.toString()
    }
}
