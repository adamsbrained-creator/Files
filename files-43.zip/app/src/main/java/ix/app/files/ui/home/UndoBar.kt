package ix.app.files.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.UndoKind
import ix.app.files.data.UndoNotice
import ix.app.files.ui.theme.IxColors
import java.text.NumberFormat

/**
 * A small bar at the bottom that says what just happened ("Deleted 3 items") and offers Undo.
 * It stays for a few seconds. Tapping the text only closes it.
 */
@Composable
fun UndoBar(notice: UndoNotice, onUndo: () -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val plural = when (notice.kind) {
        UndoKind.Delete -> R.plurals.undo_deleted
        UndoKind.Move -> R.plurals.undo_moved
        UndoKind.Copy -> R.plurals.undo_copied
    }
    val message = context.resources.getQuantityString(
        plural,
        notice.count,
        NumberFormat.getIntegerInstance().format(notice.count),
    )
    val shape = RoundedCornerShape(20.dp)

    Box(
        Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(IxColors.Sheet)
                .border(1.dp, IxColors.SheetBorder, shape)
                .padding(start = 20.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = message,
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .weight(1f)
                    .clickable(role = Role.Button, onClick = onDismiss)
                    .padding(vertical = 16.dp),
            )
            Text(
                text = stringResource(R.string.undo_action),
                color = IxColors.Accent,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(role = Role.Button, onClick = onUndo)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }
    }
}
