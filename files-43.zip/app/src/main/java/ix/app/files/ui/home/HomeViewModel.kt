package ix.app.files.ui.home

import android.app.Application
import android.media.MediaScannerConnection
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ix.app.files.R
import ix.app.files.data.AppBackup
import ix.app.files.data.AppEntry
import ix.app.files.data.AppsLoader
import ix.app.files.data.ArchiveFormat
import ix.app.files.data.BatchRename
import ix.app.files.data.Category
import ix.app.files.data.CleanGroup
import ix.app.files.data.CleanerEngine
import ix.app.files.data.Clip
import ix.app.files.data.DuplicateFinder
import ix.app.files.data.DuplicateGroup
import ix.app.files.data.FavoritesStore
import ix.app.files.data.FileOps
import ix.app.files.data.FileItem
import ix.app.files.data.FileScanner
import ix.app.files.data.FileKind
import ix.app.files.data.FolderItem
import ix.app.files.data.FolderLister
import ix.app.files.data.HomeTab
import ix.app.files.data.JobControl
import ix.app.files.data.JobStopped
import ix.app.files.data.KindSize
import ix.app.files.data.Listing
import ix.app.files.data.RenameRule
import ix.app.files.data.ScanData
import ix.app.files.data.SearchEngine
import ix.app.files.data.SearchFilter
import ix.app.files.data.SearchResults
import ix.app.files.data.CanvasSpot
import ix.app.files.data.CustomFolder
import ix.app.files.data.SAVED_SEARCH_MAX
import ix.app.files.data.SavedSearch
import ix.app.files.data.orderKey
import ix.app.files.data.SavedSearchStore
import ix.app.files.data.FolderEditTarget
import ix.app.files.data.FolderStyle
import ix.app.files.data.FolderStyleStore
import ix.app.files.data.SettingsStore
import ix.app.files.data.SheetAnchor
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.data.StorageAccess
import ix.app.files.data.StorageReport
import ix.app.files.data.ThemeMode
import ix.app.files.data.Thumbnails
import ix.app.files.data.UndoKind
import ix.app.files.data.UndoNotice
import ix.app.files.data.TextFiles
import ix.app.files.data.TrashItem
import ix.app.files.data.TrashStore
import ix.app.files.data.Vault
import ix.app.files.data.VaultNames
import ix.app.files.data.ZipBrowser
import ix.app.files.data.sortedBySpec
import ix.app.files.data.sortedFoldersBySpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

data class HomeState(
    val tab: HomeTab = HomeTab.All,
    val sort: SortSpec = SortSpec(),
    /** True for the grid of tiles, false for the list. Applies to folders, categories, search and Favorites. */
    val grid: Boolean = false,
    val showHidden: Boolean = false,
    val sheet: SheetAnchor = SheetAnchor.Hidden,
    val hasAccess: Boolean = false,
    val scanning: Boolean = false,
    val scan: ScanData = ScanData.Empty,
    val counts: Map<Category, Int> = emptyMap(),
    val recent: List<FileItem> = emptyList(),
    val openCategory: Category? = null,
    val openFiles: List<FileItem> = emptyList(),

    /** True while the Storage screen is open. [report] is filled in a moment later. */
    val reportOpen: Boolean = false,
    val report: StorageReport? = null,

    /** What is typed in the search field. Anything but blank means search results replace the tabs. */
    val query: String = "",
    val results: SearchResults = SearchResults.Empty,
    /** What the search is narrowed to. A filter alone (no text) is a search too. */
    val filter: SearchFilter = SearchFilter.None,
    /** True while the Type / Size / Date chips are shown under the search field. */
    val filtersOpen: Boolean = false,

    /** True after the user proved it is them. Private locks again by itself, see [onForegrounded]. */
    val privateUnlocked: Boolean = false,
    /** How many items sit in the Private folder. Only known while it is unlocked. */
    val privateCount: Int = 0,

    /** Items waiting to be pasted into a folder of the browser. Null when nothing is being copied or moved. */
    val clip: Clip? = null,
    /** True while a copy, move or delete runs. The screen shows a blocking "Working…" card. */
    val busy: Boolean = false,
    /** What the Working card says: Copying…, Moving…, and so on. */
    val busyLabel: Int = R.string.busy_working,
    /** How far the running job is, from 0 to 1. Null while that is not known. */
    val busyProgress: Float? = null,
    /** True when the Working card offers a Cancel button. */
    val busyCancellable: Boolean = false,

    /** Paths of the files and folders ticked in selection mode. Empty means not selecting. */
    val selected: Set<String> = emptySet(),

    /** Paths of every favorite, saved on the device. */
    val favorites: Set<String> = emptySet(),

    /** What the user changed about each Home folder: name, color, icon. Missing means default. */
    val folderStyles: Map<Category, FolderStyle> = emptyMap(),
    /** Folders the user added to Home, in the order they were made. */
    val customFolders: List<CustomFolder> = emptyList(),
    /** What the folder editor is open for, or null while it is closed. */
    val folderEditor: FolderEditTarget? = null,
    /** The saved order of the Home tiles (see FolderStyleStore). Tiles missing from it go last. */
    val homeOrder: List<String> = emptyList(),
    /** Searches the user kept, in the order they were saved. */
    val savedSearches: List<SavedSearch> = emptyList(),
    /** True when Home shows the folders on a free canvas. */
    val homeFreeform: Boolean = true,
    /** Where the user dropped each tile on the canvas, by tile key. Tiles not in it sit in their default place. */
    val homeSpots: Map<String, CanvasSpot> = emptyMap(),
    /** Where a folder made from the canvas menu should land, until the editor closes. */
    val newFolderSpot: CanvasSpot? = null,
    /** True while the name box for a new file is open. */
    val newFilePrompt: Boolean = false,
    /** True while the Home folders can be dragged into a new order. */
    val arrangingHome: Boolean = false,
    /** The favorites that still exist, ready to show on the Favorites tab. */
    val favoriteFolders: List<FolderItem> = emptyList(),
    val favoriteFiles: List<FileItem> = emptyList(),

    /** The folder the browser shows, or null while the browser is closed. */
    val browserPath: String? = null,
    val browserLoading: Boolean = false,
    val browserFailed: Boolean = false,
    val browserFolders: List<FolderItem> = emptyList(),
    val browserFiles: List<FileItem> = emptyList(),

    /** The zip being looked into, or null while that screen is closed. [zipInner] is the folder inside it. */
    val zipPath: String? = null,
    val zipInner: String = "",
    val zipLoading: Boolean = false,
    val zipFailed: Boolean = false,
    val zipFolders: List<FolderItem> = emptyList(),
    val zipFiles: List<FileItem> = emptyList(),

    /** True while the Duplicates screen is open. [dupGroups] fills in once the search finishes. */
    val dupOpen: Boolean = false,
    val dupLoading: Boolean = false,
    val dupGroups: List<DuplicateGroup> = emptyList(),

    /** True while the Cleaner screen is open. [cleanGroups] fills in once the look-through finishes. */
    val cleanOpen: Boolean = false,
    val cleanLoading: Boolean = false,
    val cleanGroups: List<CleanGroup> = emptyList(),

    /** True while the Apps screen is open. [apps] fills in once the system has been asked. */
    val appsOpen: Boolean = false,
    val appsLoading: Boolean = false,
    val apps: List<AppEntry> = emptyList(),

    /** True while the Trash screen is open. [trashItems] fills in once the folders are read. */
    val trashOpen: Boolean = false,
    val trashLoading: Boolean = false,
    val trashItems: List<TrashItem> = emptyList(),
    /** Days deleted things are kept. Zero: gone when the Undo bar goes. */
    val trashDays: Int = 30,

    /** The pictures the full-screen viewer can swipe through. Empty while the viewer is closed. */
    val viewerImages: List<FileItem> = emptyList(),
    val viewerIndex: Int = 0,

    /** The Undo bar at the bottom. Null when there is nothing to take back. */
    val undo: UndoNotice? = null,
) {
    /** True when the search results, not the tabs, are what Home shows. */
    val searching: Boolean get() = query.isNotBlank() || filter.isActive
}

/** What Undo needs to put things back. */
private class PendingUndo(
    val kind: UndoKind,
    /** For every item: where it was, and where it is now. */
    val pairs: List<Pair<String, String>>,
    /** The trash folder of a delete. It is emptied for good once the Undo bar goes away. */
    val trash: File?,
    /** Favorites that went with a delete, so Undo can star them again. */
    val lostFavorites: List<String>,
)

/** What a delete did, handed from the worker thread back to the view model. */
private class Trashed(
    val batch: File,
    val pairs: List<Pair<String, String>>,
    val removed: List<String>,
    val cancelled: Boolean,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val scanner = FileScanner()
    private val favoritesStore = FavoritesStore(application)
    private val settingsStore = SettingsStore(application)
    private val folderStyleStore = FolderStyleStore(application)
    private val savedSearchStore = SavedSearchStore(application)
    private var scanJob: Job? = null
    private var sortJob: Job? = null
    private var favoritesJob: Job? = null
    private var browserJob: Job? = null
    private var browserSortJob: Job? = null
    private var searchJob: Job? = null
    private var reportJob: Job? = null
    private var zipJob: Job? = null
    private var dupJob: Job? = null
    private var cleanJob: Job? = null
    private var trashJob: Job? = null
    private var appsJob: Job? = null
    private var tickerJob: Job? = null
    private var activeJob: JobControl? = null
    private var lastScanAt = 0L
    private var scanGeneration = 0
    private var leftAt = 0L

    /** Private lives inside the app's own storage. Other apps and the gallery can not see it. */
    private val privateDir = File(application.filesDir, "private")
    val privateRootPath: String = privateDir.absolutePath

    /**
     * Deleted files wait here until the Undo bar goes away. It sits in the app's own folder on the same storage
     * as the files, so putting a file in it is an instant rename rather than a copy.
     */
    private val trashDir = File(application.getExternalFilesDir(null) ?: application.filesDir, ".trash")

    /**
     * Where a delete puts things when they sit on the main storage. It is on the same storage as the files, so
     * moving a file in is a rename that takes no time even for a 7 GB video. The app's own folder under
     * Android/data is guarded by the system, and moving a file into it can turn into a slow copy.
     */
    private val sharedTrashDir = File(StorageAccess.root(), ".ixtrash")

    /** Both places a delete can put things. The Trash screen reads them together. */
    private val trashDirs: List<File> get() = listOf(sharedTrashDir, trashDir)

    private fun trashKeepMillis(days: Int): Long = days * 24L * 60 * 60 * 1000
    /** Unlocked copies of Private files, made for opening and sharing. Wiped when Private locks. */
    private val viewDir = File(application.cacheDir, "private-view")

    /** The one-time locking of old Private files after an unlock. Anything that writes into Private waits for it. */
    private var vaultPrep: Job? = null

    private var pendingUndo: PendingUndo? = null
    private var undoTimer: Job? = null

    /** Files taken out of a zip for opening live here. Emptied whenever a zip is opened or closed. */
    private val zipPreviewDir = File(application.cacheDir, "zip-preview")

    /** Every line of the zip being looked into, kept so walking between its folders needs no disk read. */
    @Volatile
    private var zipIndex: List<ZipBrowser.Entry> = emptyList()

    /** The unsorted contents of the folder in the browser, kept so a new sort needs no disk read. */
    @Volatile
    private var browserListing: Listing? = null

    private val _state = MutableStateFlow(
        settingsStore.load().let { settings ->
            HomeState(
                hasAccess = StorageAccess.hasAccess(application),
                favorites = favoritesStore.load(),
                folderStyles = folderStyleStore.load(),
                customFolders = folderStyleStore.loadCustom(),
                homeOrder = folderStyleStore.loadOrder(),
                homeSpots = folderStyleStore.loadSpots(),
                homeFreeform = settings.freeform,
                savedSearches = savedSearchStore.load(),
                sort = settings.sort,
                grid = settings.grid,
                showHidden = settings.showHidden,
                trashDays = settings.trashDays,
            )
        },
    )
    val state: StateFlow<HomeState> = _state.asStateFlow()

    /**
     * True while something from Private is on screen. The activity then blocks screenshots and hides the
     * window in the Recent apps screen, so private files never show up there.
     */
    val secureScreen: StateFlow<Boolean> = _state
        .map { s ->
            s.privateUnlocked && (
                s.tab == HomeTab.Private ||
                    s.browserPath?.let { isPrivatePath(it) } == true ||
                    s.zipPath?.let { isPrivatePath(it) } == true
                )
        }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    // The welcome pages show once, on a fresh install. A phone that already gave file access has used the app
    // before this existed, so it never sees them.
    private val _showWelcome = MutableStateFlow(
        !settingsStore.welcomeSeen() && !StorageAccess.hasAccess(application),
    )
    val showWelcome: StateFlow<Boolean> = _showWelcome.asStateFlow()

    /** The user finished or skipped the welcome pages. */
    fun finishWelcome() {
        settingsStore.saveWelcomeSeen()
        _showWelcome.value = false
    }

    private val _themeMode = MutableStateFlow(settingsStore.load().theme)

    /** Kept apart from [state] so the activity can follow it without redrawing for every scan update. */
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    /** Light, dark, or follow the phone. Remembered. */
    fun setThemeMode(mode: ThemeMode) {
        settingsStore.saveTheme(mode)
        _themeMode.value = mode
    }

    private val _events = MutableSharedFlow<Int>(extraBufferCapacity = 4)

    /** One-off messages for the user, as string resource ids. The screen shows them as toasts. */
    val events: SharedFlow<Int> = _events.asSharedFlow()

    init {
        Vault.configure(privateDir)
        // The Trash keeps deleted things for the chosen number of days; what is older goes now.
        viewModelScope.launch(Dispatchers.IO) {
            TrashStore.purgeOlderThan(trashDirs, trashKeepMillis(_state.value.trashDays), System.currentTimeMillis())
            viewDir.deleteRecursively()
        }
        if (_state.value.hasAccess) {
            startScan()
            resolveFavorites()
        }
    }

    /** Call when the app comes back to the front, and after the user answers the permission prompt. */
    fun refreshAccess() {
        // Coming back from uninstalling an app: the list changed.
        if (_state.value.appsOpen) loadApps()
        val granted = StorageAccess.hasAccess(getApplication())
        _state.update { it.copy(hasAccess = granted) }
        if (!granted) return
        val neverScanned = lastScanAt == 0L
        val stale = SystemClock.elapsedRealtime() - lastScanAt > RESCAN_AFTER_MS
        if (scanJob?.isActive != true && (neverScanned || stale)) startScan()
        // Files may have changed while the app was in the background.
        resolveFavorites()
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    fun selectTab(tab: HomeTab) {
        _state.update { it.copy(tab = tab, selected = emptySet(), arrangingHome = false) }
    }

    fun setSheet(anchor: SheetAnchor) {
        _state.update { it.copy(sheet = anchor) }
    }

    fun selectSort(field: SortField) {
        _state.update {
            val spec = it.sort.select(field)
            it.copy(sort = spec, recent = it.scan.recent.sortedBySpec(spec))
        }
        settingsStore.saveSort(_state.value.sort)
        sortOpenFiles()
        resortBrowser()
    }

    /** List or grid. Remembered. */
    fun setGrid(grid: Boolean) {
        settingsStore.saveGrid(grid)
        _state.update { it.copy(grid = grid) }
    }

    /** Shows or hides files and folders whose names start with a dot, in the folder browser. */
    fun setShowHidden(show: Boolean) {
        settingsStore.saveShowHidden(show)
        _state.update { it.copy(showHidden = show) }
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    // ---- Home folders (Downloads, Images, ...) ----

    fun openCategory(category: Category) {
        _state.update { it.copy(openCategory = category, openFiles = emptyList(), selected = emptySet()) }
        sortOpenFiles()
    }

    fun closeCategory() {
        sortJob?.cancel()
        _state.update { it.copy(openCategory = null, openFiles = emptyList(), selected = emptySet()) }
    }

    // ---- Home folder looks ----

    fun openFolderEditor(target: FolderEditTarget) {
        _state.update { it.copy(folderEditor = target) }
    }

    /** Closes the editor and lets the Home folders be dragged into a new order. */
    fun startArranging() {
        _state.update { it.copy(folderEditor = null, arrangingHome = true) }
    }

    fun stopArranging() {
        _state.update { it.copy(arrangingHome = false) }
    }

    /** Saves the order of the Home tiles after a drag. */
    fun setHomeOrder(order: List<String>) {
        folderStyleStore.saveOrder(order)
        _state.update { it.copy(homeOrder = order) }
    }

    fun closeFolderEditor() {
        _state.update { it.copy(folderEditor = null, newFolderSpot = null) }
    }

    fun setHomeFreeform(freeform: Boolean) {
        settingsStore.saveFreeform(freeform)
        _state.update { it.copy(homeFreeform = freeform) }
    }

    /** Remembers where the user dropped a tile on the canvas. */
    fun setHomeSpot(key: String, spot: CanvasSpot) {
        val next = _state.value.homeSpots + (key to spot)
        folderStyleStore.saveSpots(next)
        _state.update { it.copy(homeSpots = next) }
    }

    /** Opens the new folder editor from the canvas menu; the folder will land at [spot]. */
    fun startNewFolderAt(spot: CanvasSpot) {
        _state.update { it.copy(folderEditor = FolderEditTarget.New, newFolderSpot = spot) }
    }

    fun promptNewFile(show: Boolean) {
        _state.update { it.copy(newFilePrompt = show) }
    }

    /** Makes an empty text file in the main storage and opens it for writing. */
    fun createTextFile(name: String) {
        _state.update { it.copy(newFilePrompt = false) }
        val clean = name.trim()
        if (clean.isEmpty() || clean.contains('/') || clean == "." || clean == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        viewModelScope.launch {
            val created = withContext(Dispatchers.IO) {
                var target = File(StorageAccess.root(), clean)
                if (target.exists()) {
                    val dot = clean.lastIndexOf('.').takeIf { it > 0 } ?: clean.length
                    var n = 2
                    while (target.exists()) {
                        target = File(StorageAccess.root(), clean.substring(0, dot) + " " + n + clean.substring(dot))
                        n++
                    }
                }
                try {
                    if (target.createNewFile()) target else null
                } catch (e: java.io.IOException) {
                    null
                }
            }
            if (created == null) {
                _events.tryEmit(R.string.folder_failed)
            } else {
                startScan()
                openText(created.absolutePath)
            }
        }
    }

    /** Copies files picked in the system file picker into the Downloads folder. */
    fun importFiles(uris: List<android.net.Uri>) {
        if (uris.isEmpty()) return
        val resolver = getApplication<Application>().contentResolver
        viewModelScope.launch {
            val copied = withContext(Dispatchers.IO) {
                val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var count = 0
                for (uri in uris) {
                    try {
                        val name = resolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
                            ?.replace('/', '_')
                            ?.takeIf { it.isNotBlank() } ?: "imported"
                        val dot = name.lastIndexOf('.').takeIf { it > 0 } ?: name.length
                        var target = File(dir, name)
                        var n = 2
                        while (target.exists()) {
                            target = File(dir, name.substring(0, dot) + " " + n + name.substring(dot))
                            n++
                        }
                        resolver.openInputStream(uri)?.use { input ->
                            target.outputStream().use { output -> input.copyTo(output) }
                            count++
                        }
                    } catch (e: Exception) {
                        // This file is skipped; the others still copy.
                    }
                }
                count
            }
            _events.tryEmit(if (copied > 0) R.string.import_done else R.string.import_failed)
            if (copied > 0) startScan()
        }
    }

    /** Saves a new look for one built-in Home folder. A style with nothing changed goes back to the default. */
    fun setFolderStyle(category: Category, style: FolderStyle) {
        folderStyleStore.save(category, style)
        _state.update {
            val next = if (style.isDefault) it.folderStyles - category else it.folderStyles + (category to style)
            it.copy(folderStyles = next, folderEditor = null)
        }
    }

    /**
     * Adds a folder to Home. The folder is made on the main storage, or reused if one with that name is already
     * there, and the tile gets the chosen look.
     */
    fun createCustomFolder(style: FolderStyle) {
        val clean = style.name?.trim().orEmpty()
        if (clean.isEmpty() || clean.contains('/') || clean == "." || clean == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val target = File(StorageAccess.root(), clean)
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { target.isDirectory || (!target.exists() && target.mkdir()) }
            if (!ok) {
                _events.tryEmit(R.string.folder_failed)
                return@launch
            }
            val folder = CustomFolder(System.currentTimeMillis().toString(), target.absolutePath, style.copy(name = clean))
            val next = _state.value.customFolders + folder
            folderStyleStore.saveCustom(next)
            val spot = _state.value.newFolderSpot
            val spots = if (spot != null) _state.value.homeSpots + (folder.orderKey() to spot) else _state.value.homeSpots
            if (spot != null) folderStyleStore.saveSpots(spots)
            _state.update { it.copy(customFolders = next, homeSpots = spots, folderEditor = null, newFolderSpot = null) }
        }
    }

    /** Changes the look of a folder the user added. The folder on the storage keeps its own name. */
    fun updateCustomFolder(id: String, style: FolderStyle) {
        val next = _state.value.customFolders.map { if (it.id == id) it.copy(style = style) else it }
        folderStyleStore.saveCustom(next)
        _state.update { it.copy(customFolders = next, folderEditor = null) }
    }

    /** Takes the tile off Home. The folder and its files stay where they are. */
    fun removeCustomFolder(id: String) {
        val next = _state.value.customFolders.filterNot { it.id == id }
        folderStyleStore.saveCustom(next)
        _state.update { it.copy(customFolders = next, folderEditor = null) }
    }

    // ---- Selection and actions ----

    /** Ticks or unticks one item. The first tick starts selection mode, the last untick ends it. */
    fun toggleSelect(path: String) {
        _state.update {
            val now = it.selected
            it.copy(selected = if (path in now) now - path else now + path)
        }
    }

    fun clearSelection() {
        _state.update { if (it.selected.isEmpty()) it else it.copy(selected = emptySet()) }
    }

    /** If everything selected is already a favorite, removes them all. Otherwise adds them all. */
    fun toggleFavoriteSelected() {
        val chosen = _state.value.selected.filter { !isPrivatePath(it) }.toSet()
        if (chosen.isEmpty()) {
            clearSelection()
            return
        }
        val current = _state.value.favorites
        val next = if (chosen.all { it in current }) current - chosen else current + chosen
        favoritesStore.save(next)
        _state.update { it.copy(favorites = next, selected = emptySet()) }
        resolveFavorites()
    }

    /** Puts the one selected folder on Home, or takes it off if it is there already. The folder itself is untouched. */
    fun toggleHomeFolderSelected() {
        val path = _state.value.selected.singleOrNull()
        if (path == null || isPrivatePath(path) || !File(path).isDirectory) {
            clearSelection()
            return
        }
        val current = _state.value.customFolders
        val existing = current.firstOrNull { it.path == path }
        val next = if (existing != null) {
            current - existing
        } else {
            current + CustomFolder(System.currentTimeMillis().toString(), path, FolderStyle())
        }
        folderStyleStore.saveCustom(next)
        _state.update { it.copy(customFolders = next, selected = emptySet()) }
        _events.tryEmit(if (existing != null) R.string.unpinned_home else R.string.pinned_home)
    }

    /** Renames the one selected item. [newName] is the full new name, extension included. */
    fun renameSelected(newName: String) {
        val path = _state.value.selected.singleOrNull() ?: return
        val name = newName.trim()
        if (name.isEmpty() || name.contains('/') || name == "." || name == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val old = File(path)
        val target = try {
            File(old.parentFile, VaultNames.storedName(old.parentFile, name))
        } catch (e: Exception) {
            _events.tryEmit(R.string.rename_failed)
            return
        }
        if (target.path == old.path) {
            clearSelection()
            return
        }
        viewModelScope.launch {
            val renamed = withContext(Dispatchers.IO) {
                val ok = !target.exists() && old.renameTo(target)
                if (ok) MediaScannerConnection.scanFile(getApplication(), arrayOf(old.path, target.path), null, null)
                ok
            }
            if (!renamed) {
                _events.tryEmit(R.string.rename_failed)
                return@launch
            }
            val favorites = _state.value.favorites
            val nextFavorites = if (old.path in favorites) favorites - old.path + target.path else favorites
            if (nextFavorites != favorites) favoritesStore.save(nextFavorites)
            _state.update { it.copy(favorites = nextFavorites, selected = emptySet()) }
            reloadAfterChange()
            startScan()
        }
    }

    /** Renames all selected items by [rule]. Items that cannot be renamed are skipped and reported. */
    fun renameBatch(rule: RenameRule) {
        val files = _state.value.selected.map { File(it) }
        if (files.size < 2) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_renaming)
        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                val rows = BatchRename.preview(files, rule)
                val result = BatchRename.apply(rows, job)
                if (result.moved.isNotEmpty()) {
                    MediaScannerConnection.scanFile(
                        getApplication(),
                        (result.moved.keys + result.moved.values).toTypedArray(),
                        null,
                        null,
                    )
                }
                result to rows.count { it.problem != null }
            }
            val (result, blocked) = outcome
            val favorites = _state.value.favorites
            val nextFavorites = favorites.map { result.moved[it] ?: it }.toSet()
            if (nextFavorites != favorites) {
                favoritesStore.save(nextFavorites)
                _state.update { it.copy(favorites = nextFavorites) }
            }
            _events.tryEmit(
                when {
                    job.cancelled -> R.string.job_cancelled
                    result.failed > 0 || blocked > 0 -> R.string.batch_rename_partial
                    else -> R.string.batch_rename_done
                },
            )
            endJob()
            reloadAfterChange()
            startScan()
        }
    }

    /**
     * Shows the Working card for a job that reports progress and can be stopped, and returns the object the
     * job reports to. Call [endJob] when it is over.
     */
    private fun beginJob(label: Int, cancellable: Boolean = true): JobControl {
        val job = JobControl()
        activeJob = job
        tickerJob?.cancel()
        _state.update { it.copy(busy = true, busyLabel = label, busyProgress = null, busyCancellable = cancellable) }
        tickerJob = viewModelScope.launch {
            while (true) {
                delay(200)
                val total = job.totalBytes
                // Whole percents only, so the screen is not redrawn for nothing.
                val percent = if (total > 0L) ((job.done * 100L) / total).toInt().coerceIn(0, 100) else -1
                val progress = if (percent >= 0) percent / 100f else null
                if (_state.value.busyProgress != progress) _state.update { it.copy(busyProgress = progress) }
            }
        }
        return job
    }

    /** Hides the Working card again. */
    private fun endJob() {
        tickerJob?.cancel()
        tickerJob = null
        activeJob = null
        _state.update {
            it.copy(busy = false, busyLabel = R.string.busy_working, busyProgress = null, busyCancellable = false)
        }
    }

    /** The Cancel button of the Working card. The job stops at its next small step. */
    fun cancelBusyJob() {
        activeJob?.cancel()
    }

    /**
     * Deletes everything selected. Folders go with all that is inside them. The screen asks first.
     * What is outside Private goes to the trash first, so the Undo bar can bring it back.
     */
    fun deleteSelected() {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_deleting)
        val favoritesBefore = _state.value.favorites
        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                val keep = paths.filter { !isPrivatePath(it) }
                // Files on the main storage go to a trash on that same storage, so this is a rename.
                val rootPrefix = StorageAccess.root().absolutePath + "/"
                val onMain = keep.isNotEmpty() && keep.all { it.startsWith(rootPrefix) }
                var trash = if (onMain) sharedTrashDir else trashDir
                // The folder's name is the time, so batches stay apart for as long as the Trash keeps them.
                val stamp = "t" + System.currentTimeMillis()
                var batch = File(trash, stamp)
                if (keep.isNotEmpty() && !batch.mkdirs() && trash == sharedTrashDir) {
                    trash = trashDir
                    batch = File(trash, stamp)
                    batch.mkdirs()
                }
                var pairs: List<Pair<String, String>> = emptyList()
                var cancelled = false
                if (keep.isNotEmpty() && batch.isDirectory) {
                    try {
                        File(trash, ".nomedia").createNewFile()
                    } catch (e: IOException) {
                        // Only keeps the gallery out of the trash. Nothing breaks without it.
                    }
                    try {
                        pairs = FileOps.renameInto(batch, keep, job)
                    } catch (e: JobStopped) {
                        cancelled = true
                    }
                    if (cancelled) {
                        // Whatever was renamed is put straight back.
                        FileOps.relocate(pairs.map { it.second to it.first })
                        pairs = emptyList()
                    } else if (pairs.isNotEmpty()) {
                        // The note says where each item came from, for the Trash screen.
                        TrashStore.record(batch, pairs, System.currentTimeMillis())
                    }
                }
                if (!cancelled) {
                    // Whatever could not go to the trash (and everything in Private) is deleted outright.
                    val trashed = pairs.map { it.first }.toHashSet()
                    for (path in paths) {
                        if (path in trashed) continue
                        val file = File(path)
                        if (file.isDirectory) file.deleteRecursively() else file.delete()
                    }
                }
                MediaScannerConnection.scanFile(getApplication(), paths.toTypedArray(), null, null)
                if (pairs.isEmpty()) batch.deleteRecursively()
                Trashed(batch, pairs, paths.filter { !File(it).exists() }, cancelled)
            }
            if (outcome.cancelled) {
                _events.tryEmit(R.string.job_cancelled)
            } else if (outcome.removed.size < paths.size) {
                _events.tryEmit(R.string.delete_failed)
            }
            if (outcome.pairs.isNotEmpty()) {
                val lost = favoritesBefore.filter { fav ->
                    outcome.removed.any { gone -> fav == gone || fav.startsWith("$gone/") }
                }
                offerUndo(PendingUndo(UndoKind.Delete, outcome.pairs, outcome.batch, lost))
            }
            applyRemoved(outcome.removed)
        }
    }

    // ---- Undo ----

    /** Puts the Undo bar up for the action that just finished. A bar that was still up is settled first. */
    private fun offerUndo(pending: PendingUndo) {
        finishUndo()
        pendingUndo = pending
        _state.update { it.copy(undo = UndoNotice(pending.kind, pending.pairs.size)) }
        undoTimer = viewModelScope.launch {
            delay(UNDO_MS)
            finishUndo()
        }
    }

    /** The Undo bar was dismissed or ran out: what waits in the trash is deleted for good. */
    fun finishUndo() {
        undoTimer?.cancel()
        undoTimer = null
        val pending = pendingUndo ?: return
        pendingUndo = null
        _state.update { it.copy(undo = null) }
        // With the Trash switched off, what waited for Undo goes now. Otherwise it stays in the Trash screen.
        val trash = pending.trash
        if (trash != null && _state.value.trashDays == 0) viewModelScope.launch(Dispatchers.IO) { trash.deleteRecursively() }
    }

    /** The Undo button: puts the last delete, move or copy back the way it was. */
    fun undoLast() {
        val pending = pendingUndo ?: return
        pendingUndo = null
        undoTimer?.cancel()
        undoTimer = null
        _state.update { it.copy(undo = null) }
        val job = beginJob(R.string.busy_restoring, cancellable = false)
        viewModelScope.launch {
            val restored = withContext(Dispatchers.IO) {
                awaitVault()
                val back: List<Pair<String, String>> = if (pending.kind == UndoKind.Copy) {
                    // The copies are new files that this app made, so taking them away loses nothing.
                    for (pair in pending.pairs) {
                        val copy = File(pair.second)
                        if (copy.isDirectory) copy.deleteRecursively() else copy.delete()
                    }
                    emptyList()
                } else {
                    FileOps.relocate(pending.pairs.map { pair -> pair.second to pair.first }, job)
                }
                val touched = ArrayList<String>()
                touched.addAll(FileOps.filesUnder(back.map { it.second }))
                touched.addAll(pending.pairs.map { it.second })
                MediaScannerConnection.scanFile(getApplication(), touched.toTypedArray(), null, null)
                back
            }
            if (pending.kind != UndoKind.Copy && restored.size < pending.pairs.size) {
                _events.tryEmit(R.string.undo_failed)
            }
            val trash = pending.trash
            if (trash != null) {
                // What came back is struck off the Trash. Anything that did not stays there (or goes, if the Trash is off).
                val keepNothing = _state.value.trashDays == 0
                viewModelScope.launch(Dispatchers.IO) {
                    TrashStore.release(trash, restored.map { it.first })
                    if (keepNothing) trash.deleteRecursively()
                }
            }

            if (pending.kind == UndoKind.Copy) {
                applyRemoved(pending.pairs.map { it.second })
                return@launch
            }
            var favorites = _state.value.favorites
            if (pending.kind == UndoKind.Delete) {
                favorites = favorites + pending.lostFavorites.filter { File(it).exists() }
            } else {
                // A moved favorite goes back with the move.
                for ((from, actual) in restored) {
                    favorites = favorites.map { FileOps.remap(it, from, actual) ?: it }.toSet()
                }
            }
            if (favorites != _state.value.favorites) favoritesStore.save(favorites)
            endJob()
            _state.update { it.copy(favorites = favorites) }
            reloadAfterChange()
            refreshPrivateCount()
            startScan()
        }
    }

    /**
     * Drops items that are gone from the lists and from Favorites right away, instead of scanning
     * everything again, and ends the "Working…" card.
     */
    private suspend fun applyRemoved(removed: List<String>) {
        val pruned = withContext(Dispatchers.Default) { withoutPaths(_state.value.scan, removed) }
        val favorites = _state.value.favorites
        val kept = favorites.filterNot { fav ->
            removed.any { gone -> fav == gone || fav.startsWith("$gone/") }
        }.toSet()
        if (kept.size != favorites.size) favoritesStore.save(kept)
        val removedExact = removed.toHashSet()
        val removedPrefixes = removed.map { "$it/" }
        val isGone: (String) -> Boolean = { p -> p in removedExact || removedPrefixes.any { prefix -> p.startsWith(prefix) } }
        _state.update {
            it.copy(
                scan = pruned,
                counts = pruned.byCategory.mapValues { entry -> entry.value.size },
                recent = pruned.recent.sortedBySpec(it.sort),
                favorites = kept,
                // A group with only one file left is no longer a duplicate, so it drops out.
                dupGroups = it.dupGroups.mapNotNull { group ->
                    val left = group.files.filterNot { file -> isGone(file.path) }
                    if (left.size >= 2) DuplicateGroup(group.size, left) else null
                },
                viewerImages = it.viewerImages.filterNot { file -> isGone(file.path) },
                cleanGroups = it.cleanGroups.mapNotNull { group ->
                    val files = group.files.filterNot { file -> isGone(file.path) }
                    val folders = group.folders.filterNot { folder -> isGone(folder.path) }
                    if (files.isEmpty() && folders.isEmpty()) null else CleanGroup(group.kind, files, folders)
                },
            )
        }
        endJob()
        sortOpenFiles()
        reloadAfterChange()
        if (_state.value.reportOpen) computeReport()
    }

    /** Copy or Move was tapped: remember the selection and let the user pick a folder in the browser. */
    fun startClip(move: Boolean) {
        val paths = _state.value.selected.toList()
        if (paths.isEmpty()) return
        _state.update { it.copy(clip = Clip(paths, move), selected = emptySet()) }
        // Copying out of Private starts at the top of storage, since that is where things go.
        val current = _state.value.browserPath
        if (current == null || isPrivatePath(current)) openStorage()
    }

    fun cancelClip() {
        _state.update { it.copy(clip = null) }
    }

    /** Pastes the waiting items into the folder the browser is showing. */
    fun pasteHere() {
        val clip = _state.value.clip ?: return
        val dest = _state.value.browserPath ?: return
        val job = beginJob(if (clip.move) R.string.busy_moving else R.string.busy_copying)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                awaitVault()
                val outcome = FileOps.paste(File(dest), clip.paths, clip.move, job)
                val touched = ArrayList<String>()
                touched.addAll(FileOps.filesUnder(outcome.done.map { it.second } + outcome.leftover))
                if (clip.move) touched.addAll(clip.paths)
                if (touched.isNotEmpty()) {
                    MediaScannerConnection.scanFile(getApplication(), touched.toTypedArray(), null, null)
                }
                outcome
            }
            if (result.cancelled) _events.tryEmit(R.string.job_cancelled)
            if (result.skipped > 0) _events.tryEmit(R.string.paste_skipped)
            if (result.failed > 0) _events.tryEmit(R.string.paste_failed)
            if (result.leftover.isNotEmpty()) _events.tryEmit(R.string.paste_original_stays)

            // A moved favorite stays a favorite at its new place.
            var favorites = _state.value.favorites
            if (clip.move) {
                for ((from, to) in result.done) {
                    favorites = favorites.map { FileOps.remap(it, from, to) ?: it }.toSet()
                }
                if (favorites != _state.value.favorites) favoritesStore.save(favorites)
            }
            endJob()
            _state.update { it.copy(clip = null, favorites = favorites) }
            if (result.done.isNotEmpty()) {
                offerUndo(PendingUndo(if (clip.move) UndoKind.Move else UndoKind.Copy, result.done, null, emptyList()))
            }
            reloadAfterChange()
            if (result.done.isNotEmpty() || result.leftover.isNotEmpty()) startScan()
        }
    }

    /** Creates a folder inside the folder the browser is showing. */
    fun createFolder(name: String) {
        val dir = _state.value.browserPath ?: return
        val clean = name.trim()
        if (clean.isEmpty() || clean.contains('/') || clean == "." || clean == "..") {
            _events.tryEmit(R.string.rename_invalid)
            return
        }
        val target = try {
            File(dir, VaultNames.storedName(File(dir), clean))
        } catch (e: Exception) {
            _events.tryEmit(R.string.folder_failed)
            return
        }
        viewModelScope.launch {
            val created = withContext(Dispatchers.IO) { !target.exists() && target.mkdir() }
            if (created) loadBrowser(dir) else _events.tryEmit(R.string.folder_failed)
        }
    }

    // ---- Zip ----

    /** Packs the selection into one zip file, next to the first selected item. */
    fun compressSelected() {
        // Zipping reads the files as they are stored, which for Private is locked, so Private is left out.
        val paths = _state.value.selected.filter { !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_compressing)
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val sources = paths.map { File(it) }.filter { it.exists() }
                val first = sources.firstOrNull() ?: return@withContext false
                val folder = first.parentFile ?: return@withContext false
                val baseName = if (sources.size == 1) first.nameWithoutExtension.ifEmpty { first.name } else "Archive"
                val target = FileOps.uniqueTarget(folder, "$baseName.zip")
                val made = FileOps.zip(sources, target, job)
                if (made) MediaScannerConnection.scanFile(getApplication(), arrayOf(target.path), null, null)
                made
            }
            _events.tryEmit(
                when {
                    ok -> R.string.compress_done
                    job.cancelled -> R.string.job_cancelled
                    else -> R.string.compress_failed
                },
            )
            endJob()
            reloadAfterChange()
            if (ok) startScan()
        }
    }

    /** Unpacks each selected zip into a new folder named after it, next to it. */
    fun extractSelected() = extractPaths(_state.value.selected.toList())

    /** Same, for zips named directly, such as the one tapped in a list. Other files are skipped. */
    fun extractPaths(requested: List<String>) {
        val paths = requested.filter { ArchiveFormat.of(File(it).name) != null && !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_extracting)
        viewModelScope.launch {
            val failed = withContext(Dispatchers.IO) {
                var count = 0
                job.totalBytes = paths.sumOf { File(it).length() }
                for (path in paths) {
                    if (job.cancelled) break
                    val zip = File(path)
                    val folder = zip.parentFile
                    if (folder == null || !zip.isFile) {
                        count++
                        continue
                    }
                    val dest = FileOps.uniqueTarget(folder, ArchiveFormat.baseName(zip.name).ifEmpty { "Extracted" })
                    val unpacked = FileOps.unpack(zip, dest, job)
                    if (!unpacked) {
                        // Do not leave half an extracted folder behind, whether it was cancelled or failed.
                        dest.deleteRecursively()
                        if (job.cancelled) break
                        count++
                        continue
                    }
                    val made = FileOps.filesUnder(listOf(dest.path))
                    if (made.isNotEmpty()) MediaScannerConnection.scanFile(getApplication(), made.toTypedArray(), null, null)
                }
                count
            }
            _events.tryEmit(
                when {
                    job.cancelled -> R.string.job_cancelled
                    failed > 0 -> R.string.extract_failed
                    else -> R.string.extract_done
                },
            )
            endJob()
            reloadAfterChange()
            startScan()
        }
    }

    // ---- Duplicates ----

    /** Opens the Duplicates screen and searches the last scan for identical files. */
    fun openDuplicates() {
        dupJob?.cancel()
        val files = _state.value.scan.files
        _state.update { it.copy(dupOpen = true, dupLoading = true, dupGroups = emptyList(), selected = emptySet()) }
        dupJob = viewModelScope.launch(Dispatchers.IO) {
            val groups = DuplicateFinder.find(files, active = { isActive })
            _state.update { if (it.dupOpen) it.copy(dupLoading = false, dupGroups = groups) else it }
        }
    }

    fun closeDuplicates() {
        dupJob?.cancel()
        _state.update { it.copy(dupOpen = false, dupLoading = false, dupGroups = emptyList(), selected = emptySet()) }
    }

    /** Ticks every copy except the oldest of each group, so one tap on Delete clears the extras. */
    fun selectDuplicateExtras() {
        val extras = _state.value.dupGroups.flatMap { group -> group.files.drop(1).map { it.path } }.toSet()
        _state.update { it.copy(selected = extras) }
    }

    // ---- Text reader and editor ----

    private val _textDoc = MutableStateFlow<TextDoc?>(null)
    val textDoc: StateFlow<TextDoc?> = _textDoc

    /** What is typed in the editor right now. Only the view model holds it, so typing never redraws the app. */
    private var textDraft = ""
    private var textJob: Job? = null

    /** What the editor should start from: unsaved typing if there is any, otherwise the saved text. */
    fun currentDraft(): String = textDraft

    /** Opens [path] in the reader. A file in Private is read and saved in place, locked, with no readable copy. */
    fun openText(path: String) {
        val name = if (isPrivatePath(path)) VaultNames.plainName(File(path)) else File(path).name
        _state.update { if (it.selected.isEmpty()) it else it.copy(selected = emptySet()) }
        textDraft = ""
        _textDoc.value = TextDoc(path = path, name = name)
        textJob?.cancel()
        textJob = viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                awaitVault()
                TextFiles.load(File(path))
            }
            val decoded = loaded.decoded
            textDraft = decoded?.text.orEmpty()
            _textDoc.update { doc ->
                if (doc == null || doc.path != path) {
                    doc
                } else {
                    doc.copy(
                        loading = false,
                        problem = loaded.problem,
                        text = decoded?.text.orEmpty(),
                        sizeBytes = loaded.sizeBytes,
                        crlf = decoded?.crlf ?: false,
                        bom = decoded?.bom ?: false,
                        readOnlyReason = when {
                            decoded == null -> null
                            !decoded.editable -> R.string.text_read_only_encoding
                            loaded.sizeBytes > TextFiles.MAX_EDIT_BYTES -> R.string.text_read_only_big
                            else -> null
                        },
                    )
                }
            }
        }
    }

    fun closeText() {
        textJob?.cancel()
        textDraft = ""
        _textDoc.value = null
    }

    fun startEditing() {
        val doc = _textDoc.value ?: return
        if (!doc.canEdit) return
        textDraft = doc.text
        _textDoc.value = doc.copy(editing = true, dirty = false, session = doc.session + 1)
    }

    /** Called with the whole text after every change in the editor. */
    fun onTextEdited(text: String) {
        textDraft = text
        _textDoc.update { cur ->
            val differs = cur != null && text != cur.text
            if (cur == null || cur.dirty == differs) cur else cur.copy(dirty = differs)
        }
    }

    /** Leaves the editor without saving, and forgets what was typed. */
    fun discardEdits() {
        val doc = _textDoc.value ?: return
        textDraft = doc.text
        _textDoc.value = doc.copy(editing = false, dirty = false, session = doc.session + 1)
    }

    /** Leaves the editor when there is nothing unsaved. */
    fun stopEditing() {
        _textDoc.update { cur -> if (cur == null || cur.dirty) cur else cur.copy(editing = false) }
    }

    /** Saves what is typed. With [thenLeave] the editor closes afterwards, unless more was typed meanwhile. */
    fun saveText(thenLeave: Boolean) {
        val doc = _textDoc.value ?: return
        if (doc.saving) return
        if (!doc.dirty) {
            if (thenLeave) stopEditing()
            return
        }
        val snapshot = textDraft
        _textDoc.update { it?.copy(saving = true) }
        viewModelScope.launch {
            val savedSize = withContext(Dispatchers.IO) {
                awaitVault()
                val file = File(doc.path)
                if (TextFiles.save(file, snapshot, doc.crlf, doc.bom)) {
                    if (!isPrivatePath(doc.path)) {
                        MediaScannerConnection.scanFile(getApplication(), arrayOf(doc.path), null, null)
                    }
                    Vault.displaySize(file, file.length())
                } else {
                    -1L
                }
            }
            val ok = savedSize >= 0L
            _textDoc.update { cur ->
                when {
                    cur == null || cur.path != doc.path -> cur
                    !ok -> cur.copy(saving = false)
                    else -> {
                        val unchanged = textDraft == snapshot
                        cur.copy(
                            text = snapshot,
                            sizeBytes = savedSize,
                            dirty = !unchanged,
                            saving = false,
                            editing = cur.editing && !(thenLeave && unchanged),
                            session = if (thenLeave && unchanged) cur.session + 1 else cur.session,
                        )
                    }
                }
            }
            _events.tryEmit(if (ok) R.string.text_saved else R.string.text_save_failed)
            if (ok) reloadAfterChange()
        }
    }

    // ---- Picture viewer ----

    /** Opens the full-screen viewer on [images], starting at [index]. */
    fun openViewer(images: List<FileItem>, index: Int) {
        if (images.isEmpty()) return
        _state.update { it.copy(viewerImages = images, viewerIndex = index.coerceIn(0, images.size - 1), selected = emptySet()) }
    }

    fun closeViewer() {
        _state.update { if (it.viewerImages.isEmpty()) it else it.copy(viewerImages = emptyList(), viewerIndex = 0) }
    }

    /** The viewer's Delete button. The viewer asked already, so this goes straight to the usual delete. */
    fun deleteFromViewer(path: String) {
        _state.update { it.copy(selected = setOf(path)) }
        deleteSelected()
    }

    // ---- Apps ----

    /** Opens the Apps screen and reads the installed apps. */
    fun openApps() {
        _state.update { it.copy(appsOpen = true, appsLoading = true, apps = emptyList()) }
        loadApps()
    }

    fun closeApps() {
        appsJob?.cancel()
        _state.update { it.copy(appsOpen = false, appsLoading = false, apps = emptyList()) }
    }

    /** Reads the list again, for instance when the person comes back from uninstalling something. */
    private fun loadApps() {
        appsJob?.cancel()
        appsJob = viewModelScope.launch(Dispatchers.IO) {
            val list = AppsLoader.load(getApplication())
            _state.update { if (it.appsOpen) it.copy(appsLoading = false, apps = list) else it }
        }
    }

    /** Copies the apk files of [apps] into Download/App backups. */
    fun backupApps(apps: List<AppEntry>) {
        if (apps.isEmpty()) return
        val job = beginJob(R.string.busy_backing_up)
        job.totalBytes = apps.sumOf { it.bytes }
        viewModelScope.launch {
            val failed = withContext(Dispatchers.IO) {
                val dest = File(StorageAccess.root(), "Download/App backups")
                val made = ArrayList<String>()
                var count = 0
                try {
                    for (app in apps) {
                        val result = AppBackup.backup(app, dest, job)
                        if (result == null) count++ else made.add(result.path)
                    }
                } catch (e: JobStopped) {
                    // Cancelled: what was already copied stays.
                }
                val files = FileOps.filesUnder(made)
                if (files.isNotEmpty()) MediaScannerConnection.scanFile(getApplication(), files.toTypedArray(), null, null)
                count
            }
            _events.tryEmit(
                when {
                    job.cancelled -> R.string.job_cancelled
                    failed > 0 -> R.string.apps_backup_failed
                    else -> R.string.apps_backup_done
                },
            )
            endJob()
            reloadAfterChange()
            startScan()
        }
    }

    // ---- Trash ----

    /** Opens the Trash screen. Whatever is past its time goes first, then the rest is listed. */
    fun openTrash() {
        trashJob?.cancel()
        _state.update { it.copy(trashOpen = true, trashLoading = true, trashItems = emptyList()) }
        trashJob = viewModelScope.launch(Dispatchers.IO) {
            TrashStore.purgeOlderThan(trashDirs, trashKeepMillis(_state.value.trashDays), System.currentTimeMillis())
            val items = TrashStore.list(trashDirs)
            _state.update { if (it.trashOpen) it.copy(trashLoading = false, trashItems = items) else it }
        }
    }

    fun closeTrash() {
        trashJob?.cancel()
        _state.update { it.copy(trashOpen = false, trashLoading = false, trashItems = emptyList()) }
    }

    /** Reads the Trash again after something changed in it. */
    private fun refreshTrash() {
        if (!_state.value.trashOpen) return
        trashJob?.cancel()
        trashJob = viewModelScope.launch(Dispatchers.IO) {
            val items = TrashStore.list(trashDirs)
            _state.update { if (it.trashOpen) it.copy(trashLoading = false, trashItems = items) else it }
        }
    }

    /** Puts the ticked items back where they were deleted from. A taken name gets a number. */
    fun restoreTrash(storedPaths: Set<String>) {
        val items = _state.value.trashItems.filter { it.storedPath in storedPaths }
        if (items.isEmpty()) return
        val job = beginJob(R.string.busy_restoring, cancellable = false)
        viewModelScope.launch {
            val failed = withContext(Dispatchers.IO) {
                // Items whose origin is unknown come back into "Restored" on the main storage.
                val fallback = File(StorageAccess.root(), "Restored")
                val done = FileOps.relocate(TrashStore.restorePairs(items, fallback), job)
                val back = done.map { it.first }.toHashSet()
                for ((batch, group) in items.groupBy { it.batch }) {
                    TrashStore.release(batch, group.map { it.storedPath }.filter { it in back })
                }
                val touched = ArrayList<String>()
                touched.addAll(FileOps.filesUnder(done.map { it.second }))
                touched.addAll(items.mapNotNull { it.originalPath })
                MediaScannerConnection.scanFile(getApplication(), touched.toTypedArray(), null, null)
                items.size - done.size
            }
            _events.tryEmit(if (failed > 0) R.string.undo_failed else R.string.trash_restored)
            endJob()
            refreshTrash()
            reloadAfterChange()
            startScan()
        }
    }

    /** Deletes the ticked items for good. */
    fun deleteTrashForever(storedPaths: Set<String>) {
        val items = _state.value.trashItems.filter { it.storedPath in storedPaths }
        if (items.isEmpty()) return
        val job = beginJob(R.string.busy_deleting)
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    TrashStore.delete(items, job)
                } catch (e: JobStopped) {
                    // Cancelled: what was not reached stays in the Trash.
                }
            }
            endJob()
            refreshTrash()
        }
    }

    /** Empties the whole Trash. */
    fun emptyTrash() {
        beginJob(R.string.busy_deleting, cancellable = false)
        viewModelScope.launch {
            withContext(Dispatchers.IO) { TrashStore.clear(trashDirs) }
            endJob()
            refreshTrash()
        }
    }

    /** Chooses how long deleted things are kept. What is already older than that goes right away. */
    fun setTrashDays(days: Int) {
        settingsStore.saveTrashDays(days)
        _state.update { it.copy(trashDays = days) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                TrashStore.purgeOlderThan(trashDirs, trashKeepMillis(days), System.currentTimeMillis())
            }
            refreshTrash()
        }
    }

    // ---- Cleaner ----

    /** Opens the Cleaner screen and looks through the last scan for things that are safe to clear. */
    fun openCleaner() {
        cleanJob?.cancel()
        val scan = _state.value.scan
        _state.update { it.copy(cleanOpen = true, cleanLoading = true, cleanGroups = emptyList(), selected = emptySet()) }
        cleanJob = viewModelScope.launch(Dispatchers.IO) {
            val groups = CleanerEngine.find(scan, StorageAccess.root().absolutePath, active = { isActive })
            _state.update { if (it.cleanOpen) it.copy(cleanLoading = false, cleanGroups = groups) else it }
        }
    }

    fun closeCleaner() {
        cleanJob?.cancel()
        _state.update { it.copy(cleanOpen = false, cleanLoading = false, cleanGroups = emptyList(), selected = emptySet()) }
    }

    /** Ticks everything in [paths], or unticks them if they are all ticked already. Other ticks stay. */
    fun toggleGroup(paths: List<String>) {
        _state.update {
            if (it.selected.containsAll(paths)) it.copy(selected = it.selected - paths.toSet()) else it.copy(selected = it.selected + paths)
        }
    }

    // ---- Looking inside a zip ----

    /** Opens the zip's table of contents. Nothing is unpacked. */
    fun openZip(path: String) {
        zipJob?.cancel()
        zipIndex = emptyList()
        _state.update {
            it.copy(
                selected = emptySet(),
                zipPath = path,
                zipInner = "",
                zipLoading = true,
                zipFailed = false,
                zipFolders = emptyList(),
                zipFiles = emptyList(),
            )
        }
        zipJob = viewModelScope.launch(Dispatchers.IO) {
            zipPreviewDir.deleteRecursively()
            val entries = ZipBrowser.read(File(path))
            if (entries == null) {
                _state.update { if (it.zipPath == path) it.copy(zipLoading = false, zipFailed = true) else it }
            } else {
                zipIndex = entries
                val contents = ZipBrowser.contents(entries, "")
                _state.update {
                    if (it.zipPath == path) {
                        it.copy(zipLoading = false, zipFolders = contents.folders, zipFiles = contents.files)
                    } else {
                        it
                    }
                }
            }
        }
    }

    /** Walks into a folder of the open zip. [inner] is its path inside the zip. */
    fun openZipFolder(inner: String) {
        val path = _state.value.zipPath ?: return
        zipJob?.cancel()
        zipJob = viewModelScope.launch(Dispatchers.Default) {
            val contents = ZipBrowser.contents(zipIndex, inner)
            _state.update {
                if (it.zipPath == path) {
                    it.copy(zipInner = inner, zipFolders = contents.folders, zipFiles = contents.files)
                } else {
                    it
                }
            }
        }
    }

    /** One folder up inside the zip. From the top of the zip it closes the screen. */
    fun zipUp() {
        val inner = _state.value.zipInner
        if (inner.isEmpty()) closeZip() else openZipFolder(inner.substringBeforeLast('/', ""))
    }

    fun closeZip() {
        zipJob?.cancel()
        zipIndex = emptyList()
        _state.update {
            it.copy(
                zipPath = null,
                zipInner = "",
                zipLoading = false,
                zipFailed = false,
                zipFolders = emptyList(),
                zipFiles = emptyList(),
            )
        }
        viewModelScope.launch(Dispatchers.IO) { zipPreviewDir.deleteRecursively() }
    }

    /** The Extract button of the zip screen: closes it and unpacks the whole zip next to itself. */
    fun extractOpenZip() {
        val path = _state.value.zipPath ?: return
        closeZip()
        extractPaths(listOf(path))
    }

    /** Unpacks just the one file at [inner] into temporary space, then calls [onReady] with where it is. */
    fun previewZipEntry(inner: String, onReady: (String) -> Unit) {
        val zipPath = _state.value.zipPath ?: return
        val entry = zipIndex.firstOrNull { it.path == inner && !it.isDirectory } ?: return
        _state.update { it.copy(busy = true) }
        viewModelScope.launch {
            val out = withContext(Dispatchers.IO) {
                ZipBrowser.extractEntry(File(zipPath), entry, File(zipPreviewDir, System.nanoTime().toString()))
            }
            _state.update { it.copy(busy = false) }
            if (out == null) {
                _events.tryEmit(R.string.zip_entry_failed)
            } else {
                onReady(out.absolutePath)
            }
        }
    }

    // ---- Storage ----

    fun openReport() {
        _state.update { it.copy(reportOpen = true, report = null, selected = emptySet()) }
        computeReport()
    }

    fun closeReport() {
        reportJob?.cancel()
        _state.update { it.copy(reportOpen = false, report = null, selected = emptySet()) }
    }

    /** Adds up the scan by kind of file and picks the biggest files. Runs again when the scan changes. */
    private fun computeReport() {
        val files = _state.value.scan.files
        reportJob?.cancel()
        reportJob = viewModelScope.launch(Dispatchers.Default) {
            val bytes = LongArray(FileKind.entries.size)
            val counts = IntArray(FileKind.entries.size)
            var total = 0L
            for (file in files) {
                bytes[file.kind.ordinal] += file.sizeBytes
                counts[file.kind.ordinal]++
                total += file.sizeBytes
            }
            val byKind = FileKind.entries
                .map { KindSize(it, bytes[it.ordinal], counts[it.ordinal]) }
                .filter { it.count > 0 }
                .sortedByDescending { it.bytes }
            val largest = files.sortedByDescending { it.sizeBytes }.take(LARGEST_COUNT)
            val report = StorageReport(byKind = byKind, filesBytes = total, largest = largest)
            _state.update { if (it.reportOpen) it.copy(report = report) else it }
        }
    }

    // ---- Search ----

    /** Called on every keystroke. A blank query ends the search and brings the tabs back. */
    fun search(query: String) {
        _state.update {
            it.copy(
                query = query,
                // The Recent sheet has no place next to search results.
                sheet = if (query.isNotBlank() || it.filter.isActive) SheetAnchor.Hidden else it.sheet,
                selected = if (it.query == query) it.selected else emptySet(),
            )
        }
        runSearch()
    }

    /** Shows or hides the filter chips. Hiding them also drops the filters. */
    fun toggleFilters() {
        if (_state.value.filtersOpen) {
            _state.update { it.copy(filtersOpen = false, filter = SearchFilter.None, selected = emptySet()) }
            runSearch()
        } else {
            _state.update { it.copy(filtersOpen = true) }
        }
    }

    fun setFilter(filter: SearchFilter) {
        _state.update {
            it.copy(
                filter = filter,
                sheet = if (filter.isActive) SheetAnchor.Hidden else it.sheet,
                selected = emptySet(),
            )
        }
        runSearch()
    }

    /** Keeps the search on screen (its text and filters) under [name]. */
    fun saveCurrentSearch(name: String) {
        val current = _state.value
        val clean = name.trim()
        if (clean.isEmpty() || !current.searching) return
        if (current.savedSearches.size >= SAVED_SEARCH_MAX) {
            _events.tryEmit(R.string.saved_search_full)
            return
        }
        val saved = SavedSearch(System.currentTimeMillis().toString(), clean, current.query.trim(), current.filter)
        val next = current.savedSearches + saved
        savedSearchStore.save(next)
        _state.update { it.copy(savedSearches = next) }
    }

    /** Runs a saved search: fills the field, sets the filters and shows the filter chips. */
    fun applySavedSearch(saved: SavedSearch) {
        _state.update {
            it.copy(
                query = saved.query,
                filter = saved.filter,
                filtersOpen = true,
                sheet = SheetAnchor.Hidden,
                selected = emptySet(),
            )
        }
        runSearch()
    }

    fun deleteSavedSearch(id: String) {
        val next = _state.value.savedSearches.filterNot { it.id == id }
        savedSearchStore.save(next)
        _state.update { it.copy(savedSearches = next) }
    }

    /** Back from the search: empties the field, drops the filters and hides the chips. */
    fun clearSearch() {
        _state.update { it.copy(filtersOpen = false, filter = SearchFilter.None) }
        search("")
    }

    private fun runSearch() {
        val needle = _state.value.query.trim()
        val filter = _state.value.filter
        searchJob?.cancel()
        if (needle.isEmpty() && !filter.isActive) {
            _state.update { it.copy(results = SearchResults.Empty) }
            return
        }
        val index = _state.value.scan
        searchJob = viewModelScope.launch(Dispatchers.Default) {
            // Wait a moment so fast typing does not search for every letter.
            delay(SEARCH_DEBOUNCE_MS)
            val found = SearchEngine.search(index, needle, filter)
            _state.update { if (it.query.trim() == needle && it.filter == filter) it.copy(results = found) else it }
        }
    }

    /** Selects everything in [paths], or clears the selection if it is all selected already. */
    fun selectAll(paths: List<String>) {
        _state.update {
            if (it.selected.containsAll(paths)) it.copy(selected = emptySet()) else it.copy(selected = it.selected + paths)
        }
    }

    // ---- Private ----

    /**
     * Calls [onReady] with paths another app can read. Files outside Private are passed on as they are. Files in
     * Private are unlocked into a temporary folder first, which is wiped when Private locks.
     */
    fun withReadableCopies(paths: List<String>, onReady: (List<String>) -> Unit) {
        if (paths.none { isPrivatePath(it) }) {
            onReady(paths)
            return
        }
        val job = beginJob(R.string.busy_unlocking, cancellable = false)
        viewModelScope.launch {
            val readable = withContext(Dispatchers.IO) {
                awaitVault()
                val dir = File(viewDir, System.nanoTime().toString())
                dir.mkdirs()
                job.totalBytes = paths.filter { isPrivatePath(it) }.sumOf { File(it).length() }
                val result = ArrayList<String>()
                for (path in paths) {
                    val source = File(path)
                    if (!isPrivatePath(path)) {
                        result.add(path)
                    } else if (source.isFile) {
                        val copy = FileOps.uniqueTarget(dir, VaultNames.plainName(source))
                        try {
                            FileOps.copyFileTo(source, copy, job)
                            result.add(copy.path)
                        } catch (e: Exception) {
                            copy.delete()
                        }
                    }
                }
                result
            }
            endJob()
            if (readable.isEmpty()) {
                _events.tryEmit(R.string.unlock_file_failed)
            } else {
                onReady(readable)
            }
        }
    }

    /** Waits until old Private files are locked, so a file being written in is never mistaken for an old one. */
    private suspend fun awaitVault() {
        vaultPrep?.join()
    }

    fun isPrivatePath(path: String): Boolean = path == privateRootPath || path.startsWith("$privateRootPath/")

    /** The top folder the browser stops at: Private for Private paths, shared storage for the rest. */
    fun rootOf(path: String): String =
        if (isPrivatePath(path)) privateRootPath else StorageAccess.root().absolutePath

    fun unlockPrivate() {
        _state.update { it.copy(privateUnlocked = true) }
        // Reads that follow straight away must find the key allowed; opening it can take a moment.
        try {
            Vault.allowSession()
        } catch (e: Exception) {
            // Reported below, when opening the key fails.
        }
        refreshPrivateCount()
        // Opens the Private key (made on the first unlock), moves files sealed by the old key to the new one,
        // and locks files that were put here before encryption existed.
        vaultPrep = viewModelScope.launch(Dispatchers.IO) {
            try {
                Vault.unlockSession()
                Vault.upgradeLegacyKeys(privateDir)
                Vault.lockExisting(privateDir)
            } catch (e: Exception) {
                // Without the key Private can not be used, so close it again and say why.
                if (_state.value.privateUnlocked) {
                    _events.tryEmit(R.string.unlock_key_failed)
                    withContext(Dispatchers.Main) { lockPrivate() }
                }
            }
        }
    }

    /** Locks Private and closes anything that shows it. */
    fun lockPrivate() {
        val s = _state.value
        if (!s.privateUnlocked) return
        val browsingPrivate = s.browserPath?.let { isPrivatePath(it) } == true
        val clipHasPrivate = s.clip?.paths?.any { isPrivatePath(it) } == true
        val selectionHasPrivate = s.selected.any { isPrivatePath(it) }
        _state.update {
            it.copy(
                privateUnlocked = false,
                privateCount = 0,
                clip = if (clipHasPrivate) null else it.clip,
                selected = if (selectionHasPrivate) emptySet() else it.selected,
            )
        }
        if (s.viewerImages.any { isPrivatePath(it.path) }) closeViewer()
        // Anything typed and not saved in a Private file is dropped: its plain text must not stay in memory.
        if (_textDoc.value?.path?.let { isPrivatePath(it) } == true) closeText()
        if (browsingPrivate) closeBrowser()
        if (s.zipPath?.let { isPrivatePath(it) } == true) closeZip()
        Thumbnails.clear()
        // The Private key leaves memory, so nothing in Private opens until the user unlocks again.
        Vault.lockSession()
        viewModelScope.launch(Dispatchers.IO) { viewDir.deleteRecursively() }
    }

    fun openPrivate() {
        privateDir.mkdirs()
        openFolder(privateRootPath)
    }

    /** The app left the screen. Remember when, so Private can lock if the user stays away a while. */
    fun onBackgrounded() {
        leftAt = SystemClock.elapsedRealtime()
    }

    fun onForegrounded() {
        if (leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > PRIVATE_RELOCK_MS) lockPrivate()
    }

    /** Moves the selected items into Private. They disappear from everywhere else. */
    fun moveSelectedToPrivate() {
        if (!_state.value.privateUnlocked) return
        val paths = _state.value.selected.filter { !isPrivatePath(it) }
        if (paths.isEmpty()) return
        _state.update { it.copy(selected = emptySet()) }
        val job = beginJob(R.string.busy_moving)
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                awaitVault()
                privateDir.mkdirs()
                val outcome = FileOps.paste(privateDir, paths, move = true, control = job)
                MediaScannerConnection.scanFile(getApplication(), paths.toTypedArray(), null, null)
                outcome
            }
            if (result.cancelled) _events.tryEmit(R.string.job_cancelled)
            if (result.failed > 0) _events.tryEmit(R.string.paste_failed)
            if (result.leftover.isNotEmpty()) _events.tryEmit(R.string.paste_original_stays)
            if (result.done.isNotEmpty()) offerUndo(PendingUndo(UndoKind.Move, result.done, null, emptyList()))
            applyRemoved(result.done.map { it.first })
        }
    }

    private fun refreshPrivateCount() {
        if (!_state.value.privateUnlocked) return
        viewModelScope.launch(Dispatchers.IO) {
            val count = privateDir.list()?.size ?: 0
            _state.update { it.copy(privateCount = count) }
        }
    }

    private fun withoutPaths(data: ScanData, removed: List<String>): ScanData {
        val exact = removed.toHashSet()
        val prefixes = removed.map { "$it/" }
        fun gone(file: FileItem): Boolean = file.path in exact || prefixes.any { file.path.startsWith(it) }
        fun goneFolder(folder: FolderItem): Boolean =
            folder.path in exact || prefixes.any { folder.path.startsWith(it) }
        return ScanData(
            byCategory = data.byCategory.mapValues { entry -> entry.value.filterNot { gone(it) } },
            recent = data.recent.filterNot { gone(it) },
            files = data.files.filterNot { gone(it) },
            folders = data.folders.filterNot { goneFolder(it) },
        )
    }

    /** Pull to refresh in the folder browser: reads the folder again, and scans again outside Private. */
    fun refreshBrowser() {
        reloadAfterChange()
        val path = _state.value.browserPath
        if (path == null || !isPrivatePath(path)) startScan()
    }

    private fun reloadAfterChange() {
        resolveFavorites()
        refreshPrivateCount()
        _state.value.browserPath?.let { loadBrowser(it) }
    }

    // ---- Favorites ----

    /** Looks up the saved paths on disk. Ones that no longer exist are simply not shown. */
    private fun resolveFavorites() {
        val paths = _state.value.favorites
        favoritesJob?.cancel()
        favoritesJob = viewModelScope.launch(Dispatchers.IO) {
            val folders = ArrayList<FolderItem>()
            val files = ArrayList<FileItem>()
            for (path in paths) {
                if (isPrivatePath(path)) continue
                val folder = FolderLister.folderAt(path)
                if (folder != null) {
                    folders.add(folder)
                } else {
                    val file = FolderLister.fileAt(path)
                    if (file != null) files.add(file)
                }
            }
            val sortedFolders = folders.sortedBy { it.name.lowercase() }
            val sortedFiles = files.sortedBy { it.name.lowercase() }
            _state.update { it.copy(favoriteFolders = sortedFolders, favoriteFiles = sortedFiles) }
        }
    }

    // ---- Folder browser ----

    /** Opens the root of shared storage. */
    fun openStorage() {
        openFolder(StorageAccess.root().absolutePath)
    }

    fun openFolder(path: String) {
        browserListing = null
        _state.update {
            it.copy(
                selected = emptySet(),
                browserPath = path,
                browserLoading = true,
                browserFailed = false,
                browserFolders = emptyList(),
                browserFiles = emptyList(),
            )
        }
        loadBrowser(path)
    }

    /** Goes one folder up. From the top of storage it closes the browser. */
    fun browserUp() {
        val path = _state.value.browserPath ?: return
        val root = rootOf(path)
        val parent = File(path).parent
        if (path == root || parent == null || !parent.startsWith(root)) {
            closeBrowser()
        } else {
            openFolder(parent)
        }
    }

    fun closeBrowser() {
        browserJob?.cancel()
        browserSortJob?.cancel()
        browserListing = null
        _state.update {
            it.copy(
                clip = null,
                selected = emptySet(),
                browserPath = null,
                browserLoading = false,
                browserFailed = false,
                browserFolders = emptyList(),
                browserFiles = emptyList(),
            )
        }
    }

    private fun loadBrowser(path: String) {
        browserJob?.cancel()
        browserJob = viewModelScope.launch(Dispatchers.IO) {
            val listing = FolderLister.list(File(path), _state.value.showHidden)
            val spec = _state.value.sort
            val folders = listing.folders.sortedFoldersBySpec(spec)
            val files = listing.files.sortedBySpec(spec)
            _state.update {
                if (it.browserPath == path) {
                    browserListing = listing
                    it.copy(
                        browserLoading = false,
                        browserFailed = listing.failed,
                        browserFolders = folders,
                        browserFiles = files,
                    )
                } else {
                    it
                }
            }
        }
    }

    /** The sort changed: reorder what is already loaded. */
    private fun resortBrowser() {
        val path = _state.value.browserPath ?: return
        val listing = browserListing ?: return
        val spec = _state.value.sort
        browserSortJob?.cancel()
        browserSortJob = viewModelScope.launch(Dispatchers.Default) {
            val folders = listing.folders.sortedFoldersBySpec(spec)
            val files = listing.files.sortedBySpec(spec)
            _state.update {
                if (it.browserPath == path) it.copy(browserFolders = folders, browserFiles = files) else it
            }
        }
    }

    // ---- Scanning ----

    private fun startScan() {
        scanJob?.cancel()
        // The scan that was just cancelled finishes later than this line. Only the newest one may say "done".
        val generation = ++scanGeneration
        scanJob = viewModelScope.launch {
            _state.update { it.copy(scanning = true) }
            try {
                // The first scan shows progress as it goes. Later scans only replace the numbers
                // when they are complete, so counts never drop back while a rescan is running.
                val progressive = lastScanAt == 0L
                var latest: ScanData? = null
                scanner.scan(StorageAccess.root()) { data ->
                    if (progressive) applyScan(data) else latest = data
                }
                latest?.let { applyScan(it) }
                lastScanAt = SystemClock.elapsedRealtime()
            } finally {
                if (generation == scanGeneration) _state.update { it.copy(scanning = false) }
            }
        }
    }

    /** Called from the scanner's thread. Cheap on purpose: only the small recent list is sorted here. */
    private fun applyScan(data: ScanData) {
        _state.update {
            it.copy(
                scan = data,
                counts = data.byCategory.mapValues { entry -> entry.value.size },
                recent = data.recent.sortedBySpec(it.sort),
            )
        }
        sortOpenFiles()
        if (_state.value.searching) runSearch()
        if (_state.value.reportOpen) computeReport()
    }

    /** Sorting a folder with tens of thousands of files happens off the main thread. */
    private fun sortOpenFiles() {
        val current = _state.value
        val category = current.openCategory ?: return
        val source = current.scan.byCategory[category].orEmpty()
        val spec = current.sort
        sortJob?.cancel()
        sortJob = viewModelScope.launch(Dispatchers.Default) {
            val sorted = source.sortedBySpec(spec)
            _state.update { if (it.openCategory == category) it.copy(openFiles = sorted) else it }
        }
    }

    private companion object {
        const val RESCAN_AFTER_MS = 60_000L
        const val SEARCH_DEBOUNCE_MS = 120L
        const val LARGEST_COUNT = 40
        const val PRIVATE_RELOCK_MS = 60_000L

        /** How long the Undo bar stays up. */
        const val UNDO_MS = 8_000L
    }
}
