package ix.app.files.data

/** Maps a file extension to the kind of file it is, and a kind to the Home folder it belongs in. */
object FileKinds {

    private val images = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "avif", "dng", "svg")
    private val videos = setOf("mp4", "mkv", "webm", "mov", "avi", "3gp", "m4v", "wmv", "flv")
    private val audio = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr", "wma", "mid", "m4b")
    private val documents = setOf(
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf",
        "odt", "ods", "odp", "csv", "md", "epub",
    )
    private val apps = setOf("apk", "xapk", "apks", "apkm")

    fun kindOf(extension: String): FileKind = when (extension) {
        in images -> FileKind.Image
        in videos -> FileKind.Video
        in audio -> FileKind.Audio
        in documents -> FileKind.Document
        in apps -> FileKind.App
        else -> FileKind.Other
    }

    fun categoryOf(kind: FileKind): Category? = when (kind) {
        FileKind.Image -> Category.Images
        FileKind.Video -> Category.Videos
        FileKind.Audio -> Category.Audio
        FileKind.Document -> Category.Docs
        FileKind.App -> Category.Apps
        FileKind.Other -> null
    }
}
