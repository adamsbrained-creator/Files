package ix.app.files.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File

/**
 * Loads a picture for the full-screen viewer: the whole picture (not a square crop), turned the right way up,
 * and shrunk while it is read so that a 50 MP photo does not fill the phone's memory.
 */
object PictureLoader {

    /** Pictures in Private are unlocked into memory, so a very big one is not shown. */
    private const val PRIVATE_LIMIT = 48L * 1024 * 1024

    /** Pictures the viewer can try. Vector drawings (svg) are left to other apps. */
    fun viewable(file: FileItem): Boolean = file.kind == FileKind.Image && file.extension != "svg"

    /**
     * The biggest power of two to shrink by so the longer side stays at least [maxPx] long.
     * 1 means "do not shrink". Pictures already smaller than [maxPx] are never shrunk.
     */
    fun sampleSizeFor(width: Int, height: Int, maxPx: Int): Int {
        if (width <= 0 || height <= 0 || maxPx <= 0) return 1
        val longer = maxOf(width, height)
        var sample = 1
        while (longer / (sample * 2) >= maxPx) sample *= 2
        return sample
    }

    /** The picture, or null when it can not be read or decoded. Runs on a background thread. */
    suspend fun load(file: FileItem, maxPx: Int): Bitmap? = withContext(Dispatchers.IO) {
        try {
            decode(File(file.path), maxPx)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    private fun decode(stored: File, maxPx: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val bitmap: Bitmap?
        val degrees: Int
        if (Vault.isPrivate(stored) && Vault.isEncrypted(stored)) {
            val data = Vault.readAll(stored, PRIVATE_LIMIT) ?: return null
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxPx)
            }
            bitmap = BitmapFactory.decodeByteArray(data, 0, data.size, options)
            degrees = try {
                degreesOf(ExifInterface(ByteArrayInputStream(data)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL))
            } catch (e: Exception) {
                0
            }
        } else {
            BitmapFactory.decodeFile(stored.path, bounds)
            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxPx)
            }
            bitmap = BitmapFactory.decodeFile(stored.path, options)
            degrees = try {
                degreesOf(ExifInterface(stored.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL))
            } catch (e: Exception) {
                0
            }
        }
        if (bitmap == null) return null
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun degreesOf(orientation: Int): Int = when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90
        ExifInterface.ORIENTATION_ROTATE_180 -> 180
        ExifInterface.ORIENTATION_ROTATE_270 -> 270
        else -> 0
    }
}
