package ix.app.files.data

import java.io.File
import java.io.IOException
import java.security.GeneralSecurityException
import java.security.SecureRandom
import java.util.Arrays
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Locks and unlocks one small secret with a key that only works right after the user has unlocked the phone
 * (fingerprint, face or screen lock). The real one lives in the Android Keystore; tests use a software one.
 */
interface RootSealer {
    fun seal(secret: ByteArray): ByteArray

    /** Throws [IOException] when the user has not unlocked recently, or when the key is gone for good. */
    fun open(blob: ByteArray): ByteArray
}

/** The older key, which opened without asking the user. Only used to read files made by earlier versions. */
interface LegacyKey : KeyWrapper {
    /** Forgets the old key for good. */
    fun retire()
}

/**
 * The key wrapper of the Private folder.
 *
 * Every file has its own random key, sealed by one random "root" key. The root key is kept in a file next to
 * Private, sealed by a Keystore key that only works after the user has unlocked the phone. While Private is
 * unlocked the root key sits in memory, so files open without asking again. [lock] wipes it, and from then on
 * nothing in Private can be opened until the user unlocks again.
 *
 * Earlier versions sealed every file key straight with a Keystore key that never asked for the user. Those
 * files still open through [legacy]. [upgrade] moves a file key to the new scheme, and once every file has
 * moved, [retireLegacy] removes the old key.
 *
 * A sealed file key is IV (12) + key (32) + tag (16) = [Vault.WRAPPED_SIZE] bytes, the same size as before,
 * so no file has to change size.
 */
class SessionKeyWrapper(
    private val rootFile: File,
    private val sealer: RootSealer,
    legacy: LegacyKey?,
) : KeyWrapper {

    @Volatile
    private var legacy: LegacyKey? = legacy

    @Volatile
    private var root: SecretKeySpec? = null

    @Volatile
    private var allowed = false

    /** True while older files may still be sealed by the old key. */
    val hasLegacy: Boolean get() = legacy != null

    /** The user has unlocked Private. The root key is opened the first time something needs it. */
    fun allow() {
        allowed = true
    }

    /** Private is locked: forget the root key. */
    fun lock() {
        synchronized(this) {
            allowed = false
            root = null
        }
    }

    private fun rootKey(): SecretKeySpec {
        root?.let { return it }
        return synchronized(this) {
            val known = root
            if (known != null) return@synchronized known
            if (!allowed) throw IOException("Private is locked")
            val secret = loadOrCreateRoot()
            val spec = SecretKeySpec(secret, "AES")
            Arrays.fill(secret, 0)
            root = spec
            spec
        }
    }

    private fun loadOrCreateRoot(): ByteArray {
        if (rootFile.exists()) {
            val bytes = rootFile.readBytes()
            if (bytes.size <= MAGIC.size || !bytes.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) {
                throw IOException("The Private key file is damaged")
            }
            return sealer.open(bytes.copyOfRange(MAGIC.size, bytes.size))
        }
        val fresh = ByteArray(32)
        SecureRandom().nextBytes(fresh)
        val sealed = sealer.seal(fresh)
        val temp = File(rootFile.path + ".tmp")
        temp.writeBytes(MAGIC + sealed)
        // The key file appears whole or not at all.
        if (!temp.renameTo(rootFile)) {
            temp.delete()
            Arrays.fill(fresh, 0)
            throw IOException("Could not save the Private key")
        }
        return fresh
    }

    override fun wrap(key: ByteArray): ByteArray {
        val iv = ByteArray(IV_SIZE).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, rootKey(), GCMParameterSpec(TAG_BITS, iv))
        return iv + cipher.doFinal(key)
    }

    override fun unwrap(blob: ByteArray): ByteArray {
        if (blob.size <= IV_SIZE) throw IOException("Damaged key")
        return try {
            openWithRoot(blob)
        } catch (e: GeneralSecurityException) {
            // Not sealed by the root key: a file from an earlier version.
            val old = legacy ?: throw IOException("This file's key does not open", e)
            old.unwrap(blob)
        }
    }

    private fun openWithRoot(blob: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, rootKey(), GCMParameterSpec(TAG_BITS, blob, 0, IV_SIZE))
        return cipher.doFinal(blob, IV_SIZE, blob.size - IV_SIZE)
    }

    /**
     * The new form of [blob] if it was sealed by the old key, or null if it already belongs to the new scheme.
     * Throws if it opens with neither.
     */
    fun upgrade(blob: ByteArray): ByteArray? {
        if (blob.size <= IV_SIZE) throw IOException("Damaged key")
        try {
            openWithRoot(blob).also { Arrays.fill(it, 0) }
            return null
        } catch (e: GeneralSecurityException) {
            val old = legacy ?: throw IOException("This file's key does not open", e)
            val fileKey = old.unwrap(blob)
            try {
                return wrap(fileKey)
            } finally {
                Arrays.fill(fileKey, 0)
            }
        }
    }

    /** Removes the old key. Call only once every file has been upgraded. */
    fun retireLegacy() {
        val old = legacy ?: return
        old.retire()
        legacy = null
    }

    private companion object {
        val MAGIC = byteArrayOf(0x49, 0x58, 0x52, 0x31) // "IXR1"
        const val IV_SIZE = 12
        const val TAG_BITS = 128
    }
}
