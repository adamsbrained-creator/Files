package ix.app.files.data

import com.github.junrar.Archive
import java.io.File
import java.io.InputStream

/** The only place that talks to the rar library, so the rest of the app does not depend on it. */
internal object RarSupport {

    fun walk(file: File, visit: (ArchiveItem, () -> InputStream) -> Boolean) {
        Archive(file).use { archive ->
            for (header in archive.getFileHeaders()) {
                val modified = header.getMTime()?.time ?: 0L
                val item = ArchiveItem(header.getFileName() ?: "", header.isDirectory(), header.getFullUnpackSize(), modified)
                if (!visit(item) { archive.getInputStream(header) }) break
            }
        }
    }
}
