package ix.app.files.data

import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream

/** One line of an archive as the readers see it. [rawName] is the name as stored, [path] has no slash at the ends. */
internal class ArchiveItem(
    val rawName: String,
    val isDirectory: Boolean,
    val size: Long,
    val modifiedMillis: Long,
) {
    val path: String = rawName.replace('\\', '/').trim('/')
}

/**
 * Reads everything that is not a zip: 7z, rar, tar (also packed with gzip, bzip2 or xz) and single files packed
 * with gzip, bzip2 or xz. All of it is read one line after another, the same way for every format, so listing,
 * opening one file and unpacking everything share the same code.
 * Call off the main thread.
 */
object ArchiveReaders {

    /** Every entry of [file], or null when it can not be read (damaged, or locked with a password). */
    fun read(format: ArchiveFormat, file: File): List<ZipBrowser.Entry>? {
        val result = ArrayList<ZipBrowser.Entry>()
        val ok = walk(format, file, null) { item, _ ->
            // Nameless lines, and names that try to climb out of the archive, are not shown (nor ever unpacked).
            if (item.path.isEmpty() || item.path.split('/').any { it == ".." }) return@walk true
            result.add(
                ZipBrowser.Entry(
                    path = item.path,
                    rawName = item.rawName,
                    isDirectory = item.isDirectory,
                    size = item.size.coerceAtLeast(0L),
                    modifiedMillis = item.modifiedMillis.coerceAtLeast(0L),
                ),
            )
            true
        }
        return if (ok) result else null
    }

    /**
     * Unpacks the one [entry] into [destDir] and returns the new file, or null on failure.
     * Only the last part of the name is used, so nothing can land outside [destDir].
     */
    fun extractEntry(format: ArchiveFormat, file: File, entry: ZipBrowser.Entry, destDir: File): File? {
        val name = File(entry.path).name
        if (name.isEmpty() || name == "." || name == "..") return null
        var written: File? = null
        val ok = walk(format, file, null) { item, open ->
            if (item.rawName == entry.rawName && !item.isDirectory) {
                destDir.mkdirs()
                val out = File(destDir, name)
                open().use { input -> out.outputStream().use { output -> input.copyTo(output) } }
                written = out
                false
            } else {
                true
            }
        }
        return if (ok) written else null
    }

    /**
     * Unpacks [file] into [destDir]. Entries that try to climb out of the folder are skipped. Returns false if the
     * archive could not be read to the end, if it was cancelled, or if what it holds would not fit on the storage.
     * The room is checked while writing, so an archive that lies about its sizes can not fill the phone.
     */
    fun extractAll(format: ArchiveFormat, file: File, destDir: File, control: JobControl = JobControl()): Boolean {
        return try {
            destDir.mkdirs()
            val root = destDir.canonicalPath
            val free = destDir.usableSpace
            var room = if (free > 0L) free - FileOps.EXTRACT_RESERVE_BYTES else Long.MAX_VALUE
            // 7z and rar are read from the middle, so progress follows what is written, scaled to the archive's size.
            val scaled = format == ArchiveFormat.SevenZ || format == ArchiveFormat.Rar
            var inside = 0L
            if (scaled) {
                walk(format, file, null) { item, _ ->
                    inside += item.size.coerceAtLeast(0L)
                    true
                }
            }
            val archiveSize = file.length()
            val buffer = ByteArray(64 * 1024)
            val finished = walk(format, file, if (scaled) null else control) { item, open ->
                control.check()
                if (item.path.isEmpty() || item.path.split('/').any { it == ".." }) return@walk true
                val out = File(destDir, item.path)
                if (!out.canonicalPath.startsWith(root + File.separator)) return@walk true
                if (item.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    open().use { input ->
                        out.outputStream().use { output ->
                            while (true) {
                                control.check()
                                val read = input.read(buffer)
                                if (read < 0) break
                                room -= read
                                if (room < 0L) throw IOException("No room left to extract")
                                output.write(buffer, 0, read)
                                if (scaled && inside > 0L) control.add(read.toLong() * archiveSize / inside)
                            }
                        }
                    }
                    if (item.modifiedMillis > 0L) out.setLastModified(item.modifiedMillis)
                }
                true
            }
            finished
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Goes through [file] one line after another. [visit] gets the line and a way to open its content (call it at
     * most once, and only inside [visit]); it returns false to stop early. [control] counts the bytes read from the
     * file itself, when given. Returns false if something went wrong, which includes a cancelled job.
     */
    private fun walk(
        format: ArchiveFormat,
        file: File,
        control: JobControl?,
        visit: (ArchiveItem, () -> InputStream) -> Boolean,
    ): Boolean {
        return try {
            when (format) {
                ArchiveFormat.SevenZ -> walkSevenZ(file, visit)
                ArchiveFormat.Rar -> RarSupport.walk(file, visit)
                ArchiveFormat.Zip -> throw IOException("Zip is read elsewhere")
                else -> walkStream(format, file, control, visit)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun walkSevenZ(file: File, visit: (ArchiveItem, () -> InputStream) -> Boolean) {
        SevenZFile(file).use { sevenZ ->
            while (true) {
                val entry = sevenZ.nextEntry ?: break
                // "Anti items" mark deletions in an update archive. There is nothing to show or unpack.
                if (entry.isAntiItem) continue
                val modified = if (entry.hasLastModifiedDate) entry.lastModifiedDate.time else 0L
                val item = ArchiveItem(entry.name ?: "", entry.isDirectory, entry.size, modified)
                if (!visit(item) { SevenZContent(sevenZ) }) break
            }
        }
    }

    /** The content of the 7z entry that is current. */
    private class SevenZContent(private val file: SevenZFile) : InputStream() {
        override fun read(): Int = file.read()
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int = file.read(buffer, offset, length)
    }

    /** Tar files, packed or not, and single packed files. */
    private fun walkStream(
        format: ArchiveFormat,
        file: File,
        control: JobControl?,
        visit: (ArchiveItem, () -> InputStream) -> Boolean,
    ) {
        var raw: InputStream = FileInputStream(file)
        if (control != null) raw = CountingInput(raw, control)
        BufferedInputStream(raw, 64 * 1024).use { buffered ->
            val unpacked: InputStream = when (format) {
                ArchiveFormat.TarGz, ArchiveFormat.Gz -> GzipCompressorInputStream(buffered)
                ArchiveFormat.TarBz2, ArchiveFormat.Bz2 -> BZip2CompressorInputStream(buffered)
                ArchiveFormat.TarXz, ArchiveFormat.Xz -> XZCompressorInputStream(buffered)
                else -> buffered
            }
            if (format.isSingleFile) {
                // One file, named like the archive without its ending ("notes.txt.gz" holds "notes.txt").
                val name = ArchiveFormat.baseName(file.name).ifEmpty { "file" }
                visit(ArchiveItem(name, false, 0L, file.lastModified())) { unpacked }
                return
            }
            TarArchiveInputStream(unpacked).use { tar ->
                while (true) {
                    val entry = tar.nextEntry ?: break
                    // Links and device files hold no data of their own. (A link also counts as a "file" for tar.)
                    if (entry.isSymbolicLink || entry.isLink || entry.isCharacterDevice || entry.isBlockDevice || entry.isFIFO) continue
                    if (!entry.isDirectory && !entry.isFile) continue
                    val item = ArchiveItem(entry.name ?: "", entry.isDirectory, entry.size, entry.modTime?.time ?: 0L)
                    // Closing the entry's stream must not close the tar.
                    if (!visit(item) { NoClose(tar) }) break
                }
            }
        }
    }

    private class NoClose(input: InputStream) : FilterInputStream(input) {
        override fun close() {}
    }

    /** Counts what is read from the archive file and stops once the job is cancelled. */
    private class CountingInput(input: InputStream, private val control: JobControl) : FilterInputStream(input) {
        override fun read(): Int {
            control.check()
            val value = super.read()
            if (value >= 0) control.add(1L)
            return value
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            control.check()
            val count = super.read(buffer, offset, length)
            if (count > 0) control.add(count.toLong())
            return count
        }
    }
}
