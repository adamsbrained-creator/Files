package ix.app.files.data

import android.content.Context
import androidx.compose.runtime.Immutable
import org.json.JSONArray
import org.json.JSONObject

/** A search the user kept: its text and its filters, under a name of their choice. */
@Immutable
data class SavedSearch(
    val id: String,
    val name: String,
    val query: String,
    val filter: SearchFilter,
)

/** The most searches that can be kept. */
const val SAVED_SEARCH_MAX = 20

/** The longest name a saved search can have. */
const val SAVED_SEARCH_NAME_MAX = 30

/** Remembers the saved searches on the device. */
class SavedSearchStore(context: Context) {

    private val prefs = context.getSharedPreferences("saved_searches", Context.MODE_PRIVATE)

    fun load(): List<SavedSearch> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.getJSONObject(i)
                val id = o.optString("id", "")
                val name = o.optString("name", "")
                if (id.isEmpty() || name.isEmpty()) return@mapNotNull null
                SavedSearch(
                    id = id,
                    name = name,
                    query = o.optString("query", ""),
                    filter = SearchFilter(
                        kind = o.optString("kind", "").let { v -> FileKind.entries.firstOrNull { it.name == v } },
                        size = o.optString("size", "").let { v -> SizeBand.entries.firstOrNull { it.name == v } } ?: SizeBand.Any,
                        date = o.optString("date", "").let { v -> DateBand.entries.firstOrNull { it.name == v } } ?: DateBand.Any,
                    ),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(searches: List<SavedSearch>) {
        val array = JSONArray()
        searches.forEach { s ->
            val o = JSONObject()
                .put("id", s.id)
                .put("name", s.name)
                .put("query", s.query)
                .put("size", s.filter.size.name)
                .put("date", s.filter.date.name)
            s.filter.kind?.let { o.put("kind", it.name) }
            array.put(o)
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val KEY = "searches"
    }
}
