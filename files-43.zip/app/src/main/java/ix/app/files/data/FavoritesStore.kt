package ix.app.files.data

import android.content.Context

/** Remembers which files and folders are favorites, by path, on the device. */
class FavoritesStore(context: Context) {

    private val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun load(): Set<String> = prefs.getStringSet(KEY, null)?.toSet() ?: emptySet()

    fun save(paths: Set<String>) {
        prefs.edit().putStringSet(KEY, HashSet(paths)).apply()
    }

    private companion object {
        const val KEY = "paths"
    }
}
