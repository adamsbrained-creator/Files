package ix.app.files.cast

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.URL

/**
 * Talks to the home network. Everything is pinned to the Wi-Fi (or Ethernet) network on purpose: when mobile
 * data is also on, Android can otherwise send local traffic out the wrong way and the TV is never found.
 */
class AndroidLan(context: Context) : Lan {
    private val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java)

    @Suppress("DEPRECATION")
    fun network(): Network? = runCatching {
        cm.allNetworks.firstOrNull { n ->
            val caps = cm.getNetworkCapabilities(n)
            caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))
        }
    }.getOrNull()

    override fun open(url: String): HttpURLConnection {
        val u = URL(url)
        val n = network()
        val c = if (n != null) n.openConnection(u) else u.openConnection()
        return c as HttpURLConnection
    }

    override fun bind(socket: DatagramSocket) {
        network()?.let { runCatching { it.bindSocket(socket) } }
    }

    override fun localIpFor(host: String): String? {
        val target = runCatching { InetAddress.getByName(host).address }.getOrNull()
        var fallback: String? = null
        val interfaces = runCatching { NetworkInterface.getNetworkInterfaces()?.toList() }.getOrNull().orEmpty()
        for (nif in interfaces) {
            if (!runCatching { nif.isUp && !nif.isLoopback }.getOrDefault(false)) continue
            for (ia in nif.interfaceAddresses) {
                val a = ia.address as? Inet4Address ?: continue
                if (target != null && target.size == 4 && sameSubnet(a.address, target, ia.networkPrefixLength.toInt())) {
                    return a.hostAddress
                }
                if (fallback == null && a.isSiteLocalAddress) fallback = a.hostAddress
            }
        }
        return fallback
    }

    private fun sameSubnet(a: ByteArray, b: ByteArray, prefix: Int): Boolean {
        var bits = prefix
        for (i in 0 until 4) {
            val mask = when {
                bits >= 8 -> 0xFF
                bits <= 0 -> 0
                else -> (0xFF shl (8 - bits)) and 0xFF
            }
            if ((a[i].toInt() and mask) != (b[i].toInt() and mask)) return false
            bits -= 8
        }
        return true
    }
}
