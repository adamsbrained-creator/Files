package ix.app.files.ui.cast

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ix.app.files.R
import ix.app.files.cast.CastDevice
import ix.app.files.cast.CastHub
import ix.app.files.cast.CastItem
import ix.app.files.cast.CastMedia
import ix.app.files.cast.DeviceKind
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors
import java.io.File
import java.text.NumberFormat

/** The videos, songs and pictures among [paths], in name order. Folders and other files are left out. */
fun castItemsOf(paths: Collection<String>): List<CastItem> =
    paths.mapNotNull { CastMedia.itemFor(File(it)) }
        .sortedWith { a, b -> String.CASE_INSENSITIVE_ORDER.compare(a.title, b.title) }

/**
 * "Cast to": the devices on the Wi-Fi that can show things. Tapping one starts [items] on it,
 * beginning with the one at [startIndex].
 */
@Composable
fun CastSheet(items: List<CastItem>, startIndex: Int, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val devices by CastHub.devices.collectAsStateWithLifecycle()
    val scanning by CastHub.scanning.collectAsStateWithLifecycle()
    val settings by CastHub.settings.collectAsStateWithLifecycle()
    val granted by CastHub.localNetworkGranted.collectAsStateWithLifecycle()
    val state by CastHub.state.collectAsStateWithLifecycle()
    var askedForNetwork by remember { mutableStateOf(false) }

    val networkLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        CastHub.refreshPermission()
        if (CastHub.localNetworkGranted.value) CastHub.startScan(clear = true)
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        CastHub.refreshPermission()
        if (CastHub.localNetworkGranted.value) {
            CastHub.startScan()
        } else {
            askedForNetwork = true
            networkLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
        }
    }
    // Coming back from the settings page.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        CastHub.refreshPermission()
        if (CastHub.localNetworkGranted.value) CastHub.startScan()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = IxColors.Sheet,
        titleContentColor = IxColors.TextPrimary,
        textContentColor = IxColors.TextSecondary,
        title = { Text(stringResource(R.string.cast_title)) },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = summaryOf(context, items),
                    color = IxColors.TextSecondary,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )

                if (!granted) {
                    Text(stringResource(R.string.cast_permission), color = IxColors.TextPrimary, fontSize = 14.sp)
                    TextButton(
                        onClick = {
                            if (askedForNetwork) openAppSettings(context) else {
                                askedForNetwork = true
                                networkLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
                            }
                        },
                    ) {
                        Text(
                            stringResource(if (askedForNetwork) R.string.cast_open_settings else R.string.cast_allow),
                            color = IxColors.TextPrimary,
                        )
                    }
                } else if (devices.isEmpty()) {
                    Text(
                        text = stringResource(if (scanning) R.string.cast_scanning else R.string.cast_none),
                        color = IxColors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                    )
                    if (!scanning) {
                        Text(stringResource(R.string.cast_none_hint), fontSize = 13.sp)
                    }
                } else {
                    for (device in devices) {
                        DeviceRow(
                            device = device,
                            connected = state.device?.udn == device.udn,
                            onClick = {
                                // Android 13 and up asks before showing the "Casting" notification. Asked once.
                                if (Build.VERSION.SDK_INT >= 33 &&
                                    context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") !=
                                    android.content.pm.PackageManager.PERMISSION_GRANTED
                                ) {
                                    notificationLauncher.launch("android.permission.POST_NOTIFICATIONS")
                                }
                                CastHub.cast(device, items, startIndex)
                                onDismiss()
                            },
                        )
                    }
                    if (scanning) {
                        Text(stringResource(R.string.cast_scanning), fontSize = 12.sp)
                    }
                }

                OptionRow(
                    title = stringResource(R.string.cast_opt_formats),
                    hint = stringResource(R.string.cast_opt_formats_hint),
                    checked = settings.checkFormats,
                    onChange = { on -> CastHub.updateSettings { it.copy(checkFormats = on) } },
                )
                OptionRow(
                    title = stringResource(R.string.cast_opt_plain),
                    hint = stringResource(R.string.cast_opt_plain_hint),
                    checked = settings.plainStream,
                    onChange = { on -> CastHub.updateSettings { it.copy(plainStream = on) } },
                )
                Text(
                    text = stringResource(R.string.cast_copy_log),
                    color = IxColors.TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(role = Role.Button) {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("cast log", CastHub.logText()))
                            Toast.makeText(context, R.string.cast_log_copied, Toast.LENGTH_SHORT).show()
                        }
                        .padding(vertical = 6.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { CastHub.startScan(clear = true) }, enabled = granted && !scanning) {
                Text(stringResource(R.string.cast_scan_again), color = IxColors.TextPrimary)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = IxColors.TextPrimary) }
        },
    )
}

private fun summaryOf(context: Context, items: List<CastItem>): String =
    if (items.size == 1) items[0].title
    else context.resources.getQuantityString(
        R.plurals.cast_files, items.size, NumberFormat.getIntegerInstance().format(items.size),
    )

private fun openAppSettings(context: Context) {
    runCatching {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }
}

@Composable
private fun DeviceRow(device: CastDevice, connected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(IxColors.Field)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        PathIcon(
            when (device.kind) {
                DeviceKind.TV -> Glyphs.Tv
                DeviceKind.PC -> Glyphs.Laptop
                DeviceKind.SPEAKER -> Glyphs.Audio
            },
            tint = IxColors.TextPrimary,
            size = 24.dp,
            strokeWidth = 1.8f,
        )
        Column(Modifier.weight(1f)) {
            Text(
                text = device.name,
                color = IxColors.TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = device.subtitle,
                color = IxColors.TextSecondary,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (connected) {
            Text(
                text = stringResource(R.string.cast_connected),
                color = IxColors.Accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun OptionRow(title: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(text = title, color = IxColors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(text = hint, color = IxColors.TextSecondary, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = IxColors.Background,
                checkedTrackColor = IxColors.TextPrimary,
                uncheckedThumbColor = IxColors.TextSecondary,
                uncheckedTrackColor = IxColors.Chip,
                uncheckedBorderColor = IxColors.Outline,
            ),
        )
    }
}
