package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.FileItem
import ix.app.files.data.FolderItem
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

/**
 * Looks inside a zip without unpacking it: folders to walk into, files to tap.
 * Tapping a file unpacks just that one into the app's temporary space and opens it.
 * Back goes up one folder of the zip, and closes the screen at the top.
 */
@Composable
fun ZipScreen(
    zipName: String,
    inner: String,
    folders: List<FolderItem>,
    files: List<FileItem>,
    loading: Boolean,
    failed: Boolean,
    grid: Boolean,
    onUp: () -> Unit,
    onOpenFolder: (String) -> Unit,
    onOpenFile: (String) -> Unit,
    onExtract: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onUp)
    val context = LocalContext.current
    val backDescription = stringResource(R.string.back_description)
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val itemCount = folders.size + files.size
    // Nothing inside a zip can be ticked, so selection stays switched off here.
    val noSelection = remember { Selection(emptySet(), toggle = {}) }
    val title = if (inner.isEmpty()) zipName else inner.substringAfterLast('/')
    val whereLine = if (inner.isEmpty()) zipName else zipName + "  ›  " + inner.replace("/", "  ›  ")

    Box(
        modifier
            .fillMaxSize()
            .background(IxColors.Background)
            // Swallow taps so nothing underneath reacts.
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(start = 8.dp, end = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onUp)
                        .semantics { contentDescription = backDescription },
                    contentAlignment = Alignment.Center,
                ) {
                    PathIcon(Glyphs.ChevronLeft, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 2f)
                }
                Column(
                    Modifier
                        .weight(1f)
                        .padding(start = 4.dp, end = 8.dp),
                ) {
                    Text(
                        text = title,
                        color = IxColors.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = if (loading) "" else itemsLabel(context, itemCount),
                        color = IxColors.TextSecondary,
                        fontSize = 12.sp,
                        maxLines = 1,
                    )
                }
                Box(
                    Modifier
                        .height(40.dp)
                        .clip(CircleShape)
                        .background(IxColors.Button)
                        .clickable(role = Role.Button, onClick = onExtract)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(R.string.action_extract),
                        color = IxColors.TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }

            Text(
                text = whereLine,
                color = IxColors.TextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
            )

            when {
                loading -> Box(Modifier.fillMaxSize())

                failed -> ZipNote(stringResource(R.string.zip_failed))

                itemCount == 0 -> ZipNote(stringResource(R.string.zip_empty))

                // A new folder of the zip starts at the top of its list.
                else -> key(inner, grid) {
                    ItemsView(
                        folders = folders,
                        files = files,
                        grid = grid,
                        favorites = emptySet(),
                        selection = noSelection,
                        onOpenFolder = { onOpenFolder(it.path) },
                        onOpenFile = { onOpenFile(it.path) },
                        contentPadding = PaddingValues(bottom = bottomInset + 24.dp),
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}

@Composable
private fun ZipNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = text, color = IxColors.TextSecondary, fontSize = 14.sp)
    }
}
