package ix.app.files.ui.components

/** A glyph the user can pick for a Home folder. [key] is what gets saved. */
class FolderIconChoice(val key: String, val glyph: List<String>)

/**
 * Every icon offered in the folder editor. The six built-in folder icons come first.
 *
 * This is in its own file on purpose. The list reads [Glyphs] while it is being created, and [Glyphs] calls the
 * path helpers in PathIcon.kt while it is being created. With the list in PathIcon.kt as well, the two waited
 * for each other, the list saw glyphs that did not exist yet, and the app crashed as soon as it started.
 */
val FolderIconChoices: List<FolderIconChoice> = listOf(
    FolderIconChoice("downloads", Glyphs.Downloads),
    FolderIconChoice("images", Glyphs.Images),
    FolderIconChoice("videos", Glyphs.Videos),
    FolderIconChoice("audio", Glyphs.Audio),
    FolderIconChoice("docs", Glyphs.Docs),
    FolderIconChoice("apps", Glyphs.Apps),
    FolderIconChoice("star", Glyphs.Star),
    FolderIconChoice("heart", Glyphs.Heart),
    FolderIconChoice("home", Glyphs.Home),
    FolderIconChoice("camera", Glyphs.Camera),
    FolderIconChoice("book", Glyphs.Book),
    FolderIconChoice("work", Glyphs.Briefcase),
    FolderIconChoice("game", Glyphs.Game),
    FolderIconChoice("cloud", Glyphs.Cloud),
    FolderIconChoice("bolt", Glyphs.Bolt),
    FolderIconChoice("palette", Glyphs.Palette),
    FolderIconChoice("code", Glyphs.Code),
    FolderIconChoice("map", Glyphs.Pin),
    FolderIconChoice("lock", Glyphs.Lock),
    FolderIconChoice("plain", Glyphs.Folder),
)
