package ix.app.files.data

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.security.keystore.UserNotAuthenticatedException
import java.io.IOException
import java.security.GeneralSecurityException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * The Keystore key that guards the Private root key. It only works for [VALIDITY_SECONDS] after the user has
 * unlocked the phone with a fingerprint or the screen lock, so the root key can not be opened without them.
 *
 * Note: if the phone's screen lock is removed, Android deletes this key, and Private can not be opened any more.
 */
class AuthKeystoreSealer : RootSealer {

    private val lock = Any()

    private fun key(): SecretKey = synchronized(lock) {
        val store = KeyStore.getInstance("AndroidKeyStore")
        store.load(null)
        val existing = store.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true)
            // Adding a fingerprint must not make Private unreachable.
            .setInvalidatedByBiometricEnrollment(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            spec.setUserAuthenticationParameters(
                VALIDITY_SECONDS,
                KeyProperties.AUTH_DEVICE_CREDENTIAL or KeyProperties.AUTH_BIOMETRIC_STRONG,
            )
        } else {
            @Suppress("DEPRECATION")
            spec.setUserAuthenticationValidityDurationSeconds(VALIDITY_SECONDS)
        }
        generator.init(spec.build())
        generator.generateKey()
    }

    override fun seal(secret: ByteArray): ByteArray = guarded {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        cipher.iv + cipher.doFinal(secret)
    }

    override fun open(blob: ByteArray): ByteArray = guarded {
        if (blob.size <= IV_SIZE) throw IOException("Damaged key")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, blob, 0, IV_SIZE))
        cipher.doFinal(blob, IV_SIZE, blob.size - IV_SIZE)
    }

    private fun <T> guarded(block: () -> T): T = try {
        block()
    } catch (e: UserNotAuthenticatedException) {
        throw IOException("Unlock Private first", e)
    } catch (e: KeyPermanentlyInvalidatedException) {
        throw IOException("The key for Private is gone", e)
    } catch (e: GeneralSecurityException) {
        throw IOException("The key for Private could not be used", e)
    }

    companion object {
        const val ALIAS = "ix_files_private_session"
        const val VALIDITY_SECONDS = 60
        private const val IV_SIZE = 12
    }
}

/**
 * The old master key of the Private folder, which opened without asking the user. It is only read now, to open
 * files made by earlier versions until they have moved to the new key. It is never created again.
 */
class LegacyKeystoreKey : LegacyKey {

    private fun existing(): SecretKey? {
        val store = KeyStore.getInstance("AndroidKeyStore")
        store.load(null)
        return store.getKey(ALIAS, null) as? SecretKey
    }

    override fun wrap(key: ByteArray): ByteArray = throw IOException("The old key is read only")

    override fun unwrap(blob: ByteArray): ByteArray {
        if (blob.size <= IV_SIZE) throw IOException("Damaged key")
        val key = existing() ?: throw IOException("The old key is gone")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, IV_SIZE))
        return cipher.doFinal(blob, IV_SIZE, blob.size - IV_SIZE)
    }

    override fun retire() {
        val store = KeyStore.getInstance("AndroidKeyStore")
        store.load(null)
        if (store.containsAlias(ALIAS)) store.deleteEntry(ALIAS)
    }

    companion object {
        const val ALIAS = "ix_files_private_master"
        private const val IV_SIZE = 12

        /** True if an earlier version made the old key, so older files may need moving. */
        fun exists(): Boolean {
            val store = KeyStore.getInstance("AndroidKeyStore")
            store.load(null)
            return store.containsAlias(ALIAS)
        }
    }
}
