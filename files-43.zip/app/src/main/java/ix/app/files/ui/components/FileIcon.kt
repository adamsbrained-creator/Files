package ix.app.files.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.ui.theme.IxColors

private fun parse(data: String): Path = PathParser().parsePathString(data).toPath()

private val page = parse("M4 1h14l9 9v24a3 3 0 0 1-3 3H4a3 3 0 0 1-3-3V4a3 3 0 0 1 3-3z")
private val fold = parse("M18 1l9 9h-6a3 3 0 0 1-3-3z")

/** Gray page icon with the file extension on it, e.g. ".pdf". */
@Composable
fun FileIcon(extension: String, modifier: Modifier = Modifier) {
    Box(modifier.size(width = 28.dp, height = 36.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            scale(size.width / 30f, size.height / 38f, pivot = Offset.Zero) {
                drawPath(
                    page,
                    Brush.verticalGradient(
                        colors = listOf(IxColors.FileTop, IxColors.FileBottom),
                        startY = 1f,
                        endY = 37f,
                    ),
                )
                drawPath(fold, IxColors.FileFold)
            }
        }
        if (extension.isNotEmpty()) Text(
            text = ".${extension.take(4)}",
            color = IxColors.TextPrimary,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 7.dp),
        )
    }
}
