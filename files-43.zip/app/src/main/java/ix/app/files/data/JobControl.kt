package ix.app.files.data

import java.util.concurrent.atomic.AtomicLong

/** Thrown inside a running job when the user pressed Cancel. */
class JobStopped : Exception()

/**
 * Shared between a long job (copy, move, zip, extract) and the screen.
 * The job adds the bytes it has handled and checks [check] now and then; the screen reads [done] to draw
 * a progress bar and sets [cancelled] when Cancel is tapped.
 */
class JobControl {
    private val handled = AtomicLong(0L)

    /** How many bytes the whole job will handle. Zero while that is not known yet. */
    @Volatile
    var totalBytes: Long = 0L

    @Volatile
    var cancelled: Boolean = false

    val done: Long get() = handled.get()

    fun add(bytes: Long) {
        handled.addAndGet(bytes)
    }

    fun cancel() {
        cancelled = true
    }

    /** Call between small steps. Throws [JobStopped] once Cancel was tapped. */
    fun check() {
        if (cancelled) throw JobStopped()
    }
}
