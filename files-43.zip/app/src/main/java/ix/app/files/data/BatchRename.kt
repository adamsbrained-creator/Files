package ix.app.files.data

import java.io.File

/** How the new names are made. Files keep their extension in every mode. */
sealed interface RenameRule {
    /** "[base][number]": the first item gets [start], the next one more, padded with zeros to [digits] figures. */
    data class Numbering(val base: String, val start: Int, val digits: Int) : RenameRule

    /** Swaps [find] for [with] in the name part. Items that do not contain [find] stay as they are. */
    data class Replace(val find: String, val with: String, val ignoreCase: Boolean) : RenameRule

    /** Puts [prefix] before the name part and [suffix] after it (before the extension). */
    data class Affix(val prefix: String, val suffix: String) : RenameRule
}

/** Why an item cannot be renamed the way the rule asks. */
enum class RenameProblem {
    /** The new name is empty, or has a slash, or is "." or "..". */
    Invalid,

    /** The new name is too long for a file system. */
    TooLong,

    /** Another item of the batch gets the same new name. */
    Clash,

    /** Something else already has that name in the folder. */
    Exists,
}

/** One line of the preview: [file] goes from [oldName] to [newName]. [problem] is null when it can go ahead. */
class RenameRow(
    val file: File,
    val oldName: String,
    val newName: String,
    val isDirectory: Boolean,
    val problem: RenameProblem?,
) {
    val changed: Boolean get() = newName != oldName
    val ready: Boolean get() = changed && problem == null
}

/** What a batch rename did. [moved] maps each old path to the new one, for the ones that went through. */
class RenameResult(val moved: Map<String, String>, val failed: Int)

/**
 * Renames many items in one go. [preview] is pure planning and can run on every key press;
 * [apply] touches the disk and must run off the main thread.
 */
object BatchRename {

    private const val MAX_NAME_BYTES = 255

    /** Names that sort the way people count: "file2" before "file10". */
    private val naturalOrder = Comparator<String> { a, b -> compareNatural(a, b) }

    /**
     * Works out the new name of every item in [files], in natural name order, and marks the ones that cannot
     * go ahead. [plainName] is the name as the person sees it (inside Private the file name on disk is not).
     */
    fun preview(
        files: List<File>,
        rule: RenameRule,
        plainName: (File) -> String = { VaultNames.plainName(it) },
        storedName: (File, String) -> String = { file, plain -> VaultNames.storedName(file.parentFile, plain) },
    ): List<RenameRow> {
        val ordered = files.sortedWith(compareBy(naturalOrder) { plainName(it) })

        val proposed = ArrayList<String>(ordered.size)
        var number = (rule as? RenameRule.Numbering)?.start ?: 0
        for (file in ordered) {
            val old = plainName(file)
            val isDir = file.isDirectory
            val (stem, extension) = split(old, isDir)
            val next = when (rule) {
                is RenameRule.Numbering -> {
                    val text = number.toString().padStart(rule.digits.coerceIn(1, 9), '0')
                    number += 1
                    rule.base + text + extension
                }

                is RenameRule.Replace ->
                    if (rule.find.isEmpty()) old else stem.replace(rule.find, rule.with, rule.ignoreCase) + extension

                is RenameRule.Affix -> rule.prefix + stem + rule.suffix + extension
            }
            proposed.add(next)
        }

        // The ones that really move. Their old names become free, so another item may take them.
        val leaving = HashSet<String>()
        for (i in ordered.indices) {
            if (proposed[i] != plainName(ordered[i])) leaving.add(key(ordered[i]))
        }

        // How many items of the batch want each new name inside each folder. File systems on phones are often
        // case-blind, so "A.txt" and "a.txt" count as the same.
        val wanted = HashMap<String, Int>()
        for (i in ordered.indices) {
            val k = targetKey(ordered[i], proposed[i], storedName)
            wanted[k] = (wanted[k] ?: 0) + 1
        }

        val rows = ArrayList<RenameRow>(ordered.size)
        for (i in ordered.indices) {
            val file = ordered[i]
            val old = plainName(file)
            val new = proposed[i]
            var problem: RenameProblem? = null
            if (new != old) {
                problem = when {
                    new.isBlank() || new.contains('/') || new.contains('\u0000') || new == "." || new == ".." ->
                        RenameProblem.Invalid

                    safeStored(file, new, storedName).toByteArray(Charsets.UTF_8).size > MAX_NAME_BYTES ->
                        RenameProblem.TooLong

                    (wanted[targetKey(file, new, storedName)] ?: 0) > 1 -> RenameProblem.Clash

                    else -> {
                        val target = File(file.parentFile, safeStored(file, new, storedName))
                        val sameItem = target.path.equals(file.path, ignoreCase = true)
                        val freed = target.path.lowercase() in leaving
                        if (target.exists() && !sameItem && !freed) RenameProblem.Exists else null
                    }
                }
            }
            rows.add(RenameRow(file, old, new, file.isDirectory, problem))
        }
        return rows
    }

    /**
     * Renames every row that is [RenameRow.ready]. Items whose new name is another item's old name (swaps,
     * shifting "1 to 2, 2 to 3") go through a temporary name, so nothing is ever overwritten. An item that
     * cannot be renamed is left as it was. [control] is checked between items; when it is cancelled the
     * rename stops with the rest untouched.
     */
    fun apply(
        rows: List<RenameRow>,
        control: JobControl? = null,
        storedName: (File, String) -> String = { file, plain -> VaultNames.storedName(file.parentFile, plain) },
        rename: (File, File) -> Boolean = { from, to -> from.renameTo(to) },
    ): RenameResult {
        val ready = rows.filter { it.ready }
        val moved = LinkedHashMap<String, String>()
        var failed = 0
        val sources = ready.map { it.file.path.lowercase() }.toHashSet()

        val direct = ArrayList<Pair<RenameRow, File>>()
        val chained = ArrayList<Pair<RenameRow, File>>()
        for (row in ready) {
            val target = File(row.file.parentFile, storedName(row.file, row.newName))
            if (target.path.lowercase() in sources) chained.add(row to target) else direct.add(row to target)
        }

        // Items parked under a temporary name while their final name is still taken: (row, temp, target).
        val parked = ArrayList<Triple<RenameRow, File, File>>()
        try {
            for ((row, target) in direct) {
                control?.check()
                if (!target.exists() && rename(row.file, target)) {
                    moved[row.file.path] = target.path
                } else {
                    failed += 1
                }
            }

            // Phase one: out of the way. Phase two: into place. A failure puts the item back.
            for ((row, target) in chained) {
                control?.check()
                val temp = tempFor(row.file, parked.size)
                if (rename(row.file, temp)) parked.add(Triple(row, temp, target)) else failed += 1
            }
        } catch (e: JobStopped) {
            // Stopped while parking: everything parked so far goes back, and the rest stays untouched.
            for ((row, temp, _) in parked) rename(temp, row.file)
            return RenameResult(moved, failed)
        }
        // Past the point where stopping could leave names parked, so this phase always finishes.
        for ((row, temp, target) in parked) {
            if (!target.exists() && rename(temp, target)) {
                moved[row.file.path] = target.path
            } else {
                rename(temp, row.file)
                failed += 1
            }
        }
        return RenameResult(moved, failed)
    }

    private fun tempFor(file: File, index: Int): File =
        File(file.parentFile, ".ixrename-$index-${System.nanoTime()}")

    private fun safeStored(file: File, plain: String, storedName: (File, String) -> String): String =
        try {
            storedName(file, plain)
        } catch (e: Exception) {
            plain
        }

    private fun key(file: File): String = file.path.lowercase()

    private fun targetKey(file: File, plain: String, storedName: (File, String) -> String): String =
        File(file.parentFile, safeStored(file, plain, storedName)).path.lowercase()

    /** Splits "photo.jpg" into "photo" and ".jpg". Folders, hidden names and names without a dot have no extension. */
    fun split(name: String, isDirectory: Boolean): Pair<String, String> {
        if (isDirectory) return name to ""
        if (ArchiveFormat.of(name) != null) {
            val base = ArchiveFormat.baseName(name)
            if (base.isNotEmpty() && base.length < name.length) return base to name.substring(base.length)
        }
        val dot = name.lastIndexOf('.')
        return if (dot > 0 && dot < name.length - 1) name.substring(0, dot) to name.substring(dot) else name to ""
    }

    /** Compares names so that runs of digits count by value: "img2" comes before "img10". */
    fun compareNatural(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        val rest = (a.length - i) - (b.length - j)
        return if (rest != 0) rest else a.compareTo(b)
    }
}
