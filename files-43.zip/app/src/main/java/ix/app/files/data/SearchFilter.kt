package ix.app.files.data

import androidx.compose.runtime.Immutable

/** The size bands the search can be narrowed to. [min] counts, [max] does not. */
enum class SizeBand(val min: Long, val max: Long) {
    Any(0L, Long.MAX_VALUE),
    Small(0L, 1L * 1024 * 1024),
    Medium(1L * 1024 * 1024, 100L * 1024 * 1024),
    Large(100L * 1024 * 1024, Long.MAX_VALUE),
}

/** How recently something was changed. [days] is zero for [Any]. */
enum class DateBand(val days: Int) {
    Any(0),
    Day(1),
    Week(7),
    Month(30),
    Year(365),
}

/**
 * What the search is narrowed to: one kind of file, one size band, one date band. Anything left on
 * "any" lets everything through. Folders have no kind and no size, so they only stay in the results
 * while those two are on "any".
 */
@Immutable
data class SearchFilter(
    val kind: FileKind? = null,
    val size: SizeBand = SizeBand.Any,
    val date: DateBand = DateBand.Any,
) {
    val isActive: Boolean get() = kind != null || size != SizeBand.Any || date != DateBand.Any

    /** Folders can only be told apart by their date. */
    val includesFolders: Boolean get() = kind == null && size == SizeBand.Any

    fun matches(file: FileItem, now: Long): Boolean {
        if (kind != null && file.kind != kind) return false
        if (file.sizeBytes < size.min || file.sizeBytes >= size.max) return false
        return recentEnough(file.modifiedMillis, now)
    }

    fun matches(folder: FolderItem, now: Long): Boolean = includesFolders && recentEnough(folder.modifiedMillis, now)

    private fun recentEnough(modifiedMillis: Long, now: Long): Boolean {
        if (date == DateBand.Any) return true
        return modifiedMillis >= now - date.days * DAY_MILLIS
    }

    companion object {
        val None = SearchFilter()
        private const val DAY_MILLIS = 24L * 60 * 60 * 1000
    }
}
