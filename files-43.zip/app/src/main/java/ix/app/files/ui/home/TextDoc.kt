package ix.app.files.ui.home

import androidx.annotation.StringRes
import ix.app.files.data.TextProblem

/**
 * The text file open in the reader and editor. It lives apart from the main screen state, so typing
 * does not redraw everything else. The text being typed is kept by the view model, not in here.
 */
data class TextDoc(
    val path: String,
    /** The real name, with its extension, even for a file in Private. */
    val name: String,
    val loading: Boolean = true,
    val problem: TextProblem? = null,
    /** The text as last read or saved. */
    val text: String = "",
    val sizeBytes: Long = 0L,
    val crlf: Boolean = false,
    val bom: Boolean = false,
    /** Why this file can only be read, or null if it can be edited. */
    @StringRes val readOnlyReason: Int? = null,
    val editing: Boolean = false,
    /** True when what is typed differs from [text]. */
    val dirty: Boolean = false,
    val saving: Boolean = false,
    /** Goes up whenever the editor has to start again from [text]. */
    val session: Int = 0,
) {
    val canEdit: Boolean get() = !loading && problem == null && readOnlyReason == null
}
