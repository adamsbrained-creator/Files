package ix.app.files.ui.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.data.FileItem
import ix.app.files.data.FileKind
import ix.app.files.data.FolderItem
import ix.app.files.ui.components.FileIcon
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.data.Thumbnails
import ix.app.files.ui.components.Thumbnail
import ix.app.files.ui.theme.IxColors

/** A file as a tile for the grid view: a big preview or icon with the name under it. */
@Composable
fun FileTile(
    file: FileItem,
    selection: Selection,
    favorite: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Tile(
        path = file.path,
        title = if (file.extension.isEmpty()) file.name else "${file.name}.${file.extension}",
        favorite = favorite,
        selection = selection,
        onOpen = onOpen,
        modifier = modifier,
        visual = {
            if (Thumbnails.supports(file)) {
                Thumbnail(file, size = TILE_VISUAL) { FileIcon(file.extension) }
            } else {
                FileIcon(file.extension)
            }
        },
    )
}

/** A folder as a tile for the grid view. */
@Composable
fun FolderTile(
    folder: FolderItem,
    selection: Selection,
    favorite: Boolean,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Tile(
        path = folder.path,
        title = folder.name,
        favorite = favorite,
        selection = selection,
        onOpen = onOpen,
        modifier = modifier,
        visual = { FolderIcon(emptyList(), Modifier.size(width = 84.dp, height = 70.dp)) },
    )
}

private val TILE_VISUAL = 92.dp

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Tile(
    path: String,
    title: String,
    favorite: Boolean,
    selection: Selection,
    onOpen: () -> Unit,
    modifier: Modifier,
    visual: @Composable () -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val selected = path in selection.paths

    Column(
        modifier
            .padding(4.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) IxColors.Chip else Color.Transparent)
            .combinedClickable(
                role = Role.Button,
                onClick = { if (selection.active) selection.toggle(path) else onOpen() },
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    selection.toggle(path)
                },
            )
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(TILE_VISUAL), contentAlignment = Alignment.Center) {
            visual()
            if (selection.active) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp),
                ) { SelectMark(selected) }
            } else if (favorite) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(2.dp),
                ) { PathIcon(Glyphs.Star, tint = IxColors.Accent, size = 16.dp, strokeWidth = 2f) }
            }
        }
        Text(
            text = title,
            color = IxColors.TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}
