# R8 rules for ix.app.files.
# Compose, AndroidX and lifecycle ship their own consumer rules, so nothing extra is needed yet.
# Add keep rules here only when a library that uses reflection is introduced.

# Keep readable stack traces. Upload mapping.txt (the workflow does) to de-obfuscate them.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# The archive libraries (commons-compress, xz, junrar and what they build on) mention optional classes that are
# not shipped (zstd, brotli, asm, osgi, slf4j bindings). They are never used here, so R8 must not stop for them.
-dontwarn org.apache.commons.**
-dontwarn org.tukaani.**
-dontwarn com.github.junrar.**
-dontwarn com.github.luben.**
-dontwarn org.brotli.**
-dontwarn org.objectweb.asm.**
-dontwarn org.osgi.**
-dontwarn org.slf4j.**
-dontwarn javax.annotation.**
