# ix.app.files

A fast, minimal Android file manager. Kotlin, Jetpack Compose, Material 3.

Design reference: the Home mockup (dark, gray folders, bottom "Recent" sheet).
Behavior reference: [Material Files](https://github.com/zhanghai/materialfiles). It is GPL-3.0 and is
only a reference for how a file manager should behave. No code is copied from it.

## Status: Round 1 (Home screen)

| Done | Next |
| --- | --- |
| Home layout from the mockup | Round 2: real files (MediaStore + storage access), open a category |
| Header with live storage pill | Round 3: folder browser, selection, file actions |
| Search field, Stack menu button | Private folder with biometric unlock |
| All / Favorites / Private tabs | Favorites stored on device |
| Six category folders (gray folder + glyphs) | Gesture navigation |
| Recent sheet: sort menu, expand / collapse | |
| GitHub Actions: R8 release APK | |

Home currently shows **sample data** for categories, recent files and favorites.
The storage pill is real (it reads the device's storage).

## Build locally

Needs JDK 17 and the Android SDK (API 35).

```
./gradlew :app:assembleRelease
```

The APK lands in `app/build/outputs/apk/release/`.

## Build on GitHub

1. Create a repo and push this folder to `main`.
2. Open the **Actions** tab. **Release APK** runs on its own for every push.
   You can also start it with **Run workflow**.
3. When it finishes, open the run and download:
   - `ix.app.files-release-apk` is the installable APK.
   - `r8-mapping` is the R8 mapping file. Keep it to decode crash traces.
4. To publish a GitHub Release with the APK attached, push a tag: `git tag v0.1.0 && git push --tags`.

Without any secrets the APK is signed with the **debug key**. It installs fine and is good for testing.
Debug-signed and own-key-signed builds can't be installed over each other, so uninstall first if you switch.

### Sign with your own key (optional)

Create a keystore once:

```
keytool -genkeypair -v -keystore release.jks -alias ixfiles -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks > release.jks.b64        # on macOS: base64 -i release.jks
```

Then add four repository secrets (Settings > Secrets and variables > Actions):

| Secret | Value |
| --- | --- |
| `IX_KEYSTORE_BASE64` | contents of `release.jks.b64` |
| `IX_KEYSTORE_PASSWORD` | the store password |
| `IX_KEY_ALIAS` | `ixfiles` (or your alias) |
| `IX_KEY_PASSWORD` | the key password |

Keep `release.jks` somewhere safe and never commit it. Losing it means you can't update installed copies.

## Project layout

```
app/src/main/java/ix/app/files/
  MainActivity.kt
  data/        models, sample data, storage info
  ui/theme/    colors and theme
  ui/components/  PathIcon (stroked SVG icons), FolderIcon, FileIcon
  ui/home/     HomeScreen, header, tabs, category grid, recent sheet, view model
  util/        size formatting
```

Icons are drawn from the same SVG paths as the mockup, so there are no icon libraries or image files.
