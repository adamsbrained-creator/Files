package ix.app.files.data

/**
 * Placeholder content for Round 1 so the Home screen looks like the mockup.
 * Round 2 replaces this with real files from the device.
 */
object SampleData {

    val categoryCounts: Map<Category, Int> = mapOf(
        Category.Downloads to 42,
        Category.Images to 1284,
        Category.Videos to 96,
        Category.Audio to 312,
        Category.Docs to 208,
        Category.Apps to 64,
    )

    private const val MINUTE = 60_000L
    private const val HOUR = 60 * MINUTE
    private const val DAY = 24 * HOUR

    private const val KB = 1_000L
    private const val MB = 1_000 * KB

    fun recent(now: Long = System.currentTimeMillis()): List<FileItem> = listOf(
        FileItem("Invoice_October", "pdf", 1_100 * KB, now - 35 * MINUTE, FileKind.Document),
        FileItem("IMG_4821", "jpg", 3_400 * KB, now - 80 * MINUTE, FileKind.Image),
        FileItem("Voice memo 12", "m4a", 820 * KB, now - 26 * HOUR, FileKind.Audio),
        FileItem("Contract_v3", "pdf", 1_400 * KB, now - 4 * DAY, FileKind.Document),
        FileItem("Q3_notes", "pdf", 320 * KB, now - 5 * DAY, FileKind.Document),
        FileItem("Moodboard", "pdf", 4_200 * KB, now - 6 * DAY, FileKind.Document),
        FileItem("Holiday_clip", "mp4", 148 * MB, now - 7 * DAY, FileKind.Video),
        FileItem("ix-files-debug", "apk", 24 * MB, now - 9 * DAY, FileKind.App),
        FileItem("Budget_2026", "xlsx", 210 * KB, now - 10 * DAY, FileKind.Document),
        FileItem("Cover letter", "docx", 48 * KB, now - 12 * DAY, FileKind.Document),
        FileItem("Podcast_ep7", "mp3", 38 * MB, now - 14 * DAY, FileKind.Audio),
    )

    fun favorites(now: Long = System.currentTimeMillis()): List<FileItem> =
        recent(now).filter { it.name in setOf("Contract_v3", "Moodboard", "Q3_notes") }
}
