package ix.app.files.ui.home

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ix.app.files.R
import ix.app.files.data.Category
import ix.app.files.ui.components.FolderIcon
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.theme.IxColors
import java.text.NumberFormat

private val Category.titleRes: Int
    get() = when (this) {
        Category.Downloads -> R.string.category_downloads
        Category.Images -> R.string.category_images
        Category.Videos -> R.string.category_videos
        Category.Audio -> R.string.category_audio
        Category.Docs -> R.string.category_docs
        Category.Apps -> R.string.category_apps
    }

private val Category.glyph: List<String>
    get() = when (this) {
        Category.Downloads -> Glyphs.Downloads
        Category.Images -> Glyphs.Images
        Category.Videos -> Glyphs.Videos
        Category.Audio -> Glyphs.Audio
        Category.Docs -> Glyphs.Docs
        Category.Apps -> Glyphs.Apps
    }

/** The six default folders, three per row, sitting directly on the background. */
@Composable
fun CategoryGrid(
    counts: Map<Category, Int>,
    onCategoryClick: (Category) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier.padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Category.entries.chunked(3).forEach { rowItems ->
            Row(Modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { category ->
                    CategoryCell(
                        category = category,
                        count = counts[category] ?: 0,
                        onClick = { onCategoryClick(category) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryCell(
    category: Category,
    count: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FolderIcon(category.glyph, Modifier.size(width = 84.dp, height = 70.dp))
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(category.titleRes),
            color = IxColors.TextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = itemsLabel(LocalContext.current, count),
            color = IxColors.TextSecondary,
            fontSize = 12.sp,
        )
    }
}

/** "42 items", "1,284 items", "1 item". */
fun itemsLabel(context: Context, count: Int): String =
    context.resources.getQuantityString(R.plurals.items_count, count, NumberFormat.getIntegerInstance().format(count))
