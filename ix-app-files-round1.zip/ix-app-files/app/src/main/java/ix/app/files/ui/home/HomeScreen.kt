package ix.app.files.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.border
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.coerceAtMost
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import ix.app.files.R
import ix.app.files.data.HomeTab
import ix.app.files.data.StorageInfo
import ix.app.files.ui.components.Glyphs
import ix.app.files.ui.components.PathIcon
import ix.app.files.ui.theme.IxColors

@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val storage = remember { StorageInfo.read() }
    val density = LocalDensity.current

    // Height of everything above the sheet. The collapsed sheet starts right below it,
    // so it fits any screen size instead of relying on fixed offsets.
    var topContentPx by remember { mutableIntStateOf(0) }

    BackHandler(enabled = state.sheetExpanded) { viewModel.setSheetExpanded(false) }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(IxColors.Background),
    ) {
        val statusBarHeight = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        val topContent = with(density) { topContentPx.toDp() }
        val collapsedTop = (topContent + 16.dp).coerceAtMost(maxHeight - 280.dp).coerceAtLeast(0.dp)
        // Expanded: leave the title and the search field visible, cover the rest.
        val expandedTop = statusBarHeight + 128.dp

        Column(
            Modifier
                .fillMaxWidth()
                .onSizeChanged { topContentPx = it.height }
                .statusBarsPadding()
                .padding(top = 12.dp),
        ) {
            HomeHeader(storage)
            Spacer(Modifier.height(12.dp))
            SearchRow()
            Spacer(Modifier.height(6.dp))
            HomeTabs(selected = state.tab, onSelect = viewModel::selectTab)
            Spacer(Modifier.height(16.dp))

            when (state.tab) {
                HomeTab.All -> CategoryGrid(
                    counts = state.categoryCounts,
                    onCategoryClick = { /* Round 2: open the category */ },
                )

                HomeTab.Favorites -> Column {
                    state.favorites.forEach { FileRow(it) }
                }

                HomeTab.Private -> PrivateLocked()
            }
        }

        // The sheet is only shown once the content above it has been measured,
        // so it never flies in from the wrong place on launch.
        if (topContentPx > 0) {
            val sheetTop by animateDpAsState(
                targetValue = if (state.sheetExpanded) expandedTop else collapsedTop,
                label = "sheetTop",
            )
            RecentSheet(
                files = state.recent,
                sort = state.sort,
                expanded = state.sheetExpanded,
                onToggleExpanded = { viewModel.setSheetExpanded(!state.sheetExpanded) },
                onSortSelected = viewModel::selectSort,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = sheetTop),
            )
        }
    }
}

@Composable
private fun PrivateLocked() {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(IxColors.Field),
            contentAlignment = Alignment.Center,
        ) {
            PathIcon(Glyphs.Lock, tint = IxColors.TextPrimary, size = 24.dp, strokeWidth = 1.8f)
        }
        Text(
            text = stringResource(R.string.private_locked),
            color = IxColors.TextSecondary,
            fontSize = 14.sp,
        )
        Box(
            Modifier
                .height(44.dp)
                .clip(CircleShape)
                .border(1.dp, IxColors.Outline, CircleShape)
                .clickable(role = Role.Button) { /* Round 3: biometric unlock */ }
                .padding(horizontal = 28.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.private_unlock),
                color = IxColors.TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}
