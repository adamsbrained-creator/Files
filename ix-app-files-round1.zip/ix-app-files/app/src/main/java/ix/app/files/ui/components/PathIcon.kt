package ix.app.files.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Draws a stroked icon from SVG path data on a 24 x 24 grid.
 * The icons are the same paths used in the design mockup, so the app matches it exactly.
 */
@Composable
fun PathIcon(
    paths: List<String>,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    size: Dp = 24.dp,
    strokeWidth: Float = 1.8f,
) {
    val parsed = remember(paths) {
        paths.map { PathParser().parsePathString(it).toPath() }
    }
    Canvas(modifier.size(size)) {
        val factor = this.size.minDimension / 24f
        scale(factor, factor, pivot = Offset.Zero) {
            val stroke = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
            parsed.forEach { drawPath(it, tint, style = stroke) }
        }
    }
}

/** Path builders so rounded rectangles and circles can sit next to hand-written paths. */
fun roundRectPath(x: Float, y: Float, w: Float, h: Float, r: Float): String =
    "M${x + r} ${y}h${w - 2 * r}a$r $r 0 0 1 $r $r" +
        "v${h - 2 * r}a$r $r 0 0 1 -$r $r" +
        "h${-(w - 2 * r)}a$r $r 0 0 1 -$r -$r" +
        "v${-(h - 2 * r)}a$r $r 0 0 1 $r -${r}z"

fun circlePath(cx: Float, cy: Float, r: Float): String =
    "M${cx - r} ${cy}a$r $r 0 1 0 ${2 * r} 0a$r $r 0 1 0 ${-2 * r} 0z"

/** Every glyph in the app. All are 24 x 24, stroke only. */
object Glyphs {
    val Search = listOf(circlePath(11f, 11f, 7f), "M20 20l-3.5-3.5")

    /** The "Stack" menu icon chosen from the options board. */
    val Stack = listOf(
        roundRectPath(4f, 8f, 12f, 13f, 2f),
        "M8 8V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2",
    )

    val Star = listOf("M12 3.8l2.5 5.1 5.6.8-4.1 3.9 1 5.6-5-2.7-5 2.7 1-5.6L3.9 9.7l5.6-.8z")
    val Lock = listOf(roundRectPath(5f, 11f, 14f, 9f, 2.5f), "M8 11V8a4 4 0 0 1 8 0v3")

    val ArrowDown = listOf("M12 5v14M6 13l6 6 6-6")
    val ArrowUp = listOf("M12 19V5M6 11l6-6 6 6")
    val ChevronUp = listOf("M6 15l6-6 6 6")

    // Folder glyphs
    val Downloads = listOf("M12 4.5v10M7.8 10.6L12 14.8l4.2-4.2M5.5 19h13")
    val Images = listOf(
        roundRectPath(4f, 5f, 16f, 14f, 3.5f),
        circlePath(9f, 10f, 1.5f),
        "M4.5 17l4.3-4.3 3.4 3.4 2.8-2.8 4.5 4.5",
    )
    val Videos = listOf(roundRectPath(3.5f, 6f, 17f, 12f, 3.5f), "M10.5 9.6v4.8l4-2.4z")
    val Audio = listOf(
        "M9.5 17.5V6.5l9-2v11",
        circlePath(7f, 17.5f, 2.5f),
        circlePath(16f, 15.5f, 2.5f),
    )
    val Docs = listOf(
        "M7 3.5h6.5L18 8v11.5a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-15a1 1 0 0 1 1-1z",
        "M13.5 3.5V8H18M9 12.5h6M9 16h6",
    )
    val Apps = listOf(
        roundRectPath(4.5f, 4.5f, 6f, 6f, 1.8f),
        roundRectPath(13.5f, 4.5f, 6f, 6f, 1.8f),
        roundRectPath(4.5f, 13.5f, 6f, 6f, 1.8f),
        roundRectPath(13.5f, 13.5f, 6f, 6f, 1.8f),
    )
}
