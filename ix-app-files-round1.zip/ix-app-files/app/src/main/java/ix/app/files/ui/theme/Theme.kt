package ix.app.files.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Colors lifted from the Home mockup. */
object IxColors {
    val Background = Color(0xFF0E0E10)
    val Sheet = Color(0xFF141416)
    val SheetBorder = Color(0xFF232327)
    val Field = Color(0xFF1A1A1D)
    val Button = Color(0xFF26262A)
    val Chip = Color(0xFF212125)
    val Outline = Color(0xFF2C2C31)
    val Handle = Color(0xFF3A3A40)

    val TextPrimary = Color(0xFFF3F3F4)
    val TextSecondary = Color(0xFFA4A4AB)

    val Accent = Color(0xFFFF6A2B)

    // Gray folder, from the Files canvas mockup
    val FolderBack = Color(0xFF9A9AA2)
    val FolderPaper = Color(0xFFECECEE)
    val FolderFrontTop = Color(0xFFF4F4F5)
    val FolderFrontBottom = Color(0xFFC9C9CE)
    val FolderGlyph = Color(0xFF4A4A52)

    // Gray page icon used in the file list
    val FileTop = Color(0xFF8A8A92)
    val FileBottom = Color(0xFF5A5A61)
    val FileFold = Color(0xFFB4B4BC)
}

private val IxDarkColorScheme = darkColorScheme(
    background = IxColors.Background,
    surface = IxColors.Sheet,
    surfaceContainer = IxColors.Button,
    onBackground = IxColors.TextPrimary,
    onSurface = IxColors.TextPrimary,
    onSurfaceVariant = IxColors.TextSecondary,
    primary = IxColors.TextPrimary,
    onPrimary = IxColors.Background,
    outline = IxColors.Outline,
)

@Composable
fun IxFilesTheme(content: @Composable () -> Unit) {
    // Dark only for now, matching the mockup.
    MaterialTheme(
        colorScheme = IxDarkColorScheme,
        content = content,
    )
}
