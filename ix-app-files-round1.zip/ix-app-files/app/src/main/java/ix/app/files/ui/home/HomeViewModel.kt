package ix.app.files.ui.home

import androidx.lifecycle.ViewModel
import ix.app.files.data.Category
import ix.app.files.data.FileItem
import ix.app.files.data.HomeTab
import ix.app.files.data.SampleData
import ix.app.files.data.SortField
import ix.app.files.data.SortSpec
import ix.app.files.data.sortedBySpec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class HomeState(
    val tab: HomeTab = HomeTab.All,
    val sort: SortSpec = SortSpec(),
    val sheetExpanded: Boolean = false,
    val categoryCounts: Map<Category, Int> = emptyMap(),
    val recent: List<FileItem> = emptyList(),
    val favorites: List<FileItem> = emptyList(),
)

class HomeViewModel : ViewModel() {

    // Round 1 uses sample data. The sorted lists are kept in sync whenever the sort changes.
    private val allRecent = SampleData.recent()
    private val allFavorites = SampleData.favorites()

    private val _state = MutableStateFlow(
        HomeState(
            categoryCounts = SampleData.categoryCounts,
            recent = allRecent.sortedBySpec(SortSpec()),
            favorites = allFavorites.sortedBySpec(SortSpec()),
        ),
    )
    val state: StateFlow<HomeState> = _state.asStateFlow()

    fun selectTab(tab: HomeTab) = _state.update { it.copy(tab = tab) }

    fun selectSort(field: SortField) = _state.update {
        val spec = it.sort.select(field)
        it.copy(
            sort = spec,
            recent = allRecent.sortedBySpec(spec),
            favorites = allFavorites.sortedBySpec(spec),
        )
    }

    fun setSheetExpanded(expanded: Boolean) = _state.update { it.copy(sheetExpanded = expanded) }
}
