package ix.app.files.data

enum class FileKind { Document, Image, Video, Audio, App, Other }

/** A file as the UI needs it. [name] has no extension, [extension] has no dot. */
data class FileItem(
    val name: String,
    val extension: String,
    val sizeBytes: Long,
    val modifiedMillis: Long,
    val kind: FileKind,
)

enum class Category { Downloads, Images, Videos, Audio, Docs, Apps }

enum class HomeTab { All, Favorites, Private }

enum class SortField(val defaultAscending: Boolean) {
    Modified(false),
    Name(true),
    Size(false),
    Type(true),
}

data class SortSpec(val field: SortField = SortField.Modified, val ascending: Boolean = false) {
    /** Tapping the active field flips the direction. Tapping another field uses that field's default. */
    fun select(newField: SortField): SortSpec =
        if (newField == field) copy(ascending = !ascending) else SortSpec(newField, newField.defaultAscending)
}

fun List<FileItem>.sortedBySpec(spec: SortSpec): List<FileItem> {
    val comparator: Comparator<FileItem> = when (spec.field) {
        SortField.Modified -> compareBy<FileItem> { it.modifiedMillis }
        SortField.Name -> Comparator { a, b -> String.CASE_INSENSITIVE_ORDER.compare(a.name, b.name) }
        SortField.Size -> compareBy<FileItem> { it.sizeBytes }
        SortField.Type -> compareBy<FileItem> { it.kind.ordinal }.thenBy { it.extension }
    }
    return sortedWith(if (spec.ascending) comparator else comparator.reversed())
}
