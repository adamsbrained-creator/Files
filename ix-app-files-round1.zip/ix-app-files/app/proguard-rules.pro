# R8 rules for ix.app.files.
# Compose, AndroidX and lifecycle ship their own consumer rules, so nothing extra is needed yet.
# Add keep rules here only when a library that uses reflection is introduced.

# Keep readable stack traces. Upload mapping.txt (the workflow does) to de-obfuscate them.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
